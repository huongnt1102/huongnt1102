﻿namespace BuildingDesignTemplate
{
    partial class FrmShow
	{
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmShow));
			DevExpress.Utils.SuperToolTip superToolTip1 = new DevExpress.Utils.SuperToolTip();
			DevExpress.Utils.ToolTipTitleItem toolTipTitleItem1 = new DevExpress.Utils.ToolTipTitleItem();
			DevExpress.Utils.ToolTipItem toolTipItem1 = new DevExpress.Utils.ToolTipItem();
			DevExpress.Utils.SuperToolTip superToolTip2 = new DevExpress.Utils.SuperToolTip();
			DevExpress.Utils.ToolTipTitleItem toolTipTitleItem2 = new DevExpress.Utils.ToolTipTitleItem();
			DevExpress.Utils.ToolTipItem toolTipItem2 = new DevExpress.Utils.ToolTipItem();
			DevExpress.Utils.SuperToolTip superToolTip3 = new DevExpress.Utils.SuperToolTip();
			DevExpress.Utils.ToolTipTitleItem toolTipTitleItem3 = new DevExpress.Utils.ToolTipTitleItem();
			DevExpress.Utils.ToolTipItem toolTipItem3 = new DevExpress.Utils.ToolTipItem();
			DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup1 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
			this.txtContent = new DevExpress.XtraRichEdit.RichEditControl();
			this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
			this.popupMenu1 = new DevExpress.XtraBars.PopupMenu(this.components);
			this.cutItem1 = new DevExpress.XtraRichEdit.UI.CutItem();
			this.copyItem1 = new DevExpress.XtraRichEdit.UI.CopyItem();
			this.pasteItem1 = new DevExpress.XtraRichEdit.UI.PasteItem();
			this.itemField = new DevExpress.XtraBars.BarButtonItem();
			this.changeFontNameItem1 = new DevExpress.XtraRichEdit.UI.ChangeFontNameItem();
			this.repositoryItemFontEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemFontEdit();
			this.changeFontSizeItem1 = new DevExpress.XtraRichEdit.UI.ChangeFontSizeItem();
			this.repositoryItemRichEditFontSizeEdit1 = new DevExpress.XtraRichEdit.Design.RepositoryItemRichEditFontSizeEdit();
			this.changeFontColorItem1 = new DevExpress.XtraRichEdit.UI.ChangeFontColorItem();
			this.changeFontBackColorItem1 = new DevExpress.XtraRichEdit.UI.ChangeFontBackColorItem();
			this.toggleFontBoldItem1 = new DevExpress.XtraRichEdit.UI.ToggleFontBoldItem();
			this.toggleFontItalicItem1 = new DevExpress.XtraRichEdit.UI.ToggleFontItalicItem();
			this.toggleFontUnderlineItem1 = new DevExpress.XtraRichEdit.UI.ToggleFontUnderlineItem();
			this.toggleFontDoubleUnderlineItem1 = new DevExpress.XtraRichEdit.UI.ToggleFontDoubleUnderlineItem();
			this.toggleFontStrikeoutItem1 = new DevExpress.XtraRichEdit.UI.ToggleFontStrikeoutItem();
			this.toggleFontDoubleStrikeoutItem1 = new DevExpress.XtraRichEdit.UI.ToggleFontDoubleStrikeoutItem();
			this.toggleFontSuperscriptItem1 = new DevExpress.XtraRichEdit.UI.ToggleFontSuperscriptItem();
			this.toggleFontSubscriptItem1 = new DevExpress.XtraRichEdit.UI.ToggleFontSubscriptItem();
			this.fontSizeIncreaseItem1 = new DevExpress.XtraRichEdit.UI.FontSizeIncreaseItem();
			this.fontSizeDecreaseItem1 = new DevExpress.XtraRichEdit.UI.FontSizeDecreaseItem();
			this.showFontFormItem1 = new DevExpress.XtraRichEdit.UI.ShowFontFormItem();
			this.fileNewItem1 = new DevExpress.XtraRichEdit.UI.FileNewItem();
			this.fileOpenItem1 = new DevExpress.XtraRichEdit.UI.FileOpenItem();
			this.fileSaveAsItem1 = new DevExpress.XtraRichEdit.UI.FileSaveAsItem();
			this.quickPrintItem1 = new DevExpress.XtraRichEdit.UI.QuickPrintItem();
			this.printItem1 = new DevExpress.XtraRichEdit.UI.PrintItem();
			this.printPreviewItem1 = new DevExpress.XtraRichEdit.UI.PrintPreviewItem();
			this.undoItem1 = new DevExpress.XtraRichEdit.UI.UndoItem();
			this.redoItem1 = new DevExpress.XtraRichEdit.UI.RedoItem();
			this.changeStyleItem1 = new DevExpress.XtraRichEdit.UI.ChangeStyleItem();
			this.repositoryItemRichEditStyleEdit1 = new DevExpress.XtraRichEdit.Design.RepositoryItemRichEditStyleEdit();
			this.toggleParagraphAlignmentLeftItem1 = new DevExpress.XtraRichEdit.UI.ToggleParagraphAlignmentLeftItem();
			this.toggleParagraphAlignmentCenterItem1 = new DevExpress.XtraRichEdit.UI.ToggleParagraphAlignmentCenterItem();
			this.toggleParagraphAlignmentRightItem1 = new DevExpress.XtraRichEdit.UI.ToggleParagraphAlignmentRightItem();
			this.toggleParagraphAlignmentJustifyItem1 = new DevExpress.XtraRichEdit.UI.ToggleParagraphAlignmentJustifyItem();
			this.toggleNumberingListItem1 = new DevExpress.XtraRichEdit.UI.ToggleNumberingListItem();
			this.toggleBulletedListItem1 = new DevExpress.XtraRichEdit.UI.ToggleBulletedListItem();
			this.toggleMultiLevelListItem1 = new DevExpress.XtraRichEdit.UI.ToggleMultiLevelListItem();
			this.decreaseIndentItem1 = new DevExpress.XtraRichEdit.UI.DecreaseIndentItem();
			this.increaseIndentItem1 = new DevExpress.XtraRichEdit.UI.IncreaseIndentItem();
			this.toggleShowWhitespaceItem1 = new DevExpress.XtraRichEdit.UI.ToggleShowWhitespaceItem();
			this.showParagraphFormItem1 = new DevExpress.XtraRichEdit.UI.ShowParagraphFormItem();
			this.insertPictureItem1 = new DevExpress.XtraRichEdit.UI.InsertPictureItem();
			this.insertHyperlinkItem1 = new DevExpress.XtraRichEdit.UI.InsertHyperlinkItem();
			this.zoomOutItem1 = new DevExpress.XtraRichEdit.UI.ZoomOutItem();
			this.zoomInItem1 = new DevExpress.XtraRichEdit.UI.ZoomInItem();
			this.switchToSimpleViewItem1 = new DevExpress.XtraRichEdit.UI.SwitchToSimpleViewItem();
			this.switchToDraftViewItem1 = new DevExpress.XtraRichEdit.UI.SwitchToDraftViewItem();
			this.switchToPrintLayoutViewItem1 = new DevExpress.XtraRichEdit.UI.SwitchToPrintLayoutViewItem();
			this.findItem1 = new DevExpress.XtraRichEdit.UI.FindItem();
			this.replaceItem1 = new DevExpress.XtraRichEdit.UI.ReplaceItem();
			this.insertSymbolItem1 = new DevExpress.XtraRichEdit.UI.InsertSymbolItem();
			this.itemLuu = new DevExpress.XtraBars.BarButtonItem();
			this.itemDong = new DevExpress.XtraBars.BarButtonItem();
			this.barSubItem1 = new DevExpress.XtraBars.BarSubItem();
			this.barMdiChildrenListItem1 = new DevExpress.XtraBars.BarMdiChildrenListItem();
			this.fileSaveItem1 = new DevExpress.XtraRichEdit.UI.FileSaveItem();
			this.barSubItem2 = new DevExpress.XtraBars.BarSubItem();
			this.itemCopy = new DevExpress.XtraBars.BarButtonItem();
			this.itemCut = new DevExpress.XtraBars.BarButtonItem();
			this.itemPaste = new DevExpress.XtraBars.BarButtonItem();
			this.changeTableCellsShadingItem1 = new DevExpress.XtraRichEdit.UI.ChangeTableCellsShadingItem();
			this.changeTableBordersItem1 = new DevExpress.XtraRichEdit.UI.ChangeTableBordersItem();
			this.toggleTableCellsBottomBorderItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsBottomBorderItem();
			this.toggleTableCellsTopBorderItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsTopBorderItem();
			this.toggleTableCellsLeftBorderItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsLeftBorderItem();
			this.toggleTableCellsRightBorderItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsRightBorderItem();
			this.resetTableCellsAllBordersItem1 = new DevExpress.XtraRichEdit.UI.ResetTableCellsAllBordersItem();
			this.toggleTableCellsAllBordersItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsAllBordersItem();
			this.toggleTableCellsOutsideBorderItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsOutsideBorderItem();
			this.toggleTableCellsInsideBorderItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsInsideBorderItem();
			this.toggleTableCellsInsideHorizontalBorderItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsInsideHorizontalBorderItem();
			this.toggleTableCellsInsideVerticalBorderItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsInsideVerticalBorderItem();
			this.toggleShowTableGridLinesItem1 = new DevExpress.XtraRichEdit.UI.ToggleShowTableGridLinesItem();
			this.changeTableBorderLineStyleItem1 = new DevExpress.XtraRichEdit.UI.ChangeTableBorderLineStyleItem();
			this.repositoryItemBorderLineStyle1 = new DevExpress.XtraRichEdit.Forms.Design.RepositoryItemBorderLineStyle();
			this.changeTableBorderLineWeightItem1 = new DevExpress.XtraRichEdit.UI.ChangeTableBorderLineWeightItem();
			this.repositoryItemBorderLineWeight1 = new DevExpress.XtraRichEdit.Forms.Design.RepositoryItemBorderLineWeight();
			this.changeTableBorderColorItem1 = new DevExpress.XtraRichEdit.UI.ChangeTableBorderColorItem();
			this.selectTableElementsItem1 = new DevExpress.XtraRichEdit.UI.SelectTableElementsItem();
			this.selectTableCellItem1 = new DevExpress.XtraRichEdit.UI.SelectTableCellItem();
			this.selectTableColumnItem1 = new DevExpress.XtraRichEdit.UI.SelectTableColumnItem();
			this.selectTableRowItem1 = new DevExpress.XtraRichEdit.UI.SelectTableRowItem();
			this.selectTableItem1 = new DevExpress.XtraRichEdit.UI.SelectTableItem();
			this.deleteTableElementsItem1 = new DevExpress.XtraRichEdit.UI.DeleteTableElementsItem();
			this.showDeleteTableCellsFormItem1 = new DevExpress.XtraRichEdit.UI.ShowDeleteTableCellsFormItem();
			this.deleteTableColumnsItem1 = new DevExpress.XtraRichEdit.UI.DeleteTableColumnsItem();
			this.deleteTableRowsItem1 = new DevExpress.XtraRichEdit.UI.DeleteTableRowsItem();
			this.deleteTableItem1 = new DevExpress.XtraRichEdit.UI.DeleteTableItem();
			this.insertTableRowAboveItem1 = new DevExpress.XtraRichEdit.UI.InsertTableRowAboveItem();
			this.insertTableRowBelowItem1 = new DevExpress.XtraRichEdit.UI.InsertTableRowBelowItem();
			this.insertTableColumnToLeftItem1 = new DevExpress.XtraRichEdit.UI.InsertTableColumnToLeftItem();
			this.insertTableColumnToRightItem1 = new DevExpress.XtraRichEdit.UI.InsertTableColumnToRightItem();
			this.showInsertTableCellsFormItem1 = new DevExpress.XtraRichEdit.UI.ShowInsertTableCellsFormItem();
			this.mergeTableCellsItem1 = new DevExpress.XtraRichEdit.UI.MergeTableCellsItem();
			this.showSplitTableCellsForm1 = new DevExpress.XtraRichEdit.UI.ShowSplitTableCellsForm();
			this.splitTableItem1 = new DevExpress.XtraRichEdit.UI.SplitTableItem();
			this.toggleTableCellsTopLeftAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsTopLeftAlignmentItem();
			this.toggleTableCellsTopCenterAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsTopCenterAlignmentItem();
			this.toggleTableCellsTopRightAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsTopRightAlignmentItem();
			this.toggleTableCellsMiddleLeftAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsMiddleLeftAlignmentItem();
			this.toggleTableCellsMiddleCenterAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsMiddleCenterAlignmentItem();
			this.toggleTableCellsMiddleRightAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsMiddleRightAlignmentItem();
			this.toggleTableCellsBottomLeftAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsBottomLeftAlignmentItem();
			this.toggleTableCellsBottomCenterAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsBottomCenterAlignmentItem();
			this.toggleTableCellsBottomRightAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableCellsBottomRightAlignmentItem();
			this.insertPageBreakItem1 = new DevExpress.XtraRichEdit.UI.InsertPageBreakItem();
			this.insertTableItem1 = new DevExpress.XtraRichEdit.UI.InsertTableItem();
			this.insertBookmarkItem1 = new DevExpress.XtraRichEdit.UI.InsertBookmarkItem();
			this.editPageHeaderItem1 = new DevExpress.XtraRichEdit.UI.EditPageHeaderItem();
			this.editPageFooterItem1 = new DevExpress.XtraRichEdit.UI.EditPageFooterItem();
			this.insertPageNumberItem1 = new DevExpress.XtraRichEdit.UI.InsertPageNumberItem();
			this.insertPageCountItem1 = new DevExpress.XtraRichEdit.UI.InsertPageCountItem();
			this.changeTextCaseItem1 = new DevExpress.XtraRichEdit.UI.ChangeTextCaseItem();
			this.makeTextUpperCaseItem1 = new DevExpress.XtraRichEdit.UI.MakeTextUpperCaseItem();
			this.makeTextLowerCaseItem1 = new DevExpress.XtraRichEdit.UI.MakeTextLowerCaseItem();
			this.toggleTextCaseItem1 = new DevExpress.XtraRichEdit.UI.ToggleTextCaseItem();
			this.clearFormattingItem1 = new DevExpress.XtraRichEdit.UI.ClearFormattingItem();
			this.changeParagraphLineSpacingItem1 = new DevExpress.XtraRichEdit.UI.ChangeParagraphLineSpacingItem();
			this.setSingleParagraphSpacingItem1 = new DevExpress.XtraRichEdit.UI.SetSingleParagraphSpacingItem();
			this.setSesquialteralParagraphSpacingItem1 = new DevExpress.XtraRichEdit.UI.SetSesquialteralParagraphSpacingItem();
			this.setDoubleParagraphSpacingItem1 = new DevExpress.XtraRichEdit.UI.SetDoubleParagraphSpacingItem();
			this.showLineSpacingFormItem1 = new DevExpress.XtraRichEdit.UI.ShowLineSpacingFormItem();
			this.addSpacingBeforeParagraphItem1 = new DevExpress.XtraRichEdit.UI.AddSpacingBeforeParagraphItem();
			this.removeSpacingBeforeParagraphItem1 = new DevExpress.XtraRichEdit.UI.RemoveSpacingBeforeParagraphItem();
			this.addSpacingAfterParagraphItem1 = new DevExpress.XtraRichEdit.UI.AddSpacingAfterParagraphItem();
			this.removeSpacingAfterParagraphItem1 = new DevExpress.XtraRichEdit.UI.RemoveSpacingAfterParagraphItem();
			this.pasteSpecialItem1 = new DevExpress.XtraRichEdit.UI.PasteSpecialItem();
			this.barButtonGroup1 = new DevExpress.XtraBars.BarButtonGroup();
			this.barButtonGroup2 = new DevExpress.XtraBars.BarButtonGroup();
			this.barButtonGroup3 = new DevExpress.XtraBars.BarButtonGroup();
			this.barButtonGroup4 = new DevExpress.XtraBars.BarButtonGroup();
			this.barButtonGroup5 = new DevExpress.XtraBars.BarButtonGroup();
			this.barButtonGroup6 = new DevExpress.XtraBars.BarButtonGroup();
			this.barButtonGroup7 = new DevExpress.XtraBars.BarButtonGroup();
			this.changeParagraphBackColorItem1 = new DevExpress.XtraRichEdit.UI.ChangeParagraphBackColorItem();
			this.galleryChangeStyleItem1 = new DevExpress.XtraRichEdit.UI.GalleryChangeStyleItem();
			this.insertFloatingPictureItem1 = new DevExpress.XtraRichEdit.UI.InsertFloatingPictureItem();
			this.insertTextBoxItem1 = new DevExpress.XtraRichEdit.UI.InsertTextBoxItem();
			this.changeSectionPageMarginsItem1 = new DevExpress.XtraRichEdit.UI.ChangeSectionPageMarginsItem();
			this.setNormalSectionPageMarginsItem1 = new DevExpress.XtraRichEdit.UI.SetNormalSectionPageMarginsItem();
			this.setNarrowSectionPageMarginsItem1 = new DevExpress.XtraRichEdit.UI.SetNarrowSectionPageMarginsItem();
			this.setModerateSectionPageMarginsItem1 = new DevExpress.XtraRichEdit.UI.SetModerateSectionPageMarginsItem();
			this.setWideSectionPageMarginsItem1 = new DevExpress.XtraRichEdit.UI.SetWideSectionPageMarginsItem();
			this.showPageMarginsSetupFormItem1 = new DevExpress.XtraRichEdit.UI.ShowPageMarginsSetupFormItem();
			this.changeSectionPageOrientationItem1 = new DevExpress.XtraRichEdit.UI.ChangeSectionPageOrientationItem();
			this.setPortraitPageOrientationItem1 = new DevExpress.XtraRichEdit.UI.SetPortraitPageOrientationItem();
			this.setLandscapePageOrientationItem1 = new DevExpress.XtraRichEdit.UI.SetLandscapePageOrientationItem();
			this.changeSectionPaperKindItem1 = new DevExpress.XtraRichEdit.UI.ChangeSectionPaperKindItem();
			this.changeSectionColumnsItem1 = new DevExpress.XtraRichEdit.UI.ChangeSectionColumnsItem();
			this.setSectionOneColumnItem1 = new DevExpress.XtraRichEdit.UI.SetSectionOneColumnItem();
			this.setSectionTwoColumnsItem1 = new DevExpress.XtraRichEdit.UI.SetSectionTwoColumnsItem();
			this.setSectionThreeColumnsItem1 = new DevExpress.XtraRichEdit.UI.SetSectionThreeColumnsItem();
			this.showColumnsSetupFormItem1 = new DevExpress.XtraRichEdit.UI.ShowColumnsSetupFormItem();
			this.insertBreakItem1 = new DevExpress.XtraRichEdit.UI.InsertBreakItem();
			this.insertColumnBreakItem1 = new DevExpress.XtraRichEdit.UI.InsertColumnBreakItem();
			this.insertSectionBreakNextPageItem1 = new DevExpress.XtraRichEdit.UI.InsertSectionBreakNextPageItem();
			this.insertSectionBreakEvenPageItem1 = new DevExpress.XtraRichEdit.UI.InsertSectionBreakEvenPageItem();
			this.insertSectionBreakOddPageItem1 = new DevExpress.XtraRichEdit.UI.InsertSectionBreakOddPageItem();
			this.changeSectionLineNumberingItem1 = new DevExpress.XtraRichEdit.UI.ChangeSectionLineNumberingItem();
			this.setSectionLineNumberingNoneItem1 = new DevExpress.XtraRichEdit.UI.SetSectionLineNumberingNoneItem();
			this.setSectionLineNumberingContinuousItem1 = new DevExpress.XtraRichEdit.UI.SetSectionLineNumberingContinuousItem();
			this.setSectionLineNumberingRestartNewPageItem1 = new DevExpress.XtraRichEdit.UI.SetSectionLineNumberingRestartNewPageItem();
			this.setSectionLineNumberingRestartNewSectionItem1 = new DevExpress.XtraRichEdit.UI.SetSectionLineNumberingRestartNewSectionItem();
			this.toggleParagraphSuppressLineNumbersItem1 = new DevExpress.XtraRichEdit.UI.ToggleParagraphSuppressLineNumbersItem();
			this.showLineNumberingFormItem1 = new DevExpress.XtraRichEdit.UI.ShowLineNumberingFormItem();
			this.changePageColorItem1 = new DevExpress.XtraRichEdit.UI.ChangePageColorItem();
			this.insertTableOfContentsItem1 = new DevExpress.XtraRichEdit.UI.InsertTableOfContentsItem();
			this.updateTableOfContentsItem1 = new DevExpress.XtraRichEdit.UI.UpdateTableOfContentsItem();
			this.addParagraphsToTableOfContentItem1 = new DevExpress.XtraRichEdit.UI.AddParagraphsToTableOfContentItem();
			this.setParagraphHeadingLevelItem1 = new DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem();
			this.setParagraphHeadingLevelItem2 = new DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem();
			this.setParagraphHeadingLevelItem3 = new DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem();
			this.setParagraphHeadingLevelItem4 = new DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem();
			this.setParagraphHeadingLevelItem5 = new DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem();
			this.setParagraphHeadingLevelItem6 = new DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem();
			this.setParagraphHeadingLevelItem7 = new DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem();
			this.setParagraphHeadingLevelItem8 = new DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem();
			this.setParagraphHeadingLevelItem9 = new DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem();
			this.setParagraphHeadingLevelItem10 = new DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem();
			this.insertCaptionPlaceholderItem1 = new DevExpress.XtraRichEdit.UI.InsertCaptionPlaceholderItem();
			this.insertFiguresCaptionItems1 = new DevExpress.XtraRichEdit.UI.InsertFiguresCaptionItems();
			this.insertTablesCaptionItems1 = new DevExpress.XtraRichEdit.UI.InsertTablesCaptionItems();
			this.insertEquationsCaptionItems1 = new DevExpress.XtraRichEdit.UI.InsertEquationsCaptionItems();
			this.insertTableOfFiguresPlaceholderItem1 = new DevExpress.XtraRichEdit.UI.InsertTableOfFiguresPlaceholderItem();
			this.insertTableOfFiguresItems1 = new DevExpress.XtraRichEdit.UI.InsertTableOfFiguresItems();
			this.insertTableOfTablesItems1 = new DevExpress.XtraRichEdit.UI.InsertTableOfTablesItems();
			this.insertTableOfEquationsItems1 = new DevExpress.XtraRichEdit.UI.InsertTableOfEquationsItems();
			this.insertMergeFieldItem1 = new DevExpress.XtraRichEdit.UI.InsertMergeFieldItem();
			this.showAllFieldCodesItem1 = new DevExpress.XtraRichEdit.UI.ShowAllFieldCodesItem();
			this.showAllFieldResultsItem1 = new DevExpress.XtraRichEdit.UI.ShowAllFieldResultsItem();
			this.toggleViewMergedDataItem1 = new DevExpress.XtraRichEdit.UI.ToggleViewMergedDataItem();
			this.checkSpellingItem1 = new DevExpress.XtraRichEdit.UI.CheckSpellingItem();
			this.protectDocumentItem1 = new DevExpress.XtraRichEdit.UI.ProtectDocumentItem();
			this.changeRangeEditingPermissionsItem1 = new DevExpress.XtraRichEdit.UI.ChangeRangeEditingPermissionsItem();
			this.unprotectDocumentItem1 = new DevExpress.XtraRichEdit.UI.UnprotectDocumentItem();
			this.toggleShowHorizontalRulerItem1 = new DevExpress.XtraRichEdit.UI.ToggleShowHorizontalRulerItem();
			this.toggleShowVerticalRulerItem1 = new DevExpress.XtraRichEdit.UI.ToggleShowVerticalRulerItem();
			this.goToPageHeaderItem1 = new DevExpress.XtraRichEdit.UI.GoToPageHeaderItem();
			this.goToPageFooterItem1 = new DevExpress.XtraRichEdit.UI.GoToPageFooterItem();
			this.goToNextHeaderFooterItem1 = new DevExpress.XtraRichEdit.UI.GoToNextHeaderFooterItem();
			this.goToPreviousHeaderFooterItem1 = new DevExpress.XtraRichEdit.UI.GoToPreviousHeaderFooterItem();
			this.toggleLinkToPreviousItem1 = new DevExpress.XtraRichEdit.UI.ToggleLinkToPreviousItem();
			this.toggleDifferentFirstPageItem1 = new DevExpress.XtraRichEdit.UI.ToggleDifferentFirstPageItem();
			this.toggleDifferentOddAndEvenPagesItem1 = new DevExpress.XtraRichEdit.UI.ToggleDifferentOddAndEvenPagesItem();
			this.closePageHeaderFooterItem1 = new DevExpress.XtraRichEdit.UI.ClosePageHeaderFooterItem();
			this.showTablePropertiesFormItem1 = new DevExpress.XtraRichEdit.UI.ShowTablePropertiesFormItem();
			this.toggleTableAutoFitItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableAutoFitItem();
			this.toggleTableAutoFitContentsItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableAutoFitContentsItem();
			this.toggleTableAutoFitWindowItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableAutoFitWindowItem();
			this.toggleTableFixedColumnWidthItem1 = new DevExpress.XtraRichEdit.UI.ToggleTableFixedColumnWidthItem();
			this.showTableOptionsFormItem1 = new DevExpress.XtraRichEdit.UI.ShowTableOptionsFormItem();
			this.changeFloatingObjectFillColorItem1 = new DevExpress.XtraRichEdit.UI.ChangeFloatingObjectFillColorItem();
			this.changeFloatingObjectOutlineColorItem1 = new DevExpress.XtraRichEdit.UI.ChangeFloatingObjectOutlineColorItem();
			this.changeFloatingObjectOutlineWeightItem1 = new DevExpress.XtraRichEdit.UI.ChangeFloatingObjectOutlineWeightItem();
			this.repositoryItemFloatingObjectOutlineWeight1 = new DevExpress.XtraRichEdit.Forms.Design.RepositoryItemFloatingObjectOutlineWeight();
			this.changeFloatingObjectTextWrapTypeItem1 = new DevExpress.XtraRichEdit.UI.ChangeFloatingObjectTextWrapTypeItem();
			this.setFloatingObjectSquareTextWrapTypeItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectSquareTextWrapTypeItem();
			this.setFloatingObjectTightTextWrapTypeItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectTightTextWrapTypeItem();
			this.setFloatingObjectThroughTextWrapTypeItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectThroughTextWrapTypeItem();
			this.setFloatingObjectTopAndBottomTextWrapTypeItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectTopAndBottomTextWrapTypeItem();
			this.setFloatingObjectBehindTextWrapTypeItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectBehindTextWrapTypeItem();
			this.setFloatingObjectInFrontOfTextWrapTypeItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectInFrontOfTextWrapTypeItem();
			this.changeFloatingObjectAlignmentItem1 = new DevExpress.XtraRichEdit.UI.ChangeFloatingObjectAlignmentItem();
			this.setFloatingObjectTopLeftAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectTopLeftAlignmentItem();
			this.setFloatingObjectTopCenterAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectTopCenterAlignmentItem();
			this.setFloatingObjectTopRightAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectTopRightAlignmentItem();
			this.setFloatingObjectMiddleLeftAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectMiddleLeftAlignmentItem();
			this.setFloatingObjectMiddleCenterAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectMiddleCenterAlignmentItem();
			this.setFloatingObjectMiddleRightAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectMiddleRightAlignmentItem();
			this.setFloatingObjectBottomLeftAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectBottomLeftAlignmentItem();
			this.setFloatingObjectBottomCenterAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectBottomCenterAlignmentItem();
			this.setFloatingObjectBottomRightAlignmentItem1 = new DevExpress.XtraRichEdit.UI.SetFloatingObjectBottomRightAlignmentItem();
			this.floatingObjectBringForwardSubItem1 = new DevExpress.XtraRichEdit.UI.FloatingObjectBringForwardSubItem();
			this.floatingObjectBringForwardItem1 = new DevExpress.XtraRichEdit.UI.FloatingObjectBringForwardItem();
			this.floatingObjectBringToFrontItem1 = new DevExpress.XtraRichEdit.UI.FloatingObjectBringToFrontItem();
			this.floatingObjectBringInFrontOfTextItem1 = new DevExpress.XtraRichEdit.UI.FloatingObjectBringInFrontOfTextItem();
			this.floatingObjectSendBackwardSubItem1 = new DevExpress.XtraRichEdit.UI.FloatingObjectSendBackwardSubItem();
			this.floatingObjectSendBackwardItem1 = new DevExpress.XtraRichEdit.UI.FloatingObjectSendBackwardItem();
			this.floatingObjectSendToBackItem1 = new DevExpress.XtraRichEdit.UI.FloatingObjectSendToBackItem();
			this.floatingObjectSendBehindTextItem1 = new DevExpress.XtraRichEdit.UI.FloatingObjectSendBehindTextItem();
			this.itemSave = new DevExpress.XtraBars.BarButtonItem();
			this.headerFooterToolsRibbonPageCategory1 = new DevExpress.XtraRichEdit.UI.HeaderFooterToolsRibbonPageCategory();
			this.headerFooterToolsDesignRibbonPage1 = new DevExpress.XtraRichEdit.UI.HeaderFooterToolsDesignRibbonPage();
			this.headerFooterToolsDesignNavigationRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.HeaderFooterToolsDesignNavigationRibbonPageGroup();
			this.headerFooterToolsDesignOptionsRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.HeaderFooterToolsDesignOptionsRibbonPageGroup();
			this.headerFooterToolsDesignCloseRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.HeaderFooterToolsDesignCloseRibbonPageGroup();
			this.tableToolsRibbonPageCategory1 = new DevExpress.XtraRichEdit.UI.TableToolsRibbonPageCategory();
			this.tableDesignRibbonPage1 = new DevExpress.XtraRichEdit.UI.TableDesignRibbonPage();
			this.tableStylesRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TableStylesRibbonPageGroup();
			this.tableDrawBordersRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TableDrawBordersRibbonPageGroup();
			this.tableLayoutRibbonPage1 = new DevExpress.XtraRichEdit.UI.TableLayoutRibbonPage();
			this.tableTableRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TableTableRibbonPageGroup();
			this.tableRowsAndColumnsRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TableRowsAndColumnsRibbonPageGroup();
			this.tableMergeRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TableMergeRibbonPageGroup();
			this.tableCellSizeRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TableCellSizeRibbonPageGroup();
			this.tableAlignmentRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TableAlignmentRibbonPageGroup();
			this.floatingPictureToolsRibbonPageCategory1 = new DevExpress.XtraRichEdit.UI.FloatingPictureToolsRibbonPageCategory();
			this.floatingPictureToolsFormatPage1 = new DevExpress.XtraRichEdit.UI.FloatingPictureToolsFormatPage();
			this.floatingPictureToolsShapeStylesPageGroup1 = new DevExpress.XtraRichEdit.UI.FloatingPictureToolsShapeStylesPageGroup();
			this.floatingPictureToolsArrangePageGroup1 = new DevExpress.XtraRichEdit.UI.FloatingPictureToolsArrangePageGroup();
			this.fileRibbonPage1 = new DevExpress.XtraRichEdit.UI.FileRibbonPage();
			this.commonRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.CommonRibbonPageGroup();
			this.homeRibbonPage1 = new DevExpress.XtraRichEdit.UI.HomeRibbonPage();
			this.clipboardRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.ClipboardRibbonPageGroup();
			this.fontRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.FontRibbonPageGroup();
			this.paragraphRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.ParagraphRibbonPageGroup();
			this.stylesRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.StylesRibbonPageGroup();
			this.editingRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.EditingRibbonPageGroup();
			this.insertRibbonPage1 = new DevExpress.XtraRichEdit.UI.InsertRibbonPage();
			this.pagesRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.PagesRibbonPageGroup();
			this.tablesRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TablesRibbonPageGroup();
			this.illustrationsRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.IllustrationsRibbonPageGroup();
			this.linksRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.LinksRibbonPageGroup();
			this.headerFooterRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.HeaderFooterRibbonPageGroup();
			this.textRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TextRibbonPageGroup();
			this.symbolsRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.SymbolsRibbonPageGroup();
			this.pageLayoutRibbonPage1 = new DevExpress.XtraRichEdit.UI.PageLayoutRibbonPage();
			this.pageSetupRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.PageSetupRibbonPageGroup();
			this.pageBackgroundRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.PageBackgroundRibbonPageGroup();
			this.referencesRibbonPage1 = new DevExpress.XtraRichEdit.UI.ReferencesRibbonPage();
			this.tableOfContentsRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.TableOfContentsRibbonPageGroup();
			this.captionsRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.CaptionsRibbonPageGroup();
			this.mailingsRibbonPage1 = new DevExpress.XtraRichEdit.UI.MailingsRibbonPage();
			this.mailMergeRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.MailMergeRibbonPageGroup();
			this.reviewRibbonPage1 = new DevExpress.XtraRichEdit.UI.ReviewRibbonPage();
			this.documentProofingRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.DocumentProofingRibbonPageGroup();
			this.documentProtectionRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.DocumentProtectionRibbonPageGroup();
			this.viewRibbonPage1 = new DevExpress.XtraRichEdit.UI.ViewRibbonPage();
			this.documentViewsRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.DocumentViewsRibbonPageGroup();
			this.showRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.ShowRibbonPageGroup();
			this.zoomRibbonPageGroup1 = new DevExpress.XtraRichEdit.UI.ZoomRibbonPageGroup();
			this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
			this.richEditBarController1 = new DevExpress.XtraRichEdit.UI.RichEditBarController(this.components);
			this.insertPageBreakItem2 = new DevExpress.XtraRichEdit.UI.InsertPageBreakItem();
			this.backstageViewControl1 = new DevExpress.XtraBars.Ribbon.BackstageViewControl();
			this.backstageViewClientControl1 = new DevExpress.XtraBars.Ribbon.BackstageViewClientControl();
			this.backstageViewTabItem1 = new DevExpress.XtraBars.Ribbon.BackstageViewTabItem();
			this.backstageViewControl2 = new DevExpress.XtraBars.Ribbon.BackstageViewControl();
			this.backstageViewClientControl2 = new DevExpress.XtraBars.Ribbon.BackstageViewClientControl();
			this.backstageViewTabItem2 = new DevExpress.XtraBars.Ribbon.BackstageViewTabItem();
			this.backstageViewControl3 = new DevExpress.XtraBars.Ribbon.BackstageViewControl();
			this.backstageViewClientControl3 = new DevExpress.XtraBars.Ribbon.BackstageViewClientControl();
			this.backstageViewTabItem3 = new DevExpress.XtraBars.Ribbon.BackstageViewTabItem();
			this.backstageViewControl4 = new DevExpress.XtraBars.Ribbon.BackstageViewControl();
			this.backstageViewClientControl4 = new DevExpress.XtraBars.Ribbon.BackstageViewClientControl();
			this.backstageViewTabItem4 = new DevExpress.XtraBars.Ribbon.BackstageViewTabItem();
			this.backstageViewControl5 = new DevExpress.XtraBars.Ribbon.BackstageViewControl();
			this.backstageViewClientControl5 = new DevExpress.XtraBars.Ribbon.BackstageViewClientControl();
			this.backstageViewTabItem5 = new DevExpress.XtraBars.Ribbon.BackstageViewTabItem();
			((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.repositoryItemFontEdit1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.repositoryItemRichEditFontSizeEdit1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.repositoryItemRichEditStyleEdit1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.repositoryItemBorderLineStyle1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.repositoryItemBorderLineWeight1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.repositoryItemFloatingObjectOutlineWeight1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.richEditBarController1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.backstageViewControl1)).BeginInit();
			this.backstageViewControl1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.backstageViewControl2)).BeginInit();
			this.backstageViewControl2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.backstageViewControl3)).BeginInit();
			this.backstageViewControl3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.backstageViewControl4)).BeginInit();
			this.backstageViewControl4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.backstageViewControl5)).BeginInit();
			this.backstageViewControl5.SuspendLayout();
			this.SuspendLayout();
			// 
			// txtContent
			// 
			this.txtContent.Dock = System.Windows.Forms.DockStyle.Fill;
			this.txtContent.Location = new System.Drawing.Point(0, 143);
			this.txtContent.MenuManager = this.ribbonControl1;
			this.txtContent.Name = "txtContent";
			this.ribbonControl1.SetPopupContextMenu(this.txtContent, this.popupMenu1);
			this.txtContent.Size = new System.Drawing.Size(1027, 467);
			this.txtContent.TabIndex = 0;
			// 
			// ribbonControl1
			// 
			this.ribbonControl1.ApplicationButtonDropDownControl = this.backstageViewControl5;
			this.ribbonControl1.ExpandCollapseItem.Id = 0;
			this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.cutItem1,
            this.copyItem1,
            this.pasteItem1,
            this.changeFontNameItem1,
            this.changeFontSizeItem1,
            this.changeFontColorItem1,
            this.changeFontBackColorItem1,
            this.toggleFontBoldItem1,
            this.toggleFontItalicItem1,
            this.toggleFontUnderlineItem1,
            this.toggleFontDoubleUnderlineItem1,
            this.toggleFontStrikeoutItem1,
            this.toggleFontDoubleStrikeoutItem1,
            this.toggleFontSuperscriptItem1,
            this.toggleFontSubscriptItem1,
            this.fontSizeIncreaseItem1,
            this.fontSizeDecreaseItem1,
            this.fileNewItem1,
            this.fileOpenItem1,
            this.fileSaveAsItem1,
            this.quickPrintItem1,
            this.printItem1,
            this.printPreviewItem1,
            this.undoItem1,
            this.redoItem1,
            this.toggleParagraphAlignmentLeftItem1,
            this.toggleParagraphAlignmentCenterItem1,
            this.toggleParagraphAlignmentRightItem1,
            this.toggleParagraphAlignmentJustifyItem1,
            this.toggleNumberingListItem1,
            this.toggleBulletedListItem1,
            this.toggleMultiLevelListItem1,
            this.decreaseIndentItem1,
            this.increaseIndentItem1,
            this.toggleShowWhitespaceItem1,
            this.insertPictureItem1,
            this.insertHyperlinkItem1,
            this.zoomOutItem1,
            this.zoomInItem1,
            this.switchToSimpleViewItem1,
            this.switchToDraftViewItem1,
            this.switchToPrintLayoutViewItem1,
            this.findItem1,
            this.replaceItem1,
            this.insertSymbolItem1,
            this.fileSaveItem1,
            this.changeTableCellsShadingItem1,
            this.changeTableBordersItem1,
            this.toggleTableCellsBottomBorderItem1,
            this.toggleTableCellsTopBorderItem1,
            this.toggleTableCellsLeftBorderItem1,
            this.toggleTableCellsRightBorderItem1,
            this.resetTableCellsAllBordersItem1,
            this.toggleTableCellsAllBordersItem1,
            this.toggleTableCellsOutsideBorderItem1,
            this.toggleTableCellsInsideBorderItem1,
            this.toggleTableCellsInsideHorizontalBorderItem1,
            this.toggleTableCellsInsideVerticalBorderItem1,
            this.toggleShowTableGridLinesItem1,
            this.changeTableBorderLineStyleItem1,
            this.changeTableBorderLineWeightItem1,
            this.changeTableBorderColorItem1,
            this.selectTableElementsItem1,
            this.selectTableCellItem1,
            this.selectTableColumnItem1,
            this.selectTableRowItem1,
            this.selectTableItem1,
            this.deleteTableElementsItem1,
            this.showDeleteTableCellsFormItem1,
            this.deleteTableColumnsItem1,
            this.deleteTableRowsItem1,
            this.deleteTableItem1,
            this.insertTableRowAboveItem1,
            this.insertTableRowBelowItem1,
            this.insertTableColumnToLeftItem1,
            this.insertTableColumnToRightItem1,
            this.mergeTableCellsItem1,
            this.showSplitTableCellsForm1,
            this.splitTableItem1,
            this.toggleTableCellsTopLeftAlignmentItem1,
            this.toggleTableCellsTopCenterAlignmentItem1,
            this.toggleTableCellsTopRightAlignmentItem1,
            this.toggleTableCellsMiddleLeftAlignmentItem1,
            this.toggleTableCellsMiddleCenterAlignmentItem1,
            this.toggleTableCellsMiddleRightAlignmentItem1,
            this.toggleTableCellsBottomLeftAlignmentItem1,
            this.toggleTableCellsBottomCenterAlignmentItem1,
            this.toggleTableCellsBottomRightAlignmentItem1,
            this.insertPageBreakItem1,
            this.insertTableItem1,
            this.insertBookmarkItem1,
            this.editPageHeaderItem1,
            this.editPageFooterItem1,
            this.insertPageNumberItem1,
            this.insertPageCountItem1,
            this.changeTextCaseItem1,
            this.makeTextUpperCaseItem1,
            this.makeTextLowerCaseItem1,
            this.toggleTextCaseItem1,
            this.clearFormattingItem1,
            this.changeParagraphLineSpacingItem1,
            this.setSingleParagraphSpacingItem1,
            this.setSesquialteralParagraphSpacingItem1,
            this.setDoubleParagraphSpacingItem1,
            this.showLineSpacingFormItem1,
            this.addSpacingBeforeParagraphItem1,
            this.removeSpacingBeforeParagraphItem1,
            this.addSpacingAfterParagraphItem1,
            this.removeSpacingAfterParagraphItem1,
            this.itemField,
            this.pasteSpecialItem1,
            this.barButtonGroup1,
            this.barButtonGroup2,
            this.barButtonGroup3,
            this.barButtonGroup4,
            this.barButtonGroup5,
            this.barButtonGroup6,
            this.barButtonGroup7,
            this.changeParagraphBackColorItem1,
            this.galleryChangeStyleItem1,
            this.insertFloatingPictureItem1,
            this.insertTextBoxItem1,
            this.changeSectionPageMarginsItem1,
            this.setNormalSectionPageMarginsItem1,
            this.setNarrowSectionPageMarginsItem1,
            this.setModerateSectionPageMarginsItem1,
            this.setWideSectionPageMarginsItem1,
            this.showPageMarginsSetupFormItem1,
            this.changeSectionPageOrientationItem1,
            this.setPortraitPageOrientationItem1,
            this.setLandscapePageOrientationItem1,
            this.changeSectionPaperKindItem1,
            this.changeSectionColumnsItem1,
            this.setSectionOneColumnItem1,
            this.setSectionTwoColumnsItem1,
            this.setSectionThreeColumnsItem1,
            this.showColumnsSetupFormItem1,
            this.insertBreakItem1,
            this.insertColumnBreakItem1,
            this.insertSectionBreakNextPageItem1,
            this.insertSectionBreakEvenPageItem1,
            this.insertSectionBreakOddPageItem1,
            this.changeSectionLineNumberingItem1,
            this.setSectionLineNumberingNoneItem1,
            this.setSectionLineNumberingContinuousItem1,
            this.setSectionLineNumberingRestartNewPageItem1,
            this.setSectionLineNumberingRestartNewSectionItem1,
            this.toggleParagraphSuppressLineNumbersItem1,
            this.showLineNumberingFormItem1,
            this.changePageColorItem1,
            this.insertTableOfContentsItem1,
            this.updateTableOfContentsItem1,
            this.addParagraphsToTableOfContentItem1,
            this.setParagraphHeadingLevelItem1,
            this.setParagraphHeadingLevelItem2,
            this.setParagraphHeadingLevelItem3,
            this.setParagraphHeadingLevelItem4,
            this.setParagraphHeadingLevelItem5,
            this.setParagraphHeadingLevelItem6,
            this.setParagraphHeadingLevelItem7,
            this.setParagraphHeadingLevelItem8,
            this.setParagraphHeadingLevelItem9,
            this.setParagraphHeadingLevelItem10,
            this.insertCaptionPlaceholderItem1,
            this.insertFiguresCaptionItems1,
            this.insertTablesCaptionItems1,
            this.insertEquationsCaptionItems1,
            this.insertTableOfFiguresPlaceholderItem1,
            this.insertTableOfFiguresItems1,
            this.insertTableOfTablesItems1,
            this.insertTableOfEquationsItems1,
            this.insertMergeFieldItem1,
            this.showAllFieldCodesItem1,
            this.showAllFieldResultsItem1,
            this.toggleViewMergedDataItem1,
            this.checkSpellingItem1,
            this.protectDocumentItem1,
            this.changeRangeEditingPermissionsItem1,
            this.unprotectDocumentItem1,
            this.toggleShowHorizontalRulerItem1,
            this.toggleShowVerticalRulerItem1,
            this.goToPageHeaderItem1,
            this.goToPageFooterItem1,
            this.goToNextHeaderFooterItem1,
            this.goToPreviousHeaderFooterItem1,
            this.toggleLinkToPreviousItem1,
            this.toggleDifferentFirstPageItem1,
            this.toggleDifferentOddAndEvenPagesItem1,
            this.closePageHeaderFooterItem1,
            this.showTablePropertiesFormItem1,
            this.toggleTableAutoFitItem1,
            this.toggleTableAutoFitContentsItem1,
            this.toggleTableAutoFitWindowItem1,
            this.toggleTableFixedColumnWidthItem1,
            this.showTableOptionsFormItem1,
            this.changeFloatingObjectFillColorItem1,
            this.changeFloatingObjectOutlineColorItem1,
            this.changeFloatingObjectOutlineWeightItem1,
            this.changeFloatingObjectTextWrapTypeItem1,
            this.setFloatingObjectSquareTextWrapTypeItem1,
            this.setFloatingObjectTightTextWrapTypeItem1,
            this.setFloatingObjectThroughTextWrapTypeItem1,
            this.setFloatingObjectTopAndBottomTextWrapTypeItem1,
            this.setFloatingObjectBehindTextWrapTypeItem1,
            this.setFloatingObjectInFrontOfTextWrapTypeItem1,
            this.changeFloatingObjectAlignmentItem1,
            this.setFloatingObjectTopLeftAlignmentItem1,
            this.setFloatingObjectTopCenterAlignmentItem1,
            this.setFloatingObjectTopRightAlignmentItem1,
            this.setFloatingObjectMiddleLeftAlignmentItem1,
            this.setFloatingObjectMiddleCenterAlignmentItem1,
            this.setFloatingObjectMiddleRightAlignmentItem1,
            this.setFloatingObjectBottomLeftAlignmentItem1,
            this.setFloatingObjectBottomCenterAlignmentItem1,
            this.setFloatingObjectBottomRightAlignmentItem1,
            this.floatingObjectBringForwardSubItem1,
            this.floatingObjectBringForwardItem1,
            this.floatingObjectBringToFrontItem1,
            this.floatingObjectBringInFrontOfTextItem1,
            this.floatingObjectSendBackwardSubItem1,
            this.floatingObjectSendBackwardItem1,
            this.floatingObjectSendToBackItem1,
            this.floatingObjectSendBehindTextItem1,
            this.itemSave});
			this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
			this.ribbonControl1.MaxItemId = 115;
			this.ribbonControl1.Name = "ribbonControl1";
			this.ribbonControl1.PageCategories.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageCategory[] {
            this.headerFooterToolsRibbonPageCategory1,
            this.tableToolsRibbonPageCategory1,
            this.floatingPictureToolsRibbonPageCategory1});
			this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.fileRibbonPage1,
            this.homeRibbonPage1,
            this.insertRibbonPage1,
            this.pageLayoutRibbonPage1,
            this.referencesRibbonPage1,
            this.mailingsRibbonPage1,
            this.reviewRibbonPage1,
            this.viewRibbonPage1});
			this.ribbonControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemFontEdit1,
            this.repositoryItemRichEditFontSizeEdit1,
            this.repositoryItemRichEditStyleEdit1,
            this.repositoryItemTextEdit1,
            this.repositoryItemBorderLineStyle1,
            this.repositoryItemBorderLineWeight1,
            this.repositoryItemFloatingObjectOutlineWeight1});
			this.ribbonControl1.Size = new System.Drawing.Size(1027, 143);
			// 
			// popupMenu1
			// 
			this.popupMenu1.ItemLinks.Add(this.cutItem1, true, "X");
			this.popupMenu1.ItemLinks.Add(this.copyItem1, "C");
			this.popupMenu1.ItemLinks.Add(this.pasteItem1, "V");
			this.popupMenu1.ItemLinks.Add(this.itemField);
			this.popupMenu1.Name = "popupMenu1";
			this.popupMenu1.Ribbon = this.ribbonControl1;
			// 
			// cutItem1
			// 
			this.cutItem1.Id = 0;
			this.cutItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("cutItem1.ImageOptions.Image")));
			this.cutItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("cutItem1.ImageOptions.LargeImage")));
			this.cutItem1.Name = "cutItem1";
			// 
			// copyItem1
			// 
			this.copyItem1.Id = 1;
			this.copyItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("copyItem1.ImageOptions.Image")));
			this.copyItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("copyItem1.ImageOptions.LargeImage")));
			this.copyItem1.Name = "copyItem1";
			// 
			// pasteItem1
			// 
			this.pasteItem1.Id = 2;
			this.pasteItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("pasteItem1.ImageOptions.Image")));
			this.pasteItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("pasteItem1.ImageOptions.LargeImage")));
			this.pasteItem1.Name = "pasteItem1";
			// 
			// itemField
			// 
			this.itemField.Caption = "Trường trộn";
			this.itemField.Id = 205;
			this.itemField.ImageOptions.ImageIndex = 0;
			this.itemField.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T));
			this.itemField.Name = "itemField";
			this.itemField.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemField_ItemClick);
			// 
			// changeFontNameItem1
			// 
			this.changeFontNameItem1.Edit = this.repositoryItemFontEdit1;
			this.changeFontNameItem1.EditWidth = 120;
			this.changeFontNameItem1.Id = 3;
			this.changeFontNameItem1.Name = "changeFontNameItem1";
			// 
			// repositoryItemFontEdit1
			// 
			this.repositoryItemFontEdit1.AutoHeight = false;
			this.repositoryItemFontEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
			this.repositoryItemFontEdit1.Name = "repositoryItemFontEdit1";
			// 
			// changeFontSizeItem1
			// 
			this.changeFontSizeItem1.Edit = this.repositoryItemRichEditFontSizeEdit1;
			this.changeFontSizeItem1.Id = 4;
			this.changeFontSizeItem1.Name = "changeFontSizeItem1";
			// 
			// repositoryItemRichEditFontSizeEdit1
			// 
			this.repositoryItemRichEditFontSizeEdit1.AutoHeight = false;
			this.repositoryItemRichEditFontSizeEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
			this.repositoryItemRichEditFontSizeEdit1.Control = this.txtContent;
			this.repositoryItemRichEditFontSizeEdit1.Name = "repositoryItemRichEditFontSizeEdit1";
			// 
			// changeFontColorItem1
			// 
			this.changeFontColorItem1.Id = 5;
			this.changeFontColorItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("changeFontColorItem1.ImageOptions.Image")));
			this.changeFontColorItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("changeFontColorItem1.ImageOptions.LargeImage")));
			this.changeFontColorItem1.Name = "changeFontColorItem1";
			// 
			// changeFontBackColorItem1
			// 
			this.changeFontBackColorItem1.Id = 6;
			this.changeFontBackColorItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("changeFontBackColorItem1.ImageOptions.Image")));
			this.changeFontBackColorItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("changeFontBackColorItem1.ImageOptions.LargeImage")));
			this.changeFontBackColorItem1.Name = "changeFontBackColorItem1";
			// 
			// toggleFontBoldItem1
			// 
			this.toggleFontBoldItem1.Id = 7;
			this.toggleFontBoldItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleFontBoldItem1.ImageOptions.Image")));
			this.toggleFontBoldItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleFontBoldItem1.ImageOptions.LargeImage")));
			this.toggleFontBoldItem1.Name = "toggleFontBoldItem1";
			// 
			// toggleFontItalicItem1
			// 
			this.toggleFontItalicItem1.Id = 8;
			this.toggleFontItalicItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleFontItalicItem1.ImageOptions.Image")));
			this.toggleFontItalicItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleFontItalicItem1.ImageOptions.LargeImage")));
			this.toggleFontItalicItem1.Name = "toggleFontItalicItem1";
			// 
			// toggleFontUnderlineItem1
			// 
			this.toggleFontUnderlineItem1.Id = 9;
			this.toggleFontUnderlineItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleFontUnderlineItem1.ImageOptions.Image")));
			this.toggleFontUnderlineItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleFontUnderlineItem1.ImageOptions.LargeImage")));
			this.toggleFontUnderlineItem1.Name = "toggleFontUnderlineItem1";
			// 
			// toggleFontDoubleUnderlineItem1
			// 
			this.toggleFontDoubleUnderlineItem1.Id = 10;
			this.toggleFontDoubleUnderlineItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleFontDoubleUnderlineItem1.ImageOptions.Image")));
			this.toggleFontDoubleUnderlineItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleFontDoubleUnderlineItem1.ImageOptions.LargeImage")));
			this.toggleFontDoubleUnderlineItem1.Name = "toggleFontDoubleUnderlineItem1";
			// 
			// toggleFontStrikeoutItem1
			// 
			this.toggleFontStrikeoutItem1.Id = 11;
			this.toggleFontStrikeoutItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleFontStrikeoutItem1.ImageOptions.Image")));
			this.toggleFontStrikeoutItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleFontStrikeoutItem1.ImageOptions.LargeImage")));
			this.toggleFontStrikeoutItem1.Name = "toggleFontStrikeoutItem1";
			// 
			// toggleFontDoubleStrikeoutItem1
			// 
			this.toggleFontDoubleStrikeoutItem1.Id = 12;
			this.toggleFontDoubleStrikeoutItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleFontDoubleStrikeoutItem1.ImageOptions.Image")));
			this.toggleFontDoubleStrikeoutItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleFontDoubleStrikeoutItem1.ImageOptions.LargeImage")));
			this.toggleFontDoubleStrikeoutItem1.Name = "toggleFontDoubleStrikeoutItem1";
			// 
			// toggleFontSuperscriptItem1
			// 
			this.toggleFontSuperscriptItem1.Id = 13;
			this.toggleFontSuperscriptItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleFontSuperscriptItem1.ImageOptions.Image")));
			this.toggleFontSuperscriptItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleFontSuperscriptItem1.ImageOptions.LargeImage")));
			this.toggleFontSuperscriptItem1.Name = "toggleFontSuperscriptItem1";
			// 
			// toggleFontSubscriptItem1
			// 
			this.toggleFontSubscriptItem1.Id = 14;
			this.toggleFontSubscriptItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleFontSubscriptItem1.ImageOptions.Image")));
			this.toggleFontSubscriptItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleFontSubscriptItem1.ImageOptions.LargeImage")));
			this.toggleFontSubscriptItem1.Name = "toggleFontSubscriptItem1";
			// 
			// fontSizeIncreaseItem1
			// 
			this.fontSizeIncreaseItem1.Id = 15;
			this.fontSizeIncreaseItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("fontSizeIncreaseItem1.ImageOptions.Image")));
			this.fontSizeIncreaseItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("fontSizeIncreaseItem1.ImageOptions.LargeImage")));
			this.fontSizeIncreaseItem1.Name = "fontSizeIncreaseItem1";
			// 
			// fontSizeDecreaseItem1
			// 
			this.fontSizeDecreaseItem1.Id = 16;
			this.fontSizeDecreaseItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("fontSizeDecreaseItem1.ImageOptions.Image")));
			this.fontSizeDecreaseItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("fontSizeDecreaseItem1.ImageOptions.LargeImage")));
			this.fontSizeDecreaseItem1.Name = "fontSizeDecreaseItem1";
			// 
			// showFontFormItem1
			// 
			this.showFontFormItem1.Id = 17;
			this.showFontFormItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("showFontFormItem1.ImageOptions.Image")));
			this.showFontFormItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("showFontFormItem1.ImageOptions.LargeImage")));
			this.showFontFormItem1.Name = "showFontFormItem1";
			// 
			// fileNewItem1
			// 
			this.fileNewItem1.Id = 18;
			this.fileNewItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("fileNewItem1.ImageOptions.Image")));
			this.fileNewItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("fileNewItem1.ImageOptions.LargeImage")));
			this.fileNewItem1.Name = "fileNewItem1";
			// 
			// fileOpenItem1
			// 
			this.fileOpenItem1.Id = 19;
			this.fileOpenItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("fileOpenItem1.ImageOptions.Image")));
			this.fileOpenItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("fileOpenItem1.ImageOptions.LargeImage")));
			this.fileOpenItem1.Name = "fileOpenItem1";
			// 
			// fileSaveAsItem1
			// 
			this.fileSaveAsItem1.Id = 21;
			this.fileSaveAsItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("fileSaveAsItem1.ImageOptions.Image")));
			this.fileSaveAsItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("fileSaveAsItem1.ImageOptions.LargeImage")));
			this.fileSaveAsItem1.Name = "fileSaveAsItem1";
			toolTipTitleItem1.Text = "Save As (F12)";
			toolTipItem1.LeftIndent = 6;
			toolTipItem1.Text = "Save content to file.";
			superToolTip1.Items.Add(toolTipTitleItem1);
			superToolTip1.Items.Add(toolTipItem1);
			this.fileSaveAsItem1.SuperTip = superToolTip1;
			// 
			// quickPrintItem1
			// 
			this.quickPrintItem1.Id = 22;
			this.quickPrintItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("quickPrintItem1.ImageOptions.Image")));
			this.quickPrintItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("quickPrintItem1.ImageOptions.LargeImage")));
			this.quickPrintItem1.Name = "quickPrintItem1";
			// 
			// printItem1
			// 
			this.printItem1.Id = 39;
			this.printItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("printItem1.ImageOptions.Image")));
			this.printItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("printItem1.ImageOptions.LargeImage")));
			this.printItem1.Name = "printItem1";
			// 
			// printPreviewItem1
			// 
			this.printPreviewItem1.Id = 23;
			this.printPreviewItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("printPreviewItem1.ImageOptions.Image")));
			this.printPreviewItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("printPreviewItem1.ImageOptions.LargeImage")));
			this.printPreviewItem1.Name = "printPreviewItem1";
			// 
			// undoItem1
			// 
			this.undoItem1.Id = 28;
			this.undoItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("undoItem1.ImageOptions.Image")));
			this.undoItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("undoItem1.ImageOptions.LargeImage")));
			this.undoItem1.Name = "undoItem1";
			// 
			// redoItem1
			// 
			this.redoItem1.Id = 29;
			this.redoItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("redoItem1.ImageOptions.Image")));
			this.redoItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("redoItem1.ImageOptions.LargeImage")));
			this.redoItem1.Name = "redoItem1";
			// 
			// changeStyleItem1
			// 
			this.changeStyleItem1.Edit = this.repositoryItemRichEditStyleEdit1;
			this.changeStyleItem1.Id = 40;
			this.changeStyleItem1.Name = "changeStyleItem1";
			// 
			// repositoryItemRichEditStyleEdit1
			// 
			this.repositoryItemRichEditStyleEdit1.AutoHeight = false;
			this.repositoryItemRichEditStyleEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
			this.repositoryItemRichEditStyleEdit1.Control = this.txtContent;
			this.repositoryItemRichEditStyleEdit1.Name = "repositoryItemRichEditStyleEdit1";
			// 
			// toggleParagraphAlignmentLeftItem1
			// 
			this.toggleParagraphAlignmentLeftItem1.Id = 30;
			this.toggleParagraphAlignmentLeftItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleParagraphAlignmentLeftItem1.ImageOptions.Image")));
			this.toggleParagraphAlignmentLeftItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleParagraphAlignmentLeftItem1.ImageOptions.LargeImage")));
			this.toggleParagraphAlignmentLeftItem1.Name = "toggleParagraphAlignmentLeftItem1";
			// 
			// toggleParagraphAlignmentCenterItem1
			// 
			this.toggleParagraphAlignmentCenterItem1.Id = 31;
			this.toggleParagraphAlignmentCenterItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleParagraphAlignmentCenterItem1.ImageOptions.Image")));
			this.toggleParagraphAlignmentCenterItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleParagraphAlignmentCenterItem1.ImageOptions.LargeImage")));
			this.toggleParagraphAlignmentCenterItem1.Name = "toggleParagraphAlignmentCenterItem1";
			// 
			// toggleParagraphAlignmentRightItem1
			// 
			this.toggleParagraphAlignmentRightItem1.Id = 32;
			this.toggleParagraphAlignmentRightItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleParagraphAlignmentRightItem1.ImageOptions.Image")));
			this.toggleParagraphAlignmentRightItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleParagraphAlignmentRightItem1.ImageOptions.LargeImage")));
			this.toggleParagraphAlignmentRightItem1.Name = "toggleParagraphAlignmentRightItem1";
			// 
			// toggleParagraphAlignmentJustifyItem1
			// 
			this.toggleParagraphAlignmentJustifyItem1.Id = 33;
			this.toggleParagraphAlignmentJustifyItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleParagraphAlignmentJustifyItem1.ImageOptions.Image")));
			this.toggleParagraphAlignmentJustifyItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleParagraphAlignmentJustifyItem1.ImageOptions.LargeImage")));
			this.toggleParagraphAlignmentJustifyItem1.Name = "toggleParagraphAlignmentJustifyItem1";
			// 
			// toggleNumberingListItem1
			// 
			this.toggleNumberingListItem1.Id = 34;
			this.toggleNumberingListItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleNumberingListItem1.ImageOptions.Image")));
			this.toggleNumberingListItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleNumberingListItem1.ImageOptions.LargeImage")));
			this.toggleNumberingListItem1.Name = "toggleNumberingListItem1";
			// 
			// toggleBulletedListItem1
			// 
			this.toggleBulletedListItem1.Id = 35;
			this.toggleBulletedListItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleBulletedListItem1.ImageOptions.Image")));
			this.toggleBulletedListItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleBulletedListItem1.ImageOptions.LargeImage")));
			this.toggleBulletedListItem1.Name = "toggleBulletedListItem1";
			// 
			// toggleMultiLevelListItem1
			// 
			this.toggleMultiLevelListItem1.Id = 36;
			this.toggleMultiLevelListItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleMultiLevelListItem1.ImageOptions.Image")));
			this.toggleMultiLevelListItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleMultiLevelListItem1.ImageOptions.LargeImage")));
			this.toggleMultiLevelListItem1.Name = "toggleMultiLevelListItem1";
			// 
			// decreaseIndentItem1
			// 
			this.decreaseIndentItem1.Id = 37;
			this.decreaseIndentItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("decreaseIndentItem1.ImageOptions.Image")));
			this.decreaseIndentItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("decreaseIndentItem1.ImageOptions.LargeImage")));
			this.decreaseIndentItem1.Name = "decreaseIndentItem1";
			// 
			// increaseIndentItem1
			// 
			this.increaseIndentItem1.Id = 38;
			this.increaseIndentItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("increaseIndentItem1.ImageOptions.Image")));
			this.increaseIndentItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("increaseIndentItem1.ImageOptions.LargeImage")));
			this.increaseIndentItem1.Name = "increaseIndentItem1";
			// 
			// toggleShowWhitespaceItem1
			// 
			this.toggleShowWhitespaceItem1.Id = 41;
			this.toggleShowWhitespaceItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleShowWhitespaceItem1.ImageOptions.Image")));
			this.toggleShowWhitespaceItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleShowWhitespaceItem1.ImageOptions.LargeImage")));
			this.toggleShowWhitespaceItem1.Name = "toggleShowWhitespaceItem1";
			// 
			// showParagraphFormItem1
			// 
			this.showParagraphFormItem1.Id = 42;
			this.showParagraphFormItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("showParagraphFormItem1.ImageOptions.Image")));
			this.showParagraphFormItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("showParagraphFormItem1.ImageOptions.LargeImage")));
			this.showParagraphFormItem1.Name = "showParagraphFormItem1";
			// 
			// insertPictureItem1
			// 
			this.insertPictureItem1.Id = 26;
			this.insertPictureItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("insertPictureItem1.ImageOptions.Image")));
			this.insertPictureItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("insertPictureItem1.ImageOptions.LargeImage")));
			this.insertPictureItem1.Name = "insertPictureItem1";
			// 
			// insertHyperlinkItem1
			// 
			this.insertHyperlinkItem1.Id = 27;
			this.insertHyperlinkItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("insertHyperlinkItem1.ImageOptions.Image")));
			this.insertHyperlinkItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("insertHyperlinkItem1.ImageOptions.LargeImage")));
			this.insertHyperlinkItem1.Name = "insertHyperlinkItem1";
			// 
			// zoomOutItem1
			// 
			this.zoomOutItem1.Id = 24;
			this.zoomOutItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("zoomOutItem1.ImageOptions.Image")));
			this.zoomOutItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("zoomOutItem1.ImageOptions.LargeImage")));
			this.zoomOutItem1.Name = "zoomOutItem1";
			// 
			// zoomInItem1
			// 
			this.zoomInItem1.Id = 25;
			this.zoomInItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("zoomInItem1.ImageOptions.Image")));
			this.zoomInItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("zoomInItem1.ImageOptions.LargeImage")));
			this.zoomInItem1.Name = "zoomInItem1";
			// 
			// switchToSimpleViewItem1
			// 
			this.switchToSimpleViewItem1.Id = 44;
			this.switchToSimpleViewItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("switchToSimpleViewItem1.ImageOptions.Image")));
			this.switchToSimpleViewItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("switchToSimpleViewItem1.ImageOptions.LargeImage")));
			this.switchToSimpleViewItem1.Name = "switchToSimpleViewItem1";
			// 
			// switchToDraftViewItem1
			// 
			this.switchToDraftViewItem1.Id = 45;
			this.switchToDraftViewItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("switchToDraftViewItem1.ImageOptions.Image")));
			this.switchToDraftViewItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("switchToDraftViewItem1.ImageOptions.LargeImage")));
			this.switchToDraftViewItem1.Name = "switchToDraftViewItem1";
			// 
			// switchToPrintLayoutViewItem1
			// 
			this.switchToPrintLayoutViewItem1.Id = 46;
			this.switchToPrintLayoutViewItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("switchToPrintLayoutViewItem1.ImageOptions.Image")));
			this.switchToPrintLayoutViewItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("switchToPrintLayoutViewItem1.ImageOptions.LargeImage")));
			this.switchToPrintLayoutViewItem1.Name = "switchToPrintLayoutViewItem1";
			// 
			// findItem1
			// 
			this.findItem1.Id = 47;
			this.findItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("findItem1.ImageOptions.Image")));
			this.findItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("findItem1.ImageOptions.LargeImage")));
			this.findItem1.Name = "findItem1";
			// 
			// replaceItem1
			// 
			this.replaceItem1.Id = 48;
			this.replaceItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("replaceItem1.ImageOptions.Image")));
			this.replaceItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("replaceItem1.ImageOptions.LargeImage")));
			this.replaceItem1.Name = "replaceItem1";
			// 
			// insertSymbolItem1
			// 
			this.insertSymbolItem1.Id = 49;
			this.insertSymbolItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("insertSymbolItem1.ImageOptions.Image")));
			this.insertSymbolItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("insertSymbolItem1.ImageOptions.LargeImage")));
			this.insertSymbolItem1.Name = "insertSymbolItem1";
			// 
			// itemLuu
			// 
			this.itemLuu.Caption = "Lưu";
			this.itemLuu.Id = 51;
			this.itemLuu.ImageOptions.ImageIndex = 2;
			this.itemLuu.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S));
			this.itemLuu.Name = "itemLuu";
			toolTipTitleItem2.Text = "Save (Ctrl+V)";
			toolTipItem2.LeftIndent = 6;
			toolTipItem2.Text = "Save content to database.";
			superToolTip2.Items.Add(toolTipTitleItem2);
			superToolTip2.Items.Add(toolTipItem2);
			this.itemLuu.SuperTip = superToolTip2;
			this.itemLuu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLuu_ItemClick);
			// 
			// itemDong
			// 
			this.itemDong.Caption = "Đóng";
			this.itemDong.Id = 52;
			this.itemDong.ImageOptions.ImageIndex = 1;
			this.itemDong.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4));
			this.itemDong.Name = "itemDong";
			toolTipTitleItem3.Text = "Close form (Alt+F4)";
			toolTipItem3.LeftIndent = 6;
			toolTipItem3.Text = "Close this form.";
			superToolTip3.Items.Add(toolTipTitleItem3);
			superToolTip3.Items.Add(toolTipItem3);
			this.itemDong.SuperTip = superToolTip3;
			this.itemDong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDong_ItemClick);
			// 
			// barSubItem1
			// 
			this.barSubItem1.Caption = "&";
			this.barSubItem1.Id = 54;
			this.barSubItem1.Name = "barSubItem1";
			// 
			// barMdiChildrenListItem1
			// 
			this.barMdiChildrenListItem1.Caption = "barMdiChildrenListItem1";
			this.barMdiChildrenListItem1.Id = 56;
			this.barMdiChildrenListItem1.Name = "barMdiChildrenListItem1";
			// 
			// fileSaveItem1
			// 
			this.fileSaveItem1.Id = 60;
			this.fileSaveItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("fileSaveItem1.ImageOptions.Image")));
			this.fileSaveItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("fileSaveItem1.ImageOptions.LargeImage")));
			this.fileSaveItem1.Name = "fileSaveItem1";
			// 
			// barSubItem2
			// 
			this.barSubItem2.Caption = "Insert";
			this.barSubItem2.Id = 61;
			this.barSubItem2.Name = "barSubItem2";
			// 
			// itemCopy
			// 
			this.itemCopy.Caption = "Copy";
			this.itemCopy.Id = 104;
			this.itemCopy.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C));
			this.itemCopy.Name = "itemCopy";
			// 
			// itemCut
			// 
			this.itemCut.Caption = "Cut";
			this.itemCut.Id = 105;
			this.itemCut.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X));
			this.itemCut.Name = "itemCut";
			// 
			// itemPaste
			// 
			this.itemPaste.Caption = "Paste";
			this.itemPaste.Id = 106;
			this.itemPaste.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V));
			this.itemPaste.Name = "itemPaste";
			// 
			// changeTableCellsShadingItem1
			// 
			this.changeTableCellsShadingItem1.Id = 117;
			this.changeTableCellsShadingItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("changeTableCellsShadingItem1.ImageOptions.Image")));
			this.changeTableCellsShadingItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("changeTableCellsShadingItem1.ImageOptions.LargeImage")));
			this.changeTableCellsShadingItem1.Name = "changeTableCellsShadingItem1";
			// 
			// changeTableBordersItem1
			// 
			this.changeTableBordersItem1.Id = 118;
			this.changeTableBordersItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("changeTableBordersItem1.ImageOptions.Image")));
			this.changeTableBordersItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("changeTableBordersItem1.ImageOptions.LargeImage")));
			this.changeTableBordersItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsBottomBorderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsTopBorderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsLeftBorderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsRightBorderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.resetTableCellsAllBordersItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsAllBordersItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsOutsideBorderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsInsideBorderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsInsideHorizontalBorderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableCellsInsideVerticalBorderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.KeyTip, this.toggleShowTableGridLinesItem1, "", false, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.Standard, "TG", "")});
			this.changeTableBordersItem1.Name = "changeTableBordersItem1";
			// 
			// toggleTableCellsBottomBorderItem1
			// 
			this.toggleTableCellsBottomBorderItem1.Id = 119;
			this.toggleTableCellsBottomBorderItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsBottomBorderItem1.ImageOptions.Image")));
			this.toggleTableCellsBottomBorderItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsBottomBorderItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsBottomBorderItem1.Name = "toggleTableCellsBottomBorderItem1";
			// 
			// toggleTableCellsTopBorderItem1
			// 
			this.toggleTableCellsTopBorderItem1.Id = 120;
			this.toggleTableCellsTopBorderItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsTopBorderItem1.ImageOptions.Image")));
			this.toggleTableCellsTopBorderItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsTopBorderItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsTopBorderItem1.Name = "toggleTableCellsTopBorderItem1";
			// 
			// toggleTableCellsLeftBorderItem1
			// 
			this.toggleTableCellsLeftBorderItem1.Id = 121;
			this.toggleTableCellsLeftBorderItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsLeftBorderItem1.ImageOptions.Image")));
			this.toggleTableCellsLeftBorderItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsLeftBorderItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsLeftBorderItem1.Name = "toggleTableCellsLeftBorderItem1";
			// 
			// toggleTableCellsRightBorderItem1
			// 
			this.toggleTableCellsRightBorderItem1.Id = 122;
			this.toggleTableCellsRightBorderItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsRightBorderItem1.ImageOptions.Image")));
			this.toggleTableCellsRightBorderItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsRightBorderItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsRightBorderItem1.Name = "toggleTableCellsRightBorderItem1";
			// 
			// resetTableCellsAllBordersItem1
			// 
			this.resetTableCellsAllBordersItem1.Id = 123;
			this.resetTableCellsAllBordersItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resetTableCellsAllBordersItem1.ImageOptions.Image")));
			this.resetTableCellsAllBordersItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("resetTableCellsAllBordersItem1.ImageOptions.LargeImage")));
			this.resetTableCellsAllBordersItem1.Name = "resetTableCellsAllBordersItem1";
			// 
			// toggleTableCellsAllBordersItem1
			// 
			this.toggleTableCellsAllBordersItem1.Id = 124;
			this.toggleTableCellsAllBordersItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsAllBordersItem1.ImageOptions.Image")));
			this.toggleTableCellsAllBordersItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsAllBordersItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsAllBordersItem1.Name = "toggleTableCellsAllBordersItem1";
			// 
			// toggleTableCellsOutsideBorderItem1
			// 
			this.toggleTableCellsOutsideBorderItem1.Id = 125;
			this.toggleTableCellsOutsideBorderItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsOutsideBorderItem1.ImageOptions.Image")));
			this.toggleTableCellsOutsideBorderItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsOutsideBorderItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsOutsideBorderItem1.Name = "toggleTableCellsOutsideBorderItem1";
			// 
			// toggleTableCellsInsideBorderItem1
			// 
			this.toggleTableCellsInsideBorderItem1.Id = 126;
			this.toggleTableCellsInsideBorderItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsInsideBorderItem1.ImageOptions.Image")));
			this.toggleTableCellsInsideBorderItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsInsideBorderItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsInsideBorderItem1.Name = "toggleTableCellsInsideBorderItem1";
			// 
			// toggleTableCellsInsideHorizontalBorderItem1
			// 
			this.toggleTableCellsInsideHorizontalBorderItem1.Id = 127;
			this.toggleTableCellsInsideHorizontalBorderItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsInsideHorizontalBorderItem1.ImageOptions.Image")));
			this.toggleTableCellsInsideHorizontalBorderItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsInsideHorizontalBorderItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsInsideHorizontalBorderItem1.Name = "toggleTableCellsInsideHorizontalBorderItem1";
			// 
			// toggleTableCellsInsideVerticalBorderItem1
			// 
			this.toggleTableCellsInsideVerticalBorderItem1.Id = 128;
			this.toggleTableCellsInsideVerticalBorderItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsInsideVerticalBorderItem1.ImageOptions.Image")));
			this.toggleTableCellsInsideVerticalBorderItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsInsideVerticalBorderItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsInsideVerticalBorderItem1.Name = "toggleTableCellsInsideVerticalBorderItem1";
			// 
			// toggleShowTableGridLinesItem1
			// 
			this.toggleShowTableGridLinesItem1.Id = 129;
			this.toggleShowTableGridLinesItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleShowTableGridLinesItem1.ImageOptions.Image")));
			this.toggleShowTableGridLinesItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleShowTableGridLinesItem1.ImageOptions.LargeImage")));
			this.toggleShowTableGridLinesItem1.Name = "toggleShowTableGridLinesItem1";
			// 
			// changeTableBorderLineStyleItem1
			// 
			this.changeTableBorderLineStyleItem1.Edit = this.repositoryItemBorderLineStyle1;
			this.changeTableBorderLineStyleItem1.EditWidth = 130;
			this.changeTableBorderLineStyleItem1.Id = 130;
			this.changeTableBorderLineStyleItem1.Name = "changeTableBorderLineStyleItem1";
			// 
			// repositoryItemBorderLineStyle1
			// 
			this.repositoryItemBorderLineStyle1.AutoHeight = false;
			this.repositoryItemBorderLineStyle1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
			this.repositoryItemBorderLineStyle1.Control = this.txtContent;
			this.repositoryItemBorderLineStyle1.Name = "repositoryItemBorderLineStyle1";
			// 
			// changeTableBorderLineWeightItem1
			// 
			this.changeTableBorderLineWeightItem1.Edit = this.repositoryItemBorderLineWeight1;
			this.changeTableBorderLineWeightItem1.EditValue = 20;
			this.changeTableBorderLineWeightItem1.EditWidth = 130;
			this.changeTableBorderLineWeightItem1.Id = 131;
			this.changeTableBorderLineWeightItem1.Name = "changeTableBorderLineWeightItem1";
			// 
			// repositoryItemBorderLineWeight1
			// 
			this.repositoryItemBorderLineWeight1.AutoHeight = false;
			this.repositoryItemBorderLineWeight1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
			this.repositoryItemBorderLineWeight1.Control = this.txtContent;
			this.repositoryItemBorderLineWeight1.Name = "repositoryItemBorderLineWeight1";
			// 
			// changeTableBorderColorItem1
			// 
			this.changeTableBorderColorItem1.Id = 132;
			this.changeTableBorderColorItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("changeTableBorderColorItem1.ImageOptions.Image")));
			this.changeTableBorderColorItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("changeTableBorderColorItem1.ImageOptions.LargeImage")));
			this.changeTableBorderColorItem1.Name = "changeTableBorderColorItem1";
			// 
			// selectTableElementsItem1
			// 
			this.selectTableElementsItem1.Id = 133;
			this.selectTableElementsItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("selectTableElementsItem1.ImageOptions.Image")));
			this.selectTableElementsItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("selectTableElementsItem1.ImageOptions.LargeImage")));
			this.selectTableElementsItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.selectTableCellItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.selectTableColumnItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.selectTableRowItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.selectTableItem1)});
			this.selectTableElementsItem1.Name = "selectTableElementsItem1";
			// 
			// selectTableCellItem1
			// 
			this.selectTableCellItem1.Id = 134;
			this.selectTableCellItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("selectTableCellItem1.ImageOptions.Image")));
			this.selectTableCellItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("selectTableCellItem1.ImageOptions.LargeImage")));
			this.selectTableCellItem1.Name = "selectTableCellItem1";
			// 
			// selectTableColumnItem1
			// 
			this.selectTableColumnItem1.Id = 135;
			this.selectTableColumnItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("selectTableColumnItem1.ImageOptions.Image")));
			this.selectTableColumnItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("selectTableColumnItem1.ImageOptions.LargeImage")));
			this.selectTableColumnItem1.Name = "selectTableColumnItem1";
			// 
			// selectTableRowItem1
			// 
			this.selectTableRowItem1.Id = 136;
			this.selectTableRowItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("selectTableRowItem1.ImageOptions.Image")));
			this.selectTableRowItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("selectTableRowItem1.ImageOptions.LargeImage")));
			this.selectTableRowItem1.Name = "selectTableRowItem1";
			// 
			// selectTableItem1
			// 
			this.selectTableItem1.Id = 137;
			this.selectTableItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("selectTableItem1.ImageOptions.Image")));
			this.selectTableItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("selectTableItem1.ImageOptions.LargeImage")));
			this.selectTableItem1.Name = "selectTableItem1";
			// 
			// deleteTableElementsItem1
			// 
			this.deleteTableElementsItem1.Id = 138;
			this.deleteTableElementsItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("deleteTableElementsItem1.ImageOptions.Image")));
			this.deleteTableElementsItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("deleteTableElementsItem1.ImageOptions.LargeImage")));
			this.deleteTableElementsItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.showDeleteTableCellsFormItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.deleteTableColumnsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.deleteTableRowsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.deleteTableItem1)});
			this.deleteTableElementsItem1.Name = "deleteTableElementsItem1";
			// 
			// showDeleteTableCellsFormItem1
			// 
			this.showDeleteTableCellsFormItem1.Id = 139;
			this.showDeleteTableCellsFormItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("showDeleteTableCellsFormItem1.ImageOptions.Image")));
			this.showDeleteTableCellsFormItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("showDeleteTableCellsFormItem1.ImageOptions.LargeImage")));
			this.showDeleteTableCellsFormItem1.Name = "showDeleteTableCellsFormItem1";
			// 
			// deleteTableColumnsItem1
			// 
			this.deleteTableColumnsItem1.Id = 140;
			this.deleteTableColumnsItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("deleteTableColumnsItem1.ImageOptions.Image")));
			this.deleteTableColumnsItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("deleteTableColumnsItem1.ImageOptions.LargeImage")));
			this.deleteTableColumnsItem1.Name = "deleteTableColumnsItem1";
			// 
			// deleteTableRowsItem1
			// 
			this.deleteTableRowsItem1.Id = 141;
			this.deleteTableRowsItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("deleteTableRowsItem1.ImageOptions.Image")));
			this.deleteTableRowsItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("deleteTableRowsItem1.ImageOptions.LargeImage")));
			this.deleteTableRowsItem1.Name = "deleteTableRowsItem1";
			// 
			// deleteTableItem1
			// 
			this.deleteTableItem1.Id = 142;
			this.deleteTableItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("deleteTableItem1.ImageOptions.Image")));
			this.deleteTableItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("deleteTableItem1.ImageOptions.LargeImage")));
			this.deleteTableItem1.Name = "deleteTableItem1";
			// 
			// insertTableRowAboveItem1
			// 
			this.insertTableRowAboveItem1.Id = 143;
			this.insertTableRowAboveItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("insertTableRowAboveItem1.ImageOptions.Image")));
			this.insertTableRowAboveItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("insertTableRowAboveItem1.ImageOptions.LargeImage")));
			this.insertTableRowAboveItem1.Name = "insertTableRowAboveItem1";
			// 
			// insertTableRowBelowItem1
			// 
			this.insertTableRowBelowItem1.Id = 144;
			this.insertTableRowBelowItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("insertTableRowBelowItem1.ImageOptions.Image")));
			this.insertTableRowBelowItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("insertTableRowBelowItem1.ImageOptions.LargeImage")));
			this.insertTableRowBelowItem1.Name = "insertTableRowBelowItem1";
			// 
			// insertTableColumnToLeftItem1
			// 
			this.insertTableColumnToLeftItem1.Id = 145;
			this.insertTableColumnToLeftItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("insertTableColumnToLeftItem1.ImageOptions.Image")));
			this.insertTableColumnToLeftItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("insertTableColumnToLeftItem1.ImageOptions.LargeImage")));
			this.insertTableColumnToLeftItem1.Name = "insertTableColumnToLeftItem1";
			// 
			// insertTableColumnToRightItem1
			// 
			this.insertTableColumnToRightItem1.Id = 146;
			this.insertTableColumnToRightItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("insertTableColumnToRightItem1.ImageOptions.Image")));
			this.insertTableColumnToRightItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("insertTableColumnToRightItem1.ImageOptions.LargeImage")));
			this.insertTableColumnToRightItem1.Name = "insertTableColumnToRightItem1";
			// 
			// showInsertTableCellsFormItem1
			// 
			this.showInsertTableCellsFormItem1.Id = 147;
			this.showInsertTableCellsFormItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("showInsertTableCellsFormItem1.ImageOptions.Image")));
			this.showInsertTableCellsFormItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("showInsertTableCellsFormItem1.ImageOptions.LargeImage")));
			this.showInsertTableCellsFormItem1.Name = "showInsertTableCellsFormItem1";
			// 
			// mergeTableCellsItem1
			// 
			this.mergeTableCellsItem1.Id = 148;
			this.mergeTableCellsItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("mergeTableCellsItem1.ImageOptions.Image")));
			this.mergeTableCellsItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("mergeTableCellsItem1.ImageOptions.LargeImage")));
			this.mergeTableCellsItem1.Name = "mergeTableCellsItem1";
			// 
			// showSplitTableCellsForm1
			// 
			this.showSplitTableCellsForm1.Id = 149;
			this.showSplitTableCellsForm1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("showSplitTableCellsForm1.ImageOptions.Image")));
			this.showSplitTableCellsForm1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("showSplitTableCellsForm1.ImageOptions.LargeImage")));
			this.showSplitTableCellsForm1.Name = "showSplitTableCellsForm1";
			// 
			// splitTableItem1
			// 
			this.splitTableItem1.Id = 150;
			this.splitTableItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("splitTableItem1.ImageOptions.Image")));
			this.splitTableItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("splitTableItem1.ImageOptions.LargeImage")));
			this.splitTableItem1.Name = "splitTableItem1";
			// 
			// toggleTableCellsTopLeftAlignmentItem1
			// 
			this.toggleTableCellsTopLeftAlignmentItem1.Id = 151;
			this.toggleTableCellsTopLeftAlignmentItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsTopLeftAlignmentItem1.ImageOptions.Image")));
			this.toggleTableCellsTopLeftAlignmentItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsTopLeftAlignmentItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsTopLeftAlignmentItem1.Name = "toggleTableCellsTopLeftAlignmentItem1";
			// 
			// toggleTableCellsTopCenterAlignmentItem1
			// 
			this.toggleTableCellsTopCenterAlignmentItem1.Id = 152;
			this.toggleTableCellsTopCenterAlignmentItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsTopCenterAlignmentItem1.ImageOptions.Image")));
			this.toggleTableCellsTopCenterAlignmentItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsTopCenterAlignmentItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsTopCenterAlignmentItem1.Name = "toggleTableCellsTopCenterAlignmentItem1";
			// 
			// toggleTableCellsTopRightAlignmentItem1
			// 
			this.toggleTableCellsTopRightAlignmentItem1.Id = 153;
			this.toggleTableCellsTopRightAlignmentItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsTopRightAlignmentItem1.ImageOptions.Image")));
			this.toggleTableCellsTopRightAlignmentItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsTopRightAlignmentItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsTopRightAlignmentItem1.Name = "toggleTableCellsTopRightAlignmentItem1";
			// 
			// toggleTableCellsMiddleLeftAlignmentItem1
			// 
			this.toggleTableCellsMiddleLeftAlignmentItem1.Id = 154;
			this.toggleTableCellsMiddleLeftAlignmentItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsMiddleLeftAlignmentItem1.ImageOptions.Image")));
			this.toggleTableCellsMiddleLeftAlignmentItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsMiddleLeftAlignmentItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsMiddleLeftAlignmentItem1.Name = "toggleTableCellsMiddleLeftAlignmentItem1";
			// 
			// toggleTableCellsMiddleCenterAlignmentItem1
			// 
			this.toggleTableCellsMiddleCenterAlignmentItem1.Id = 155;
			this.toggleTableCellsMiddleCenterAlignmentItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsMiddleCenterAlignmentItem1.ImageOptions.Image")));
			this.toggleTableCellsMiddleCenterAlignmentItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsMiddleCenterAlignmentItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsMiddleCenterAlignmentItem1.Name = "toggleTableCellsMiddleCenterAlignmentItem1";
			// 
			// toggleTableCellsMiddleRightAlignmentItem1
			// 
			this.toggleTableCellsMiddleRightAlignmentItem1.Id = 156;
			this.toggleTableCellsMiddleRightAlignmentItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsMiddleRightAlignmentItem1.ImageOptions.Image")));
			this.toggleTableCellsMiddleRightAlignmentItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsMiddleRightAlignmentItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsMiddleRightAlignmentItem1.Name = "toggleTableCellsMiddleRightAlignmentItem1";
			// 
			// toggleTableCellsBottomLeftAlignmentItem1
			// 
			this.toggleTableCellsBottomLeftAlignmentItem1.Id = 157;
			this.toggleTableCellsBottomLeftAlignmentItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsBottomLeftAlignmentItem1.ImageOptions.Image")));
			this.toggleTableCellsBottomLeftAlignmentItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsBottomLeftAlignmentItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsBottomLeftAlignmentItem1.Name = "toggleTableCellsBottomLeftAlignmentItem1";
			// 
			// toggleTableCellsBottomCenterAlignmentItem1
			// 
			this.toggleTableCellsBottomCenterAlignmentItem1.Id = 158;
			this.toggleTableCellsBottomCenterAlignmentItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsBottomCenterAlignmentItem1.ImageOptions.Image")));
			this.toggleTableCellsBottomCenterAlignmentItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsBottomCenterAlignmentItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsBottomCenterAlignmentItem1.Name = "toggleTableCellsBottomCenterAlignmentItem1";
			// 
			// toggleTableCellsBottomRightAlignmentItem1
			// 
			this.toggleTableCellsBottomRightAlignmentItem1.Id = 159;
			this.toggleTableCellsBottomRightAlignmentItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsBottomRightAlignmentItem1.ImageOptions.Image")));
			this.toggleTableCellsBottomRightAlignmentItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("toggleTableCellsBottomRightAlignmentItem1.ImageOptions.LargeImage")));
			this.toggleTableCellsBottomRightAlignmentItem1.Name = "toggleTableCellsBottomRightAlignmentItem1";
			// 
			// insertPageBreakItem1
			// 
			this.insertPageBreakItem1.Id = 160;
			this.insertPageBreakItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("insertPageBreakItem1.ImageOptions.Image")));
			this.insertPageBreakItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("insertPageBreakItem1.ImageOptions.LargeImage")));
			this.insertPageBreakItem1.Name = "insertPageBreakItem1";
			// 
			// insertTableItem1
			// 
			this.insertTableItem1.Id = 161;
			this.insertTableItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("insertTableItem1.ImageOptions.Image")));
			this.insertTableItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("insertTableItem1.ImageOptions.LargeImage")));
			this.insertTableItem1.Name = "insertTableItem1";
			// 
			// insertBookmarkItem1
			// 
			this.insertBookmarkItem1.Id = 166;
			this.insertBookmarkItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("insertBookmarkItem1.ImageOptions.Image")));
			this.insertBookmarkItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("insertBookmarkItem1.ImageOptions.LargeImage")));
			this.insertBookmarkItem1.Name = "insertBookmarkItem1";
			// 
			// editPageHeaderItem1
			// 
			this.editPageHeaderItem1.Id = 162;
			this.editPageHeaderItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("editPageHeaderItem1.ImageOptions.Image")));
			this.editPageHeaderItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("editPageHeaderItem1.ImageOptions.LargeImage")));
			this.editPageHeaderItem1.Name = "editPageHeaderItem1";
			// 
			// editPageFooterItem1
			// 
			this.editPageFooterItem1.Id = 163;
			this.editPageFooterItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("editPageFooterItem1.ImageOptions.Image")));
			this.editPageFooterItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("editPageFooterItem1.ImageOptions.LargeImage")));
			this.editPageFooterItem1.Name = "editPageFooterItem1";
			// 
			// insertPageNumberItem1
			// 
			this.insertPageNumberItem1.Id = 164;
			this.insertPageNumberItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("insertPageNumberItem1.ImageOptions.Image")));
			this.insertPageNumberItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("insertPageNumberItem1.ImageOptions.LargeImage")));
			this.insertPageNumberItem1.Name = "insertPageNumberItem1";
			// 
			// insertPageCountItem1
			// 
			this.insertPageCountItem1.Id = 165;
			this.insertPageCountItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("insertPageCountItem1.ImageOptions.Image")));
			this.insertPageCountItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("insertPageCountItem1.ImageOptions.LargeImage")));
			this.insertPageCountItem1.Name = "insertPageCountItem1";
			// 
			// changeTextCaseItem1
			// 
			this.changeTextCaseItem1.Id = 167;
			this.changeTextCaseItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("changeTextCaseItem1.ImageOptions.Image")));
			this.changeTextCaseItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("changeTextCaseItem1.ImageOptions.LargeImage")));
			this.changeTextCaseItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.makeTextUpperCaseItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.makeTextLowerCaseItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTextCaseItem1)});
			this.changeTextCaseItem1.Name = "changeTextCaseItem1";
			// 
			// makeTextUpperCaseItem1
			// 
			this.makeTextUpperCaseItem1.Id = 168;
			this.makeTextUpperCaseItem1.Name = "makeTextUpperCaseItem1";
			// 
			// makeTextLowerCaseItem1
			// 
			this.makeTextLowerCaseItem1.Id = 169;
			this.makeTextLowerCaseItem1.Name = "makeTextLowerCaseItem1";
			// 
			// toggleTextCaseItem1
			// 
			this.toggleTextCaseItem1.Id = 170;
			this.toggleTextCaseItem1.Name = "toggleTextCaseItem1";
			// 
			// clearFormattingItem1
			// 
			this.clearFormattingItem1.Id = 171;
			this.clearFormattingItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("clearFormattingItem1.ImageOptions.Image")));
			this.clearFormattingItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("clearFormattingItem1.ImageOptions.LargeImage")));
			this.clearFormattingItem1.Name = "clearFormattingItem1";
			// 
			// changeParagraphLineSpacingItem1
			// 
			this.changeParagraphLineSpacingItem1.Id = 172;
			this.changeParagraphLineSpacingItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("changeParagraphLineSpacingItem1.ImageOptions.Image")));
			this.changeParagraphLineSpacingItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("changeParagraphLineSpacingItem1.ImageOptions.LargeImage")));
			this.changeParagraphLineSpacingItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.setSingleParagraphSpacingItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setSesquialteralParagraphSpacingItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setDoubleParagraphSpacingItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.showLineSpacingFormItem1),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.KeyTip, this.addSpacingBeforeParagraphItem1, "", false, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.Standard, "B", ""),
            new DevExpress.XtraBars.LinkPersistInfo(this.removeSpacingBeforeParagraphItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.addSpacingAfterParagraphItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.removeSpacingAfterParagraphItem1)});
			this.changeParagraphLineSpacingItem1.Name = "changeParagraphLineSpacingItem1";
			// 
			// setSingleParagraphSpacingItem1
			// 
			this.setSingleParagraphSpacingItem1.Id = 173;
			this.setSingleParagraphSpacingItem1.Name = "setSingleParagraphSpacingItem1";
			// 
			// setSesquialteralParagraphSpacingItem1
			// 
			this.setSesquialteralParagraphSpacingItem1.Id = 174;
			this.setSesquialteralParagraphSpacingItem1.Name = "setSesquialteralParagraphSpacingItem1";
			// 
			// setDoubleParagraphSpacingItem1
			// 
			this.setDoubleParagraphSpacingItem1.Id = 175;
			this.setDoubleParagraphSpacingItem1.Name = "setDoubleParagraphSpacingItem1";
			// 
			// showLineSpacingFormItem1
			// 
			this.showLineSpacingFormItem1.Id = 176;
			this.showLineSpacingFormItem1.Name = "showLineSpacingFormItem1";
			// 
			// addSpacingBeforeParagraphItem1
			// 
			this.addSpacingBeforeParagraphItem1.Id = 177;
			this.addSpacingBeforeParagraphItem1.Name = "addSpacingBeforeParagraphItem1";
			// 
			// removeSpacingBeforeParagraphItem1
			// 
			this.removeSpacingBeforeParagraphItem1.Id = 178;
			this.removeSpacingBeforeParagraphItem1.Name = "removeSpacingBeforeParagraphItem1";
			// 
			// addSpacingAfterParagraphItem1
			// 
			this.addSpacingAfterParagraphItem1.Id = 179;
			this.addSpacingAfterParagraphItem1.Name = "addSpacingAfterParagraphItem1";
			// 
			// removeSpacingAfterParagraphItem1
			// 
			this.removeSpacingAfterParagraphItem1.Id = 180;
			this.removeSpacingAfterParagraphItem1.Name = "removeSpacingAfterParagraphItem1";
			// 
			// pasteSpecialItem1
			// 
			this.pasteSpecialItem1.Id = 8;
			this.pasteSpecialItem1.Name = "pasteSpecialItem1";
			// 
			// barButtonGroup1
			// 
			this.barButtonGroup1.Id = 1;
			this.barButtonGroup1.ItemLinks.Add(this.changeFontNameItem1, "FF");
			this.barButtonGroup1.ItemLinks.Add(this.changeFontSizeItem1);
			this.barButtonGroup1.ItemLinks.Add(this.fontSizeIncreaseItem1, "FG");
			this.barButtonGroup1.ItemLinks.Add(this.fontSizeDecreaseItem1, "FK");
			this.barButtonGroup1.Name = "barButtonGroup1";
			this.barButtonGroup1.Tag = "{97BBE334-159B-44d9-A168-0411957565E8}";
			// 
			// barButtonGroup2
			// 
			this.barButtonGroup2.Id = 2;
			this.barButtonGroup2.ItemLinks.Add(this.toggleFontBoldItem1);
			this.barButtonGroup2.ItemLinks.Add(this.toggleFontItalicItem1);
			this.barButtonGroup2.ItemLinks.Add(this.toggleFontUnderlineItem1);
			this.barButtonGroup2.ItemLinks.Add(this.toggleFontDoubleUnderlineItem1);
			this.barButtonGroup2.ItemLinks.Add(this.toggleFontStrikeoutItem1);
			this.barButtonGroup2.ItemLinks.Add(this.toggleFontDoubleStrikeoutItem1);
			this.barButtonGroup2.ItemLinks.Add(this.toggleFontSuperscriptItem1);
			this.barButtonGroup2.ItemLinks.Add(this.toggleFontSubscriptItem1);
			this.barButtonGroup2.Name = "barButtonGroup2";
			this.barButtonGroup2.Tag = "{433DA7F0-03E2-4650-9DB5-66DD92D16E39}";
			// 
			// barButtonGroup3
			// 
			this.barButtonGroup3.Id = 3;
			this.barButtonGroup3.ItemLinks.Add(this.changeFontColorItem1, "FC");
			this.barButtonGroup3.ItemLinks.Add(this.changeFontBackColorItem1, "I");
			this.barButtonGroup3.Name = "barButtonGroup3";
			this.barButtonGroup3.Tag = "{DF8C5334-EDE3-47c9-A42C-FE9A9247E180}";
			// 
			// barButtonGroup4
			// 
			this.barButtonGroup4.Id = 4;
			this.barButtonGroup4.ItemLinks.Add(this.toggleBulletedListItem1, "U");
			this.barButtonGroup4.ItemLinks.Add(this.toggleNumberingListItem1, "N");
			this.barButtonGroup4.ItemLinks.Add(this.toggleMultiLevelListItem1, "M");
			this.barButtonGroup4.Name = "barButtonGroup4";
			this.barButtonGroup4.Tag = "{0B3A7A43-3079-4ce0-83A8-3789F5F6DC9F}";
			// 
			// barButtonGroup5
			// 
			this.barButtonGroup5.Id = 5;
			this.barButtonGroup5.ItemLinks.Add(this.decreaseIndentItem1, "AO");
			this.barButtonGroup5.ItemLinks.Add(this.increaseIndentItem1, "AI");
			this.barButtonGroup5.ItemLinks.Add(this.toggleShowWhitespaceItem1);
			this.barButtonGroup5.Name = "barButtonGroup5";
			this.barButtonGroup5.Tag = "{4747D5AB-2BEB-4ea6-9A1D-8E4FB36F1B40}";
			// 
			// barButtonGroup6
			// 
			this.barButtonGroup6.Id = 6;
			this.barButtonGroup6.ItemLinks.Add(this.toggleParagraphAlignmentLeftItem1, "AL");
			this.barButtonGroup6.ItemLinks.Add(this.toggleParagraphAlignmentCenterItem1, "AC");
			this.barButtonGroup6.ItemLinks.Add(this.toggleParagraphAlignmentRightItem1, "AR");
			this.barButtonGroup6.ItemLinks.Add(this.toggleParagraphAlignmentJustifyItem1, "AJ");
			this.barButtonGroup6.Name = "barButtonGroup6";
			this.barButtonGroup6.Tag = "{8E89E775-996E-49a0-AADA-DE338E34732E}";
			// 
			// barButtonGroup7
			// 
			this.barButtonGroup7.Id = 7;
			this.barButtonGroup7.ItemLinks.Add(this.changeParagraphLineSpacingItem1, "K");
			this.barButtonGroup7.ItemLinks.Add(this.changeParagraphBackColorItem1, "H");
			this.barButtonGroup7.Name = "barButtonGroup7";
			this.barButtonGroup7.Tag = "{9A8DEAD8-3890-4857-A395-EC625FD02217}";
			// 
			// changeParagraphBackColorItem1
			// 
			this.changeParagraphBackColorItem1.Id = 9;
			this.changeParagraphBackColorItem1.Name = "changeParagraphBackColorItem1";
			// 
			// galleryChangeStyleItem1
			// 
			// 
			// 
			// 
			this.galleryChangeStyleItem1.Gallery.ColumnCount = 10;
			this.galleryChangeStyleItem1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup1});
			this.galleryChangeStyleItem1.Gallery.ImageSize = new System.Drawing.Size(65, 46);
			this.galleryChangeStyleItem1.Id = 10;
			this.galleryChangeStyleItem1.Name = "galleryChangeStyleItem1";
			// 
			// insertFloatingPictureItem1
			// 
			this.insertFloatingPictureItem1.Id = 11;
			this.insertFloatingPictureItem1.Name = "insertFloatingPictureItem1";
			// 
			// insertTextBoxItem1
			// 
			this.insertTextBoxItem1.Id = 12;
			this.insertTextBoxItem1.Name = "insertTextBoxItem1";
			// 
			// changeSectionPageMarginsItem1
			// 
			this.changeSectionPageMarginsItem1.Id = 13;
			this.changeSectionPageMarginsItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.setNormalSectionPageMarginsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setNarrowSectionPageMarginsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setModerateSectionPageMarginsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setWideSectionPageMarginsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.showPageMarginsSetupFormItem1)});
			this.changeSectionPageMarginsItem1.Name = "changeSectionPageMarginsItem1";
			// 
			// setNormalSectionPageMarginsItem1
			// 
			this.setNormalSectionPageMarginsItem1.Id = 14;
			this.setNormalSectionPageMarginsItem1.Name = "setNormalSectionPageMarginsItem1";
			// 
			// setNarrowSectionPageMarginsItem1
			// 
			this.setNarrowSectionPageMarginsItem1.Id = 15;
			this.setNarrowSectionPageMarginsItem1.Name = "setNarrowSectionPageMarginsItem1";
			// 
			// setModerateSectionPageMarginsItem1
			// 
			this.setModerateSectionPageMarginsItem1.Id = 16;
			this.setModerateSectionPageMarginsItem1.Name = "setModerateSectionPageMarginsItem1";
			// 
			// setWideSectionPageMarginsItem1
			// 
			this.setWideSectionPageMarginsItem1.Id = 17;
			this.setWideSectionPageMarginsItem1.Name = "setWideSectionPageMarginsItem1";
			// 
			// showPageMarginsSetupFormItem1
			// 
			this.showPageMarginsSetupFormItem1.Id = 18;
			this.showPageMarginsSetupFormItem1.Name = "showPageMarginsSetupFormItem1";
			// 
			// changeSectionPageOrientationItem1
			// 
			this.changeSectionPageOrientationItem1.Id = 19;
			this.changeSectionPageOrientationItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.setPortraitPageOrientationItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setLandscapePageOrientationItem1)});
			this.changeSectionPageOrientationItem1.Name = "changeSectionPageOrientationItem1";
			// 
			// setPortraitPageOrientationItem1
			// 
			this.setPortraitPageOrientationItem1.Id = 20;
			this.setPortraitPageOrientationItem1.Name = "setPortraitPageOrientationItem1";
			// 
			// setLandscapePageOrientationItem1
			// 
			this.setLandscapePageOrientationItem1.Id = 21;
			this.setLandscapePageOrientationItem1.Name = "setLandscapePageOrientationItem1";
			// 
			// changeSectionPaperKindItem1
			// 
			this.changeSectionPaperKindItem1.Id = 22;
			this.changeSectionPaperKindItem1.Name = "changeSectionPaperKindItem1";
			// 
			// changeSectionColumnsItem1
			// 
			this.changeSectionColumnsItem1.Id = 23;
			this.changeSectionColumnsItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.setSectionOneColumnItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setSectionTwoColumnsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setSectionThreeColumnsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.showColumnsSetupFormItem1)});
			this.changeSectionColumnsItem1.Name = "changeSectionColumnsItem1";
			// 
			// setSectionOneColumnItem1
			// 
			this.setSectionOneColumnItem1.Id = 24;
			this.setSectionOneColumnItem1.Name = "setSectionOneColumnItem1";
			// 
			// setSectionTwoColumnsItem1
			// 
			this.setSectionTwoColumnsItem1.Id = 25;
			this.setSectionTwoColumnsItem1.Name = "setSectionTwoColumnsItem1";
			// 
			// setSectionThreeColumnsItem1
			// 
			this.setSectionThreeColumnsItem1.Id = 26;
			this.setSectionThreeColumnsItem1.Name = "setSectionThreeColumnsItem1";
			// 
			// showColumnsSetupFormItem1
			// 
			this.showColumnsSetupFormItem1.Id = 27;
			this.showColumnsSetupFormItem1.Name = "showColumnsSetupFormItem1";
			// 
			// insertBreakItem1
			// 
			this.insertBreakItem1.Id = 28;
			this.insertBreakItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.KeyTip, this.insertPageBreakItem1, "", false, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.Standard, "B", ""),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertColumnBreakItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertSectionBreakNextPageItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertSectionBreakEvenPageItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertSectionBreakOddPageItem1)});
			this.insertBreakItem1.Name = "insertBreakItem1";
			// 
			// insertColumnBreakItem1
			// 
			this.insertColumnBreakItem1.Id = 29;
			this.insertColumnBreakItem1.Name = "insertColumnBreakItem1";
			// 
			// insertSectionBreakNextPageItem1
			// 
			this.insertSectionBreakNextPageItem1.Id = 30;
			this.insertSectionBreakNextPageItem1.Name = "insertSectionBreakNextPageItem1";
			// 
			// insertSectionBreakEvenPageItem1
			// 
			this.insertSectionBreakEvenPageItem1.Id = 31;
			this.insertSectionBreakEvenPageItem1.Name = "insertSectionBreakEvenPageItem1";
			// 
			// insertSectionBreakOddPageItem1
			// 
			this.insertSectionBreakOddPageItem1.Id = 32;
			this.insertSectionBreakOddPageItem1.Name = "insertSectionBreakOddPageItem1";
			// 
			// changeSectionLineNumberingItem1
			// 
			this.changeSectionLineNumberingItem1.Id = 33;
			this.changeSectionLineNumberingItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.setSectionLineNumberingNoneItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setSectionLineNumberingContinuousItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setSectionLineNumberingRestartNewPageItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setSectionLineNumberingRestartNewSectionItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleParagraphSuppressLineNumbersItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.showLineNumberingFormItem1)});
			this.changeSectionLineNumberingItem1.Name = "changeSectionLineNumberingItem1";
			// 
			// setSectionLineNumberingNoneItem1
			// 
			this.setSectionLineNumberingNoneItem1.Id = 34;
			this.setSectionLineNumberingNoneItem1.Name = "setSectionLineNumberingNoneItem1";
			// 
			// setSectionLineNumberingContinuousItem1
			// 
			this.setSectionLineNumberingContinuousItem1.Id = 35;
			this.setSectionLineNumberingContinuousItem1.Name = "setSectionLineNumberingContinuousItem1";
			// 
			// setSectionLineNumberingRestartNewPageItem1
			// 
			this.setSectionLineNumberingRestartNewPageItem1.Id = 36;
			this.setSectionLineNumberingRestartNewPageItem1.Name = "setSectionLineNumberingRestartNewPageItem1";
			// 
			// setSectionLineNumberingRestartNewSectionItem1
			// 
			this.setSectionLineNumberingRestartNewSectionItem1.Id = 37;
			this.setSectionLineNumberingRestartNewSectionItem1.Name = "setSectionLineNumberingRestartNewSectionItem1";
			// 
			// toggleParagraphSuppressLineNumbersItem1
			// 
			this.toggleParagraphSuppressLineNumbersItem1.Id = 38;
			this.toggleParagraphSuppressLineNumbersItem1.Name = "toggleParagraphSuppressLineNumbersItem1";
			// 
			// showLineNumberingFormItem1
			// 
			this.showLineNumberingFormItem1.Id = 39;
			this.showLineNumberingFormItem1.Name = "showLineNumberingFormItem1";
			// 
			// changePageColorItem1
			// 
			this.changePageColorItem1.Id = 40;
			this.changePageColorItem1.Name = "changePageColorItem1";
			// 
			// insertTableOfContentsItem1
			// 
			this.insertTableOfContentsItem1.Id = 41;
			this.insertTableOfContentsItem1.Name = "insertTableOfContentsItem1";
			// 
			// updateTableOfContentsItem1
			// 
			this.updateTableOfContentsItem1.Id = 42;
			this.updateTableOfContentsItem1.Name = "updateTableOfContentsItem1";
			// 
			// addParagraphsToTableOfContentItem1
			// 
			this.addParagraphsToTableOfContentItem1.Id = 43;
			this.addParagraphsToTableOfContentItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.setParagraphHeadingLevelItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setParagraphHeadingLevelItem2),
            new DevExpress.XtraBars.LinkPersistInfo(this.setParagraphHeadingLevelItem3),
            new DevExpress.XtraBars.LinkPersistInfo(this.setParagraphHeadingLevelItem4),
            new DevExpress.XtraBars.LinkPersistInfo(this.setParagraphHeadingLevelItem5),
            new DevExpress.XtraBars.LinkPersistInfo(this.setParagraphHeadingLevelItem6),
            new DevExpress.XtraBars.LinkPersistInfo(this.setParagraphHeadingLevelItem7),
            new DevExpress.XtraBars.LinkPersistInfo(this.setParagraphHeadingLevelItem8),
            new DevExpress.XtraBars.LinkPersistInfo(this.setParagraphHeadingLevelItem9),
            new DevExpress.XtraBars.LinkPersistInfo(this.setParagraphHeadingLevelItem10)});
			this.addParagraphsToTableOfContentItem1.Name = "addParagraphsToTableOfContentItem1";
			// 
			// setParagraphHeadingLevelItem1
			// 
			this.setParagraphHeadingLevelItem1.Id = 44;
			this.setParagraphHeadingLevelItem1.Name = "setParagraphHeadingLevelItem1";
			this.setParagraphHeadingLevelItem1.OutlineLevel = 0;
			// 
			// setParagraphHeadingLevelItem2
			// 
			this.setParagraphHeadingLevelItem2.Id = 45;
			this.setParagraphHeadingLevelItem2.Name = "setParagraphHeadingLevelItem2";
			this.setParagraphHeadingLevelItem2.OutlineLevel = 1;
			// 
			// setParagraphHeadingLevelItem3
			// 
			this.setParagraphHeadingLevelItem3.Id = 46;
			this.setParagraphHeadingLevelItem3.Name = "setParagraphHeadingLevelItem3";
			this.setParagraphHeadingLevelItem3.OutlineLevel = 2;
			// 
			// setParagraphHeadingLevelItem4
			// 
			this.setParagraphHeadingLevelItem4.Id = 47;
			this.setParagraphHeadingLevelItem4.Name = "setParagraphHeadingLevelItem4";
			this.setParagraphHeadingLevelItem4.OutlineLevel = 3;
			// 
			// setParagraphHeadingLevelItem5
			// 
			this.setParagraphHeadingLevelItem5.Id = 48;
			this.setParagraphHeadingLevelItem5.Name = "setParagraphHeadingLevelItem5";
			this.setParagraphHeadingLevelItem5.OutlineLevel = 4;
			// 
			// setParagraphHeadingLevelItem6
			// 
			this.setParagraphHeadingLevelItem6.Id = 49;
			this.setParagraphHeadingLevelItem6.Name = "setParagraphHeadingLevelItem6";
			this.setParagraphHeadingLevelItem6.OutlineLevel = 5;
			// 
			// setParagraphHeadingLevelItem7
			// 
			this.setParagraphHeadingLevelItem7.Id = 50;
			this.setParagraphHeadingLevelItem7.Name = "setParagraphHeadingLevelItem7";
			this.setParagraphHeadingLevelItem7.OutlineLevel = 6;
			// 
			// setParagraphHeadingLevelItem8
			// 
			this.setParagraphHeadingLevelItem8.Id = 51;
			this.setParagraphHeadingLevelItem8.Name = "setParagraphHeadingLevelItem8";
			this.setParagraphHeadingLevelItem8.OutlineLevel = 7;
			// 
			// setParagraphHeadingLevelItem9
			// 
			this.setParagraphHeadingLevelItem9.Id = 52;
			this.setParagraphHeadingLevelItem9.Name = "setParagraphHeadingLevelItem9";
			this.setParagraphHeadingLevelItem9.OutlineLevel = 8;
			// 
			// setParagraphHeadingLevelItem10
			// 
			this.setParagraphHeadingLevelItem10.Id = 53;
			this.setParagraphHeadingLevelItem10.Name = "setParagraphHeadingLevelItem10";
			this.setParagraphHeadingLevelItem10.OutlineLevel = 9;
			// 
			// insertCaptionPlaceholderItem1
			// 
			this.insertCaptionPlaceholderItem1.Id = 54;
			this.insertCaptionPlaceholderItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.insertFiguresCaptionItems1),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertTablesCaptionItems1),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertEquationsCaptionItems1)});
			this.insertCaptionPlaceholderItem1.Name = "insertCaptionPlaceholderItem1";
			// 
			// insertFiguresCaptionItems1
			// 
			this.insertFiguresCaptionItems1.Id = 55;
			this.insertFiguresCaptionItems1.Name = "insertFiguresCaptionItems1";
			// 
			// insertTablesCaptionItems1
			// 
			this.insertTablesCaptionItems1.Id = 56;
			this.insertTablesCaptionItems1.Name = "insertTablesCaptionItems1";
			// 
			// insertEquationsCaptionItems1
			// 
			this.insertEquationsCaptionItems1.Id = 57;
			this.insertEquationsCaptionItems1.Name = "insertEquationsCaptionItems1";
			// 
			// insertTableOfFiguresPlaceholderItem1
			// 
			this.insertTableOfFiguresPlaceholderItem1.Id = 58;
			this.insertTableOfFiguresPlaceholderItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.insertTableOfFiguresItems1),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertTableOfTablesItems1),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertTableOfEquationsItems1)});
			this.insertTableOfFiguresPlaceholderItem1.Name = "insertTableOfFiguresPlaceholderItem1";
			// 
			// insertTableOfFiguresItems1
			// 
			this.insertTableOfFiguresItems1.Id = 59;
			this.insertTableOfFiguresItems1.Name = "insertTableOfFiguresItems1";
			// 
			// insertTableOfTablesItems1
			// 
			this.insertTableOfTablesItems1.Id = 60;
			this.insertTableOfTablesItems1.Name = "insertTableOfTablesItems1";
			// 
			// insertTableOfEquationsItems1
			// 
			this.insertTableOfEquationsItems1.Id = 61;
			this.insertTableOfEquationsItems1.Name = "insertTableOfEquationsItems1";
			// 
			// insertMergeFieldItem1
			// 
			this.insertMergeFieldItem1.Id = 62;
			this.insertMergeFieldItem1.Name = "insertMergeFieldItem1";
			// 
			// showAllFieldCodesItem1
			// 
			this.showAllFieldCodesItem1.Id = 63;
			this.showAllFieldCodesItem1.Name = "showAllFieldCodesItem1";
			// 
			// showAllFieldResultsItem1
			// 
			this.showAllFieldResultsItem1.Id = 64;
			this.showAllFieldResultsItem1.Name = "showAllFieldResultsItem1";
			// 
			// toggleViewMergedDataItem1
			// 
			this.toggleViewMergedDataItem1.Id = 65;
			this.toggleViewMergedDataItem1.Name = "toggleViewMergedDataItem1";
			// 
			// checkSpellingItem1
			// 
			this.checkSpellingItem1.Id = 66;
			this.checkSpellingItem1.Name = "checkSpellingItem1";
			// 
			// protectDocumentItem1
			// 
			this.protectDocumentItem1.Id = 67;
			this.protectDocumentItem1.Name = "protectDocumentItem1";
			// 
			// changeRangeEditingPermissionsItem1
			// 
			this.changeRangeEditingPermissionsItem1.Id = 68;
			this.changeRangeEditingPermissionsItem1.Name = "changeRangeEditingPermissionsItem1";
			// 
			// unprotectDocumentItem1
			// 
			this.unprotectDocumentItem1.Id = 69;
			this.unprotectDocumentItem1.Name = "unprotectDocumentItem1";
			// 
			// toggleShowHorizontalRulerItem1
			// 
			this.toggleShowHorizontalRulerItem1.Id = 70;
			this.toggleShowHorizontalRulerItem1.Name = "toggleShowHorizontalRulerItem1";
			// 
			// toggleShowVerticalRulerItem1
			// 
			this.toggleShowVerticalRulerItem1.Id = 71;
			this.toggleShowVerticalRulerItem1.Name = "toggleShowVerticalRulerItem1";
			// 
			// goToPageHeaderItem1
			// 
			this.goToPageHeaderItem1.Id = 72;
			this.goToPageHeaderItem1.Name = "goToPageHeaderItem1";
			// 
			// goToPageFooterItem1
			// 
			this.goToPageFooterItem1.Id = 73;
			this.goToPageFooterItem1.Name = "goToPageFooterItem1";
			// 
			// goToNextHeaderFooterItem1
			// 
			this.goToNextHeaderFooterItem1.Id = 74;
			this.goToNextHeaderFooterItem1.Name = "goToNextHeaderFooterItem1";
			// 
			// goToPreviousHeaderFooterItem1
			// 
			this.goToPreviousHeaderFooterItem1.Id = 75;
			this.goToPreviousHeaderFooterItem1.Name = "goToPreviousHeaderFooterItem1";
			// 
			// toggleLinkToPreviousItem1
			// 
			this.toggleLinkToPreviousItem1.Id = 76;
			this.toggleLinkToPreviousItem1.Name = "toggleLinkToPreviousItem1";
			// 
			// toggleDifferentFirstPageItem1
			// 
			this.toggleDifferentFirstPageItem1.Id = 77;
			this.toggleDifferentFirstPageItem1.Name = "toggleDifferentFirstPageItem1";
			// 
			// toggleDifferentOddAndEvenPagesItem1
			// 
			this.toggleDifferentOddAndEvenPagesItem1.Id = 78;
			this.toggleDifferentOddAndEvenPagesItem1.Name = "toggleDifferentOddAndEvenPagesItem1";
			// 
			// closePageHeaderFooterItem1
			// 
			this.closePageHeaderFooterItem1.Id = 79;
			this.closePageHeaderFooterItem1.Name = "closePageHeaderFooterItem1";
			// 
			// showTablePropertiesFormItem1
			// 
			this.showTablePropertiesFormItem1.Id = 80;
			this.showTablePropertiesFormItem1.Name = "showTablePropertiesFormItem1";
			// 
			// toggleTableAutoFitItem1
			// 
			this.toggleTableAutoFitItem1.Id = 81;
			this.toggleTableAutoFitItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableAutoFitContentsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableAutoFitWindowItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleTableFixedColumnWidthItem1)});
			this.toggleTableAutoFitItem1.Name = "toggleTableAutoFitItem1";
			// 
			// toggleTableAutoFitContentsItem1
			// 
			this.toggleTableAutoFitContentsItem1.Id = 82;
			this.toggleTableAutoFitContentsItem1.Name = "toggleTableAutoFitContentsItem1";
			// 
			// toggleTableAutoFitWindowItem1
			// 
			this.toggleTableAutoFitWindowItem1.Id = 83;
			this.toggleTableAutoFitWindowItem1.Name = "toggleTableAutoFitWindowItem1";
			// 
			// toggleTableFixedColumnWidthItem1
			// 
			this.toggleTableFixedColumnWidthItem1.Id = 84;
			this.toggleTableFixedColumnWidthItem1.Name = "toggleTableFixedColumnWidthItem1";
			// 
			// showTableOptionsFormItem1
			// 
			this.showTableOptionsFormItem1.Id = 85;
			this.showTableOptionsFormItem1.Name = "showTableOptionsFormItem1";
			// 
			// changeFloatingObjectFillColorItem1
			// 
			this.changeFloatingObjectFillColorItem1.Id = 86;
			this.changeFloatingObjectFillColorItem1.Name = "changeFloatingObjectFillColorItem1";
			// 
			// changeFloatingObjectOutlineColorItem1
			// 
			this.changeFloatingObjectOutlineColorItem1.Id = 87;
			this.changeFloatingObjectOutlineColorItem1.Name = "changeFloatingObjectOutlineColorItem1";
			// 
			// changeFloatingObjectOutlineWeightItem1
			// 
			this.changeFloatingObjectOutlineWeightItem1.Edit = this.repositoryItemFloatingObjectOutlineWeight1;
			this.changeFloatingObjectOutlineWeightItem1.EditValue = 20;
			this.changeFloatingObjectOutlineWeightItem1.Id = 88;
			this.changeFloatingObjectOutlineWeightItem1.Name = "changeFloatingObjectOutlineWeightItem1";
			// 
			// repositoryItemFloatingObjectOutlineWeight1
			// 
			this.repositoryItemFloatingObjectOutlineWeight1.AutoHeight = false;
			this.repositoryItemFloatingObjectOutlineWeight1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
			this.repositoryItemFloatingObjectOutlineWeight1.Control = this.txtContent;
			this.repositoryItemFloatingObjectOutlineWeight1.Name = "repositoryItemFloatingObjectOutlineWeight1";
			// 
			// changeFloatingObjectTextWrapTypeItem1
			// 
			this.changeFloatingObjectTextWrapTypeItem1.Id = 89;
			this.changeFloatingObjectTextWrapTypeItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectSquareTextWrapTypeItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectTightTextWrapTypeItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectThroughTextWrapTypeItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectTopAndBottomTextWrapTypeItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectBehindTextWrapTypeItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectInFrontOfTextWrapTypeItem1)});
			this.changeFloatingObjectTextWrapTypeItem1.Name = "changeFloatingObjectTextWrapTypeItem1";
			// 
			// setFloatingObjectSquareTextWrapTypeItem1
			// 
			this.setFloatingObjectSquareTextWrapTypeItem1.Id = 90;
			this.setFloatingObjectSquareTextWrapTypeItem1.Name = "setFloatingObjectSquareTextWrapTypeItem1";
			// 
			// setFloatingObjectTightTextWrapTypeItem1
			// 
			this.setFloatingObjectTightTextWrapTypeItem1.Id = 91;
			this.setFloatingObjectTightTextWrapTypeItem1.Name = "setFloatingObjectTightTextWrapTypeItem1";
			// 
			// setFloatingObjectThroughTextWrapTypeItem1
			// 
			this.setFloatingObjectThroughTextWrapTypeItem1.Id = 92;
			this.setFloatingObjectThroughTextWrapTypeItem1.Name = "setFloatingObjectThroughTextWrapTypeItem1";
			// 
			// setFloatingObjectTopAndBottomTextWrapTypeItem1
			// 
			this.setFloatingObjectTopAndBottomTextWrapTypeItem1.Id = 93;
			this.setFloatingObjectTopAndBottomTextWrapTypeItem1.Name = "setFloatingObjectTopAndBottomTextWrapTypeItem1";
			// 
			// setFloatingObjectBehindTextWrapTypeItem1
			// 
			this.setFloatingObjectBehindTextWrapTypeItem1.Id = 94;
			this.setFloatingObjectBehindTextWrapTypeItem1.Name = "setFloatingObjectBehindTextWrapTypeItem1";
			// 
			// setFloatingObjectInFrontOfTextWrapTypeItem1
			// 
			this.setFloatingObjectInFrontOfTextWrapTypeItem1.Id = 95;
			this.setFloatingObjectInFrontOfTextWrapTypeItem1.Name = "setFloatingObjectInFrontOfTextWrapTypeItem1";
			// 
			// changeFloatingObjectAlignmentItem1
			// 
			this.changeFloatingObjectAlignmentItem1.Id = 96;
			this.changeFloatingObjectAlignmentItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectTopLeftAlignmentItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectTopCenterAlignmentItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectTopRightAlignmentItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectMiddleLeftAlignmentItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectMiddleCenterAlignmentItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectMiddleRightAlignmentItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectBottomLeftAlignmentItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectBottomCenterAlignmentItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setFloatingObjectBottomRightAlignmentItem1)});
			this.changeFloatingObjectAlignmentItem1.Name = "changeFloatingObjectAlignmentItem1";
			// 
			// setFloatingObjectTopLeftAlignmentItem1
			// 
			this.setFloatingObjectTopLeftAlignmentItem1.Id = 97;
			this.setFloatingObjectTopLeftAlignmentItem1.Name = "setFloatingObjectTopLeftAlignmentItem1";
			// 
			// setFloatingObjectTopCenterAlignmentItem1
			// 
			this.setFloatingObjectTopCenterAlignmentItem1.Id = 98;
			this.setFloatingObjectTopCenterAlignmentItem1.Name = "setFloatingObjectTopCenterAlignmentItem1";
			// 
			// setFloatingObjectTopRightAlignmentItem1
			// 
			this.setFloatingObjectTopRightAlignmentItem1.Id = 99;
			this.setFloatingObjectTopRightAlignmentItem1.Name = "setFloatingObjectTopRightAlignmentItem1";
			// 
			// setFloatingObjectMiddleLeftAlignmentItem1
			// 
			this.setFloatingObjectMiddleLeftAlignmentItem1.Id = 100;
			this.setFloatingObjectMiddleLeftAlignmentItem1.Name = "setFloatingObjectMiddleLeftAlignmentItem1";
			// 
			// setFloatingObjectMiddleCenterAlignmentItem1
			// 
			this.setFloatingObjectMiddleCenterAlignmentItem1.Id = 101;
			this.setFloatingObjectMiddleCenterAlignmentItem1.Name = "setFloatingObjectMiddleCenterAlignmentItem1";
			// 
			// setFloatingObjectMiddleRightAlignmentItem1
			// 
			this.setFloatingObjectMiddleRightAlignmentItem1.Id = 102;
			this.setFloatingObjectMiddleRightAlignmentItem1.Name = "setFloatingObjectMiddleRightAlignmentItem1";
			// 
			// setFloatingObjectBottomLeftAlignmentItem1
			// 
			this.setFloatingObjectBottomLeftAlignmentItem1.Id = 103;
			this.setFloatingObjectBottomLeftAlignmentItem1.Name = "setFloatingObjectBottomLeftAlignmentItem1";
			// 
			// setFloatingObjectBottomCenterAlignmentItem1
			// 
			this.setFloatingObjectBottomCenterAlignmentItem1.Id = 104;
			this.setFloatingObjectBottomCenterAlignmentItem1.Name = "setFloatingObjectBottomCenterAlignmentItem1";
			// 
			// setFloatingObjectBottomRightAlignmentItem1
			// 
			this.setFloatingObjectBottomRightAlignmentItem1.Id = 105;
			this.setFloatingObjectBottomRightAlignmentItem1.Name = "setFloatingObjectBottomRightAlignmentItem1";
			// 
			// floatingObjectBringForwardSubItem1
			// 
			this.floatingObjectBringForwardSubItem1.Id = 106;
			this.floatingObjectBringForwardSubItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.floatingObjectBringForwardItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.floatingObjectBringToFrontItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.floatingObjectBringInFrontOfTextItem1)});
			this.floatingObjectBringForwardSubItem1.Name = "floatingObjectBringForwardSubItem1";
			// 
			// floatingObjectBringForwardItem1
			// 
			this.floatingObjectBringForwardItem1.Id = 107;
			this.floatingObjectBringForwardItem1.Name = "floatingObjectBringForwardItem1";
			// 
			// floatingObjectBringToFrontItem1
			// 
			this.floatingObjectBringToFrontItem1.Id = 108;
			this.floatingObjectBringToFrontItem1.Name = "floatingObjectBringToFrontItem1";
			// 
			// floatingObjectBringInFrontOfTextItem1
			// 
			this.floatingObjectBringInFrontOfTextItem1.Id = 109;
			this.floatingObjectBringInFrontOfTextItem1.Name = "floatingObjectBringInFrontOfTextItem1";
			// 
			// floatingObjectSendBackwardSubItem1
			// 
			this.floatingObjectSendBackwardSubItem1.Id = 110;
			this.floatingObjectSendBackwardSubItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.floatingObjectSendBackwardItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.floatingObjectSendToBackItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.floatingObjectSendBehindTextItem1)});
			this.floatingObjectSendBackwardSubItem1.Name = "floatingObjectSendBackwardSubItem1";
			// 
			// floatingObjectSendBackwardItem1
			// 
			this.floatingObjectSendBackwardItem1.Id = 111;
			this.floatingObjectSendBackwardItem1.Name = "floatingObjectSendBackwardItem1";
			// 
			// floatingObjectSendToBackItem1
			// 
			this.floatingObjectSendToBackItem1.Id = 112;
			this.floatingObjectSendToBackItem1.Name = "floatingObjectSendToBackItem1";
			// 
			// floatingObjectSendBehindTextItem1
			// 
			this.floatingObjectSendBehindTextItem1.Id = 113;
			this.floatingObjectSendBehindTextItem1.Name = "floatingObjectSendBehindTextItem1";
			// 
			// itemSave
			// 
			this.itemSave.Caption = "Lưu biểu mẫu";
			this.itemSave.Id = 114;
			this.itemSave.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemSave.ImageOptions.Image")));
			this.itemSave.ImageOptions.ImageIndex = 2;
			this.itemSave.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemSave.ImageOptions.LargeImage")));
			this.itemSave.Name = "itemSave";
			this.itemSave.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLuu_ItemClick);
			// 
			// headerFooterToolsRibbonPageCategory1
			// 
			this.headerFooterToolsRibbonPageCategory1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(176)))), ((int)(((byte)(35)))));
			this.headerFooterToolsRibbonPageCategory1.Control = this.txtContent;
			this.headerFooterToolsRibbonPageCategory1.Name = "headerFooterToolsRibbonPageCategory1";
			this.headerFooterToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.headerFooterToolsDesignRibbonPage1});
			// 
			// headerFooterToolsDesignRibbonPage1
			// 
			this.headerFooterToolsDesignRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.headerFooterToolsDesignNavigationRibbonPageGroup1,
            this.headerFooterToolsDesignOptionsRibbonPageGroup1,
            this.headerFooterToolsDesignCloseRibbonPageGroup1});
			this.headerFooterToolsDesignRibbonPage1.Name = "headerFooterToolsDesignRibbonPage1";
			// 
			// headerFooterToolsDesignNavigationRibbonPageGroup1
			// 
			this.headerFooterToolsDesignNavigationRibbonPageGroup1.ItemLinks.Add(this.goToPageHeaderItem1, "E");
			this.headerFooterToolsDesignNavigationRibbonPageGroup1.ItemLinks.Add(this.goToPageFooterItem1, "G");
			this.headerFooterToolsDesignNavigationRibbonPageGroup1.ItemLinks.Add(this.goToNextHeaderFooterItem1, "X");
			this.headerFooterToolsDesignNavigationRibbonPageGroup1.ItemLinks.Add(this.goToPreviousHeaderFooterItem1, "R");
			this.headerFooterToolsDesignNavigationRibbonPageGroup1.ItemLinks.Add(this.toggleLinkToPreviousItem1, "K");
			this.headerFooterToolsDesignNavigationRibbonPageGroup1.Name = "headerFooterToolsDesignNavigationRibbonPageGroup1";
			// 
			// headerFooterToolsDesignOptionsRibbonPageGroup1
			// 
			this.headerFooterToolsDesignOptionsRibbonPageGroup1.ItemLinks.Add(this.toggleDifferentFirstPageItem1, "A");
			this.headerFooterToolsDesignOptionsRibbonPageGroup1.ItemLinks.Add(this.toggleDifferentOddAndEvenPagesItem1, "V");
			this.headerFooterToolsDesignOptionsRibbonPageGroup1.Name = "headerFooterToolsDesignOptionsRibbonPageGroup1";
			// 
			// headerFooterToolsDesignCloseRibbonPageGroup1
			// 
			this.headerFooterToolsDesignCloseRibbonPageGroup1.ItemLinks.Add(this.closePageHeaderFooterItem1, "C");
			this.headerFooterToolsDesignCloseRibbonPageGroup1.Name = "headerFooterToolsDesignCloseRibbonPageGroup1";
			// 
			// tableToolsRibbonPageCategory1
			// 
			this.tableToolsRibbonPageCategory1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(233)))), ((int)(((byte)(20)))));
			this.tableToolsRibbonPageCategory1.Control = this.txtContent;
			this.tableToolsRibbonPageCategory1.Name = "tableToolsRibbonPageCategory1";
			this.tableToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.tableDesignRibbonPage1,
            this.tableLayoutRibbonPage1});
			// 
			// tableDesignRibbonPage1
			// 
			this.tableDesignRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.tableStylesRibbonPageGroup1,
            this.tableDrawBordersRibbonPageGroup1});
			this.tableDesignRibbonPage1.Name = "tableDesignRibbonPage1";
			// 
			// tableStylesRibbonPageGroup1
			// 
			this.tableStylesRibbonPageGroup1.ItemLinks.Add(this.changeTableCellsShadingItem1, "H");
			this.tableStylesRibbonPageGroup1.ItemLinks.Add(this.changeTableBordersItem1, "B");
			this.tableStylesRibbonPageGroup1.Name = "tableStylesRibbonPageGroup1";
			// 
			// tableDrawBordersRibbonPageGroup1
			// 
			this.tableDrawBordersRibbonPageGroup1.ItemLinks.Add(this.changeTableBorderLineStyleItem1);
			this.tableDrawBordersRibbonPageGroup1.ItemLinks.Add(this.changeTableBorderLineWeightItem1);
			this.tableDrawBordersRibbonPageGroup1.ItemLinks.Add(this.changeTableBorderColorItem1, "C");
			this.tableDrawBordersRibbonPageGroup1.Name = "tableDrawBordersRibbonPageGroup1";
			// 
			// tableLayoutRibbonPage1
			// 
			this.tableLayoutRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.tableTableRibbonPageGroup1,
            this.tableRowsAndColumnsRibbonPageGroup1,
            this.tableMergeRibbonPageGroup1,
            this.tableCellSizeRibbonPageGroup1,
            this.tableAlignmentRibbonPageGroup1});
			this.tableLayoutRibbonPage1.Name = "tableLayoutRibbonPage1";
			// 
			// tableTableRibbonPageGroup1
			// 
			this.tableTableRibbonPageGroup1.ItemLinks.Add(this.selectTableElementsItem1, "K");
			this.tableTableRibbonPageGroup1.ItemLinks.Add(this.toggleShowTableGridLinesItem1, "TG");
			this.tableTableRibbonPageGroup1.ItemLinks.Add(this.showTablePropertiesFormItem1, "O");
			this.tableTableRibbonPageGroup1.Name = "tableTableRibbonPageGroup1";
			// 
			// tableRowsAndColumnsRibbonPageGroup1
			// 
			this.tableRowsAndColumnsRibbonPageGroup1.ItemLinks.Add(this.deleteTableElementsItem1, "D");
			this.tableRowsAndColumnsRibbonPageGroup1.ItemLinks.Add(this.insertTableRowAboveItem1, "A");
			this.tableRowsAndColumnsRibbonPageGroup1.ItemLinks.Add(this.insertTableRowBelowItem1, "E");
			this.tableRowsAndColumnsRibbonPageGroup1.ItemLinks.Add(this.insertTableColumnToLeftItem1, "L");
			this.tableRowsAndColumnsRibbonPageGroup1.ItemLinks.Add(this.insertTableColumnToRightItem1, "R");
			this.tableRowsAndColumnsRibbonPageGroup1.Name = "tableRowsAndColumnsRibbonPageGroup1";
			// 
			// tableMergeRibbonPageGroup1
			// 
			this.tableMergeRibbonPageGroup1.ItemLinks.Add(this.mergeTableCellsItem1, "M");
			this.tableMergeRibbonPageGroup1.ItemLinks.Add(this.showSplitTableCellsForm1, "P");
			this.tableMergeRibbonPageGroup1.ItemLinks.Add(this.splitTableItem1, "Q");
			this.tableMergeRibbonPageGroup1.Name = "tableMergeRibbonPageGroup1";
			// 
			// tableCellSizeRibbonPageGroup1
			// 
			this.tableCellSizeRibbonPageGroup1.ItemLinks.Add(this.toggleTableAutoFitItem1, "F");
			this.tableCellSizeRibbonPageGroup1.Name = "tableCellSizeRibbonPageGroup1";
			// 
			// tableAlignmentRibbonPageGroup1
			// 
			this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsTopLeftAlignmentItem1, "TL");
			this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsMiddleLeftAlignmentItem1, "CL");
			this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsBottomLeftAlignmentItem1, "BL");
			this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsTopCenterAlignmentItem1, "TC");
			this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsMiddleCenterAlignmentItem1, "CC");
			this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsBottomCenterAlignmentItem1, "BC");
			this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsTopRightAlignmentItem1, "TR");
			this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsMiddleRightAlignmentItem1, "CR");
			this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.toggleTableCellsBottomRightAlignmentItem1, "BR");
			this.tableAlignmentRibbonPageGroup1.ItemLinks.Add(this.showTableOptionsFormItem1, "N");
			this.tableAlignmentRibbonPageGroup1.Name = "tableAlignmentRibbonPageGroup1";
			// 
			// floatingPictureToolsRibbonPageCategory1
			// 
			this.floatingPictureToolsRibbonPageCategory1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(201)))), ((int)(((byte)(0)))), ((int)(((byte)(119)))));
			this.floatingPictureToolsRibbonPageCategory1.Control = this.txtContent;
			this.floatingPictureToolsRibbonPageCategory1.Name = "floatingPictureToolsRibbonPageCategory1";
			this.floatingPictureToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.floatingPictureToolsFormatPage1});
			// 
			// floatingPictureToolsFormatPage1
			// 
			this.floatingPictureToolsFormatPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.floatingPictureToolsShapeStylesPageGroup1,
            this.floatingPictureToolsArrangePageGroup1});
			this.floatingPictureToolsFormatPage1.Name = "floatingPictureToolsFormatPage1";
			// 
			// floatingPictureToolsShapeStylesPageGroup1
			// 
			this.floatingPictureToolsShapeStylesPageGroup1.ItemLinks.Add(this.changeFloatingObjectFillColorItem1);
			this.floatingPictureToolsShapeStylesPageGroup1.ItemLinks.Add(this.changeFloatingObjectOutlineColorItem1);
			this.floatingPictureToolsShapeStylesPageGroup1.ItemLinks.Add(this.changeFloatingObjectOutlineWeightItem1);
			this.floatingPictureToolsShapeStylesPageGroup1.Name = "floatingPictureToolsShapeStylesPageGroup1";
			// 
			// floatingPictureToolsArrangePageGroup1
			// 
			this.floatingPictureToolsArrangePageGroup1.ItemLinks.Add(this.changeFloatingObjectTextWrapTypeItem1, "TW");
			this.floatingPictureToolsArrangePageGroup1.ItemLinks.Add(this.changeFloatingObjectAlignmentItem1, "PO");
			this.floatingPictureToolsArrangePageGroup1.ItemLinks.Add(this.floatingObjectBringForwardSubItem1, "AF");
			this.floatingPictureToolsArrangePageGroup1.ItemLinks.Add(this.floatingObjectSendBackwardSubItem1, "AE");
			this.floatingPictureToolsArrangePageGroup1.Name = "floatingPictureToolsArrangePageGroup1";
			// 
			// fileRibbonPage1
			// 
			this.fileRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonRibbonPageGroup1});
			this.fileRibbonPage1.Name = "fileRibbonPage1";
			// 
			// commonRibbonPageGroup1
			// 
			this.commonRibbonPageGroup1.ItemLinks.Add(this.fileNewItem1, "N");
			this.commonRibbonPageGroup1.ItemLinks.Add(this.fileOpenItem1, "O");
			this.commonRibbonPageGroup1.ItemLinks.Add(this.fileSaveItem1, "S");
			this.commonRibbonPageGroup1.ItemLinks.Add(this.fileSaveAsItem1, "A");
			this.commonRibbonPageGroup1.ItemLinks.Add(this.quickPrintItem1);
			this.commonRibbonPageGroup1.ItemLinks.Add(this.printItem1, "P");
			this.commonRibbonPageGroup1.ItemLinks.Add(this.printPreviewItem1);
			this.commonRibbonPageGroup1.ItemLinks.Add(this.undoItem1);
			this.commonRibbonPageGroup1.ItemLinks.Add(this.redoItem1);
			this.commonRibbonPageGroup1.ItemLinks.Add(this.itemSave);
			this.commonRibbonPageGroup1.Name = "commonRibbonPageGroup1";
			// 
			// homeRibbonPage1
			// 
			this.homeRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.clipboardRibbonPageGroup1,
            this.fontRibbonPageGroup1,
            this.paragraphRibbonPageGroup1,
            this.stylesRibbonPageGroup1,
            this.editingRibbonPageGroup1});
			this.homeRibbonPage1.Name = "homeRibbonPage1";
			// 
			// clipboardRibbonPageGroup1
			// 
			this.clipboardRibbonPageGroup1.ItemLinks.Add(this.pasteItem1, "V");
			this.clipboardRibbonPageGroup1.ItemLinks.Add(this.cutItem1, "X");
			this.clipboardRibbonPageGroup1.ItemLinks.Add(this.copyItem1, "C");
			this.clipboardRibbonPageGroup1.ItemLinks.Add(this.pasteSpecialItem1);
			this.clipboardRibbonPageGroup1.Name = "clipboardRibbonPageGroup1";
			// 
			// fontRibbonPageGroup1
			// 
			this.fontRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup1);
			this.fontRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup2);
			this.fontRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup3);
			this.fontRibbonPageGroup1.ItemLinks.Add(this.changeTextCaseItem1);
			this.fontRibbonPageGroup1.ItemLinks.Add(this.clearFormattingItem1, "E");
			this.fontRibbonPageGroup1.Name = "fontRibbonPageGroup1";
			// 
			// paragraphRibbonPageGroup1
			// 
			this.paragraphRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup4);
			this.paragraphRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup5);
			this.paragraphRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup6);
			this.paragraphRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup7);
			this.paragraphRibbonPageGroup1.Name = "paragraphRibbonPageGroup1";
			// 
			// stylesRibbonPageGroup1
			// 
			this.stylesRibbonPageGroup1.ItemLinks.Add(this.galleryChangeStyleItem1);
			this.stylesRibbonPageGroup1.Name = "stylesRibbonPageGroup1";
			// 
			// editingRibbonPageGroup1
			// 
			this.editingRibbonPageGroup1.ItemLinks.Add(this.findItem1, "FD");
			this.editingRibbonPageGroup1.ItemLinks.Add(this.replaceItem1, "R");
			this.editingRibbonPageGroup1.Name = "editingRibbonPageGroup1";
			// 
			// insertRibbonPage1
			// 
			this.insertRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.pagesRibbonPageGroup1,
            this.tablesRibbonPageGroup1,
            this.illustrationsRibbonPageGroup1,
            this.linksRibbonPageGroup1,
            this.headerFooterRibbonPageGroup1,
            this.textRibbonPageGroup1,
            this.symbolsRibbonPageGroup1});
			this.insertRibbonPage1.Name = "insertRibbonPage1";
			// 
			// pagesRibbonPageGroup1
			// 
			this.pagesRibbonPageGroup1.ItemLinks.Add(this.insertPageBreakItem1, "B");
			this.pagesRibbonPageGroup1.Name = "pagesRibbonPageGroup1";
			// 
			// tablesRibbonPageGroup1
			// 
			this.tablesRibbonPageGroup1.ItemLinks.Add(this.insertTableItem1, "T");
			this.tablesRibbonPageGroup1.Name = "tablesRibbonPageGroup1";
			// 
			// illustrationsRibbonPageGroup1
			// 
			this.illustrationsRibbonPageGroup1.ItemLinks.Add(this.insertPictureItem1, "P");
			this.illustrationsRibbonPageGroup1.ItemLinks.Add(this.insertFloatingPictureItem1);
			this.illustrationsRibbonPageGroup1.Name = "illustrationsRibbonPageGroup1";
			// 
			// linksRibbonPageGroup1
			// 
			this.linksRibbonPageGroup1.ItemLinks.Add(this.insertBookmarkItem1, "K");
			this.linksRibbonPageGroup1.ItemLinks.Add(this.insertHyperlinkItem1, "I");
			this.linksRibbonPageGroup1.Name = "linksRibbonPageGroup1";
			// 
			// headerFooterRibbonPageGroup1
			// 
			this.headerFooterRibbonPageGroup1.ItemLinks.Add(this.editPageHeaderItem1, "H");
			this.headerFooterRibbonPageGroup1.ItemLinks.Add(this.editPageFooterItem1, "O");
			this.headerFooterRibbonPageGroup1.ItemLinks.Add(this.insertPageNumberItem1, "NU");
			this.headerFooterRibbonPageGroup1.ItemLinks.Add(this.insertPageCountItem1);
			this.headerFooterRibbonPageGroup1.Name = "headerFooterRibbonPageGroup1";
			// 
			// textRibbonPageGroup1
			// 
			this.textRibbonPageGroup1.ItemLinks.Add(this.insertTextBoxItem1, "X");
			this.textRibbonPageGroup1.Name = "textRibbonPageGroup1";
			// 
			// symbolsRibbonPageGroup1
			// 
			this.symbolsRibbonPageGroup1.ItemLinks.Add(this.insertSymbolItem1, "U");
			this.symbolsRibbonPageGroup1.Name = "symbolsRibbonPageGroup1";
			// 
			// pageLayoutRibbonPage1
			// 
			this.pageLayoutRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.pageSetupRibbonPageGroup1,
            this.pageBackgroundRibbonPageGroup1});
			this.pageLayoutRibbonPage1.Name = "pageLayoutRibbonPage1";
			// 
			// pageSetupRibbonPageGroup1
			// 
			this.pageSetupRibbonPageGroup1.ItemLinks.Add(this.changeSectionPageMarginsItem1, "M");
			this.pageSetupRibbonPageGroup1.ItemLinks.Add(this.changeSectionPageOrientationItem1, "O");
			this.pageSetupRibbonPageGroup1.ItemLinks.Add(this.changeSectionPaperKindItem1, "SZ");
			this.pageSetupRibbonPageGroup1.ItemLinks.Add(this.changeSectionColumnsItem1, "J");
			this.pageSetupRibbonPageGroup1.ItemLinks.Add(this.insertBreakItem1, "B");
			this.pageSetupRibbonPageGroup1.ItemLinks.Add(this.changeSectionLineNumberingItem1, "LN");
			this.pageSetupRibbonPageGroup1.Name = "pageSetupRibbonPageGroup1";
			// 
			// pageBackgroundRibbonPageGroup1
			// 
			this.pageBackgroundRibbonPageGroup1.ItemLinks.Add(this.changePageColorItem1, "PC");
			this.pageBackgroundRibbonPageGroup1.Name = "pageBackgroundRibbonPageGroup1";
			// 
			// referencesRibbonPage1
			// 
			this.referencesRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.tableOfContentsRibbonPageGroup1,
            this.captionsRibbonPageGroup1});
			this.referencesRibbonPage1.Name = "referencesRibbonPage1";
			// 
			// tableOfContentsRibbonPageGroup1
			// 
			this.tableOfContentsRibbonPageGroup1.ItemLinks.Add(this.insertTableOfContentsItem1, "T");
			this.tableOfContentsRibbonPageGroup1.ItemLinks.Add(this.updateTableOfContentsItem1, "U");
			this.tableOfContentsRibbonPageGroup1.ItemLinks.Add(this.addParagraphsToTableOfContentItem1, "A");
			this.tableOfContentsRibbonPageGroup1.Name = "tableOfContentsRibbonPageGroup1";
			// 
			// captionsRibbonPageGroup1
			// 
			this.captionsRibbonPageGroup1.ItemLinks.Add(this.insertCaptionPlaceholderItem1, "C");
			this.captionsRibbonPageGroup1.ItemLinks.Add(this.insertTableOfFiguresPlaceholderItem1, "G");
			this.captionsRibbonPageGroup1.ItemLinks.Add(this.updateTableOfContentsItem1, "U");
			this.captionsRibbonPageGroup1.Name = "captionsRibbonPageGroup1";
			// 
			// mailingsRibbonPage1
			// 
			this.mailingsRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.mailMergeRibbonPageGroup1});
			this.mailingsRibbonPage1.Name = "mailingsRibbonPage1";
			// 
			// mailMergeRibbonPageGroup1
			// 
			this.mailMergeRibbonPageGroup1.ItemLinks.Add(this.insertMergeFieldItem1);
			this.mailMergeRibbonPageGroup1.ItemLinks.Add(this.showAllFieldCodesItem1);
			this.mailMergeRibbonPageGroup1.ItemLinks.Add(this.showAllFieldResultsItem1);
			this.mailMergeRibbonPageGroup1.ItemLinks.Add(this.toggleViewMergedDataItem1, "P");
			this.mailMergeRibbonPageGroup1.Name = "mailMergeRibbonPageGroup1";
			// 
			// reviewRibbonPage1
			// 
			this.reviewRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.documentProofingRibbonPageGroup1,
            this.documentProtectionRibbonPageGroup1});
			this.reviewRibbonPage1.Name = "reviewRibbonPage1";
			// 
			// documentProofingRibbonPageGroup1
			// 
			this.documentProofingRibbonPageGroup1.ItemLinks.Add(this.checkSpellingItem1, "S");
			this.documentProofingRibbonPageGroup1.Name = "documentProofingRibbonPageGroup1";
			// 
			// documentProtectionRibbonPageGroup1
			// 
			this.documentProtectionRibbonPageGroup1.ItemLinks.Add(this.protectDocumentItem1);
			this.documentProtectionRibbonPageGroup1.ItemLinks.Add(this.changeRangeEditingPermissionsItem1);
			this.documentProtectionRibbonPageGroup1.ItemLinks.Add(this.unprotectDocumentItem1);
			this.documentProtectionRibbonPageGroup1.Name = "documentProtectionRibbonPageGroup1";
			// 
			// viewRibbonPage1
			// 
			this.viewRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.documentViewsRibbonPageGroup1,
            this.showRibbonPageGroup1,
            this.zoomRibbonPageGroup1});
			this.viewRibbonPage1.Name = "viewRibbonPage1";
			// 
			// documentViewsRibbonPageGroup1
			// 
			this.documentViewsRibbonPageGroup1.ItemLinks.Add(this.switchToSimpleViewItem1, "L");
			this.documentViewsRibbonPageGroup1.ItemLinks.Add(this.switchToDraftViewItem1, "E");
			this.documentViewsRibbonPageGroup1.ItemLinks.Add(this.switchToPrintLayoutViewItem1, "P");
			this.documentViewsRibbonPageGroup1.Name = "documentViewsRibbonPageGroup1";
			// 
			// showRibbonPageGroup1
			// 
			this.showRibbonPageGroup1.ItemLinks.Add(this.toggleShowHorizontalRulerItem1);
			this.showRibbonPageGroup1.ItemLinks.Add(this.toggleShowVerticalRulerItem1);
			this.showRibbonPageGroup1.Name = "showRibbonPageGroup1";
			// 
			// zoomRibbonPageGroup1
			// 
			this.zoomRibbonPageGroup1.ItemLinks.Add(this.zoomOutItem1);
			this.zoomRibbonPageGroup1.ItemLinks.Add(this.zoomInItem1);
			this.zoomRibbonPageGroup1.Name = "zoomRibbonPageGroup1";
			// 
			// repositoryItemTextEdit1
			// 
			this.repositoryItemTextEdit1.AutoHeight = false;
			this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
			// 
			// richEditBarController1
			// 
			this.richEditBarController1.BarItems.Add(this.cutItem1);
			this.richEditBarController1.BarItems.Add(this.copyItem1);
			this.richEditBarController1.BarItems.Add(this.pasteItem1);
			this.richEditBarController1.BarItems.Add(this.changeFontNameItem1);
			this.richEditBarController1.BarItems.Add(this.changeFontSizeItem1);
			this.richEditBarController1.BarItems.Add(this.changeFontColorItem1);
			this.richEditBarController1.BarItems.Add(this.changeFontBackColorItem1);
			this.richEditBarController1.BarItems.Add(this.toggleFontBoldItem1);
			this.richEditBarController1.BarItems.Add(this.toggleFontItalicItem1);
			this.richEditBarController1.BarItems.Add(this.toggleFontUnderlineItem1);
			this.richEditBarController1.BarItems.Add(this.toggleFontDoubleUnderlineItem1);
			this.richEditBarController1.BarItems.Add(this.toggleFontStrikeoutItem1);
			this.richEditBarController1.BarItems.Add(this.toggleFontDoubleStrikeoutItem1);
			this.richEditBarController1.BarItems.Add(this.toggleFontSuperscriptItem1);
			this.richEditBarController1.BarItems.Add(this.toggleFontSubscriptItem1);
			this.richEditBarController1.BarItems.Add(this.fontSizeIncreaseItem1);
			this.richEditBarController1.BarItems.Add(this.fontSizeDecreaseItem1);
			this.richEditBarController1.BarItems.Add(this.showFontFormItem1);
			this.richEditBarController1.BarItems.Add(this.fileNewItem1);
			this.richEditBarController1.BarItems.Add(this.fileOpenItem1);
			this.richEditBarController1.BarItems.Add(this.fileSaveAsItem1);
			this.richEditBarController1.BarItems.Add(this.quickPrintItem1);
			this.richEditBarController1.BarItems.Add(this.printItem1);
			this.richEditBarController1.BarItems.Add(this.printPreviewItem1);
			this.richEditBarController1.BarItems.Add(this.undoItem1);
			this.richEditBarController1.BarItems.Add(this.redoItem1);
			this.richEditBarController1.BarItems.Add(this.changeStyleItem1);
			this.richEditBarController1.BarItems.Add(this.toggleParagraphAlignmentLeftItem1);
			this.richEditBarController1.BarItems.Add(this.toggleParagraphAlignmentCenterItem1);
			this.richEditBarController1.BarItems.Add(this.toggleParagraphAlignmentRightItem1);
			this.richEditBarController1.BarItems.Add(this.toggleParagraphAlignmentJustifyItem1);
			this.richEditBarController1.BarItems.Add(this.toggleNumberingListItem1);
			this.richEditBarController1.BarItems.Add(this.toggleBulletedListItem1);
			this.richEditBarController1.BarItems.Add(this.toggleMultiLevelListItem1);
			this.richEditBarController1.BarItems.Add(this.decreaseIndentItem1);
			this.richEditBarController1.BarItems.Add(this.increaseIndentItem1);
			this.richEditBarController1.BarItems.Add(this.toggleShowWhitespaceItem1);
			this.richEditBarController1.BarItems.Add(this.showParagraphFormItem1);
			this.richEditBarController1.BarItems.Add(this.insertPictureItem1);
			this.richEditBarController1.BarItems.Add(this.insertHyperlinkItem1);
			this.richEditBarController1.BarItems.Add(this.zoomOutItem1);
			this.richEditBarController1.BarItems.Add(this.zoomInItem1);
			this.richEditBarController1.BarItems.Add(this.switchToSimpleViewItem1);
			this.richEditBarController1.BarItems.Add(this.switchToDraftViewItem1);
			this.richEditBarController1.BarItems.Add(this.switchToPrintLayoutViewItem1);
			this.richEditBarController1.BarItems.Add(this.findItem1);
			this.richEditBarController1.BarItems.Add(this.replaceItem1);
			this.richEditBarController1.BarItems.Add(this.insertSymbolItem1);
			this.richEditBarController1.BarItems.Add(this.fileSaveItem1);
			this.richEditBarController1.BarItems.Add(this.changeTableCellsShadingItem1);
			this.richEditBarController1.BarItems.Add(this.changeTableBordersItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsBottomBorderItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsTopBorderItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsLeftBorderItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsRightBorderItem1);
			this.richEditBarController1.BarItems.Add(this.resetTableCellsAllBordersItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsAllBordersItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsOutsideBorderItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsInsideBorderItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsInsideHorizontalBorderItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsInsideVerticalBorderItem1);
			this.richEditBarController1.BarItems.Add(this.toggleShowTableGridLinesItem1);
			this.richEditBarController1.BarItems.Add(this.changeTableBorderLineStyleItem1);
			this.richEditBarController1.BarItems.Add(this.changeTableBorderLineWeightItem1);
			this.richEditBarController1.BarItems.Add(this.changeTableBorderColorItem1);
			this.richEditBarController1.BarItems.Add(this.selectTableElementsItem1);
			this.richEditBarController1.BarItems.Add(this.selectTableCellItem1);
			this.richEditBarController1.BarItems.Add(this.selectTableColumnItem1);
			this.richEditBarController1.BarItems.Add(this.selectTableRowItem1);
			this.richEditBarController1.BarItems.Add(this.selectTableItem1);
			this.richEditBarController1.BarItems.Add(this.deleteTableElementsItem1);
			this.richEditBarController1.BarItems.Add(this.showDeleteTableCellsFormItem1);
			this.richEditBarController1.BarItems.Add(this.deleteTableColumnsItem1);
			this.richEditBarController1.BarItems.Add(this.deleteTableRowsItem1);
			this.richEditBarController1.BarItems.Add(this.deleteTableItem1);
			this.richEditBarController1.BarItems.Add(this.insertTableRowAboveItem1);
			this.richEditBarController1.BarItems.Add(this.insertTableRowBelowItem1);
			this.richEditBarController1.BarItems.Add(this.insertTableColumnToLeftItem1);
			this.richEditBarController1.BarItems.Add(this.insertTableColumnToRightItem1);
			this.richEditBarController1.BarItems.Add(this.showInsertTableCellsFormItem1);
			this.richEditBarController1.BarItems.Add(this.mergeTableCellsItem1);
			this.richEditBarController1.BarItems.Add(this.showSplitTableCellsForm1);
			this.richEditBarController1.BarItems.Add(this.splitTableItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsTopLeftAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsTopCenterAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsTopRightAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsMiddleLeftAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsMiddleCenterAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsMiddleRightAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsBottomLeftAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsBottomCenterAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableCellsBottomRightAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.insertPageBreakItem1);
			this.richEditBarController1.BarItems.Add(this.insertTableItem1);
			this.richEditBarController1.BarItems.Add(this.insertBookmarkItem1);
			this.richEditBarController1.BarItems.Add(this.editPageHeaderItem1);
			this.richEditBarController1.BarItems.Add(this.editPageFooterItem1);
			this.richEditBarController1.BarItems.Add(this.insertPageNumberItem1);
			this.richEditBarController1.BarItems.Add(this.insertPageCountItem1);
			this.richEditBarController1.BarItems.Add(this.changeTextCaseItem1);
			this.richEditBarController1.BarItems.Add(this.makeTextUpperCaseItem1);
			this.richEditBarController1.BarItems.Add(this.makeTextLowerCaseItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTextCaseItem1);
			this.richEditBarController1.BarItems.Add(this.clearFormattingItem1);
			this.richEditBarController1.BarItems.Add(this.changeParagraphLineSpacingItem1);
			this.richEditBarController1.BarItems.Add(this.setSingleParagraphSpacingItem1);
			this.richEditBarController1.BarItems.Add(this.setSesquialteralParagraphSpacingItem1);
			this.richEditBarController1.BarItems.Add(this.setDoubleParagraphSpacingItem1);
			this.richEditBarController1.BarItems.Add(this.showLineSpacingFormItem1);
			this.richEditBarController1.BarItems.Add(this.addSpacingBeforeParagraphItem1);
			this.richEditBarController1.BarItems.Add(this.removeSpacingBeforeParagraphItem1);
			this.richEditBarController1.BarItems.Add(this.addSpacingAfterParagraphItem1);
			this.richEditBarController1.BarItems.Add(this.removeSpacingAfterParagraphItem1);
			this.richEditBarController1.BarItems.Add(this.pasteSpecialItem1);
			this.richEditBarController1.BarItems.Add(this.changeParagraphBackColorItem1);
			this.richEditBarController1.BarItems.Add(this.galleryChangeStyleItem1);
			this.richEditBarController1.BarItems.Add(this.insertFloatingPictureItem1);
			this.richEditBarController1.BarItems.Add(this.insertTextBoxItem1);
			this.richEditBarController1.BarItems.Add(this.changeSectionPageMarginsItem1);
			this.richEditBarController1.BarItems.Add(this.setNormalSectionPageMarginsItem1);
			this.richEditBarController1.BarItems.Add(this.setNarrowSectionPageMarginsItem1);
			this.richEditBarController1.BarItems.Add(this.setModerateSectionPageMarginsItem1);
			this.richEditBarController1.BarItems.Add(this.setWideSectionPageMarginsItem1);
			this.richEditBarController1.BarItems.Add(this.showPageMarginsSetupFormItem1);
			this.richEditBarController1.BarItems.Add(this.changeSectionPageOrientationItem1);
			this.richEditBarController1.BarItems.Add(this.setPortraitPageOrientationItem1);
			this.richEditBarController1.BarItems.Add(this.setLandscapePageOrientationItem1);
			this.richEditBarController1.BarItems.Add(this.changeSectionPaperKindItem1);
			this.richEditBarController1.BarItems.Add(this.changeSectionColumnsItem1);
			this.richEditBarController1.BarItems.Add(this.setSectionOneColumnItem1);
			this.richEditBarController1.BarItems.Add(this.setSectionTwoColumnsItem1);
			this.richEditBarController1.BarItems.Add(this.setSectionThreeColumnsItem1);
			this.richEditBarController1.BarItems.Add(this.showColumnsSetupFormItem1);
			this.richEditBarController1.BarItems.Add(this.insertBreakItem1);
			this.richEditBarController1.BarItems.Add(this.insertPageBreakItem2);
			this.richEditBarController1.BarItems.Add(this.insertColumnBreakItem1);
			this.richEditBarController1.BarItems.Add(this.insertSectionBreakNextPageItem1);
			this.richEditBarController1.BarItems.Add(this.insertSectionBreakEvenPageItem1);
			this.richEditBarController1.BarItems.Add(this.insertSectionBreakOddPageItem1);
			this.richEditBarController1.BarItems.Add(this.changeSectionLineNumberingItem1);
			this.richEditBarController1.BarItems.Add(this.setSectionLineNumberingNoneItem1);
			this.richEditBarController1.BarItems.Add(this.setSectionLineNumberingContinuousItem1);
			this.richEditBarController1.BarItems.Add(this.setSectionLineNumberingRestartNewPageItem1);
			this.richEditBarController1.BarItems.Add(this.setSectionLineNumberingRestartNewSectionItem1);
			this.richEditBarController1.BarItems.Add(this.toggleParagraphSuppressLineNumbersItem1);
			this.richEditBarController1.BarItems.Add(this.showLineNumberingFormItem1);
			this.richEditBarController1.BarItems.Add(this.changePageColorItem1);
			this.richEditBarController1.BarItems.Add(this.insertTableOfContentsItem1);
			this.richEditBarController1.BarItems.Add(this.updateTableOfContentsItem1);
			this.richEditBarController1.BarItems.Add(this.addParagraphsToTableOfContentItem1);
			this.richEditBarController1.BarItems.Add(this.setParagraphHeadingLevelItem1);
			this.richEditBarController1.BarItems.Add(this.setParagraphHeadingLevelItem2);
			this.richEditBarController1.BarItems.Add(this.setParagraphHeadingLevelItem3);
			this.richEditBarController1.BarItems.Add(this.setParagraphHeadingLevelItem4);
			this.richEditBarController1.BarItems.Add(this.setParagraphHeadingLevelItem5);
			this.richEditBarController1.BarItems.Add(this.setParagraphHeadingLevelItem6);
			this.richEditBarController1.BarItems.Add(this.setParagraphHeadingLevelItem7);
			this.richEditBarController1.BarItems.Add(this.setParagraphHeadingLevelItem8);
			this.richEditBarController1.BarItems.Add(this.setParagraphHeadingLevelItem9);
			this.richEditBarController1.BarItems.Add(this.setParagraphHeadingLevelItem10);
			this.richEditBarController1.BarItems.Add(this.insertCaptionPlaceholderItem1);
			this.richEditBarController1.BarItems.Add(this.insertFiguresCaptionItems1);
			this.richEditBarController1.BarItems.Add(this.insertTablesCaptionItems1);
			this.richEditBarController1.BarItems.Add(this.insertEquationsCaptionItems1);
			this.richEditBarController1.BarItems.Add(this.insertTableOfFiguresPlaceholderItem1);
			this.richEditBarController1.BarItems.Add(this.insertTableOfFiguresItems1);
			this.richEditBarController1.BarItems.Add(this.insertTableOfTablesItems1);
			this.richEditBarController1.BarItems.Add(this.insertTableOfEquationsItems1);
			this.richEditBarController1.BarItems.Add(this.insertMergeFieldItem1);
			this.richEditBarController1.BarItems.Add(this.showAllFieldCodesItem1);
			this.richEditBarController1.BarItems.Add(this.showAllFieldResultsItem1);
			this.richEditBarController1.BarItems.Add(this.toggleViewMergedDataItem1);
			this.richEditBarController1.BarItems.Add(this.checkSpellingItem1);
			this.richEditBarController1.BarItems.Add(this.protectDocumentItem1);
			this.richEditBarController1.BarItems.Add(this.changeRangeEditingPermissionsItem1);
			this.richEditBarController1.BarItems.Add(this.unprotectDocumentItem1);
			this.richEditBarController1.BarItems.Add(this.toggleShowHorizontalRulerItem1);
			this.richEditBarController1.BarItems.Add(this.toggleShowVerticalRulerItem1);
			this.richEditBarController1.BarItems.Add(this.goToPageHeaderItem1);
			this.richEditBarController1.BarItems.Add(this.goToPageFooterItem1);
			this.richEditBarController1.BarItems.Add(this.goToNextHeaderFooterItem1);
			this.richEditBarController1.BarItems.Add(this.goToPreviousHeaderFooterItem1);
			this.richEditBarController1.BarItems.Add(this.toggleLinkToPreviousItem1);
			this.richEditBarController1.BarItems.Add(this.toggleDifferentFirstPageItem1);
			this.richEditBarController1.BarItems.Add(this.toggleDifferentOddAndEvenPagesItem1);
			this.richEditBarController1.BarItems.Add(this.closePageHeaderFooterItem1);
			this.richEditBarController1.BarItems.Add(this.showTablePropertiesFormItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableAutoFitItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableAutoFitContentsItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableAutoFitWindowItem1);
			this.richEditBarController1.BarItems.Add(this.toggleTableFixedColumnWidthItem1);
			this.richEditBarController1.BarItems.Add(this.showTableOptionsFormItem1);
			this.richEditBarController1.BarItems.Add(this.changeFloatingObjectFillColorItem1);
			this.richEditBarController1.BarItems.Add(this.changeFloatingObjectOutlineColorItem1);
			this.richEditBarController1.BarItems.Add(this.changeFloatingObjectOutlineWeightItem1);
			this.richEditBarController1.BarItems.Add(this.changeFloatingObjectTextWrapTypeItem1);
			this.richEditBarController1.BarItems.Add(this.setFloatingObjectSquareTextWrapTypeItem1);
			this.richEditBarController1.BarItems.Add(this.setFloatingObjectTightTextWrapTypeItem1);
			this.richEditBarController1.BarItems.Add(this.setFloatingObjectThroughTextWrapTypeItem1);
			this.richEditBarController1.BarItems.Add(this.setFloatingObjectTopAndBottomTextWrapTypeItem1);
			this.richEditBarController1.BarItems.Add(this.setFloatingObjectBehindTextWrapTypeItem1);
			this.richEditBarController1.BarItems.Add(this.setFloatingObjectInFrontOfTextWrapTypeItem1);
			this.richEditBarController1.BarItems.Add(this.changeFloatingObjectAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.setFloatingObjectTopLeftAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.setFloatingObjectTopCenterAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.setFloatingObjectTopRightAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.setFloatingObjectMiddleLeftAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.setFloatingObjectMiddleCenterAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.setFloatingObjectMiddleRightAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.setFloatingObjectBottomLeftAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.setFloatingObjectBottomCenterAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.setFloatingObjectBottomRightAlignmentItem1);
			this.richEditBarController1.BarItems.Add(this.floatingObjectBringForwardSubItem1);
			this.richEditBarController1.BarItems.Add(this.floatingObjectBringForwardItem1);
			this.richEditBarController1.BarItems.Add(this.floatingObjectBringToFrontItem1);
			this.richEditBarController1.BarItems.Add(this.floatingObjectBringInFrontOfTextItem1);
			this.richEditBarController1.BarItems.Add(this.floatingObjectSendBackwardSubItem1);
			this.richEditBarController1.BarItems.Add(this.floatingObjectSendBackwardItem1);
			this.richEditBarController1.BarItems.Add(this.floatingObjectSendToBackItem1);
			this.richEditBarController1.BarItems.Add(this.floatingObjectSendBehindTextItem1);
			this.richEditBarController1.Control = this.txtContent;
			// 
			// insertPageBreakItem2
			// 
			this.insertPageBreakItem2.Name = "insertPageBreakItem2";
			// 
			// backstageViewControl1
			// 
			this.backstageViewControl1.Controls.Add(this.backstageViewClientControl1);
			this.backstageViewControl1.Items.Add(this.backstageViewTabItem1);
			this.backstageViewControl1.Location = new System.Drawing.Point(71, 214);
			this.backstageViewControl1.Name = "backstageViewControl1";
			this.backstageViewControl1.Size = new System.Drawing.Size(480, 150);
			this.backstageViewControl1.TabIndex = 2;
			// 
			// backstageViewClientControl1
			// 
			this.backstageViewClientControl1.Location = new System.Drawing.Point(0, 0);
			this.backstageViewClientControl1.Name = "backstageViewClientControl1";
			this.backstageViewClientControl1.Size = new System.Drawing.Size(150, 150);
			this.backstageViewClientControl1.TabIndex = 1;
			// 
			// backstageViewTabItem1
			// 
			this.backstageViewTabItem1.Caption = "backstageViewTabItem1";
			this.backstageViewTabItem1.ContentControl = this.backstageViewClientControl1;
			this.backstageViewTabItem1.Name = "backstageViewTabItem1";
			// 
			// backstageViewControl2
			// 
			this.backstageViewControl2.Controls.Add(this.backstageViewClientControl2);
			this.backstageViewControl2.Items.Add(this.backstageViewTabItem2);
			this.backstageViewControl2.Location = new System.Drawing.Point(71, 214);
			this.backstageViewControl2.Name = "backstageViewControl2";
			this.backstageViewControl2.Size = new System.Drawing.Size(480, 150);
			this.backstageViewControl2.TabIndex = 3;
			// 
			// backstageViewClientControl2
			// 
			this.backstageViewClientControl2.Location = new System.Drawing.Point(0, 0);
			this.backstageViewClientControl2.Name = "backstageViewClientControl2";
			this.backstageViewClientControl2.Size = new System.Drawing.Size(150, 150);
			this.backstageViewClientControl2.TabIndex = 1;
			// 
			// backstageViewTabItem2
			// 
			this.backstageViewTabItem2.Caption = "backstageViewTabItem2";
			this.backstageViewTabItem2.ContentControl = this.backstageViewClientControl2;
			this.backstageViewTabItem2.Name = "backstageViewTabItem2";
			// 
			// backstageViewControl3
			// 
			this.backstageViewControl3.Controls.Add(this.backstageViewClientControl3);
			this.backstageViewControl3.Items.Add(this.backstageViewTabItem3);
			this.backstageViewControl3.Location = new System.Drawing.Point(71, 214);
			this.backstageViewControl3.Name = "backstageViewControl3";
			this.backstageViewControl3.Size = new System.Drawing.Size(480, 150);
			this.backstageViewControl3.TabIndex = 4;
			// 
			// backstageViewClientControl3
			// 
			this.backstageViewClientControl3.Location = new System.Drawing.Point(0, 0);
			this.backstageViewClientControl3.Name = "backstageViewClientControl3";
			this.backstageViewClientControl3.Size = new System.Drawing.Size(150, 150);
			this.backstageViewClientControl3.TabIndex = 1;
			// 
			// backstageViewTabItem3
			// 
			this.backstageViewTabItem3.Caption = "backstageViewTabItem3";
			this.backstageViewTabItem3.ContentControl = this.backstageViewClientControl3;
			this.backstageViewTabItem3.Name = "backstageViewTabItem3";
			// 
			// backstageViewControl4
			// 
			this.backstageViewControl4.Controls.Add(this.backstageViewClientControl4);
			this.backstageViewControl4.Items.Add(this.backstageViewTabItem4);
			this.backstageViewControl4.Location = new System.Drawing.Point(71, 214);
			this.backstageViewControl4.Name = "backstageViewControl4";
			this.backstageViewControl4.Size = new System.Drawing.Size(480, 150);
			this.backstageViewControl4.TabIndex = 5;
			// 
			// backstageViewClientControl4
			// 
			this.backstageViewClientControl4.Location = new System.Drawing.Point(0, 0);
			this.backstageViewClientControl4.Name = "backstageViewClientControl4";
			this.backstageViewClientControl4.Size = new System.Drawing.Size(150, 150);
			this.backstageViewClientControl4.TabIndex = 1;
			// 
			// backstageViewTabItem4
			// 
			this.backstageViewTabItem4.Caption = "backstageViewTabItem4";
			this.backstageViewTabItem4.ContentControl = this.backstageViewClientControl4;
			this.backstageViewTabItem4.Name = "backstageViewTabItem4";
			// 
			// backstageViewControl5
			// 
			this.backstageViewControl5.Controls.Add(this.backstageViewClientControl5);
			this.backstageViewControl5.Items.Add(this.backstageViewTabItem5);
			this.backstageViewControl5.Location = new System.Drawing.Point(71, 214);
			this.backstageViewControl5.Name = "backstageViewControl5";
			this.backstageViewControl5.OwnerControl = this.ribbonControl1;
			this.backstageViewControl5.Size = new System.Drawing.Size(480, 150);
			this.backstageViewControl5.TabIndex = 6;
			// 
			// backstageViewClientControl5
			// 
			this.backstageViewClientControl5.Location = new System.Drawing.Point(0, 0);
			this.backstageViewClientControl5.Name = "backstageViewClientControl5";
			this.backstageViewClientControl5.Size = new System.Drawing.Size(150, 150);
			this.backstageViewClientControl5.TabIndex = 1;
			// 
			// backstageViewTabItem5
			// 
			this.backstageViewTabItem5.Caption = "backstageViewTabItem5";
			this.backstageViewTabItem5.ContentControl = this.backstageViewClientControl5;
			this.backstageViewTabItem5.Name = "backstageViewTabItem5";
			// 
			// frmDesign
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1027, 610);
			this.Controls.Add(this.txtContent);
			this.Controls.Add(this.backstageViewControl1);
			this.Controls.Add(this.backstageViewControl2);
			this.Controls.Add(this.backstageViewControl3);
			this.Controls.Add(this.backstageViewControl4);
			this.Controls.Add(this.backstageViewControl5);
			this.Controls.Add(this.ribbonControl1);
			this.MinimizeBox = false;
			this.Name = "frmDesign";
			this.Ribbon = this.ribbonControl1;
			this.ShowIcon = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Trình soạn thảo biểu mẫu";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.repositoryItemFontEdit1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.repositoryItemRichEditFontSizeEdit1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.repositoryItemRichEditStyleEdit1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.repositoryItemBorderLineStyle1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.repositoryItemBorderLineWeight1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.repositoryItemFloatingObjectOutlineWeight1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.richEditBarController1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.backstageViewControl1)).EndInit();
			this.backstageViewControl1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.backstageViewControl2)).EndInit();
			this.backstageViewControl2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.backstageViewControl3)).EndInit();
			this.backstageViewControl3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.backstageViewControl4)).EndInit();
			this.backstageViewControl4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.backstageViewControl5)).EndInit();
			this.backstageViewControl5.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraRichEdit.RichEditControl txtContent;
        private DevExpress.XtraRichEdit.UI.CutItem cutItem1;
        private DevExpress.XtraRichEdit.UI.CopyItem copyItem1;
        private DevExpress.XtraRichEdit.UI.PasteItem pasteItem1;
        private DevExpress.XtraRichEdit.UI.RichEditBarController richEditBarController1;
        private DevExpress.XtraRichEdit.UI.ChangeFontNameItem changeFontNameItem1;
        private DevExpress.XtraRichEdit.UI.ChangeFontSizeItem changeFontSizeItem1;
        private DevExpress.XtraRichEdit.UI.ChangeFontColorItem changeFontColorItem1;
        private DevExpress.XtraRichEdit.UI.ChangeFontBackColorItem changeFontBackColorItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFontBoldItem toggleFontBoldItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFontItalicItem toggleFontItalicItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFontUnderlineItem toggleFontUnderlineItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFontDoubleUnderlineItem toggleFontDoubleUnderlineItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFontStrikeoutItem toggleFontStrikeoutItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFontDoubleStrikeoutItem toggleFontDoubleStrikeoutItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFontSuperscriptItem toggleFontSuperscriptItem1;
        private DevExpress.XtraRichEdit.UI.ToggleFontSubscriptItem toggleFontSubscriptItem1;
        private DevExpress.XtraRichEdit.UI.FontSizeIncreaseItem fontSizeIncreaseItem1;
        private DevExpress.XtraRichEdit.UI.FontSizeDecreaseItem fontSizeDecreaseItem1;
        private DevExpress.XtraRichEdit.UI.ShowFontFormItem showFontFormItem1;
        private DevExpress.XtraRichEdit.UI.FileNewItem fileNewItem1;
        private DevExpress.XtraRichEdit.UI.FileOpenItem fileOpenItem1;
        private DevExpress.XtraRichEdit.UI.FileSaveAsItem fileSaveAsItem1;
        private DevExpress.XtraRichEdit.UI.QuickPrintItem quickPrintItem1;
        private DevExpress.XtraRichEdit.UI.PrintPreviewItem printPreviewItem1;
        private DevExpress.XtraRichEdit.UI.ZoomOutItem zoomOutItem1;
        private DevExpress.XtraRichEdit.UI.ZoomInItem zoomInItem1;
        private DevExpress.XtraRichEdit.UI.InsertPictureItem insertPictureItem1;
        private DevExpress.XtraRichEdit.UI.InsertHyperlinkItem insertHyperlinkItem1;
        private DevExpress.XtraRichEdit.UI.UndoItem undoItem1;
        private DevExpress.XtraRichEdit.UI.RedoItem redoItem1;
        private DevExpress.XtraRichEdit.UI.ToggleParagraphAlignmentLeftItem toggleParagraphAlignmentLeftItem1;
        private DevExpress.XtraRichEdit.UI.ToggleParagraphAlignmentCenterItem toggleParagraphAlignmentCenterItem1;
        private DevExpress.XtraRichEdit.UI.ToggleParagraphAlignmentRightItem toggleParagraphAlignmentRightItem1;
        private DevExpress.XtraRichEdit.UI.ToggleParagraphAlignmentJustifyItem toggleParagraphAlignmentJustifyItem1;
        private DevExpress.XtraRichEdit.UI.ToggleNumberingListItem toggleNumberingListItem1;
        private DevExpress.XtraRichEdit.UI.ToggleBulletedListItem toggleBulletedListItem1;
        private DevExpress.XtraRichEdit.UI.ToggleMultiLevelListItem toggleMultiLevelListItem1;
        private DevExpress.XtraRichEdit.UI.DecreaseIndentItem decreaseIndentItem1;
        private DevExpress.XtraRichEdit.UI.IncreaseIndentItem increaseIndentItem1;
        private DevExpress.XtraRichEdit.UI.PrintItem printItem1;
        private DevExpress.XtraRichEdit.UI.ChangeStyleItem changeStyleItem1;
        private DevExpress.XtraRichEdit.UI.ToggleShowWhitespaceItem toggleShowWhitespaceItem1;
        private DevExpress.XtraRichEdit.UI.ShowParagraphFormItem showParagraphFormItem1;
        private DevExpress.XtraRichEdit.UI.SwitchToSimpleViewItem switchToSimpleViewItem1;
        private DevExpress.XtraRichEdit.UI.SwitchToDraftViewItem switchToDraftViewItem1;
        private DevExpress.XtraRichEdit.UI.SwitchToPrintLayoutViewItem switchToPrintLayoutViewItem1;
        private DevExpress.XtraRichEdit.UI.FindItem findItem1;
        private DevExpress.XtraRichEdit.UI.ReplaceItem replaceItem1;
        private DevExpress.XtraRichEdit.UI.InsertSymbolItem insertSymbolItem1;
        private DevExpress.XtraBars.BarButtonItem itemLuu;
        private DevExpress.XtraBars.BarButtonItem itemDong;
        private DevExpress.XtraBars.BarSubItem barSubItem1;
        private DevExpress.XtraBars.BarMdiChildrenListItem barMdiChildrenListItem1;
        private DevExpress.XtraRichEdit.UI.FileSaveItem fileSaveItem1;
        private DevExpress.XtraBars.BarSubItem barSubItem2;
        private DevExpress.XtraBars.PopupMenu popupMenu1;
        private DevExpress.XtraBars.BarButtonItem itemCopy;
        private DevExpress.XtraBars.BarButtonItem itemCut;
        private DevExpress.XtraBars.BarButtonItem itemPaste;
        private DevExpress.XtraRichEdit.UI.ChangeTableCellsShadingItem changeTableCellsShadingItem1;
        private DevExpress.XtraRichEdit.UI.ChangeTableBordersItem changeTableBordersItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsBottomBorderItem toggleTableCellsBottomBorderItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsTopBorderItem toggleTableCellsTopBorderItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsLeftBorderItem toggleTableCellsLeftBorderItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsRightBorderItem toggleTableCellsRightBorderItem1;
        private DevExpress.XtraRichEdit.UI.ResetTableCellsAllBordersItem resetTableCellsAllBordersItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsAllBordersItem toggleTableCellsAllBordersItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsOutsideBorderItem toggleTableCellsOutsideBorderItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsInsideBorderItem toggleTableCellsInsideBorderItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsInsideHorizontalBorderItem toggleTableCellsInsideHorizontalBorderItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsInsideVerticalBorderItem toggleTableCellsInsideVerticalBorderItem1;
        private DevExpress.XtraRichEdit.UI.ToggleShowTableGridLinesItem toggleShowTableGridLinesItem1;
        private DevExpress.XtraRichEdit.UI.ChangeTableBorderLineStyleItem changeTableBorderLineStyleItem1;
        private DevExpress.XtraRichEdit.UI.ChangeTableBorderLineWeightItem changeTableBorderLineWeightItem1;
        private DevExpress.XtraRichEdit.UI.ChangeTableBorderColorItem changeTableBorderColorItem1;
        private DevExpress.XtraRichEdit.UI.SelectTableElementsItem selectTableElementsItem1;
        private DevExpress.XtraRichEdit.UI.SelectTableCellItem selectTableCellItem1;
        private DevExpress.XtraRichEdit.UI.SelectTableColumnItem selectTableColumnItem1;
        private DevExpress.XtraRichEdit.UI.SelectTableRowItem selectTableRowItem1;
        private DevExpress.XtraRichEdit.UI.SelectTableItem selectTableItem1;
        private DevExpress.XtraRichEdit.UI.DeleteTableElementsItem deleteTableElementsItem1;
        private DevExpress.XtraRichEdit.UI.ShowDeleteTableCellsFormItem showDeleteTableCellsFormItem1;
        private DevExpress.XtraRichEdit.UI.DeleteTableColumnsItem deleteTableColumnsItem1;
        private DevExpress.XtraRichEdit.UI.DeleteTableRowsItem deleteTableRowsItem1;
        private DevExpress.XtraRichEdit.UI.DeleteTableItem deleteTableItem1;
        private DevExpress.XtraRichEdit.UI.InsertTableRowAboveItem insertTableRowAboveItem1;
        private DevExpress.XtraRichEdit.UI.InsertTableRowBelowItem insertTableRowBelowItem1;
        private DevExpress.XtraRichEdit.UI.InsertTableColumnToLeftItem insertTableColumnToLeftItem1;
        private DevExpress.XtraRichEdit.UI.InsertTableColumnToRightItem insertTableColumnToRightItem1;
        private DevExpress.XtraRichEdit.UI.ShowInsertTableCellsFormItem showInsertTableCellsFormItem1;
        private DevExpress.XtraRichEdit.UI.MergeTableCellsItem mergeTableCellsItem1;
        private DevExpress.XtraRichEdit.UI.ShowSplitTableCellsForm showSplitTableCellsForm1;
        private DevExpress.XtraRichEdit.UI.SplitTableItem splitTableItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsTopLeftAlignmentItem toggleTableCellsTopLeftAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsTopCenterAlignmentItem toggleTableCellsTopCenterAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsTopRightAlignmentItem toggleTableCellsTopRightAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsMiddleLeftAlignmentItem toggleTableCellsMiddleLeftAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsMiddleCenterAlignmentItem toggleTableCellsMiddleCenterAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsMiddleRightAlignmentItem toggleTableCellsMiddleRightAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsBottomLeftAlignmentItem toggleTableCellsBottomLeftAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsBottomCenterAlignmentItem toggleTableCellsBottomCenterAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableCellsBottomRightAlignmentItem toggleTableCellsBottomRightAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.InsertPageBreakItem insertPageBreakItem1;
        private DevExpress.XtraRichEdit.UI.InsertTableItem insertTableItem1;
        private DevExpress.XtraRichEdit.UI.EditPageHeaderItem editPageHeaderItem1;
        private DevExpress.XtraRichEdit.UI.EditPageFooterItem editPageFooterItem1;
        private DevExpress.XtraRichEdit.UI.InsertPageNumberItem insertPageNumberItem1;
        private DevExpress.XtraRichEdit.UI.InsertPageCountItem insertPageCountItem1;
        private DevExpress.XtraRichEdit.UI.InsertBookmarkItem insertBookmarkItem1;
        private DevExpress.XtraRichEdit.UI.ChangeTextCaseItem changeTextCaseItem1;
        private DevExpress.XtraRichEdit.UI.MakeTextUpperCaseItem makeTextUpperCaseItem1;
        private DevExpress.XtraRichEdit.UI.MakeTextLowerCaseItem makeTextLowerCaseItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTextCaseItem toggleTextCaseItem1;
        private DevExpress.XtraRichEdit.UI.ClearFormattingItem clearFormattingItem1;
        private DevExpress.XtraRichEdit.UI.ChangeParagraphLineSpacingItem changeParagraphLineSpacingItem1;
        private DevExpress.XtraRichEdit.UI.SetSingleParagraphSpacingItem setSingleParagraphSpacingItem1;
        private DevExpress.XtraRichEdit.UI.SetSesquialteralParagraphSpacingItem setSesquialteralParagraphSpacingItem1;
        private DevExpress.XtraRichEdit.UI.SetDoubleParagraphSpacingItem setDoubleParagraphSpacingItem1;
        private DevExpress.XtraRichEdit.UI.ShowLineSpacingFormItem showLineSpacingFormItem1;
        private DevExpress.XtraRichEdit.UI.AddSpacingBeforeParagraphItem addSpacingBeforeParagraphItem1;
        private DevExpress.XtraRichEdit.UI.RemoveSpacingBeforeParagraphItem removeSpacingBeforeParagraphItem1;
        private DevExpress.XtraRichEdit.UI.AddSpacingAfterParagraphItem addSpacingAfterParagraphItem1;
        private DevExpress.XtraRichEdit.UI.RemoveSpacingAfterParagraphItem removeSpacingAfterParagraphItem1;
        private DevExpress.XtraBars.BarButtonItem itemField;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraEditors.Repository.RepositoryItemFontEdit repositoryItemFontEdit1;
        private DevExpress.XtraRichEdit.Design.RepositoryItemRichEditFontSizeEdit repositoryItemRichEditFontSizeEdit1;
        private DevExpress.XtraRichEdit.Design.RepositoryItemRichEditStyleEdit repositoryItemRichEditStyleEdit1;
        private DevExpress.XtraRichEdit.Forms.Design.RepositoryItemBorderLineStyle repositoryItemBorderLineStyle1;
        private DevExpress.XtraRichEdit.Forms.Design.RepositoryItemBorderLineWeight repositoryItemBorderLineWeight1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraRichEdit.UI.PasteSpecialItem pasteSpecialItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup2;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup3;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup4;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup5;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup6;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup7;
        private DevExpress.XtraRichEdit.UI.ChangeParagraphBackColorItem changeParagraphBackColorItem1;
        private DevExpress.XtraRichEdit.UI.GalleryChangeStyleItem galleryChangeStyleItem1;
        private DevExpress.XtraRichEdit.UI.InsertFloatingPictureItem insertFloatingPictureItem1;
        private DevExpress.XtraRichEdit.UI.InsertTextBoxItem insertTextBoxItem1;
        private DevExpress.XtraRichEdit.UI.ChangeSectionPageMarginsItem changeSectionPageMarginsItem1;
        private DevExpress.XtraRichEdit.UI.SetNormalSectionPageMarginsItem setNormalSectionPageMarginsItem1;
        private DevExpress.XtraRichEdit.UI.SetNarrowSectionPageMarginsItem setNarrowSectionPageMarginsItem1;
        private DevExpress.XtraRichEdit.UI.SetModerateSectionPageMarginsItem setModerateSectionPageMarginsItem1;
        private DevExpress.XtraRichEdit.UI.SetWideSectionPageMarginsItem setWideSectionPageMarginsItem1;
        private DevExpress.XtraRichEdit.UI.ShowPageMarginsSetupFormItem showPageMarginsSetupFormItem1;
        private DevExpress.XtraRichEdit.UI.ChangeSectionPageOrientationItem changeSectionPageOrientationItem1;
        private DevExpress.XtraRichEdit.UI.SetPortraitPageOrientationItem setPortraitPageOrientationItem1;
        private DevExpress.XtraRichEdit.UI.SetLandscapePageOrientationItem setLandscapePageOrientationItem1;
        private DevExpress.XtraRichEdit.UI.ChangeSectionPaperKindItem changeSectionPaperKindItem1;
        private DevExpress.XtraRichEdit.UI.ChangeSectionColumnsItem changeSectionColumnsItem1;
        private DevExpress.XtraRichEdit.UI.SetSectionOneColumnItem setSectionOneColumnItem1;
        private DevExpress.XtraRichEdit.UI.SetSectionTwoColumnsItem setSectionTwoColumnsItem1;
        private DevExpress.XtraRichEdit.UI.SetSectionThreeColumnsItem setSectionThreeColumnsItem1;
        private DevExpress.XtraRichEdit.UI.ShowColumnsSetupFormItem showColumnsSetupFormItem1;
        private DevExpress.XtraRichEdit.UI.InsertBreakItem insertBreakItem1;
        private DevExpress.XtraRichEdit.UI.InsertColumnBreakItem insertColumnBreakItem1;
        private DevExpress.XtraRichEdit.UI.InsertSectionBreakNextPageItem insertSectionBreakNextPageItem1;
        private DevExpress.XtraRichEdit.UI.InsertSectionBreakEvenPageItem insertSectionBreakEvenPageItem1;
        private DevExpress.XtraRichEdit.UI.InsertSectionBreakOddPageItem insertSectionBreakOddPageItem1;
        private DevExpress.XtraRichEdit.UI.ChangeSectionLineNumberingItem changeSectionLineNumberingItem1;
        private DevExpress.XtraRichEdit.UI.SetSectionLineNumberingNoneItem setSectionLineNumberingNoneItem1;
        private DevExpress.XtraRichEdit.UI.SetSectionLineNumberingContinuousItem setSectionLineNumberingContinuousItem1;
        private DevExpress.XtraRichEdit.UI.SetSectionLineNumberingRestartNewPageItem setSectionLineNumberingRestartNewPageItem1;
        private DevExpress.XtraRichEdit.UI.SetSectionLineNumberingRestartNewSectionItem setSectionLineNumberingRestartNewSectionItem1;
        private DevExpress.XtraRichEdit.UI.ToggleParagraphSuppressLineNumbersItem toggleParagraphSuppressLineNumbersItem1;
        private DevExpress.XtraRichEdit.UI.ShowLineNumberingFormItem showLineNumberingFormItem1;
        private DevExpress.XtraRichEdit.UI.ChangePageColorItem changePageColorItem1;
        private DevExpress.XtraRichEdit.UI.InsertTableOfContentsItem insertTableOfContentsItem1;
        private DevExpress.XtraRichEdit.UI.UpdateTableOfContentsItem updateTableOfContentsItem1;
        private DevExpress.XtraRichEdit.UI.AddParagraphsToTableOfContentItem addParagraphsToTableOfContentItem1;
        private DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem setParagraphHeadingLevelItem1;
        private DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem setParagraphHeadingLevelItem2;
        private DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem setParagraphHeadingLevelItem3;
        private DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem setParagraphHeadingLevelItem4;
        private DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem setParagraphHeadingLevelItem5;
        private DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem setParagraphHeadingLevelItem6;
        private DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem setParagraphHeadingLevelItem7;
        private DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem setParagraphHeadingLevelItem8;
        private DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem setParagraphHeadingLevelItem9;
        private DevExpress.XtraRichEdit.UI.SetParagraphHeadingLevelItem setParagraphHeadingLevelItem10;
        private DevExpress.XtraRichEdit.UI.InsertCaptionPlaceholderItem insertCaptionPlaceholderItem1;
        private DevExpress.XtraRichEdit.UI.InsertFiguresCaptionItems insertFiguresCaptionItems1;
        private DevExpress.XtraRichEdit.UI.InsertTablesCaptionItems insertTablesCaptionItems1;
        private DevExpress.XtraRichEdit.UI.InsertEquationsCaptionItems insertEquationsCaptionItems1;
        private DevExpress.XtraRichEdit.UI.InsertTableOfFiguresPlaceholderItem insertTableOfFiguresPlaceholderItem1;
        private DevExpress.XtraRichEdit.UI.InsertTableOfFiguresItems insertTableOfFiguresItems1;
        private DevExpress.XtraRichEdit.UI.InsertTableOfTablesItems insertTableOfTablesItems1;
        private DevExpress.XtraRichEdit.UI.InsertTableOfEquationsItems insertTableOfEquationsItems1;
        private DevExpress.XtraRichEdit.UI.InsertMergeFieldItem insertMergeFieldItem1;
        private DevExpress.XtraRichEdit.UI.ShowAllFieldCodesItem showAllFieldCodesItem1;
        private DevExpress.XtraRichEdit.UI.ShowAllFieldResultsItem showAllFieldResultsItem1;
        private DevExpress.XtraRichEdit.UI.ToggleViewMergedDataItem toggleViewMergedDataItem1;
        private DevExpress.XtraRichEdit.UI.CheckSpellingItem checkSpellingItem1;
        private DevExpress.XtraRichEdit.UI.ProtectDocumentItem protectDocumentItem1;
        private DevExpress.XtraRichEdit.UI.ChangeRangeEditingPermissionsItem changeRangeEditingPermissionsItem1;
        private DevExpress.XtraRichEdit.UI.UnprotectDocumentItem unprotectDocumentItem1;
        private DevExpress.XtraRichEdit.UI.ToggleShowHorizontalRulerItem toggleShowHorizontalRulerItem1;
        private DevExpress.XtraRichEdit.UI.ToggleShowVerticalRulerItem toggleShowVerticalRulerItem1;
        private DevExpress.XtraRichEdit.UI.GoToPageHeaderItem goToPageHeaderItem1;
        private DevExpress.XtraRichEdit.UI.GoToPageFooterItem goToPageFooterItem1;
        private DevExpress.XtraRichEdit.UI.GoToNextHeaderFooterItem goToNextHeaderFooterItem1;
        private DevExpress.XtraRichEdit.UI.GoToPreviousHeaderFooterItem goToPreviousHeaderFooterItem1;
        private DevExpress.XtraRichEdit.UI.ToggleLinkToPreviousItem toggleLinkToPreviousItem1;
        private DevExpress.XtraRichEdit.UI.ToggleDifferentFirstPageItem toggleDifferentFirstPageItem1;
        private DevExpress.XtraRichEdit.UI.ToggleDifferentOddAndEvenPagesItem toggleDifferentOddAndEvenPagesItem1;
        private DevExpress.XtraRichEdit.UI.ClosePageHeaderFooterItem closePageHeaderFooterItem1;
        private DevExpress.XtraRichEdit.UI.ShowTablePropertiesFormItem showTablePropertiesFormItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableAutoFitItem toggleTableAutoFitItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableAutoFitContentsItem toggleTableAutoFitContentsItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableAutoFitWindowItem toggleTableAutoFitWindowItem1;
        private DevExpress.XtraRichEdit.UI.ToggleTableFixedColumnWidthItem toggleTableFixedColumnWidthItem1;
        private DevExpress.XtraRichEdit.UI.ShowTableOptionsFormItem showTableOptionsFormItem1;
        private DevExpress.XtraRichEdit.UI.ChangeFloatingObjectFillColorItem changeFloatingObjectFillColorItem1;
        private DevExpress.XtraRichEdit.UI.ChangeFloatingObjectOutlineColorItem changeFloatingObjectOutlineColorItem1;
        private DevExpress.XtraRichEdit.UI.ChangeFloatingObjectOutlineWeightItem changeFloatingObjectOutlineWeightItem1;
        private DevExpress.XtraRichEdit.Forms.Design.RepositoryItemFloatingObjectOutlineWeight repositoryItemFloatingObjectOutlineWeight1;
        private DevExpress.XtraRichEdit.UI.ChangeFloatingObjectTextWrapTypeItem changeFloatingObjectTextWrapTypeItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectSquareTextWrapTypeItem setFloatingObjectSquareTextWrapTypeItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectTightTextWrapTypeItem setFloatingObjectTightTextWrapTypeItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectThroughTextWrapTypeItem setFloatingObjectThroughTextWrapTypeItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectTopAndBottomTextWrapTypeItem setFloatingObjectTopAndBottomTextWrapTypeItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectBehindTextWrapTypeItem setFloatingObjectBehindTextWrapTypeItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectInFrontOfTextWrapTypeItem setFloatingObjectInFrontOfTextWrapTypeItem1;
        private DevExpress.XtraRichEdit.UI.ChangeFloatingObjectAlignmentItem changeFloatingObjectAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectTopLeftAlignmentItem setFloatingObjectTopLeftAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectTopCenterAlignmentItem setFloatingObjectTopCenterAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectTopRightAlignmentItem setFloatingObjectTopRightAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectMiddleLeftAlignmentItem setFloatingObjectMiddleLeftAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectMiddleCenterAlignmentItem setFloatingObjectMiddleCenterAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectMiddleRightAlignmentItem setFloatingObjectMiddleRightAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectBottomLeftAlignmentItem setFloatingObjectBottomLeftAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectBottomCenterAlignmentItem setFloatingObjectBottomCenterAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.SetFloatingObjectBottomRightAlignmentItem setFloatingObjectBottomRightAlignmentItem1;
        private DevExpress.XtraRichEdit.UI.FloatingObjectBringForwardSubItem floatingObjectBringForwardSubItem1;
        private DevExpress.XtraRichEdit.UI.FloatingObjectBringForwardItem floatingObjectBringForwardItem1;
        private DevExpress.XtraRichEdit.UI.FloatingObjectBringToFrontItem floatingObjectBringToFrontItem1;
        private DevExpress.XtraRichEdit.UI.FloatingObjectBringInFrontOfTextItem floatingObjectBringInFrontOfTextItem1;
        private DevExpress.XtraRichEdit.UI.FloatingObjectSendBackwardSubItem floatingObjectSendBackwardSubItem1;
        private DevExpress.XtraRichEdit.UI.FloatingObjectSendBackwardItem floatingObjectSendBackwardItem1;
        private DevExpress.XtraRichEdit.UI.FloatingObjectSendToBackItem floatingObjectSendToBackItem1;
        private DevExpress.XtraRichEdit.UI.FloatingObjectSendBehindTextItem floatingObjectSendBehindTextItem1;
        private DevExpress.XtraRichEdit.UI.HeaderFooterToolsRibbonPageCategory headerFooterToolsRibbonPageCategory1;
        private DevExpress.XtraRichEdit.UI.HeaderFooterToolsDesignRibbonPage headerFooterToolsDesignRibbonPage1;
        private DevExpress.XtraRichEdit.UI.HeaderFooterToolsDesignNavigationRibbonPageGroup headerFooterToolsDesignNavigationRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.HeaderFooterToolsDesignOptionsRibbonPageGroup headerFooterToolsDesignOptionsRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.HeaderFooterToolsDesignCloseRibbonPageGroup headerFooterToolsDesignCloseRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TableToolsRibbonPageCategory tableToolsRibbonPageCategory1;
        private DevExpress.XtraRichEdit.UI.TableDesignRibbonPage tableDesignRibbonPage1;
        private DevExpress.XtraRichEdit.UI.TableStylesRibbonPageGroup tableStylesRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TableDrawBordersRibbonPageGroup tableDrawBordersRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TableLayoutRibbonPage tableLayoutRibbonPage1;
        private DevExpress.XtraRichEdit.UI.TableTableRibbonPageGroup tableTableRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TableRowsAndColumnsRibbonPageGroup tableRowsAndColumnsRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TableMergeRibbonPageGroup tableMergeRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TableCellSizeRibbonPageGroup tableCellSizeRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TableAlignmentRibbonPageGroup tableAlignmentRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.FloatingPictureToolsRibbonPageCategory floatingPictureToolsRibbonPageCategory1;
        private DevExpress.XtraRichEdit.UI.FloatingPictureToolsFormatPage floatingPictureToolsFormatPage1;
        private DevExpress.XtraRichEdit.UI.FloatingPictureToolsShapeStylesPageGroup floatingPictureToolsShapeStylesPageGroup1;
        private DevExpress.XtraRichEdit.UI.FloatingPictureToolsArrangePageGroup floatingPictureToolsArrangePageGroup1;
        private DevExpress.XtraRichEdit.UI.FileRibbonPage fileRibbonPage1;
        private DevExpress.XtraRichEdit.UI.CommonRibbonPageGroup commonRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.HomeRibbonPage homeRibbonPage1;
        private DevExpress.XtraRichEdit.UI.ClipboardRibbonPageGroup clipboardRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.FontRibbonPageGroup fontRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.ParagraphRibbonPageGroup paragraphRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.StylesRibbonPageGroup stylesRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.EditingRibbonPageGroup editingRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.InsertRibbonPage insertRibbonPage1;
        private DevExpress.XtraRichEdit.UI.PagesRibbonPageGroup pagesRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TablesRibbonPageGroup tablesRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.IllustrationsRibbonPageGroup illustrationsRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.LinksRibbonPageGroup linksRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.HeaderFooterRibbonPageGroup headerFooterRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.TextRibbonPageGroup textRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.SymbolsRibbonPageGroup symbolsRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.PageLayoutRibbonPage pageLayoutRibbonPage1;
        private DevExpress.XtraRichEdit.UI.PageSetupRibbonPageGroup pageSetupRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.PageBackgroundRibbonPageGroup pageBackgroundRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.ReferencesRibbonPage referencesRibbonPage1;
        private DevExpress.XtraRichEdit.UI.TableOfContentsRibbonPageGroup tableOfContentsRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.CaptionsRibbonPageGroup captionsRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.MailingsRibbonPage mailingsRibbonPage1;
        private DevExpress.XtraRichEdit.UI.MailMergeRibbonPageGroup mailMergeRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.ReviewRibbonPage reviewRibbonPage1;
        private DevExpress.XtraRichEdit.UI.DocumentProofingRibbonPageGroup documentProofingRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.DocumentProtectionRibbonPageGroup documentProtectionRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.ViewRibbonPage viewRibbonPage1;
        private DevExpress.XtraRichEdit.UI.DocumentViewsRibbonPageGroup documentViewsRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.ShowRibbonPageGroup showRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.ZoomRibbonPageGroup zoomRibbonPageGroup1;
        private DevExpress.XtraRichEdit.UI.InsertPageBreakItem insertPageBreakItem2;
        private DevExpress.XtraBars.BarButtonItem itemSave;
		private DevExpress.XtraBars.Ribbon.BackstageViewControl backstageViewControl5;
		private DevExpress.XtraBars.Ribbon.BackstageViewClientControl backstageViewClientControl5;
		private DevExpress.XtraBars.Ribbon.BackstageViewTabItem backstageViewTabItem5;
		private DevExpress.XtraBars.Ribbon.BackstageViewControl backstageViewControl1;
		private DevExpress.XtraBars.Ribbon.BackstageViewClientControl backstageViewClientControl1;
		private DevExpress.XtraBars.Ribbon.BackstageViewTabItem backstageViewTabItem1;
		private DevExpress.XtraBars.Ribbon.BackstageViewControl backstageViewControl2;
		private DevExpress.XtraBars.Ribbon.BackstageViewClientControl backstageViewClientControl2;
		private DevExpress.XtraBars.Ribbon.BackstageViewTabItem backstageViewTabItem2;
		private DevExpress.XtraBars.Ribbon.BackstageViewControl backstageViewControl3;
		private DevExpress.XtraBars.Ribbon.BackstageViewClientControl backstageViewClientControl3;
		private DevExpress.XtraBars.Ribbon.BackstageViewTabItem backstageViewTabItem3;
		private DevExpress.XtraBars.Ribbon.BackstageViewControl backstageViewControl4;
		private DevExpress.XtraBars.Ribbon.BackstageViewClientControl backstageViewClientControl4;
		private DevExpress.XtraBars.Ribbon.BackstageViewTabItem backstageViewTabItem4;
	}
}