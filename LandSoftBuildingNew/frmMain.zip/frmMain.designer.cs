﻿namespace LandSoftBuildingMain
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.Utils.SuperToolTip superToolTip4 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem4 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip1 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem1 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip2 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem2 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip3 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem3 = new DevExpress.Utils.ToolTipTitleItem();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            DevExpress.Utils.SuperToolTip superToolTip5 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipItem toolTipItem1 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip6 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipItem toolTipItem2 = new DevExpress.Utils.ToolTipItem();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup1 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem1 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            DevExpress.Utils.SuperToolTip superToolTip7 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipItem toolTipItem3 = new DevExpress.Utils.ToolTipItem();
            DevExpress.XtraBars.Alerter.AlertButton alertButton1 = new DevExpress.XtraBars.Alerter.AlertButton();
            DevExpress.XtraBars.Alerter.AlertButton alertButton2 = new DevExpress.XtraBars.Alerter.AlertButton();
            DevExpress.XtraBars.Alerter.AlertButton alertButton3 = new DevExpress.XtraBars.Alerter.AlertButton();
            DevExpress.XtraBars.Alerter.AlertButton alertButton4 = new DevExpress.XtraBars.Alerter.AlertButton();
            DevExpress.XtraBars.Alerter.AlertButton alertButton5 = new DevExpress.XtraBars.Alerter.AlertButton();
            DevExpress.XtraBars.Alerter.AlertButton alertButton6 = new DevExpress.XtraBars.Alerter.AlertButton();
            this.ribbon = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.applicationMenu1 = new DevExpress.XtraBars.Ribbon.ApplicationMenu();
            this.btnchangepass = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhatKyHeThong = new DevExpress.XtraBars.BarButtonItem();
            this.btnlogout = new DevExpress.XtraBars.BarButtonItem();
            this.btnexit = new DevExpress.XtraBars.BarButtonItem();
            this.itemChayLaiSoQuy = new DevExpress.XtraBars.BarButtonItem();
            this.imageCollection1 = new DevExpress.Utils.ImageCollection();
            this.itemThamQuan_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemToaNha = new DevExpress.XtraBars.BarButtonItem();
            this.itemMatBang = new DevExpress.XtraBars.BarButtonItem();
            this.itemLoaiTaiSan = new DevExpress.XtraBars.BarButtonItem();
            this.itemHangSanXuat = new DevExpress.XtraBars.BarButtonItem();
            this.itemXuatXu = new DevExpress.XtraBars.BarButtonItem();
            this.itemTrangThaiTaiSan = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhaCungCap = new DevExpress.XtraBars.BarButtonItem();
            this.itemTaiSanDangSuDung = new DevExpress.XtraBars.BarButtonItem();
            this.itemKeHoachBaoTri_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemKeHoachBaoTri = new DevExpress.XtraBars.BarButtonItem();
            this.itemBaoTri_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemBaoTri = new DevExpress.XtraBars.BarButtonItem();
            this.itemDXMS_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemDXMS = new DevExpress.XtraBars.BarButtonItem();
            this.itemDatHang_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemDatHang = new DevExpress.XtraBars.BarButtonItem();
            this.itemMuaHang_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemMuaHang = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhapKho_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhapKho = new DevExpress.XtraBars.BarButtonItem();
            this.itemXuatKho = new DevExpress.XtraBars.BarButtonItem();
            this.itemXuatKho_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemMatBang_TrangThai = new DevExpress.XtraBars.BarButtonItem();
            this.itemChoThue_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemChoThue = new DevExpress.XtraBars.BarButtonItem();
            this.itemTheXe_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemLoaiXe = new DevExpress.XtraBars.BarButtonItem();
            this.itemThangMay_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemThangMay = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhanKhau_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhanKhau = new DevExpress.XtraBars.BarButtonItem();
            this.itemDien = new DevExpress.XtraBars.BarButtonItem();
            this.itemNuoc = new DevExpress.XtraBars.BarButtonItem();
            this.itemDien_DinhMuc = new DevExpress.XtraBars.BarButtonItem();
            this.itemNuoc_DinhMuc = new DevExpress.XtraBars.BarButtonItem();
            this.itemThueNgoai_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemThueNgoai = new DevExpress.XtraBars.BarButtonItem();
            this.itemHopTac_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemHopTac = new DevExpress.XtraBars.BarButtonItem();
            this.itemDichVuKhac_Loai = new DevExpress.XtraBars.BarButtonItem();
            this.itemDichVuKhac = new DevExpress.XtraBars.BarButtonItem();
            this.itemSuaChua_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemSuaChua = new DevExpress.XtraBars.BarButtonItem();
            this.itemYeuCau = new DevExpress.XtraBars.BarButtonItem();
            this.itemYeuCau_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemKhachHang_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemKhachHang = new DevExpress.XtraBars.BarButtonItem();
            this.itemSkins = new DevExpress.XtraBars.RibbonGalleryBarItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.btnThemNhanVien = new DevExpress.XtraBars.BarButtonItem();
            this.btnNhanVienManager = new DevExpress.XtraBars.BarButtonItem();
            this.btnPhanQuyenNV = new DevExpress.XtraBars.BarButtonItem();
            this.itemMatBang_Them = new DevExpress.XtraBars.BarButtonItem();
            this.itemKhoiNha = new DevExpress.XtraBars.BarButtonItem();
            this.itemMatBang_View = new DevExpress.XtraBars.BarButtonItem();
            this.itemTangLau = new DevExpress.XtraBars.BarButtonItem();
            this.itemTrangThaiKHBT = new DevExpress.XtraBars.BarButtonItem();
            this.itemTrangThaiChoThue = new DevExpress.XtraBars.BarButtonItem();
            this.itemTrangThaiThueNgoai = new DevExpress.XtraBars.BarButtonItem();
            this.itemTrangThaiHopTac = new DevExpress.XtraBars.BarButtonItem();
            this.xtrbtnDangKyKhachHang = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem9 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem10 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem11 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem12 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem13 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem14 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem15 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem16 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem17 = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem1 = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem18 = new DevExpress.XtraBars.BarButtonItem();
            this.btnbieumau = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem8 = new DevExpress.XtraBars.BarButtonItem();
            this.btnHoaDon = new DevExpress.XtraBars.BarButtonItem();
            this.btnLoaiMatBang = new DevExpress.XtraBars.BarButtonItem();
            this.btnKhoManager = new DevExpress.XtraBars.BarButtonItem();
            this.btnPhongBan = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItemDanhMucToaNha = new DevExpress.XtraBars.BarSubItem();
            this.itemNhomMB = new DevExpress.XtraBars.BarButtonItem();
            this.itemLoaiTien = new DevExpress.XtraBars.BarButtonItem();
            this.itemDonViTinh = new DevExpress.XtraBars.BarButtonItem();
            this.itemLoaiGiaThue = new DevExpress.XtraBars.BarButtonItem();
            this.btnKhuVuc = new DevExpress.XtraBars.BarButtonItem();
            this.itemChucVu = new DevExpress.XtraBars.BarButtonItem();
            this.itemDMTK = new DevExpress.XtraBars.BarButtonItem();
            this.itemNganHang = new DevExpress.XtraBars.BarButtonItem();
            this.itemQuocTich = new DevExpress.XtraBars.BarButtonItem();
            this.itemLoaiYeuCau = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItemDanhMucTaiSan = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItemKhoHang = new DevExpress.XtraBars.BarButtonItem();
            this.itemDVT = new DevExpress.XtraBars.BarButtonItem();
            this.itemHeThongKT = new DevExpress.XtraBars.BarButtonItem();
            this.itemDVSD = new DevExpress.XtraBars.BarButtonItem();
            this.btnChatLuong = new DevExpress.XtraBars.BarButtonItem();
            this.btnNguonGocHT = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonGroup1 = new DevExpress.XtraBars.BarButtonGroup();
            this.barSubItem4 = new DevExpress.XtraBars.BarSubItem();
            this.barSubItemDanhMucDichVu = new DevExpress.XtraBars.BarSubItem();
            this.barSubItem6 = new DevExpress.XtraBars.BarSubItem();
            this.barButtonGroup2 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup3 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup4 = new DevExpress.XtraBars.BarButtonGroup();
            this.barSubItem2 = new DevExpress.XtraBars.BarSubItem();
            this.groupDanhMucDV = new DevExpress.XtraBars.BarSubItem();
            this.itemLoaiDichVu = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem34 = new DevExpress.XtraBars.BarButtonItem();
            this.itemBangGiaDichVuCoBan = new DevExpress.XtraBars.BarButtonItem();
            this.itemCapNhatBangGiaDichVuCoBan = new DevExpress.XtraBars.BarButtonItem();
            this.itemSoDuDauKy = new DevExpress.XtraBars.BarButtonItem();
            this.itemTXDinhMuc = new DevExpress.XtraBars.BarButtonItem();
            this.itemCauHinhAPITheXe = new DevExpress.XtraBars.BarButtonItem();
            this.itemDien3Pha_DinhMuc = new DevExpress.XtraBars.BarButtonItem();
            this.itemDienDieuHoa_DinhMuc = new DevExpress.XtraBars.BarButtonItem();
            this.itemDMNuoc = new DevExpress.XtraBars.BarButtonItem();
            this.itemNuoc_UuDai = new DevExpress.XtraBars.BarButtonItem();
            this.itemNuocCachTinh = new DevExpress.XtraBars.BarButtonItem();
            this.itemNuocNong_DongHo = new DevExpress.XtraBars.BarButtonItem();
            this.itemDongHoDien = new DevExpress.XtraBars.BarButtonItem();
            this.itemDongHoDienDieuHoa = new DevExpress.XtraBars.BarButtonItem();
            this.itemDongHoDien3Pha = new DevExpress.XtraBars.BarButtonItem();
            this.itemDongHoDienLanh = new DevExpress.XtraBars.BarButtonItem();
            this.itemNuocNong_DinhMuc = new DevExpress.XtraBars.BarButtonItem();
            this.itemNuocDongHo = new DevExpress.XtraBars.BarButtonItem();
            this.btnsmGas = new DevExpress.XtraBars.BarButtonItem();
            this.itemCaiDatChietKhau = new DevExpress.XtraBars.BarButtonItem();
            this.itemLaiSuatChamNop = new DevExpress.XtraBars.BarButtonItem();
            this.itemCaiDatDuyetHoaDon = new DevExpress.XtraBars.BarButtonItem();
            this.BtnCauHinhColor = new DevExpress.XtraBars.BarButtonItem();
            this.itemCauHinhNhanVienQuanLyNhanMail = new DevExpress.XtraBars.BarButtonItem();
            this.btnCauHinhVAT = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.itemTrangThaiNhanKhau = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItemTaiSan = new DevExpress.XtraBars.BarButtonItem();
            this.btnThongKeTQ = new DevExpress.XtraBars.BarButtonItem();
            this.butnTkMBTheoTT = new DevExpress.XtraBars.BarButtonItem();
            this.btnTKDienNuoc = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.btnTrangThaiTheXe = new DevExpress.XtraBars.BarButtonItem();
            this.btnTrangThaiThangMay = new DevExpress.XtraBars.BarButtonItem();
            this.btnTrangThaiYC = new DevExpress.XtraBars.BarButtonItem();
            this.btnDoUuTienYC = new DevExpress.XtraBars.BarButtonItem();
            this.btnEmail = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem6 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem19 = new DevExpress.XtraBars.BarButtonItem();
            this.itemCongNoTheoKhachHang = new DevExpress.XtraBars.BarButtonItem();
            this.btnBaoCaothu = new DevExpress.XtraBars.BarButtonItem();
            this.BtnBaoCaoChi = new DevExpress.XtraBars.BarButtonItem();
            this.btnBaoCaoCongNoTheoMatBang = new DevExpress.XtraBars.BarButtonItem();
            this.itemTKThuChi = new DevExpress.XtraBars.BarButtonItem();
            this.itemTKHDTTT = new DevExpress.XtraBars.BarButtonItem();
            this.barStaticItemLogin = new DevExpress.XtraBars.BarStaticItem();
            this.itemDoanhThuHopDongThue = new DevExpress.XtraBars.BarButtonItem();
            this.itemTyGia = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhacNoKhachHang = new DevExpress.XtraBars.BarButtonItem();
            this.itemTTNhacNo = new DevExpress.XtraBars.BarButtonItem();
            this.exportTS2Excel = new DevExpress.XtraBars.BarButtonItem();
            this.btnExportDV2Excel = new DevExpress.XtraBars.BarButtonItem();
            this.btnCongNohdtn = new DevExpress.XtraBars.BarButtonItem();
            this.btnCongNoHDHT = new DevExpress.XtraBars.BarButtonItem();
            this.itemThongKeYeuCau = new DevExpress.XtraBars.BarButtonItem();
            this.itemCopyRight = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemPictureEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit();
            this.itemBaoCaoMatBang = new DevExpress.XtraBars.BarButtonItem();
            this.itemThongBaoThuPhi = new DevExpress.XtraBars.BarButtonItem();
            this.itemThongBaoCatNuoc = new DevExpress.XtraBars.BarButtonItem();
            this.itemBaoCaoTongHop = new DevExpress.XtraBars.BarButtonItem();
            this.itemBaoCaoKetQauKinhDoanh = new DevExpress.XtraBars.BarButtonItem();
            this.itemChiTietNopTien = new DevExpress.XtraBars.BarButtonItem();
            this.itemChiTietThuPhi = new DevExpress.XtraBars.BarButtonItem();
            this.itemTheoDoiCongNo = new DevExpress.XtraBars.BarButtonItem();
            this.itemCongNoTongHop = new DevExpress.XtraBars.BarButtonItem();
            this.itemTheoDoiCongNoPQL = new DevExpress.XtraBars.BarButtonItem();
            this.itemTQQuanLy = new DevExpress.XtraBars.BarButtonItem();
            this.btnAnhNinh = new DevExpress.XtraBars.BarButtonItem();
            this.btnNhatKyAN = new DevExpress.XtraBars.BarButtonItem();
            this.btnNVCT = new DevExpress.XtraBars.BarButtonItem();
            this.btnGhiNhanSV = new DevExpress.XtraBars.BarButtonItem();
            this.btnAdminLogAN = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonGroup5 = new DevExpress.XtraBars.BarButtonGroup();
            this.btnChucVuMNG = new DevExpress.XtraBars.BarButtonItem();
            this.btnPhiQuanLy = new DevExpress.XtraBars.BarButtonItem();
            this.btnQuyTac = new DevExpress.XtraBars.BarButtonItem();
            this.btnDichVuCongCong = new DevExpress.XtraBars.BarButtonItem();
            this.btnDichVuCCManger = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItemCongNo = new DevExpress.XtraBars.BarSubItem();
            this.barSubItemKinhDoanh = new DevExpress.XtraBars.BarSubItem();
            this.barSubItemThongBao = new DevExpress.XtraBars.BarSubItem();
            this.subTaiSan = new DevExpress.XtraBars.BarSubItem();
            this.btnBangkePhieuXuat = new DevExpress.XtraBars.BarButtonItem();
            this.btnBangKePhieuNhap = new DevExpress.XtraBars.BarButtonItem();
            this.rptThongKeKhoaHang = new DevExpress.XtraBars.BarButtonItem();
            this.itemThueNganHanAdd = new DevExpress.XtraBars.BarButtonItem();
            this.itemThueNganHan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem20 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem21 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem22 = new DevExpress.XtraBars.BarButtonItem();
            this.btnLichThanhToanDien = new DevExpress.XtraBars.BarButtonItem();
            this.btnThemLichThanhToanDien = new DevExpress.XtraBars.BarButtonItem();
            this.btnNgonNgu = new DevExpress.XtraBars.BarButtonItem();
            this.btnAddThePhongTap = new DevExpress.XtraBars.BarButtonItem();
            this.btnQuanLyThePhongTap = new DevExpress.XtraBars.BarButtonItem();
            this.btnLoaiThePhongTap = new DevExpress.XtraBars.BarButtonItem();
            this.btnVietPhieuThu = new DevExpress.XtraBars.BarButtonItem();
            this.btnVietPhieuChi = new DevExpress.XtraBars.BarButtonItem();
            this.btnHoaDonGiayBao = new DevExpress.XtraBars.BarButtonItem();
            this.btnKhachHangBaoCao = new DevExpress.XtraBars.BarButtonItem();
            this.btnGiuXe = new DevExpress.XtraBars.BarButtonItem();
            this.btnTieuThuDien = new DevExpress.XtraBars.BarButtonItem();
            this.btnTieuThuNuoc = new DevExpress.XtraBars.BarButtonItem();
            this.btnThongKeTieuThuDienNuoc = new DevExpress.XtraBars.BarButtonItem();
            this.btnDeXuatAdd = new DevExpress.XtraBars.BarButtonItem();
            this.btnDeXuatManager = new DevExpress.XtraBars.BarButtonItem();
            this.btnMuaHangAdd = new DevExpress.XtraBars.BarButtonItem();
            this.btnMuaHangManager = new DevExpress.XtraBars.BarButtonItem();
            this.btnBaoGiaAdd = new DevExpress.XtraBars.BarButtonItem();
            this.btnBaoGiaManager = new DevExpress.XtraBars.BarButtonItem();
            this.btnGas = new DevExpress.XtraBars.BarButtonItem();
            this.btnSupport = new DevExpress.XtraBars.BarButtonItem();
            this.btnPhiKhac = new DevExpress.XtraBars.BarSubItem();
            this.btnPhiVeSinh = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhiBaoTri = new DevExpress.XtraBars.BarButtonItem();
            this.itemDKThanhToan = new DevExpress.XtraBars.BarButtonItem();
            this.btnChietKhauPQL = new DevExpress.XtraBars.BarButtonItem();
            this.itemTongHopDNG = new DevExpress.XtraBars.BarButtonItem();
            this.itemSettingPQL = new DevExpress.XtraBars.BarButtonItem();
            this.itemSettingTheXe = new DevExpress.XtraBars.BarButtonItem();
            this.itemSetupPhiChoThue = new DevExpress.XtraBars.BarButtonItem();
            this.itemAddProvider = new DevExpress.XtraBars.BarButtonItem();
            this.itemListProvider = new DevExpress.XtraBars.BarButtonItem();
            this.navSetupTheXe = new DevExpress.XtraBars.BarSubItem();
            this.itemDMChuKy = new DevExpress.XtraBars.BarButtonItem();
            this.navCaiDatPVS = new DevExpress.XtraBars.BarSubItem();
            this.ribbonGalleryBarItem1 = new DevExpress.XtraBars.RibbonGalleryBarItem();
            this.ribbonGalleryBarItem2 = new DevExpress.XtraBars.RibbonGalleryBarItem();
            this.itemBCBangKeThuChi = new DevExpress.XtraBars.BarButtonItem();
            this.itemCustomerDeb = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCTieuThuGas = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCGas = new DevExpress.XtraBars.BarSubItem();
            this.itemBCGasChiTiet = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCGasPhieuThu = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCGasTTNam = new DevExpress.XtraBars.BarButtonItem();
            this.itenBCNuoc = new DevExpress.XtraBars.BarSubItem();
            this.itemBCTieuThuNuoc = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCNuocChiTiet = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCNuocPhieuThu = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCNuocTTNam = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCDien = new DevExpress.XtraBars.BarSubItem();
            this.itemBCDienChiTiet = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCDienTTNam = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCDSGasNuoc = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCPhatSinhPQL = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCTongHopThu = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCTongPhaiThu = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCTongHopChuaThu = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCDoanhThuTheoNgay = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCPhiQuanLy = new DevExpress.XtraBars.BarSubItem();
            this.itemBCPQLBangThuPhi = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCPQL_PhieuThu = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhieuTHuPVS = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCPQLChiTietPhatSinh = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCLuyKeNam = new DevExpress.XtraBars.BarButtonItem();
            this.itemNgungCungCapDV = new DevExpress.XtraBars.BarButtonItem();
            this.itemKhoaSoAdd = new DevExpress.XtraBars.BarButtonItem();
            this.itemKhoaSoList = new DevExpress.XtraBars.BarButtonItem();
            this.subBCTheXe = new DevExpress.XtraBars.BarSubItem();
            this.itemBCTX_DanhSachDangKy = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCTX_ChiTietPhatSinh = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCTX_PhieuThu = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCTX_ChuaThanhToan = new DevExpress.XtraBars.BarButtonItem();
            this.itemTXList = new DevExpress.XtraBars.BarButtonItem();
            this.itemTXDoiChuThe = new DevExpress.XtraBars.BarButtonItem();
            this.itemTXGiaHan = new DevExpress.XtraBars.BarButtonItem();
            this.itemTXHetHan = new DevExpress.XtraBars.BarButtonItem();
            this.itemTXDangKy = new DevExpress.XtraBars.BarButtonItem();
            this.itemTXCongNo = new DevExpress.XtraBars.BarButtonItem();
            this.itemConfigFTP = new DevExpress.XtraBars.BarButtonItem();
            this.itemDKUuDai_Add = new DevExpress.XtraBars.BarButtonItem();
            this.itemDKUuDai_List = new DevExpress.XtraBars.BarButtonItem();
            this.itemHoBoi_add = new DevExpress.XtraBars.BarButtonItem();
            this.itemHoBoi_list = new DevExpress.XtraBars.BarSubItem();
            this.itemHoBoiThe_list = new DevExpress.XtraBars.BarButtonItem();
            this.itemHoBoiCongNo = new DevExpress.XtraBars.BarButtonItem();
            this.itemHoiBoiLoaiThe = new DevExpress.XtraBars.BarButtonItem();
            this.itemHoBoiDinhMuc = new DevExpress.XtraBars.BarButtonItem();
            this.itemCaiDatTTCanhBao = new DevExpress.XtraBars.BarButtonItem();
            this.itemThemGhiTang = new DevExpress.XtraBars.BarButtonItem();
            this.itemDSGhiTang = new DevExpress.XtraBars.BarButtonItem();
            this.itemThemDGL = new DevExpress.XtraBars.BarButtonItem();
            this.itemDSDanhGiaLai = new DevExpress.XtraBars.BarButtonItem();
            this.itemThemDC = new DevExpress.XtraBars.BarButtonItem();
            this.itemDSDieuChuyen = new DevExpress.XtraBars.BarButtonItem();
            this.itemThemGhiGiam = new DevExpress.XtraBars.BarButtonItem();
            this.itemDSGhiGiam = new DevExpress.XtraBars.BarButtonItem();
            this.itemTinhKH = new DevExpress.XtraBars.BarButtonItem();
            this.itemDSKhauHao = new DevExpress.XtraBars.BarButtonItem();
            this.itemThemThongKe = new DevExpress.XtraBars.BarButtonItem();
            this.itemDSThognKe = new DevExpress.XtraBars.BarButtonItem();
            this.itemThemBC = new DevExpress.XtraBars.BarButtonItem();
            this.itemDSBaoCao = new DevExpress.XtraBars.BarButtonItem();
            this.itemDSCVLuoi = new DevExpress.XtraBars.BarButtonItem();
            this.itemDSCVLich = new DevExpress.XtraBars.BarButtonItem();
            this.itemDSCongViecDG = new DevExpress.XtraBars.BarButtonItem();
            this.itemDSCVDGLich = new DevExpress.XtraBars.BarButtonItem();
            this.itemTyGiaTN = new DevExpress.XtraBars.BarButtonItem();
            this.itemTNTyGia = new DevExpress.XtraBars.BarButtonItem();
            this.itemNHThem = new DevExpress.XtraBars.BarButtonItem();
            this.itemNHCongNo = new DevExpress.XtraBars.BarButtonItem();
            this.itemMayDieuHoa = new DevExpress.XtraBars.BarButtonItem();
            this.itemThemDHNG = new DevExpress.XtraBars.BarButtonItem();
            this.itemDSDHNG = new DevExpress.XtraBars.BarButtonItem();
            this.itemCNDHNG = new DevExpress.XtraBars.BarButtonItem();
            this.itemBKThuPhiCC = new DevExpress.XtraBars.BarSubItem();
            this.itemBanCDPSCN = new DevExpress.XtraBars.BarButtonItem();
            this.itemBangKeCT = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem23 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem24 = new DevExpress.XtraBars.BarButtonItem();
            this.itemSoCTCN = new DevExpress.XtraBars.BarButtonItem();
            this.itemKhoanThuHDT = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCCacKhoanPhiDV = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCCacKhoanTon = new DevExpress.XtraBars.BarButtonItem();
            this.itemBCTongHopCN = new DevExpress.XtraBars.BarButtonItem();
            this.itemDCChiTietCN = new DevExpress.XtraBars.BarButtonItem();
            this.itemLoaiHDTN = new DevExpress.XtraBars.BarButtonItem();
            this.itemTHemDVGS = new DevExpress.XtraBars.BarButtonItem();
            this.itemDSGS = new DevExpress.XtraBars.BarButtonItem();
            this.itemLSDCCongNo = new DevExpress.XtraBars.BarButtonItem();
            this.itemHoaDonAdd = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem26 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem25 = new DevExpress.XtraBars.BarButtonItem();
            this.itemTheXe = new DevExpress.XtraBars.BarButtonItem();
            this.itemDichVuKhacAdd = new DevExpress.XtraBars.BarButtonItem();
            this.itemReport_BaoCaoDatCoc = new DevExpress.XtraBars.BarButtonItem();
            this.itemReport_HopDongChoThue = new DevExpress.XtraBars.BarButtonItem();
            this.itemRreport_DienDieuHoa = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem27 = new DevExpress.XtraBars.BarButtonItem();
            this.itemDien3Pha = new DevExpress.XtraBars.BarButtonItem();
            this.itemThanhLyChoThue = new DevExpress.XtraBars.BarButtonItem();
            this.itemChoThue_MatBang = new DevExpress.XtraBars.BarButtonItem();
            this.itemBieuMau = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhomMatBang = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhanNhomMatBang = new DevExpress.XtraBars.BarButtonItem();
            this.itemDienDongHo = new DevExpress.XtraBars.BarButtonItem();
            this.barCheckItem1 = new DevExpress.XtraBars.BarCheckItem();
            this.itemPhieuThuAdd = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhieuThu = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhieuChiAdd = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhieuChi = new DevExpress.XtraBars.BarButtonItem();
            this.itemKhauTruAdd = new DevExpress.XtraBars.BarButtonItem();
            this.itemKhauTru = new DevExpress.XtraBars.BarButtonItem();
            this.itemDichVuThongKeKhac = new DevExpress.XtraBars.BarSubItem();
            this.itemBaoCaoHDThueGianHangThueKHTHue = new DevExpress.XtraBars.BarButtonItem();
            this.itemReport_KeHoachThuTien = new DevExpress.XtraBars.BarButtonItem();
            this.itemDichVu_Report_KhauTru = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem3 = new DevExpress.XtraBars.BarSubItem();
            this.itemNuocNong = new DevExpress.XtraBars.BarButtonItem();
            this.itemNuocSinhHoat = new DevExpress.XtraBars.BarButtonItem();
            this.itemEmail_Config = new DevExpress.XtraBars.BarButtonItem();
            this.itemEmail_SettingStaff = new DevExpress.XtraBars.BarButtonItem();
            this.itemEmail_Category = new DevExpress.XtraBars.BarButtonItem();
            this.itemEmail_Templates = new DevExpress.XtraBars.BarButtonItem();
            this.itemReport_PhieuThu = new DevExpress.XtraBars.BarButtonItem();
            this.itemReport_PhieuChi = new DevExpress.XtraBars.BarButtonItem();
            this.itemReport_PhieuKhauTru = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhomKhachHang = new DevExpress.XtraBars.BarButtonItem();
            this.itemQuanHe = new DevExpress.XtraBars.BarButtonItem();
            this.barDanhMuc = new DevExpress.XtraBars.BarSubItem();
            this.itemLoaiKhachHang = new DevExpress.XtraBars.BarButtonItem();
            this.itemNguonDen = new DevExpress.XtraBars.BarButtonItem();
            this.itemMucDoLeTan = new DevExpress.XtraBars.BarButtonItem();
            this.itemTrangThaiLeTan = new DevExpress.XtraBars.BarButtonItem();
            this.itemYeuCau_CaiDat = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhomCongViec = new DevExpress.XtraBars.BarButtonItem();
            this.itemCauHinhNgayNghi = new DevExpress.XtraBars.BarButtonItem();
            this.itemCauHinhNgayNghiTheoToaNha = new DevExpress.XtraBars.BarButtonItem();
            this.itemBoPhanLienHe = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhomLienHe = new DevExpress.XtraBars.BarButtonItem();
            this.itemLeTan_Add = new DevExpress.XtraBars.BarButtonItem();
            this.itemLenTan_List = new DevExpress.XtraBars.BarButtonItem();
            this.itemChoThue_LTT = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem5 = new DevExpress.XtraBars.BarSubItem();
            this.itemGanHetHan = new DevExpress.XtraBars.BarButtonItem();
            this.itemDaHetHan = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem7 = new DevExpress.XtraBars.BarSubItem();
            this.itemDienDieuHoa = new DevExpress.XtraBars.BarButtonItem();
            this.itemDienLanh = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem8 = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem28 = new DevExpress.XtraBars.BarButtonItem();
            this.itemReport_ChiTietCongNo = new DevExpress.XtraBars.BarButtonItem();
            this.itemGiuXe_CongNoTheXe = new DevExpress.XtraBars.BarButtonItem();
            this.itemGAS_Report_BieuDo = new DevExpress.XtraBars.BarButtonItem();
            this.itemDien_BieuDo = new DevExpress.XtraBars.BarButtonItem();
            this.itemDien3Pha_BieuDo = new DevExpress.XtraBars.BarButtonItem();
            this.itemDienDieuHoa_BieuDo = new DevExpress.XtraBars.BarButtonItem();
            this.itemNuoc_BieuDo = new DevExpress.XtraBars.BarButtonItem();
            this.itemNuocNong_BieuDo = new DevExpress.XtraBars.BarButtonItem();
            this.itemNuocSinhHoat_BieuDo = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem32 = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhanLoaiLich = new DevExpress.XtraBars.BarButtonItem();
            this.itemThoiDiemLich = new DevExpress.XtraBars.BarButtonItem();
            this.itemDanhSachLich = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhanLoai = new DevExpress.XtraBars.BarButtonItem();
            this.itemTrangThai = new DevExpress.XtraBars.BarButtonItem();
            this.itemMucDo = new DevExpress.XtraBars.BarButtonItem();
            this.itemTienDo = new DevExpress.XtraBars.BarButtonItem();
            this.itemThemMoi = new DevExpress.XtraBars.BarButtonItem();
            this.itemDanhSach = new DevExpress.XtraBars.BarButtonItem();
            this.itemTaiLieu = new DevExpress.XtraBars.BarButtonItem();
            this.itemTaiLieu_Loai = new DevExpress.XtraBars.BarButtonItem();
            this.itemReport_DaThuTheXe = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhanQuyenBaoCao = new DevExpress.XtraBars.BarButtonItem();
            this.itemHoaDonDaXoa = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhieuThuDaXoa = new DevExpress.XtraBars.BarButtonItem();
            this.itemTheXeDaXoa = new DevExpress.XtraBars.BarButtonItem();
            this.itemBaoCaoCongNoTongHopTheoThang = new DevExpress.XtraBars.BarButtonItem();
            this.itemTheThangMay = new DevExpress.XtraBars.BarButtonItem();
            this.itemKhoThe = new DevExpress.XtraBars.BarButtonItem();
            this.itemDSCapThe = new DevExpress.XtraBars.BarButtonItem();
            this.itemConfigPhone = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhatKyCuocGoi = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem9 = new DevExpress.XtraBars.BarSubItem();
            this.bbiDanhSachYeuCau = new DevExpress.XtraBars.BarButtonItem();
            this.bbiCongViecCuaToi = new DevExpress.XtraBars.BarButtonItem();
            this.itemMauMail = new DevExpress.XtraBars.BarButtonItem();
            this.itemDanhSachNhan = new DevExpress.XtraBars.BarButtonItem();
            this.itemThuongHieu = new DevExpress.XtraBars.BarButtonItem();
            this.itemDanhSachGui = new DevExpress.XtraBars.BarButtonItem();
            this.itemCheckTaiKhoan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem29 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem31 = new DevExpress.XtraBars.BarButtonItem();
            this.itemHDCTNSapHetHan = new DevExpress.XtraBars.BarButtonItem();
            this.itemHDCTN = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem33 = new DevExpress.XtraBars.BarButtonItem();
            this.itemCongNoDongTien = new DevExpress.XtraBars.BarButtonItem();
            this.itemDSChuyenTien = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhieuChiKyQuy = new DevExpress.XtraBars.BarButtonItem();
            this.itemBieuDoMotToaNha = new DevExpress.XtraBars.BarSubItem();
            this.itemThongKeTheoNhomCongViec = new DevExpress.XtraBars.BarButtonItem();
            this.itemBDTinhTrangXuLy = new DevExpress.XtraBars.BarButtonItem();
            this.itemTheoDanhGiaCuaCuDan = new DevExpress.XtraBars.BarButtonItem();
            this.itemTheoNguonPhanAnh = new DevExpress.XtraBars.BarButtonItem();
            this.itemDoUuTien = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhanAnhTheoToaNha = new DevExpress.XtraBars.BarButtonItem();
            this.itemViewBieuDoAll = new DevExpress.XtraBars.BarButtonItem();
            this.itemThongKeThoiGian = new DevExpress.XtraBars.BarButtonItem();
            this.itemSubTinTuc = new DevExpress.XtraBars.BarSubItem();
            this.itemTinTuc_TyLeDangTin = new DevExpress.XtraBars.BarButtonItem();
            this.itemTinTuc_ThongKeTheoTungToaNha = new DevExpress.XtraBars.BarButtonItem();
            this.itemTinTuc_ThongKeTheoTongToaNha = new DevExpress.XtraBars.BarButtonItem();
            this.itemTinTuc_ThongKeTongHop = new DevExpress.XtraBars.BarButtonItem();
            this.itemSubApp = new DevExpress.XtraBars.BarSubItem();
            this.itemApp_TyLeSuDungTheoTungToaNha = new DevExpress.XtraBars.BarButtonItem();
            this.itemApp_TyLeSuDungTongToaNha = new DevExpress.XtraBars.BarButtonItem();
            this.itemApp_ThongKeSuDungTungToaNha = new DevExpress.XtraBars.BarButtonItem();
            this.itemApp_ThongKeSuDungCacToaNha = new DevExpress.XtraBars.BarButtonItem();
            this.itemTheoNhieuToaNha = new DevExpress.XtraBars.BarSubItem();
            this.itemNhomCongViecMuiltiTN = new DevExpress.XtraBars.BarButtonItem();
            this.itemTinhTrangXuLyTheoNhieuToaNha = new DevExpress.XtraBars.BarButtonItem();
            this.itemDanhGiaCuaCuDanTheoMuiltiToaNha = new DevExpress.XtraBars.BarButtonItem();
            this.itemNguonTiepNhanTheoMuilti = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhieuTN_PhanAnhTheoThang = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhieuTN_TongPhanAnh = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhieuTN_BaoCaoTongHop = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem10 = new DevExpress.XtraBars.BarSubItem();
            this.itemTTTaiSan = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhaCCTS = new DevExpress.XtraBars.BarButtonItem();
            this.itemDMHeThong = new DevExpress.XtraBars.BarButtonItem();
            this.itemDMLoaiTaiSan = new DevExpress.XtraBars.BarButtonItem();
            this.itemDMTenTaiSan = new DevExpress.XtraBars.BarButtonItem();
            this.ItemCaiDatHeThongChoToaNha = new DevExpress.XtraBars.BarButtonItem();
            this.itemDMChiTietTaiSan = new DevExpress.XtraBars.BarButtonItem();
            this.ItemDMVanHanh = new DevExpress.XtraBars.BarSubItem();
            this.ItemTanSuat = new DevExpress.XtraBars.BarButtonItem();
            this.itemLoaiCaTruc = new DevExpress.XtraBars.BarButtonItem();
            this.itemCongCuThietBi = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhomProfile = new DevExpress.XtraBars.BarButtonItem();
            this.itemCauHinhCapDuyet = new DevExpress.XtraBars.BarButtonItem();
            this.itemCauHinhTinhTrangPhieu = new DevExpress.XtraBars.BarButtonItem();
            this.ItemKeHoachVanHanh = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhieuVanHanh = new DevExpress.XtraBars.BarButtonItem();
            this.itemProfile = new DevExpress.XtraBars.BarButtonItem();
            this.itemGiaoNhanCa = new DevExpress.XtraBars.BarButtonItem();
            this.itemDeXuatDoiCa = new DevExpress.XtraBars.BarButtonItem();
            this.itemBangPhanCong = new DevExpress.XtraBars.BarButtonItem();
            this.itemLichTruc = new DevExpress.XtraBars.BarButtonItem();
            this.itemVHKeHoachBaoTri = new DevExpress.XtraBars.BarButtonItem();
            this.itemVHPhieuBaoTri = new DevExpress.XtraBars.BarButtonItem();
            this.itemGanProFileChoHeThong = new DevExpress.XtraBars.BarButtonItem();
            this.itemDanhMucProfile = new DevExpress.XtraBars.BarButtonItem();
            this.itemGanProfileChoToaNha = new DevExpress.XtraBars.BarButtonItem();
            this.barDanhMucVatTu = new DevExpress.XtraBars.BarSubItem();
            this.itemVTDonViTinh = new DevExpress.XtraBars.BarButtonItem();
            this.itemVTDanhMucKhoHang = new DevExpress.XtraBars.BarButtonItem();
            this.itemVTDanhMucLoaiNhapKho = new DevExpress.XtraBars.BarButtonItem();
            this.itemVTDanhMucLoaiXuatKho = new DevExpress.XtraBars.BarButtonItem();
            this.itemVTDanhMucVatTu = new DevExpress.XtraBars.BarButtonItem();
            this.itemDeXuatMuaHang = new DevExpress.XtraBars.BarButtonItem();
            this.itemDanhSachMuaHang = new DevExpress.XtraBars.BarButtonItem();
            this.itemVTNhapKho = new DevExpress.XtraBars.BarButtonItem();
            this.itemVTXuatKho = new DevExpress.XtraBars.BarButtonItem();
            this.itemVTTonKho = new DevExpress.XtraBars.BarButtonItem();
            this.barSubQuanLyHoSo = new DevExpress.XtraBars.BarSubItem();
            this.itemQLHS_LoaiVanBan = new DevExpress.XtraBars.BarButtonItem();
            this.itemQLHS_MucDoBaoMat = new DevExpress.XtraBars.BarButtonItem();
            this.itemQLHS_MucDoKhanCap = new DevExpress.XtraBars.BarButtonItem();
            this.itemQLHS_HoSo = new DevExpress.XtraBars.BarButtonItem();
            this.itemNoiBanHanh = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhanLoaiDiDen = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem37 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem38 = new DevExpress.XtraBars.BarButtonItem();
            this.itemQuanLyHoSo = new DevExpress.XtraBars.BarButtonItem();
            this.itemQLHS_KhoGiay = new DevExpress.XtraBars.BarButtonItem();
            this.itemQLHS_DayKe = new DevExpress.XtraBars.BarButtonItem();
            this.itemXuatKhoSuDung = new DevExpress.XtraBars.BarButtonItem();
            this.itemDeXuatSuaChua = new DevExpress.XtraBars.BarButtonItem();
            this.itemThongKeSoLieuVH = new DevExpress.XtraBars.BarSubItem();
            this.itemTKTinhHinhThucHien = new DevExpress.XtraBars.BarButtonItem();
            this.itemTKTinhHinhKiemTraDinhKy = new DevExpress.XtraBars.BarButtonItem();
            this.itemTKKiemTraDinhKy = new DevExpress.XtraBars.BarButtonItem();
            this.itemTKCheckList = new DevExpress.XtraBars.BarButtonItem();
            this.itemViewPhieuBaoTri = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhieuTN_SoLuongNhomCongViec = new DevExpress.XtraBars.BarButtonItem();
            this.itemViewKeHoachBaoTri = new DevExpress.XtraBars.BarButtonItem();
            this.itemSMSSoDuTaiKhoan = new DevExpress.XtraBars.BarButtonItem();
            this.itemSMSLichSu = new DevExpress.XtraBars.BarButtonItem();
            this.itemSMS_Mau = new DevExpress.XtraBars.BarButtonItem();
            this.itemCaiDatBieuMau = new DevExpress.XtraBars.BarButtonItem();
            this.itemScheduleComfirm = new DevExpress.XtraBars.BarButtonItem();
            this.itemEmailSetup = new DevExpress.XtraBars.BarButtonItem();
            this.itemBcThuChiTm = new DevExpress.XtraBars.BarButtonItem();
            this.itemBcCongNoDichVu = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonGroup6 = new DevExpress.XtraBars.BarButtonGroup();
            this.itemBaoCaoDaThu = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem11 = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem30 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem35 = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem12 = new DevExpress.XtraBars.BarSubItem();
            this.itemBcChiTietThuPqlThang = new DevExpress.XtraBars.BarButtonItem();
            this.itemGroupBcCongNoTongHop = new DevExpress.XtraBars.BarSubItem();
            this.itemBaoCaoCongNoAll = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhiPhaiThuTrongThang = new DevExpress.XtraBars.BarButtonItem();
            this.itemHoaDonThongKe = new DevExpress.XtraBars.BarButtonItem();
            this.itemBaoCaoCongNoDichVu = new DevExpress.XtraBars.BarButtonItem();
            this.itemReportPhiDaThu = new DevExpress.XtraBars.BarButtonItem();
            this.itemBaoCaoTongHopCongNoDichVu = new DevExpress.XtraBars.BarButtonItem();
            this.itemBcCongNoTongHopTheoThang = new DevExpress.XtraBars.BarButtonItem();
            this.itemBaoCaoCacKhoanDaKhauTru = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem68 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem69 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem70 = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem13 = new DevExpress.XtraBars.BarSubItem();
            this.itemReportBaoCaoTienDien = new DevExpress.XtraBars.BarButtonItem();
            this.itemRreportDienDieuHoa = new DevExpress.XtraBars.BarButtonItem();
            this.itemBieuDoTieuThuDien = new DevExpress.XtraBars.BarButtonItem();
            this.itemBieuDoTieuThuDien3Pha = new DevExpress.XtraBars.BarButtonItem();
            this.itemBieuDoTieuThuDienDieuHoa = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem14 = new DevExpress.XtraBars.BarSubItem();
            this.itemBaoCaoDichVuNuoc = new DevExpress.XtraBars.BarButtonItem();
            this.itemBieuDoTieuThuNuoc = new DevExpress.XtraBars.BarButtonItem();
            this.itemBieuDoTieuThuNuocNong = new DevExpress.XtraBars.BarButtonItem();
            this.itemBieuDoTieuThuNuocSinhHoat = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem15 = new DevExpress.XtraBars.BarSubItem();
            this.itemBaoCaoDichVuGas = new DevExpress.XtraBars.BarButtonItem();
            this.itemBieuDoTieuThuGas = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem16 = new DevExpress.XtraBars.BarSubItem();
            this.itemBaoCaoDichVuGuiXe = new DevExpress.XtraBars.BarButtonItem();
            this.itemSoCongNoTheXe = new DevExpress.XtraBars.BarButtonItem();
            this.itemBaoCaoDaThuTheXePhatSinh = new DevExpress.XtraBars.BarButtonItem();
            this.itemBaoCaoChiTietPhiGiuXeThang = new DevExpress.XtraBars.BarButtonItem();
            this.itemBaoCaoDoanhThuGiuXeOTo = new DevExpress.XtraBars.BarButtonItem();
            this.itemBaoCaoDoanhThuGiuXeMay = new DevExpress.XtraBars.BarButtonItem();
            this.itemBaoCaoDoanhThuGiuXeDap = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem18 = new DevExpress.XtraBars.BarSubItem();
            this.itemScheduleStatus = new DevExpress.XtraBars.BarButtonItem();
            this.itemScheduleComfirm1 = new DevExpress.XtraBars.BarButtonItem();
            this.ItemScheduleGroup = new DevExpress.XtraBars.BarButtonItem();
            this.itemUserHandover = new DevExpress.XtraBars.BarButtonItem();
            this.itemDuty = new DevExpress.XtraBars.BarButtonItem();
            this.itemStatus = new DevExpress.XtraBars.BarButtonItem();
            this.itemTrangThaiDuyetDeXuat = new DevExpress.XtraBars.BarButtonItem();
            this.itemTieuDeThongBao = new DevExpress.XtraBars.BarButtonItem();
            this.itemNoiDungThongBao = new DevExpress.XtraBars.BarButtonItem();
            this.itemUnit = new DevExpress.XtraBars.BarButtonItem();
            this.itemAssetGroups = new DevExpress.XtraBars.BarButtonItem();
            this.itemStatusAsset = new DevExpress.XtraBars.BarButtonItem();
            this.itemCarTyle = new DevExpress.XtraBars.BarButtonItem();
            this.itemNewsTyle = new DevExpress.XtraBars.BarButtonItem();
            this.itemGroupChecklist = new DevExpress.XtraBars.BarButtonItem();
            this.itemBlockChecklist = new DevExpress.XtraBars.BarButtonItem();
            this.itemSchedule = new DevExpress.XtraBars.BarButtonItem();
            this.itemHandover = new DevExpress.XtraBars.BarButtonItem();
            this.itemHandoverHistory = new DevExpress.XtraBars.BarButtonItem();
            this.itemCarSetup = new DevExpress.XtraBars.BarButtonItem();
            this.itemCarSchedule = new DevExpress.XtraBars.BarButtonItem();
            this.itemNewsManager = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem19 = new DevExpress.XtraBars.BarSubItem();
            this.itemSendMailToManager = new DevExpress.XtraBars.BarButtonItem();
            this.itemDeposit = new DevExpress.XtraBars.BarButtonItem();
            this.itemDepositDelete = new DevExpress.XtraBars.BarButtonItem();
            this.itemWithDraw = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem20 = new DevExpress.XtraBars.BarSubItem();
            this.itemDrTyle = new DevExpress.XtraBars.BarButtonItem();
            this.itemDepositManager = new DevExpress.XtraBars.BarButtonItem();
            this.itemSoQuyDatCoc = new DevExpress.XtraBars.BarButtonItem();
            this.itemHangMuc = new DevExpress.XtraBars.BarButtonItem();
            this.itemChecklist = new DevExpress.XtraBars.BarButtonItem();
            this.itemChecklistToaNha = new DevExpress.XtraBars.BarButtonItem();
            this.itemHandoverLocal = new DevExpress.XtraBars.BarButtonItem();
            this.itemPlanCustomer = new DevExpress.XtraBars.BarButtonItem();
            this.itemScheduleCustomer = new DevExpress.XtraBars.BarButtonItem();
            this.itemHandoverCustomer = new DevExpress.XtraBars.BarButtonItem();
            this.itemHistoryCustomer = new DevExpress.XtraBars.BarButtonItem();
            this.itemAssetCategory = new DevExpress.XtraBars.BarButtonItem();
            this.itemDeXuatThayCa = new DevExpress.XtraBars.BarButtonItem();
            this.itemDienTichLapDay = new DevExpress.XtraBars.BarButtonItem();
            this.itemBieuMauHDT = new DevExpress.XtraBars.BarButtonItem();
            this.itemTruongTronHDT = new DevExpress.XtraBars.BarButtonItem();
            this.itemMauHDT = new DevExpress.XtraBars.BarButtonItem();
            this.itemLapHoaDonHDT = new DevExpress.XtraBars.BarButtonItem();
            this.itemHoaDonHDT = new DevExpress.XtraBars.BarButtonItem();
            this.itemHoaDonDaXoaHDT = new DevExpress.XtraBars.BarButtonItem();
            this.itemCongNoHDT = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhieuThuHDT = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhieuThuDaXoaHDT = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhieuDieuChuyenHDT = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhieuChiHDT = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhieuKhauTruHDT = new DevExpress.XtraBars.BarButtonItem();
            this.itemMoneyPurpose = new DevExpress.XtraBars.BarButtonItem();
            this.itemMoneyPurposeItems = new DevExpress.XtraBars.BarButtonItem();
            this.itemHopDongDatCoc = new DevExpress.XtraBars.BarButtonItem();
            this.itemKhachHangTiemNang = new DevExpress.XtraBars.BarButtonItem();
            this.itemDanhSachCongViec = new DevExpress.XtraBars.BarButtonItem();
            this.itemHopDongThueNgoai = new DevExpress.XtraBars.BarButtonItem();
            this.itemDeXuatDoiLich = new DevExpress.XtraBars.BarButtonItem();
            this.itemDanhSachThanhCong = new DevExpress.XtraBars.BarButtonItem();
            this.itemDanhSachSuaChua = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem36 = new DevExpress.XtraBars.BarButtonItem();
            this.itemHdtnGanHetHan = new DevExpress.XtraBars.BarButtonItem();
            this.itemHdtnHetHan = new DevExpress.XtraBars.BarButtonItem();
            this.itemThanhLyHdtn = new DevExpress.XtraBars.BarButtonItem();
            this.itemCongNoTienDatCoc = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem21 = new DevExpress.XtraBars.BarSubItem();
            this.itemNoiDungCongViec = new DevExpress.XtraBars.BarButtonItem();
            this.itemNoiDungNhomCongViec = new DevExpress.XtraBars.BarButtonItem();
            this.itemTruongTron = new DevExpress.XtraBars.BarButtonItem();
            this.itemTruongTronHdtn = new DevExpress.XtraBars.BarButtonItem();
            this.itemBieuMauHdtn = new DevExpress.XtraBars.BarButtonItem();
            this.btnPhanQuyenBieuMauHdtn = new DevExpress.XtraBars.BarButtonItem();
            this.itemCongNoDoiTac = new DevExpress.XtraBars.BarButtonItem();
            this.itemBaoCaoThongKeKinhPhi = new DevExpress.XtraBars.BarButtonItem();
            this.itemCongNoTongHopHdtn = new DevExpress.XtraBars.BarButtonItem();
            this.itemTienTrinhThucHien = new DevExpress.XtraBars.BarButtonItem();
            this.itemLichThanhToan = new DevExpress.XtraBars.BarButtonItem();
            this.itemDanhGiaHdtn = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhanQuyenBieuDoMain = new DevExpress.XtraBars.BarButtonItem();
            this.itemCapNhatItemMain = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhanQuyenItem = new DevExpress.XtraBars.BarButtonItem();
            this.itemCoPhanQuyen = new DevExpress.XtraBars.BarButtonItem();
            this.itemTruongTronDatCocThiCong = new DevExpress.XtraBars.BarButtonItem();
            this.itemBieuMauDatCocThiCong = new DevExpress.XtraBars.BarButtonItem();
            this.itemPhanQuyenBieuMauDatCocThiCong = new DevExpress.XtraBars.BarButtonItem();
            this.itemVanBanDen = new DevExpress.XtraBars.BarButtonItem();
            this.itemVanBanDi = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem22 = new DevExpress.XtraBars.BarSubItem();
            this.barSubItem23 = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem39 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem40 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem41 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem42 = new DevExpress.XtraBars.BarButtonItem();
            this.itemSoDoPhanLo = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem43 = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem24 = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem44 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem45 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem47 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem48 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem49 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem50 = new DevExpress.XtraBars.BarButtonItem();
            this.itemCauHinhPage = new DevExpress.XtraBars.BarButtonItem();
            this.itemDanhSachMau = new DevExpress.XtraBars.BarButtonItem();
            this.itemLayDanhSachKhachHang = new DevExpress.XtraBars.BarButtonItem();
            this.IiemDanhsachkhachhangquantam = new DevExpress.XtraBars.BarButtonItem();
            this.istemLichSuGuiSms = new DevExpress.XtraBars.BarButtonItem();
            this.itemDuTinh = new DevExpress.XtraBars.BarSubItem();
            this.itemDuTinhHDT = new DevExpress.XtraBars.BarButtonItem();
            this.itemDuTinhPQL = new DevExpress.XtraBars.BarButtonItem();
            this.itemDuTinhXe = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem51 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem52 = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhanVienQuanTam = new DevExpress.XtraBars.BarButtonItem();
            this.itemMauGuiNhanVien = new DevExpress.XtraBars.BarButtonItem();
            this.itemLichSuGuiNhanVien = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem53 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem54 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem55 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem56 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem57 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem58 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem59 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem60 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem61 = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem25 = new DevExpress.XtraBars.BarSubItem();
            this.itemNguonKH = new DevExpress.XtraBars.BarButtonItem();
            this.itemQuyMo = new DevExpress.XtraBars.BarButtonItem();
            this.itemLocation = new DevExpress.XtraBars.BarSubItem();
            this.itemXa = new DevExpress.XtraBars.BarButtonItem();
            this.itemHuyen = new DevExpress.XtraBars.BarButtonItem();
            this.itemTinh = new DevExpress.XtraBars.BarButtonItem();
            this.itemHTTX = new DevExpress.XtraBars.BarButtonItem();
            this.itemNhuCauThue = new DevExpress.XtraBars.BarButtonItem();
            this.itemCauHinhTiemNang = new DevExpress.XtraBars.BarButtonItem();
            this.itemLoaiBaoGia = new DevExpress.XtraBars.BarButtonItem();
            this.itemTrangThaiCSKH = new DevExpress.XtraBars.BarButtonItem();
            this.itemNgheNghiep = new DevExpress.XtraBars.BarButtonItem();
            this.itemCSKH = new DevExpress.XtraBars.BarButtonItem();
            this.itemCSKHChinhThuc = new DevExpress.XtraBars.BarButtonItem();
            this.itemTraCuuDoanhNghiep = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem65 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem66 = new DevExpress.XtraBars.BarButtonItem();
            this.itemBaoGia = new DevExpress.XtraBars.BarButtonItem();
            this.itemCoHoi = new DevExpress.XtraBars.BarButtonItem();
            this.itemNguoiLienHe = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem62 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem63 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem64 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem67 = new DevExpress.XtraBars.BarButtonItem();
            this.itemKhaoSat = new DevExpress.XtraBars.BarButtonItem();
            this.itemThongKeKhaoSat = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem71 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem72 = new DevExpress.XtraBars.BarButtonItem();
            this.itemVer = new DevExpress.XtraBars.BarButtonItem();
            this.btnBCDienTichChoThue = new DevExpress.XtraBars.BarButtonItem();
            this.btnBaoCaoDienNuoc = new DevExpress.XtraBars.BarButtonItem();
            this.btnBCTongHopNuoc = new DevExpress.XtraBars.BarButtonItem();
            this.btnLienHe = new DevExpress.XtraBars.BarButtonItem();
            this.btnBanner = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem73 = new DevExpress.XtraBars.BarButtonItem();
            this.btnMenuDVMoi = new DevExpress.XtraBars.BarSubItem();
            this.btnchuyendo = new DevExpress.XtraBars.BarButtonItem();
            this.btnDSDangKyNV = new DevExpress.XtraBars.BarButtonItem();
            this.btnLamNgoaiGio = new DevExpress.XtraBars.BarButtonItem();
            this.itemKeHoachXitConTrung = new DevExpress.XtraBars.BarButtonItem();
            this.itemLichBaoTri_Lich = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage4 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroupHeThong = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonGroupToaNha = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup22 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroupBieuMau = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.groupGiaoDien = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup24 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageToaNha = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroupToaNha = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroupNhanVien = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup46 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroupMatBang = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup39 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage3 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup11 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup35 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup33 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup12 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup34 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup25 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup29 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageKhachHang = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup18 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroupKhachHang = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroupCuDan = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroupYeuCau = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup19 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup5 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup40 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup27 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage7 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup49 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup50 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup51 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup52 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup53 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup54 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup55 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup57 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage6 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup36 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup37 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup38 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage9 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup58 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.pageHopDongThueNgoai = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup44 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup41 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.groupHopDong = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.groupTienTrinh = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup43 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup42 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup45 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.groupBaoCaoHdtn = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageDichVu = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroupDMDV = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.GroupDichVuKhac = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup14 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroupDienNuoc = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup23 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroupHoaDon = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup15 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.pageSoQuy = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup8 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup13 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.pageGroupChuyenTienvaKyQuy = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup17 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage5 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup30 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup56 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup31 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup9 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup10 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.groupBieuMauDatCocThiCong = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup32 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageTaiSan = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup3 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.pageGroupVatTu = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup7 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageVanHanh = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageDMVanHanh = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup4 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.pageSuaChua = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroupVanHanh = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup6 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup_BaoCaoVanHanh = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup20 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup21 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.itemPageKhaoSat = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup16 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup26 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup_SMS = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup28 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup48 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.pageAbout = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.pgAbout = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup47 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonStatusBar = new DevExpress.XtraBars.Ribbon.RibbonStatusBar();
            this.repositoryItemPopupContainerEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemPopupContainerEdit();
            this.btnGiayBao = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem7 = new DevExpress.XtraBars.BarButtonItem();
            this.dockManager1 = new DevExpress.XtraBars.Docking.DockManager();
            this.hideContainerRight = new DevExpress.XtraBars.Docking.AutoHideContainer();
            this.dockPanelThongBao = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel2_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.splitContainerControlRightPanel = new DevExpress.XtraEditors.SplitContainerControl();
            this.gcthongbao = new DevExpress.XtraGrid.GridControl();
            this.grvthongbao = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.gcNhacViec = new DevExpress.XtraGrid.GridControl();
            this.grvNhacViec = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colDD = new DevExpress.XtraGrid.Columns.GridColumn();
            this.checkIsRead = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.txtNoiDung = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.timerCapNhat = new System.Windows.Forms.Timer();
            this.itemThamQuan = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem17 = new DevExpress.XtraBars.BarSubItem();
            this.alertControlNhacViec = new DevExpress.XtraBars.Alerter.AlertControl();
            this.pageMain = new DevExpress.XtraTabbedMdi.XtraTabbedMdiManager();
            this.alertControlKeHoachBaoTri = new DevExpress.XtraBars.Alerter.AlertControl();
            this.timerReminder = new System.Windows.Forms.Timer();
            this.alctAltert = new DevExpress.XtraBars.Alerter.AlertControl();
            this.ribbonPage8 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.barButtonItem46 = new DevExpress.XtraBars.BarButtonItem();
            this.btnDangKyChuyenDo = new DevExpress.XtraBars.BarButtonItem();
            this.itemLichBaoTri_KhachHangXacNhan = new DevExpress.XtraBars.BarButtonItem();
            ((System.ComponentModel.ISupportInitialize)(this.ribbon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.applicationMenu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPopupContainerEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dockManager1)).BeginInit();
            this.hideContainerRight.SuspendLayout();
            this.dockPanelThongBao.SuspendLayout();
            this.dockPanel2_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControlRightPanel)).BeginInit();
            this.splitContainerControlRightPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcthongbao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvthongbao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcNhacViec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvNhacViec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkIsRead)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNoiDung)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pageMain)).BeginInit();
            this.SuspendLayout();
            // 
            // ribbon
            // 
            this.ribbon.AllowCustomization = true;
            this.ribbon.ApplicationButtonDropDownControl = this.applicationMenu1;
            this.ribbon.ApplicationButtonImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_guest_filled_50px;
            toolTipTitleItem4.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.LandSoft;
            toolTipTitleItem4.Text = "LandSoftBuilding\r\n\r\nCopyright @2011 by DIPVietnam";
            superToolTip4.Items.Add(toolTipTitleItem4);
            this.ribbon.ApplicationButtonSuperTip = superToolTip4;
            this.ribbon.ApplicationButtonText = null;
            this.ribbon.AutoSizeItems = true;
            this.ribbon.ExpandCollapseItem.Id = 0;
            this.ribbon.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.ribbon.Images = this.imageCollection1;
            this.ribbon.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbon.ExpandCollapseItem,
            this.itemThamQuan_Them,
            this.itemToaNha,
            this.itemMatBang,
            this.itemLoaiTaiSan,
            this.itemHangSanXuat,
            this.itemXuatXu,
            this.itemTrangThaiTaiSan,
            this.itemNhaCungCap,
            this.itemTaiSanDangSuDung,
            this.itemKeHoachBaoTri_Them,
            this.itemKeHoachBaoTri,
            this.itemBaoTri_Them,
            this.itemBaoTri,
            this.itemDXMS_Them,
            this.itemDXMS,
            this.itemDatHang_Them,
            this.itemDatHang,
            this.itemMuaHang_Them,
            this.itemMuaHang,
            this.itemNhapKho_Them,
            this.itemNhapKho,
            this.itemXuatKho,
            this.itemXuatKho_Them,
            this.itemMatBang_TrangThai,
            this.itemChoThue_Them,
            this.itemChoThue,
            this.itemTheXe_Them,
            this.itemLoaiXe,
            this.itemThangMay_Them,
            this.itemThangMay,
            this.itemNhanKhau_Them,
            this.itemNhanKhau,
            this.itemDien,
            this.itemNuoc,
            this.itemDien_DinhMuc,
            this.itemNuoc_DinhMuc,
            this.itemThueNgoai_Them,
            this.itemThueNgoai,
            this.itemHopTac_Them,
            this.itemHopTac,
            this.itemDichVuKhac_Loai,
            this.itemDichVuKhac,
            this.itemSuaChua_Them,
            this.itemSuaChua,
            this.itemYeuCau,
            this.itemYeuCau_Them,
            this.itemKhachHang_Them,
            this.itemKhachHang,
            this.itemSkins,
            this.barButtonItem1,
            this.barButtonItem2,
            this.btnThemNhanVien,
            this.btnNhanVienManager,
            this.btnPhanQuyenNV,
            this.itemMatBang_Them,
            this.itemKhoiNha,
            this.itemMatBang_View,
            this.itemTangLau,
            this.itemTrangThaiKHBT,
            this.itemTrangThaiChoThue,
            this.itemTrangThaiThueNgoai,
            this.itemTrangThaiHopTac,
            this.xtrbtnDangKyKhachHang,
            this.barButtonItem9,
            this.barButtonItem10,
            this.barButtonItem11,
            this.barButtonItem12,
            this.barButtonItem13,
            this.barButtonItem14,
            this.barButtonItem15,
            this.barButtonItem16,
            this.barButtonItem17,
            this.barSubItem1,
            this.barButtonItem18,
            this.btnbieumau,
            this.btnlogout,
            this.btnchangepass,
            this.btnexit,
            this.barButtonItem8,
            this.btnHoaDon,
            this.btnLoaiMatBang,
            this.btnKhoManager,
            this.btnPhongBan,
            this.barSubItemDanhMucToaNha,
            this.barSubItemDanhMucTaiSan,
            this.barButtonGroup1,
            this.barSubItem4,
            this.barSubItemDanhMucDichVu,
            this.barSubItem6,
            this.barButtonGroup2,
            this.barButtonGroup3,
            this.barButtonGroup4,
            this.barSubItem2,
            this.groupDanhMucDV,
            this.barButtonItem4,
            this.itemTrangThaiNhanKhau,
            this.barButtonItemTaiSan,
            this.btnThongKeTQ,
            this.butnTkMBTheoTT,
            this.btnTKDienNuoc,
            this.barButtonItem5,
            this.btnTrangThaiTheXe,
            this.btnTrangThaiThangMay,
            this.btnTrangThaiYC,
            this.btnDoUuTienYC,
            this.btnEmail,
            this.barButtonItem6,
            this.barButtonItem19,
            this.itemCongNoTheoKhachHang,
            this.btnBaoCaothu,
            this.BtnBaoCaoChi,
            this.btnBaoCaoCongNoTheoMatBang,
            this.itemTKThuChi,
            this.itemTKHDTTT,
            this.barStaticItemLogin,
            this.itemDoanhThuHopDongThue,
            this.itemTyGia,
            this.itemNhacNoKhachHang,
            this.itemTTNhacNo,
            this.exportTS2Excel,
            this.btnExportDV2Excel,
            this.btnCongNohdtn,
            this.btnCongNoHDHT,
            this.itemThongKeYeuCau,
            this.itemCopyRight,
            this.itemBaoCaoMatBang,
            this.itemThongBaoThuPhi,
            this.itemThongBaoCatNuoc,
            this.itemBaoCaoTongHop,
            this.itemBaoCaoKetQauKinhDoanh,
            this.itemChiTietNopTien,
            this.itemChiTietThuPhi,
            this.itemTheoDoiCongNo,
            this.itemCongNoTongHop,
            this.itemTheoDoiCongNoPQL,
            this.itemTQQuanLy,
            this.btnAnhNinh,
            this.btnNhatKyAN,
            this.btnNVCT,
            this.btnGhiNhanSV,
            this.btnAdminLogAN,
            this.barButtonGroup5,
            this.btnChucVuMNG,
            this.btnPhiQuanLy,
            this.btnQuyTac,
            this.btnKhuVuc,
            this.btnDichVuCongCong,
            this.btnDichVuCCManger,
            this.barButtonItemKhoHang,
            this.barSubItemCongNo,
            this.barSubItemKinhDoanh,
            this.barSubItemThongBao,
            this.subTaiSan,
            this.btnBangkePhieuXuat,
            this.btnBangKePhieuNhap,
            this.rptThongKeKhoaHang,
            this.itemThueNganHanAdd,
            this.itemThueNganHan,
            this.barButtonItem3,
            this.barButtonItem20,
            this.barButtonItem21,
            this.barButtonItem22,
            this.btnLichThanhToanDien,
            this.btnThemLichThanhToanDien,
            this.btnNgonNgu,
            this.btnAddThePhongTap,
            this.btnQuanLyThePhongTap,
            this.btnLoaiThePhongTap,
            this.btnVietPhieuThu,
            this.btnVietPhieuChi,
            this.btnHoaDonGiayBao,
            this.btnKhachHangBaoCao,
            this.btnGiuXe,
            this.btnTieuThuDien,
            this.btnTieuThuNuoc,
            this.btnThongKeTieuThuDienNuoc,
            this.btnDeXuatAdd,
            this.btnDeXuatManager,
            this.btnMuaHangAdd,
            this.btnMuaHangManager,
            this.btnBaoGiaAdd,
            this.btnBaoGiaManager,
            this.btnGas,
            this.btnsmGas,
            this.btnSupport,
            this.btnPhiKhac,
            this.btnPhiVeSinh,
            this.btnChietKhauPQL,
            this.itemTongHopDNG,
            this.itemSettingPQL,
            this.itemSettingTheXe,
            this.itemSetupPhiChoThue,
            this.itemAddProvider,
            this.itemListProvider,
            this.navSetupTheXe,
            this.navCaiDatPVS,
            this.ribbonGalleryBarItem1,
            this.ribbonGalleryBarItem2,
            this.itemDMNuoc,
            this.itemTXDinhMuc,
            this.itemBCBangKeThuChi,
            this.itemCustomerDeb,
            this.itemDMChuKy,
            this.itemBCTieuThuGas,
            this.itemBCGas,
            this.itenBCNuoc,
            this.itemBCDien,
            this.itemBCTieuThuNuoc,
            this.itemBCGasChiTiet,
            this.itemBCNuocChiTiet,
            this.itemBCDienChiTiet,
            this.itemBCDSGasNuoc,
            this.itemBCGasPhieuThu,
            this.itemBCNuocPhieuThu,
            this.itemBCPhatSinhPQL,
            this.itemBCTongHopThu,
            this.itemBCTongPhaiThu,
            this.itemBCTongHopChuaThu,
            this.itemBCDoanhThuTheoNgay,
            this.itemBCPhiQuanLy,
            this.itemBCPQLBangThuPhi,
            this.itemBCPQLChiTietPhatSinh,
            this.itemBCLuyKeNam,
            this.itemBCGasTTNam,
            this.itemBCNuocTTNam,
            this.itemBCDienTTNam,
            this.itemNgungCungCapDV,
            this.itemBCPQL_PhieuThu,
            this.itemKhoaSoAdd,
            this.itemKhoaSoList,
            this.itemPhieuTHuPVS,
            this.subBCTheXe,
            this.itemBCTX_DanhSachDangKy,
            this.itemBCTX_ChiTietPhatSinh,
            this.itemBCTX_PhieuThu,
            this.itemBCTX_ChuaThanhToan,
            this.itemTXList,
            this.itemTXDoiChuThe,
            this.itemTXGiaHan,
            this.itemTXHetHan,
            this.itemTXDangKy,
            this.itemTXCongNo,
            this.itemConfigFTP,
            this.itemDKUuDai_Add,
            this.itemDKUuDai_List,
            this.itemHoBoi_add,
            this.itemHoBoi_list,
            this.itemHoBoiThe_list,
            this.itemHoBoiCongNo,
            this.itemHoBoiDinhMuc,
            this.itemHoiBoiLoaiThe,
            this.itemLaiSuatChamNop,
            this.itemCaiDatTTCanhBao,
            this.itemPhiBaoTri,
            this.itemThemGhiTang,
            this.itemDSGhiTang,
            this.itemThemDGL,
            this.itemDSDanhGiaLai,
            this.itemThemDC,
            this.itemDSDieuChuyen,
            this.itemThemGhiGiam,
            this.itemDSGhiGiam,
            this.itemTinhKH,
            this.itemDSKhauHao,
            this.itemThemThongKe,
            this.itemDSThognKe,
            this.itemThemBC,
            this.itemDSBaoCao,
            this.itemDSCVLuoi,
            this.itemDSCVLich,
            this.itemDSCongViecDG,
            this.itemDSCVDGLich,
            this.itemHeThongKT,
            this.itemDVSD,
            this.itemTyGiaTN,
            this.itemTNTyGia,
            this.btnChatLuong,
            this.btnNguonGocHT,
            this.itemDMTK,
            this.itemNHThem,
            this.itemNHCongNo,
            this.itemMayDieuHoa,
            this.itemThemDHNG,
            this.itemDSDHNG,
            this.itemCNDHNG,
            this.itemBKThuPhiCC,
            this.itemBanCDPSCN,
            this.itemBangKeCT,
            this.barButtonItem23,
            this.barButtonItem24,
            this.itemSoCTCN,
            this.itemKhoanThuHDT,
            this.itemBCCacKhoanPhiDV,
            this.itemBCCacKhoanTon,
            this.itemLoaiHDTN,
            this.itemBCTongHopCN,
            this.itemDVT,
            this.itemDCChiTietCN,
            this.itemTHemDVGS,
            this.itemDSGS,
            this.itemDKThanhToan,
            this.itemLSDCCongNo,
            this.itemLoaiTien,
            this.itemLoaiGiaThue,
            this.itemHoaDonAdd,
            this.itemLoaiDichVu,
            this.itemCaiDatChietKhau,
            this.barButtonItem26,
            this.barButtonItem25,
            this.itemTheXe,
            this.itemDichVuKhacAdd,
            this.itemReport_BaoCaoDatCoc,
            this.itemReport_HopDongChoThue,
            this.itemRreport_DienDieuHoa,
            this.itemNuoc_UuDai,
            this.itemDonViTinh,
            this.barButtonItem27,
            this.itemNuocCachTinh,
            this.itemBangGiaDichVuCoBan,
            this.itemDien3Pha,
            this.itemDien3Pha_DinhMuc,
            this.itemThanhLyChoThue,
            this.itemChoThue_MatBang,
            this.itemBieuMau,
            this.itemNhomMatBang,
            this.itemPhanNhomMatBang,
            this.itemDienDongHo,
            this.itemNuocDongHo,
            this.barCheckItem1,
            this.itemNganHang,
            this.itemPhieuThuAdd,
            this.itemPhieuThu,
            this.itemPhieuChiAdd,
            this.itemPhieuChi,
            this.itemKhauTruAdd,
            this.itemKhauTru,
            this.itemDichVuThongKeKhac,
            this.itemDichVu_Report_KhauTru,
            this.barSubItem3,
            this.itemNuocNong_DongHo,
            this.itemNuocNong_DinhMuc,
            this.itemNuocNong,
            this.itemNuocSinhHoat,
            this.itemEmail_Config,
            this.itemEmail_SettingStaff,
            this.itemEmail_Category,
            this.itemEmail_Templates,
            this.itemReport_PhieuThu,
            this.itemReport_PhieuChi,
            this.itemReport_PhieuKhauTru,
            this.itemNhomKhachHang,
            this.itemCaiDatDuyetHoaDon,
            this.itemQuanHe,
            this.barDanhMuc,
            this.itemYeuCau_CaiDat,
            this.itemNguonDen,
            this.itemLeTan_Add,
            this.itemLenTan_List,
            this.itemChoThue_LTT,
            this.barSubItem5,
            this.barSubItem7,
            this.itemDienDieuHoa,
            this.barSubItem8,
            this.barButtonItem28,
            this.itemDienDieuHoa_DinhMuc,
            this.itemReport_KeHoachThuTien,
            this.itemReport_ChiTietCongNo,
            this.itemGiuXe_CongNoTheXe,
            this.itemGAS_Report_BieuDo,
            this.itemDien_BieuDo,
            this.itemDien3Pha_BieuDo,
            this.itemDienDieuHoa_BieuDo,
            this.itemNuoc_BieuDo,
            this.itemNuocNong_BieuDo,
            this.itemNuocSinhHoat_BieuDo,
            this.barButtonItem32,
            this.itemPhanLoaiLich,
            this.itemThoiDiemLich,
            this.itemDanhSachLich,
            this.itemPhanLoai,
            this.itemTrangThai,
            this.itemMucDo,
            this.itemTienDo,
            this.itemThemMoi,
            this.itemDanhSach,
            this.itemTaiLieu,
            this.itemTaiLieu_Loai,
            this.itemReport_DaThuTheXe,
            this.itemPhanQuyenBaoCao,
            this.itemGanHetHan,
            this.itemDaHetHan,
            this.itemBaoCaoHDThueGianHangThueKHTHue,
            this.itemHoaDonDaXoa,
            this.itemPhieuThuDaXoa,
            this.itemTheXeDaXoa,
            this.itemBaoCaoCongNoTongHopTheoThang,
            this.itemQuocTich,
            this.itemLoaiYeuCau,
            this.itemMucDoLeTan,
            this.itemTrangThaiLeTan,
            this.itemTheThangMay,
            this.itemKhoThe,
            this.itemDSCapThe,
            this.itemNhatKyHeThong,
            this.itemLoaiKhachHang,
            this.itemConfigPhone,
            this.itemNhatKyCuocGoi,
            this.barSubItem9,
            this.bbiDanhSachYeuCau,
            this.bbiCongViecCuaToi,
            this.itemMauMail,
            this.itemDanhSachNhan,
            this.itemThuongHieu,
            this.itemDanhSachGui,
            this.itemCheckTaiKhoan,
            this.barButtonItem29,
            this.itemCapNhatBangGiaDichVuCoBan,
            this.barButtonItem31,
            this.itemHDCTNSapHetHan,
            this.itemHDCTN,
            this.barButtonItem33,
            this.barButtonItem34,
            this.itemCongNoDongTien,
            this.itemChayLaiSoQuy,
            this.itemDSChuyenTien,
            this.itemPhieuChiKyQuy,
            this.itemBieuDoMotToaNha,
            this.itemThongKeTheoNhomCongViec,
            this.itemBDTinhTrangXuLy,
            this.itemTheoDanhGiaCuaCuDan,
            this.itemTheoNguonPhanAnh,
            this.itemDoUuTien,
            this.itemPhanAnhTheoToaNha,
            this.itemTheoNhieuToaNha,
            this.itemNhomCongViecMuiltiTN,
            this.itemTinhTrangXuLyTheoNhieuToaNha,
            this.itemDanhGiaCuaCuDanTheoMuiltiToaNha,
            this.itemNguonTiepNhanTheoMuilti,
            this.itemViewBieuDoAll,
            this.barSubItem10,
            this.itemTTTaiSan,
            this.itemNhaCCTS,
            this.itemDMHeThong,
            this.itemDMLoaiTaiSan,
            this.itemDMTenTaiSan,
            this.ItemCaiDatHeThongChoToaNha,
            this.itemDMChiTietTaiSan,
            this.ItemDMVanHanh,
            this.ItemTanSuat,
            this.itemLoaiCaTruc,
            this.itemCongCuThietBi,
            this.ItemKeHoachVanHanh,
            this.itemPhieuVanHanh,
            this.itemProfile,
            this.itemGiaoNhanCa,
            this.itemDeXuatDoiCa,
            this.itemBangPhanCong,
            this.itemLichTruc,
            this.itemVHKeHoachBaoTri,
            this.itemVHPhieuBaoTri,
            this.itemGanProFileChoHeThong,
            this.itemDanhMucProfile,
            this.itemGanProfileChoToaNha,
            this.itemNhomProfile,
            this.itemCauHinhCapDuyet,
            this.barDanhMucVatTu,
            this.itemVTDonViTinh,
            this.itemVTDanhMucVatTu,
            this.itemVTDanhMucKhoHang,
            this.itemVTDanhMucLoaiNhapKho,
            this.itemVTDanhMucLoaiXuatKho,
            this.itemDeXuatMuaHang,
            this.itemDanhSachMuaHang,
            this.itemVTNhapKho,
            this.itemVTXuatKho,
            this.itemVTTonKho,
            this.itemCauHinhAPITheXe,
            this.barSubQuanLyHoSo,
            this.itemQuanLyHoSo,
            this.itemQLHS_KhoGiay,
            this.itemQLHS_LoaiVanBan,
            this.itemQLHS_MucDoBaoMat,
            this.itemQLHS_MucDoKhanCap,
            this.itemQLHS_DayKe,
            this.itemQLHS_HoSo,
            this.itemXuatKhoSuDung,
            this.itemDeXuatSuaChua,
            this.itemCauHinhNgayNghi,
            this.itemCauHinhNgayNghiTheoToaNha,
            this.itemThongKeThoiGian,
            this.itemNhomCongViec,
            this.itemCauHinhTinhTrangPhieu,
            this.itemThongKeSoLieuVH,
            this.itemTKCheckList,
            this.itemTKTinhHinhThucHien,
            this.itemTKTinhHinhKiemTraDinhKy,
            this.itemTKKiemTraDinhKy,
            this.itemViewPhieuBaoTri,
            this.itemSubTinTuc,
            this.itemSubApp,
            this.itemTinTuc_TyLeDangTin,
            this.itemTinTuc_ThongKeTheoTungToaNha,
            this.itemTinTuc_ThongKeTheoTongToaNha,
            this.itemTinTuc_ThongKeTongHop,
            this.itemApp_TyLeSuDungTheoTungToaNha,
            this.itemApp_TyLeSuDungTongToaNha,
            this.itemApp_ThongKeSuDungTungToaNha,
            this.itemApp_ThongKeSuDungCacToaNha,
            this.itemNhieuTN_SoLuongNhomCongViec,
            this.itemNhieuTN_PhanAnhTheoThang,
            this.itemNhieuTN_TongPhanAnh,
            this.itemNhieuTN_BaoCaoTongHop,
            this.itemViewKeHoachBaoTri,
            this.itemSMSSoDuTaiKhoan,
            this.itemSMSLichSu,
            this.itemSMS_Mau,
            this.BtnCauHinhColor,
            this.itemCaiDatBieuMau,
            this.itemScheduleComfirm,
            this.itemEmailSetup,
            this.itemBcThuChiTm,
            this.itemBcCongNoDichVu,
            this.barButtonGroup6,
            this.itemBaoCaoDaThu,
            this.barSubItem11,
            this.barButtonItem30,
            this.barButtonItem35,
            this.barSubItem12,
            this.itemBcChiTietThuPqlThang,
            this.itemGroupBcCongNoTongHop,
            this.itemHoaDonThongKe,
            this.itemReportPhiDaThu,
            this.itemBaoCaoTongHopCongNoDichVu,
            this.itemBcCongNoTongHopTheoThang,
            this.itemBaoCaoCacKhoanDaKhauTru,
            this.barSubItem13,
            this.itemReportBaoCaoTienDien,
            this.itemRreportDienDieuHoa,
            this.itemBieuDoTieuThuDien,
            this.itemBieuDoTieuThuDien3Pha,
            this.itemBieuDoTieuThuDienDieuHoa,
            this.barSubItem14,
            this.itemBaoCaoDichVuNuoc,
            this.itemBieuDoTieuThuNuoc,
            this.itemBieuDoTieuThuNuocNong,
            this.itemBieuDoTieuThuNuocSinhHoat,
            this.barSubItem15,
            this.itemBaoCaoDichVuGas,
            this.itemBieuDoTieuThuGas,
            this.barSubItem16,
            this.itemBaoCaoDichVuGuiXe,
            this.itemSoCongNoTheXe,
            this.itemBaoCaoDaThuTheXePhatSinh,
            this.itemBaoCaoChiTietPhiGiuXeThang,
            this.itemBaoCaoDoanhThuGiuXeOTo,
            this.itemBaoCaoDoanhThuGiuXeMay,
            this.itemBaoCaoDoanhThuGiuXeDap,
            this.itemCauHinhNhanVienQuanLyNhanMail,
            this.barSubItem18,
            this.itemScheduleStatus,
            this.itemScheduleComfirm1,
            this.ItemScheduleGroup,
            this.itemCarTyle,
            this.itemNewsTyle,
            this.itemSchedule,
            this.itemHandover,
            this.itemHandoverHistory,
            this.itemCarSetup,
            this.itemCarSchedule,
            this.itemNewsManager,
            this.barSubItem19,
            this.itemSendMailToManager,
            this.itemDeposit,
            this.itemDepositDelete,
            this.itemWithDraw,
            this.barSubItem20,
            this.itemDrTyle,
            this.itemBaoCaoCongNoDichVu,
            this.itemDepositManager,
            this.itemSoQuyDatCoc,
            this.itemHangMuc,
            this.itemChecklist,
            this.itemChecklistToaNha,
            this.itemHandoverLocal,
            this.itemUserHandover,
            this.itemPlanCustomer,
            this.itemScheduleCustomer,
            this.itemHandoverCustomer,
            this.itemDuty,
            this.itemStatus,
            this.itemHistoryCustomer,
            this.itemAssetCategory,
            this.itemAssetGroups,
            this.itemUnit,
            this.itemStatusAsset,
            this.itemGroupChecklist,
            this.itemBlockChecklist,
            this.itemDeXuatThayCa,
            this.itemNhomMB,
            this.itemDienTichLapDay,
            this.itemBieuMauHDT,
            this.itemTruongTronHDT,
            this.itemMauHDT,
            this.itemLapHoaDonHDT,
            this.itemHoaDonHDT,
            this.itemHoaDonDaXoaHDT,
            this.itemCongNoHDT,
            this.itemPhieuThuHDT,
            this.itemPhieuThuDaXoaHDT,
            this.itemPhieuDieuChuyenHDT,
            this.itemPhieuChiHDT,
            this.itemPhieuKhauTruHDT,
            this.itemMoneyPurpose,
            this.itemMoneyPurposeItems,
            this.itemHopDongDatCoc,
            this.itemKhachHangTiemNang,
            this.itemDanhSachCongViec,
            this.itemHopDongThueNgoai,
            this.itemDeXuatDoiLich,
            this.itemDanhSachThanhCong,
            this.itemDanhSachSuaChua,
            this.barButtonItem36,
            this.itemTrangThaiDuyetDeXuat,
            this.itemTieuDeThongBao,
            this.itemNoiDungThongBao,
            this.itemHdtnGanHetHan,
            this.itemHdtnHetHan,
            this.itemThanhLyHdtn,
            this.itemCongNoTienDatCoc,
            this.barSubItem21,
            this.itemNoiDungCongViec,
            this.itemNoiDungNhomCongViec,
            this.itemTruongTron,
            this.itemTruongTronHdtn,
            this.itemBieuMauHdtn,
            this.btnPhanQuyenBieuMauHdtn,
            this.itemCongNoDoiTac,
            this.itemBaoCaoThongKeKinhPhi,
            this.itemSoDuDauKy,
            this.itemCongNoTongHopHdtn,
            this.itemTienTrinhThucHien,
            this.itemLichThanhToan,
            this.itemDanhGiaHdtn,
            this.itemPhanQuyenBieuDoMain,
            this.itemCapNhatItemMain,
            this.itemPhanQuyenItem,
            this.itemCoPhanQuyen,
            this.itemTruongTronDatCocThiCong,
            this.itemBieuMauDatCocThiCong,
            this.itemPhanQuyenBieuMauDatCocThiCong,
            this.itemBaoCaoCongNoAll,
            this.itemPhiPhaiThuTrongThang,
            this.itemNoiBanHanh,
            this.itemPhanLoaiDiDen,
            this.itemVanBanDen,
            this.itemVanBanDi,
            this.barSubItem22,
            this.itemChucVu,
            this.barButtonItem37,
            this.barButtonItem38,
            this.barSubItem23,
            this.barButtonItem39,
            this.barButtonItem40,
            this.barButtonItem41,
            this.barButtonItem42,
            this.itemSoDoPhanLo,
            this.barButtonItem43,
            this.barSubItem24,
            this.barButtonItem44,
            this.barButtonItem45,
            this.barButtonItem47,
            this.barButtonItem48,
            this.barButtonItem49,
            this.itemCauHinhPage,
            this.itemDanhSachMau,
            this.itemLayDanhSachKhachHang,
            this.IiemDanhsachkhachhangquantam,
            this.istemLichSuGuiSms,
            this.barButtonItem50,
            this.itemDuTinh,
            this.barButtonItem51,
            this.barButtonItem52,
            this.itemDuTinhXe,
            this.itemDuTinhPQL,
            this.itemDuTinhHDT,
            this.itemDongHoDien,
            this.itemDongHoDienDieuHoa,
            this.itemNhanVienQuanTam,
            this.itemMauGuiNhanVien,
            this.itemLichSuGuiNhanVien,
            this.barButtonItem53,
            this.barButtonItem54,
            this.barButtonItem55,
            this.barButtonItem56,
            this.barButtonItem57,
            this.barButtonItem58,
            this.barButtonItem59,
            this.barButtonItem60,
            this.barButtonItem61,
            this.barSubItem25,
            this.itemCSKH,
            this.itemCSKHChinhThuc,
            this.itemTraCuuDoanhNghiep,
            this.barButtonItem65,
            this.barButtonItem66,
            this.itemBaoGia,
            this.itemCoHoi,
            this.itemNguonKH,
            this.itemQuyMo,
            this.itemLocation,
            this.itemTrangThaiCSKH,
            this.itemHTTX,
            this.itemNhuCauThue,
            this.itemCauHinhTiemNang,
            this.itemLoaiBaoGia,
            this.itemXa,
            this.itemHuyen,
            this.itemTinh,
            this.itemNgheNghiep,
            this.itemNguoiLienHe,
            this.barButtonItem62,
            this.barButtonItem63,
            this.barButtonItem64,
            this.barButtonItem67,
            this.itemKhaoSat,
            this.itemThongKeKhaoSat,
            this.barButtonItem68,
            this.barButtonItem69,
            this.barButtonItem70,
            this.barButtonItem71,
            this.barButtonItem72,
            this.itemVer,
            this.btnBCDienTichChoThue,
            this.btnBaoCaoDienNuoc,
            this.btnBCTongHopNuoc,
            this.btnLienHe,
            this.btnCauHinhVAT,
            this.btnBanner,
            this.itemDongHoDien3Pha,
            this.itemBoPhanLienHe,
            this.itemNhomLienHe,
            this.barButtonItem73,
            this.itemDienLanh,
            this.btnMenuDVMoi,
            this.btnchuyendo,
            this.btnDSDangKyNV,
            this.btnLamNgoaiGio,
            this.itemDongHoDienLanh,
            this.itemKeHoachXitConTrung,
            this.itemLichBaoTri_Lich,
            this.itemLichBaoTri_KhachHangXacNhan});
            this.ribbon.LargeImages = this.imageCollection1;
            this.ribbon.Location = new System.Drawing.Point(0, 0);
            this.ribbon.MaxItemId = 1049;
            this.ribbon.MdiMergeStyle = DevExpress.XtraBars.Ribbon.RibbonMdiMergeStyle.Never;
            this.ribbon.Name = "ribbon";
            this.ribbon.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage4,
            this.ribbonPageToaNha,
            this.ribbonPage3,
            this.ribbonPageKhachHang,
            this.ribbonPage7,
            this.ribbonPage6,
            this.ribbonPage9,
            this.pageHopDongThueNgoai,
            this.ribbonPageDichVu,
            this.pageSoQuy,
            this.ribbonPage5,
            this.ribbonPageTaiSan,
            this.ribbonPageVanHanh,
            this.ribbonPage2,
            this.ribbonPage1,
            this.pageAbout});
            this.ribbon.SetPopupContextMenu(this.ribbon, this.applicationMenu1);
            this.ribbon.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemPictureEdit3});
            this.ribbon.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.Office2019;
            this.ribbon.ShowDisplayOptionsMenuButton = DevExpress.Utils.DefaultBoolean.True;
            this.ribbon.Size = new System.Drawing.Size(1376, 146);
            this.ribbon.StatusBar = this.ribbonStatusBar;
            // 
            // applicationMenu1
            // 
            this.applicationMenu1.ItemLinks.Add(this.btnchangepass);
            this.applicationMenu1.ItemLinks.Add(this.itemNhatKyHeThong);
            this.applicationMenu1.ItemLinks.Add(this.btnlogout);
            this.applicationMenu1.ItemLinks.Add(this.btnexit);
            this.applicationMenu1.ItemLinks.Add(this.itemChayLaiSoQuy);
            this.applicationMenu1.Name = "applicationMenu1";
            this.applicationMenu1.Ribbon = this.ribbon;
            // 
            // btnchangepass
            // 
            this.btnchangepass.Caption = "Đổi mật khẩu";
            this.btnchangepass.Id = 103;
            this.btnchangepass.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_key_2_filled_50px;
            this.btnchangepass.Name = "btnchangepass";
            toolTipTitleItem1.Text = "Đổi mật khẩu đăng nhập\r\n";
            superToolTip1.Items.Add(toolTipTitleItem1);
            this.btnchangepass.SuperTip = superToolTip1;
            this.btnchangepass.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnchangepass_ItemClick);
            // 
            // itemNhatKyHeThong
            // 
            this.itemNhatKyHeThong.Caption = "Nhật ký hệ thống";
            this.itemNhatKyHeThong.Id = 609;
            this.itemNhatKyHeThong.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_Agreement_Delete_50px;
            this.itemNhatKyHeThong.Name = "itemNhatKyHeThong";
            this.itemNhatKyHeThong.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemNhatKyHeThong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhatKyHeThong_ItemClick);
            // 
            // btnlogout
            // 
            this.btnlogout.Caption = "Đăng xuất";
            this.btnlogout.Id = 102;
            this.btnlogout.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_lock_filled_50px;
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph;
            toolTipTitleItem2.Text = "Thoát phiên làm việc hiện tại";
            superToolTip2.Items.Add(toolTipTitleItem2);
            this.btnlogout.SuperTip = superToolTip2;
            this.btnlogout.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnlogout_ItemClick);
            // 
            // btnexit
            // 
            this.btnexit.Caption = "Thoát chương trình";
            this.btnexit.Id = 104;
            this.btnexit.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_shutdown_filled_50px;
            this.btnexit.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4));
            this.btnexit.Name = "btnexit";
            toolTipTitleItem3.Text = "Thoát khỏi chương trình";
            superToolTip3.Items.Add(toolTipTitleItem3);
            this.btnexit.SuperTip = superToolTip3;
            this.btnexit.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnexit_ItemClick);
            // 
            // itemChayLaiSoQuy
            // 
            this.itemChayLaiSoQuy.Caption = "Chạy lại sổ quỹ";
            this.itemChayLaiSoQuy.Id = 645;
            this.itemChayLaiSoQuy.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_last_24_hours_filled_50px;
            this.itemChayLaiSoQuy.Name = "itemChayLaiSoQuy";
            this.itemChayLaiSoQuy.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemChayLaiSoQuy.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemChayLaiSoQuy_ItemClick);
            // 
            // imageCollection1
            // 
            this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection1.ImageStream")));
            this.imageCollection1.Images.SetKeyName(0, "add_outline.png");
            this.imageCollection1.Images.SetKeyName(1, "gear.png");
            this.imageCollection1.Images.SetKeyName(2, "lock.png");
            this.imageCollection1.Images.SetKeyName(3, "exit.png");
            this.imageCollection1.Images.SetKeyName(4, "Add Green64.png");
            this.imageCollection1.Images.SetKeyName(5, "1338255359_companies.png");
            this.imageCollection1.Images.SetKeyName(6, "group.png");
            this.imageCollection1.Images.SetKeyName(7, "1338256996_group.png");
            this.imageCollection1.Images.SetKeyName(8, "add_32.png");
            this.imageCollection1.Images.SetKeyName(9, "1337494333_document.png");
            this.imageCollection1.Images.SetKeyName(10, "email.png");
            this.imageCollection1.Images.SetKeyName(11, "e_mail64.png");
            this.imageCollection1.Images.SetKeyName(12, "1336097347_agt_print [].png");
            this.imageCollection1.Images.SetKeyName(13, "1337746971_blockdevice [].png");
            this.imageCollection1.Images.SetKeyName(14, "1338255002_Company32 [].png");
            this.imageCollection1.Images.SetKeyName(15, "1338257801_inventory_categories [].png");
            this.imageCollection1.Images.SetKeyName(16, "1338260699_preferences-contact-list [].png");
            this.imageCollection1.Images.SetKeyName(17, "bitwash [].png");
            this.imageCollection1.Images.SetKeyName(18, "report.png");
            this.imageCollection1.Images.SetKeyName(19, "dip.png");
            this.imageCollection1.Images.SetKeyName(20, "1338256418_customer_service.png");
            this.imageCollection1.Images.SetKeyName(21, "1338256038_emblem-work.png");
            this.imageCollection1.Images.SetKeyName(22, "1338864049_system-software-update.png");
            this.imageCollection1.Images.SetKeyName(23, "1337747012_Generate-tables [].png");
            this.imageCollection1.Images.SetKeyName(24, "companies.png");
            this.imageCollection1.Images.SetKeyName(25, "companies.png");
            this.imageCollection1.Images.SetKeyName(26, "surveys.png");
            this.imageCollection1.Images.SetKeyName(27, "table_money.png");
            this.imageCollection1.Images.SetKeyName(28, "customers.png");
            this.imageCollection1.Images.SetKeyName(29, "tools-16.png");
            this.imageCollection1.Images.SetKeyName(30, "select16.png");
            this.imageCollection1.Images.SetKeyName(31, "add-notes.png");
            this.imageCollection1.Images.SetKeyName(32, "gas.png");
            this.imageCollection1.Images.SetKeyName(33, "invoice.png");
            this.imageCollection1.Images.SetKeyName(34, "peoples.png");
            this.imageCollection1.Images.SetKeyName(35, "task.png");
            this.imageCollection1.Images.SetKeyName(36, "task3.png");
            this.imageCollection1.Images.SetKeyName(37, "appointment2.png");
            this.imageCollection1.Images.SetKeyName(38, "contact.png");
            this.imageCollection1.Images.SetKeyName(39, "peoples48.png");
            this.imageCollection1.Images.SetKeyName(40, "copy_16x16.gif");
            this.imageCollection1.Images.SetKeyName(41, "help.png");
            this.imageCollection1.Images.SetKeyName(42, "users_group.png");
            this.imageCollection1.Images.SetKeyName(43, "edit_16x16.gif");
            this.imageCollection1.Images.SetKeyName(44, "list_bullets.png");
            this.imageCollection1.Images.SetKeyName(45, "view_list16.png");
            this.imageCollection1.Images.SetKeyName(46, "service.png");
            this.imageCollection1.Images.SetKeyName(47, "service.png");
            this.imageCollection1.Images.SetKeyName(48, "Company32.png");
            this.imageCollection1.Images.SetKeyName(49, "support.png");
            this.imageCollection1.Images.SetKeyName(50, "tool.png");
            this.imageCollection1.Images.SetKeyName(51, "mute.png");
            this.imageCollection1.Images.SetKeyName(52, "play.png");
            this.imageCollection1.Images.SetKeyName(53, "stop.png");
            this.imageCollection1.Images.SetKeyName(54, "cross.png");
            this.imageCollection1.Images.SetKeyName(55, "Card in Use_100.png");
            this.imageCollection1.Images.SetKeyName(56, "phone-icon.png");
            this.imageCollection1.Images.SetKeyName(58, "1496183860_mail.png");
            this.imageCollection1.Images.SetKeyName(59, "1496184088_system-search.png");
            this.imageCollection1.Images.SetKeyName(60, "utilities.png");
            this.imageCollection1.Images.SetKeyName(61, "utilities (1).png");
            this.imageCollection1.Images.SetKeyName(62, "icons8_user_shield_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(63, "icons8_skyscrapers_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(64, "icons8_group_background_selected_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(65, "icons8_service_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(66, "icons8_general_ledger_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(67, "icons8_money_bag_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(68, "icons8_services_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(69, "icons8_overtime_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(70, "icons8_groups_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(71, "icons8_viber_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(72, "icons8_list_50px.png");
            this.imageCollection1.Images.SetKeyName(73, "icons8_pie_chart_report_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(74, "icons8_stack_of_photos_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(75, "icons8_form_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(76, "icons8_summary_list_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(77, "icons8_past_filled_50px_1.png");
            this.imageCollection1.Images.SetKeyName(78, "icons8_refund_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(79, "icons8_sms_token_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(80, "icons8_coins_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(81, "icons8_key_2_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(82, "icons8_client_company_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(83, "Tien3.png");
            this.imageCollection1.Images.SetKeyName(84, "HopDong1.png");
            this.imageCollection1.Images.SetKeyName(85, "icons8_diploma_1_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(86, "icons8_phonelink_setup_filled_50px.png");
            this.imageCollection1.Images.SetKeyName(87, "icons8-account-100.png");
            this.imageCollection1.Images.SetKeyName(88, "icons8-survey-100.png");
            // 
            // itemThamQuan_Them
            // 
            this.itemThamQuan_Them.Caption = "Thêm mới";
            this.itemThamQuan_Them.Id = 1;
            this.itemThamQuan_Them.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.add_tag48;
            this.itemThamQuan_Them.ImageOptions.LargeImageIndex = 0;
            this.itemThamQuan_Them.Name = "itemThamQuan_Them";
            this.itemThamQuan_Them.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThamQuan_Them_ItemClick);
            // 
            // itemToaNha
            // 
            this.itemToaNha.Caption = "Dự án";
            this.itemToaNha.Id = 4;
            this.itemToaNha.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_city_filled_50px;
            this.itemToaNha.Name = "itemToaNha";
            this.itemToaNha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemToaNha_ItemClick);
            // 
            // itemMatBang
            // 
            this.itemMatBang.Caption = "Danh sách";
            this.itemMatBang.Id = 6;
            this.itemMatBang.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_company_filled_50px;
            this.itemMatBang.ImageOptions.LargeImageIndex = 1;
            this.itemMatBang.Name = "itemMatBang";
            this.itemMatBang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemMatBang_ItemClick);
            // 
            // itemLoaiTaiSan
            // 
            this.itemLoaiTaiSan.Id = 747;
            this.itemLoaiTaiSan.Name = "itemLoaiTaiSan";
            // 
            // itemHangSanXuat
            // 
            this.itemHangSanXuat.Id = 748;
            this.itemHangSanXuat.Name = "itemHangSanXuat";
            // 
            // itemXuatXu
            // 
            this.itemXuatXu.Id = 749;
            this.itemXuatXu.Name = "itemXuatXu";
            // 
            // itemTrangThaiTaiSan
            // 
            this.itemTrangThaiTaiSan.Id = 750;
            this.itemTrangThaiTaiSan.Name = "itemTrangThaiTaiSan";
            // 
            // itemNhaCungCap
            // 
            this.itemNhaCungCap.Caption = "Nhà cung cấp";
            this.itemNhaCungCap.Id = 11;
            this.itemNhaCungCap.ImageOptions.ImageIndex = 72;
            this.itemNhaCungCap.Name = "itemNhaCungCap";
            this.itemNhaCungCap.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhaCungCap_ItemClick);
            // 
            // itemTaiSanDangSuDung
            // 
            this.itemTaiSanDangSuDung.Id = 751;
            this.itemTaiSanDangSuDung.Name = "itemTaiSanDangSuDung";
            // 
            // itemKeHoachBaoTri_Them
            // 
            this.itemKeHoachBaoTri_Them.Caption = "Thêm mới";
            this.itemKeHoachBaoTri_Them.Id = 13;
            this.itemKeHoachBaoTri_Them.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.add_tag48;
            this.itemKeHoachBaoTri_Them.ImageOptions.LargeImageIndex = 0;
            this.itemKeHoachBaoTri_Them.Name = "itemKeHoachBaoTri_Them";
            this.itemKeHoachBaoTri_Them.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKeHoachBaoTri_Them_ItemClick);
            // 
            // itemKeHoachBaoTri
            // 
            this.itemKeHoachBaoTri.Caption = "Danh sách";
            this.itemKeHoachBaoTri.Id = 14;
            this.itemKeHoachBaoTri.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.view_list32;
            this.itemKeHoachBaoTri.ImageOptions.LargeImageIndex = 1;
            this.itemKeHoachBaoTri.Name = "itemKeHoachBaoTri";
            this.itemKeHoachBaoTri.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKeHoachBaoTri_ItemClick);
            // 
            // itemBaoTri_Them
            // 
            this.itemBaoTri_Them.Caption = "Thêm mới";
            this.itemBaoTri_Them.Id = 15;
            this.itemBaoTri_Them.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.add_tag48;
            this.itemBaoTri_Them.ImageOptions.LargeImageIndex = 0;
            this.itemBaoTri_Them.Name = "itemBaoTri_Them";
            this.itemBaoTri_Them.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoTri_Them_ItemClick);
            // 
            // itemBaoTri
            // 
            this.itemBaoTri.Caption = "Danh sách";
            this.itemBaoTri.Id = 16;
            this.itemBaoTri.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.view_list32;
            this.itemBaoTri.ImageOptions.LargeImageIndex = 1;
            this.itemBaoTri.Name = "itemBaoTri";
            this.itemBaoTri.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoTri_ItemClick);
            // 
            // itemDXMS_Them
            // 
            this.itemDXMS_Them.Id = 752;
            this.itemDXMS_Them.Name = "itemDXMS_Them";
            // 
            // itemDXMS
            // 
            this.itemDXMS.Id = 753;
            this.itemDXMS.Name = "itemDXMS";
            // 
            // itemDatHang_Them
            // 
            this.itemDatHang_Them.Id = 754;
            this.itemDatHang_Them.Name = "itemDatHang_Them";
            // 
            // itemDatHang
            // 
            this.itemDatHang.Id = 755;
            this.itemDatHang.Name = "itemDatHang";
            // 
            // itemMuaHang_Them
            // 
            this.itemMuaHang_Them.Id = 756;
            this.itemMuaHang_Them.Name = "itemMuaHang_Them";
            // 
            // itemMuaHang
            // 
            this.itemMuaHang.Id = 757;
            this.itemMuaHang.Name = "itemMuaHang";
            // 
            // itemNhapKho_Them
            // 
            this.itemNhapKho_Them.Id = 758;
            this.itemNhapKho_Them.Name = "itemNhapKho_Them";
            // 
            // itemNhapKho
            // 
            this.itemNhapKho.Id = 759;
            this.itemNhapKho.Name = "itemNhapKho";
            // 
            // itemXuatKho
            // 
            this.itemXuatKho.Id = 760;
            this.itemXuatKho.Name = "itemXuatKho";
            // 
            // itemXuatKho_Them
            // 
            this.itemXuatKho_Them.Id = 761;
            this.itemXuatKho_Them.Name = "itemXuatKho_Them";
            // 
            // itemMatBang_TrangThai
            // 
            this.itemMatBang_TrangThai.Caption = "Trạng thái mặt bằng";
            this.itemMatBang_TrangThai.Id = 27;
            this.itemMatBang_TrangThai.ImageOptions.ImageIndex = 72;
            this.itemMatBang_TrangThai.Name = "itemMatBang_TrangThai";
            this.itemMatBang_TrangThai.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemMatBang_TrangThai_ItemClick);
            // 
            // itemChoThue_Them
            // 
            this.itemChoThue_Them.Caption = "Lập hợp đồng";
            this.itemChoThue_Them.Id = 28;
            this.itemChoThue_Them.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_them;
            this.itemChoThue_Them.ImageOptions.LargeImageIndex = 0;
            this.itemChoThue_Them.Name = "itemChoThue_Them";
            this.itemChoThue_Them.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemChoThue_Them.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemChoThue_Them_ItemClick);
            // 
            // itemChoThue
            // 
            this.itemChoThue.Caption = "Hợp đồng cho thuê";
            this.itemChoThue.Id = 29;
            this.itemChoThue.ImageOptions.ImageIndex = 72;
            this.itemChoThue.Name = "itemChoThue";
            this.itemChoThue.Tag = "Dịch vụ - Cho thuê - Quản lý";
            this.itemChoThue.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemChoThue_ItemClick);
            // 
            // itemTheXe_Them
            // 
            this.itemTheXe_Them.Caption = "Đăng ký";
            this.itemTheXe_Them.Id = 30;
            this.itemTheXe_Them.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_them;
            this.itemTheXe_Them.ImageOptions.LargeImageIndex = 45;
            this.itemTheXe_Them.Name = "itemTheXe_Them";
            this.itemTheXe_Them.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemTheXe_Them.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTheXe_Them_ItemClick);
            // 
            // itemLoaiXe
            // 
            this.itemLoaiXe.Caption = "Loại xe";
            this.itemLoaiXe.Id = 31;
            this.itemLoaiXe.ImageOptions.ImageIndex = 72;
            this.itemLoaiXe.Name = "itemLoaiXe";
            this.itemLoaiXe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLoaiXe_ItemClick);
            // 
            // itemThangMay_Them
            // 
            this.itemThangMay_Them.Caption = "Đăng ký";
            this.itemThangMay_Them.Id = 33;
            this.itemThangMay_Them.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemThangMay_Them.ImageOptions.LargeImage")));
            this.itemThangMay_Them.ImageOptions.LargeImageIndex = 4;
            this.itemThangMay_Them.Name = "itemThangMay_Them";
            this.itemThangMay_Them.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThangMay_Them_ItemClick);
            // 
            // itemThangMay
            // 
            this.itemThangMay.Caption = "Danh sách";
            this.itemThangMay.Id = 34;
            this.itemThangMay.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemThangMay.ImageOptions.LargeImage")));
            this.itemThangMay.ImageOptions.LargeImageIndex = 1;
            this.itemThangMay.Name = "itemThangMay";
            this.itemThangMay.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.itemThangMay.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThangMay_ItemClick);
            // 
            // itemNhanKhau_Them
            // 
            this.itemNhanKhau_Them.Caption = "Đăng ký";
            this.itemNhanKhau_Them.Id = 35;
            this.itemNhanKhau_Them.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_plus_filled_50px;
            this.itemNhanKhau_Them.ImageOptions.LargeImageIndex = 4;
            this.itemNhanKhau_Them.Name = "itemNhanKhau_Them";
            this.itemNhanKhau_Them.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemNhanKhau_Them.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhanKhau_Them_ItemClick);
            // 
            // itemNhanKhau
            // 
            this.itemNhanKhau.Caption = "Danh sách";
            this.itemNhanKhau.Id = 36;
            this.itemNhanKhau.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_client_company_filled_50px;
            this.itemNhanKhau.Name = "itemNhanKhau";
            this.itemNhanKhau.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhanKhau_ItemClick);
            // 
            // itemDien
            // 
            this.itemDien.Caption = "Điện chiếu sáng";
            this.itemDien.Id = 37;
            this.itemDien.ImageOptions.ImageIndex = 72;
            this.itemDien.ImageOptions.LargeImageIndex = 1;
            this.itemDien.Name = "itemDien";
            this.itemDien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDien_ItemClick);
            // 
            // itemNuoc
            // 
            this.itemNuoc.Caption = "Nước";
            this.itemNuoc.Id = 38;
            this.itemNuoc.ImageOptions.ImageIndex = 72;
            this.itemNuoc.ImageOptions.LargeImageIndex = 1;
            this.itemNuoc.Name = "itemNuoc";
            this.itemNuoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNuoc_ItemClick);
            // 
            // itemDien_DinhMuc
            // 
            this.itemDien_DinhMuc.Caption = "Định mức điện";
            this.itemDien_DinhMuc.Id = 39;
            this.itemDien_DinhMuc.ImageOptions.ImageIndex = 72;
            this.itemDien_DinhMuc.Name = "itemDien_DinhMuc";
            this.itemDien_DinhMuc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDien_DinhMuc_ItemClick);
            // 
            // itemNuoc_DinhMuc
            // 
            this.itemNuoc_DinhMuc.Caption = "Định mức nước";
            this.itemNuoc_DinhMuc.Id = 40;
            this.itemNuoc_DinhMuc.ImageOptions.ImageIndex = 45;
            this.itemNuoc_DinhMuc.Name = "itemNuoc_DinhMuc";
            this.itemNuoc_DinhMuc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNuoc_DinhMuc_ItemClick);
            // 
            // itemThueNgoai_Them
            // 
            this.itemThueNgoai_Them.Caption = "Thêm mới";
            this.itemThueNgoai_Them.Id = 41;
            this.itemThueNgoai_Them.ImageOptions.ImageIndex = 0;
            this.itemThueNgoai_Them.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemThueNgoai_Them.ImageOptions.LargeImage")));
            this.itemThueNgoai_Them.ImageOptions.LargeImageIndex = 0;
            this.itemThueNgoai_Them.Name = "itemThueNgoai_Them";
            this.itemThueNgoai_Them.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThueNgoai_Them_ItemClick);
            // 
            // itemThueNgoai
            // 
            this.itemThueNgoai.Caption = "Danh sách";
            this.itemThueNgoai.Id = 42;
            this.itemThueNgoai.ImageOptions.LargeImageIndex = 45;
            this.itemThueNgoai.Name = "itemThueNgoai";
            this.itemThueNgoai.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThueNgoai_ItemClick);
            // 
            // itemHopTac_Them
            // 
            this.itemHopTac_Them.Caption = "Thêm mới";
            this.itemHopTac_Them.Id = 43;
            this.itemHopTac_Them.ImageOptions.ImageIndex = 0;
            this.itemHopTac_Them.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemHopTac_Them.ImageOptions.LargeImage")));
            this.itemHopTac_Them.ImageOptions.LargeImageIndex = 0;
            this.itemHopTac_Them.Name = "itemHopTac_Them";
            this.itemHopTac_Them.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHopTac_Them_ItemClick);
            // 
            // itemHopTac
            // 
            this.itemHopTac.Caption = "Danh sách";
            this.itemHopTac.Id = 44;
            this.itemHopTac.ImageOptions.ImageIndex = 45;
            this.itemHopTac.Name = "itemHopTac";
            this.itemHopTac.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHopTac_ItemClick);
            // 
            // itemDichVuKhac_Loai
            // 
            this.itemDichVuKhac_Loai.Caption = "Loại dịch vụ khác";
            this.itemDichVuKhac_Loai.Id = 45;
            this.itemDichVuKhac_Loai.ImageOptions.ImageIndex = 45;
            this.itemDichVuKhac_Loai.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemDichVuKhac_Loai.ImageOptions.LargeImage")));
            this.itemDichVuKhac_Loai.ImageOptions.LargeImageIndex = 1;
            this.itemDichVuKhac_Loai.Name = "itemDichVuKhac_Loai";
            // 
            // itemDichVuKhac
            // 
            this.itemDichVuKhac.Caption = "Danh sách";
            this.itemDichVuKhac.Id = 46;
            this.itemDichVuKhac.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_dich_vu;
            this.itemDichVuKhac.ImageOptions.LargeImageIndex = 46;
            this.itemDichVuKhac.Name = "itemDichVuKhac";
            this.itemDichVuKhac.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDichVuKhac_ItemClick);
            // 
            // itemSuaChua_Them
            // 
            this.itemSuaChua_Them.Caption = "Thêm mới";
            this.itemSuaChua_Them.Id = 47;
            this.itemSuaChua_Them.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.add_tag48;
            this.itemSuaChua_Them.ImageOptions.LargeImageIndex = 0;
            this.itemSuaChua_Them.Name = "itemSuaChua_Them";
            this.itemSuaChua_Them.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemSuaChua_Them_ItemClick);
            // 
            // itemSuaChua
            // 
            this.itemSuaChua.Caption = "Danh sách";
            this.itemSuaChua.Id = 48;
            this.itemSuaChua.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.view_list32;
            this.itemSuaChua.ImageOptions.LargeImageIndex = 1;
            this.itemSuaChua.Name = "itemSuaChua";
            this.itemSuaChua.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemSuaChua_ItemClick);
            // 
            // itemYeuCau
            // 
            this.itemYeuCau.Caption = "Danh sách yêu cầu";
            this.itemYeuCau.Id = 49;
            this.itemYeuCau.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.yeu_cau;
            this.itemYeuCau.ImageOptions.LargeImageIndex = 1;
            this.itemYeuCau.Name = "itemYeuCau";
            this.itemYeuCau.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemYeuCau.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemYeuCau_ItemClick);
            // 
            // itemYeuCau_Them
            // 
            this.itemYeuCau_Them.Caption = "Thêm yêu cầu mới";
            this.itemYeuCau_Them.Id = 50;
            this.itemYeuCau_Them.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_plus_filled_50px;
            this.itemYeuCau_Them.ImageOptions.LargeImageIndex = 0;
            this.itemYeuCau_Them.Name = "itemYeuCau_Them";
            this.itemYeuCau_Them.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemYeuCau_Them.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemYeuCau_Them_ItemClick);
            // 
            // itemKhachHang_Them
            // 
            this.itemKhachHang_Them.Caption = "Thêm mới";
            this.itemKhachHang_Them.Id = 51;
            this.itemKhachHang_Them.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_plus_filled_50px;
            this.itemKhachHang_Them.ImageOptions.LargeImageIndex = 0;
            this.itemKhachHang_Them.Name = "itemKhachHang_Them";
            this.itemKhachHang_Them.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemKhachHang_Them.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKhachHang_Them_ItemClick);
            // 
            // itemKhachHang
            // 
            this.itemKhachHang.Caption = "Danh sách";
            this.itemKhachHang.Id = 52;
            this.itemKhachHang.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_contract_job_filled_50px;
            this.itemKhachHang.ImageOptions.LargeImageIndex = 1;
            this.itemKhachHang.Name = "itemKhachHang";
            this.itemKhachHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKhachHang_ItemClick);
            // 
            // itemSkins
            // 
            this.itemSkins.Caption = "ribbonGalleryBarItem1";
            this.itemSkins.Id = 53;
            this.itemSkins.Name = "itemSkins";
            this.itemSkins.GalleryItemClick += new DevExpress.XtraBars.Ribbon.GalleryItemClickEventHandler(this.itemSkins_GalleryItemClick);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "Khóa";
            this.barButtonItem1.Id = 54;
            this.barButtonItem1.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_lock_filled_50px;
            this.barButtonItem1.Name = "barButtonItem1";
            this.barButtonItem1.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem1_ItemClick);
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "Thoát";
            this.barButtonItem2.Id = 55;
            this.barButtonItem2.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_shutdown_filled_50px;
            this.barButtonItem2.Name = "barButtonItem2";
            this.barButtonItem2.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem2_ItemClick);
            // 
            // btnThemNhanVien
            // 
            this.btnThemNhanVien.Caption = "Thêm mới";
            this.btnThemNhanVien.Id = 56;
            this.btnThemNhanVien.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_plus_filled_50px;
            this.btnThemNhanVien.Name = "btnThemNhanVien";
            this.btnThemNhanVien.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.btnThemNhanVien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnThemNhanVien_ItemClick);
            // 
            // btnNhanVienManager
            // 
            this.btnNhanVienManager.Caption = "Danh sách";
            this.btnNhanVienManager.Id = 57;
            this.btnNhanVienManager.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_classroom_filled_50px;
            this.btnNhanVienManager.Name = "btnNhanVienManager";
            this.btnNhanVienManager.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnNhanVienManager_ItemClick);
            // 
            // btnPhanQuyenNV
            // 
            this.btnPhanQuyenNV.Caption = "Phân quyền";
            this.btnPhanQuyenNV.Id = 58;
            this.btnPhanQuyenNV.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_move_node_down_filled_50px;
            this.btnPhanQuyenNV.Name = "btnPhanQuyenNV";
            this.btnPhanQuyenNV.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnPhanQuyenNV_ItemClick);
            // 
            // itemMatBang_Them
            // 
            this.itemMatBang_Them.Caption = "Thêm mới";
            this.itemMatBang_Them.Id = 59;
            this.itemMatBang_Them.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_plus_filled_50px;
            this.itemMatBang_Them.Name = "itemMatBang_Them";
            this.itemMatBang_Them.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemMatBang_Them.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemMatBang_Them_ItemClick);
            // 
            // itemKhoiNha
            // 
            this.itemKhoiNha.Caption = "Khối nhà";
            this.itemKhoiNha.Id = 61;
            this.itemKhoiNha.ImageOptions.ImageIndex = 72;
            this.itemKhoiNha.Name = "itemKhoiNha";
            this.itemKhoiNha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKhoiNha_ItemClick);
            // 
            // itemMatBang_View
            // 
            this.itemMatBang_View.Caption = "Xem tổng thể";
            this.itemMatBang_View.Id = 64;
            this.itemMatBang_View.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_tong_the;
            this.itemMatBang_View.Name = "itemMatBang_View";
            this.itemMatBang_View.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemMatBang_View_ItemClick);
            // 
            // itemTangLau
            // 
            this.itemTangLau.Caption = "Tầng (lầu)";
            this.itemTangLau.Id = 65;
            this.itemTangLau.ImageOptions.ImageIndex = 72;
            this.itemTangLau.Name = "itemTangLau";
            this.itemTangLau.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTangLau_ItemClick);
            // 
            // itemTrangThaiKHBT
            // 
            this.itemTrangThaiKHBT.Caption = "Trạng thái";
            this.itemTrangThaiKHBT.Id = 68;
            this.itemTrangThaiKHBT.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemTrangThaiKHBT.ImageOptions.LargeImage")));
            this.itemTrangThaiKHBT.ImageOptions.LargeImageIndex = 1;
            this.itemTrangThaiKHBT.Name = "itemTrangThaiKHBT";
            this.itemTrangThaiKHBT.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemTrangThaiKHBT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTrangThaiKHBT_ItemClick);
            // 
            // itemTrangThaiChoThue
            // 
            this.itemTrangThaiChoThue.Caption = "Trạng thái cho thuê";
            this.itemTrangThaiChoThue.Id = 69;
            this.itemTrangThaiChoThue.ImageOptions.ImageIndex = 45;
            this.itemTrangThaiChoThue.Name = "itemTrangThaiChoThue";
            this.itemTrangThaiChoThue.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTrangThaiChoThue_ItemClick);
            // 
            // itemTrangThaiThueNgoai
            // 
            this.itemTrangThaiThueNgoai.Caption = "Trạng thái thuê ngoài";
            this.itemTrangThaiThueNgoai.Id = 70;
            this.itemTrangThaiThueNgoai.ImageOptions.ImageIndex = 45;
            this.itemTrangThaiThueNgoai.Name = "itemTrangThaiThueNgoai";
            this.itemTrangThaiThueNgoai.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTrangThaiThueNgoai_ItemClick);
            // 
            // itemTrangThaiHopTac
            // 
            this.itemTrangThaiHopTac.Caption = "Trạng thái hợp tác";
            this.itemTrangThaiHopTac.Id = 71;
            this.itemTrangThaiHopTac.ImageOptions.ImageIndex = 45;
            this.itemTrangThaiHopTac.Name = "itemTrangThaiHopTac";
            this.itemTrangThaiHopTac.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTrangThaiHopTac_ItemClick);
            // 
            // xtrbtnDangKyKhachHang
            // 
            this.xtrbtnDangKyKhachHang.Caption = "Đăng ký khách hàng";
            this.xtrbtnDangKyKhachHang.Id = 76;
            this.xtrbtnDangKyKhachHang.Name = "xtrbtnDangKyKhachHang";
            // 
            // barButtonItem9
            // 
            this.barButtonItem9.Caption = "Yêu cầu Khóa/Mở Khóa văn phòng";
            this.barButtonItem9.Id = 78;
            this.barButtonItem9.Name = "barButtonItem9";
            // 
            // barButtonItem10
            // 
            this.barButtonItem10.Caption = "Đăng ký công nhân";
            this.barButtonItem10.Id = 79;
            this.barButtonItem10.Name = "barButtonItem10";
            // 
            // barButtonItem11
            // 
            this.barButtonItem11.Caption = "Đăng ký xe / đỗ xe / đổi xe";
            this.barButtonItem11.Id = 80;
            this.barButtonItem11.Name = "barButtonItem11";
            // 
            // barButtonItem12
            // 
            this.barButtonItem12.Caption = "Đề nghị / Phê bình / Phàn nàn";
            this.barButtonItem12.Id = 81;
            this.barButtonItem12.Name = "barButtonItem12";
            // 
            // barButtonItem13
            // 
            this.barButtonItem13.Caption = "Kê khai tài sản / tìm thấy";
            this.barButtonItem13.Id = 82;
            this.barButtonItem13.Name = "barButtonItem13";
            // 
            // barButtonItem14
            // 
            this.barButtonItem14.Caption = "Đăng ký thiết bị / dụng cụ nhà thầu";
            this.barButtonItem14.Id = 83;
            this.barButtonItem14.Name = "barButtonItem14";
            // 
            // barButtonItem15
            // 
            this.barButtonItem15.Caption = "Di chuyển tài sản";
            this.barButtonItem15.Id = 84;
            this.barButtonItem15.Name = "barButtonItem15";
            // 
            // barButtonItem16
            // 
            this.barButtonItem16.Caption = "Đăng ký bảng hiệu";
            this.barButtonItem16.Id = 85;
            this.barButtonItem16.Name = "barButtonItem16";
            // 
            // barButtonItem17
            // 
            this.barButtonItem17.Caption = "Đăng ký máy lạnh ngoài giờ";
            this.barButtonItem17.Id = 86;
            this.barButtonItem17.Name = "barButtonItem17";
            // 
            // barSubItem1
            // 
            this.barSubItem1.Caption = "Danh sách khách hàng";
            this.barSubItem1.Id = 89;
            this.barSubItem1.ImageOptions.LargeImageIndex = 1;
            this.barSubItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem18)});
            this.barSubItem1.Name = "barSubItem1";
            // 
            // barButtonItem18
            // 
            this.barButtonItem18.Caption = "Khách hàng";
            this.barButtonItem18.Id = 90;
            this.barButtonItem18.Name = "barButtonItem18";
            this.barButtonItem18.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem18_ItemClick_1);
            // 
            // btnbieumau
            // 
            this.btnbieumau.Caption = "Quản lý biểu mẫu";
            this.btnbieumau.Id = 92;
            this.btnbieumau.ImageOptions.DisabledImageIndex = 0;
            this.btnbieumau.ImageOptions.ImageIndex = 0;
            this.btnbieumau.ImageOptions.LargeImageIndex = 1;
            this.btnbieumau.Name = "btnbieumau";
            // 
            // barButtonItem8
            // 
            this.barButtonItem8.Caption = "barButtonItem8";
            this.barButtonItem8.Id = 107;
            this.barButtonItem8.Name = "barButtonItem8";
            // 
            // btnHoaDon
            // 
            this.btnHoaDon.Caption = "Hóa đơn";
            this.btnHoaDon.Id = 108;
            this.btnHoaDon.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_paid_bill_filled_50px;
            this.btnHoaDon.Name = "btnHoaDon";
            this.btnHoaDon.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnHoaDon_ItemClick);
            // 
            // btnLoaiMatBang
            // 
            this.btnLoaiMatBang.Caption = "Loại mặt bằng";
            this.btnLoaiMatBang.Id = 109;
            this.btnLoaiMatBang.ImageOptions.ImageIndex = 72;
            this.btnLoaiMatBang.Name = "btnLoaiMatBang";
            this.btnLoaiMatBang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLoaiMatBang_ItemClick);
            // 
            // btnKhoManager
            // 
            this.btnKhoManager.Id = 762;
            this.btnKhoManager.Name = "btnKhoManager";
            // 
            // btnPhongBan
            // 
            this.btnPhongBan.Caption = "Phòng ban";
            this.btnPhongBan.Id = 111;
            this.btnPhongBan.ImageOptions.ImageIndex = 72;
            this.btnPhongBan.Name = "btnPhongBan";
            this.btnPhongBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnPhongBan_ItemClick);
            // 
            // barSubItemDanhMucToaNha
            // 
            this.barSubItemDanhMucToaNha.Caption = "Danh mục chung";
            this.barSubItemDanhMucToaNha.Id = 112;
            this.barSubItemDanhMucToaNha.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_sorting_answers_filled_50px;
            this.barSubItemDanhMucToaNha.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemKhoiNha),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTangLau),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnLoaiMatBang),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNhomMB),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemMatBang_TrangThai),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemLoaiTien, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDonViTinh),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemLoaiGiaThue),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnKhuVuc, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNhaCungCap),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnPhongBan),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemChucVu),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDMTK),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNganHang),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemQuocTich),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemLoaiYeuCau)});
            this.barSubItemDanhMucToaNha.Name = "barSubItemDanhMucToaNha";
            // 
            // itemNhomMB
            // 
            this.itemNhomMB.Caption = "Nhóm mặt bằng";
            this.itemNhomMB.Id = 882;
            this.itemNhomMB.ImageOptions.ImageIndex = 72;
            this.itemNhomMB.Name = "itemNhomMB";
            this.itemNhomMB.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhomMB_ItemClick);
            // 
            // itemLoaiTien
            // 
            this.itemLoaiTien.Caption = "Loại Tiền";
            this.itemLoaiTien.Id = 432;
            this.itemLoaiTien.ImageOptions.ImageIndex = 72;
            this.itemLoaiTien.Name = "itemLoaiTien";
            this.itemLoaiTien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLoaiTien_ItemClick);
            // 
            // itemDonViTinh
            // 
            this.itemDonViTinh.Caption = "Đơn vị tính";
            this.itemDonViTinh.Id = 512;
            this.itemDonViTinh.ImageOptions.ImageIndex = 72;
            this.itemDonViTinh.Name = "itemDonViTinh";
            this.itemDonViTinh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDonViTinh_ItemClick);
            // 
            // itemLoaiGiaThue
            // 
            this.itemLoaiGiaThue.Caption = "Loại Giá Thuê";
            this.itemLoaiGiaThue.Id = 434;
            this.itemLoaiGiaThue.ImageOptions.ImageIndex = 72;
            this.itemLoaiGiaThue.Name = "itemLoaiGiaThue";
            this.itemLoaiGiaThue.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLoaiGiaThue_ItemClick);
            // 
            // btnKhuVuc
            // 
            this.btnKhuVuc.Caption = "Khu vực";
            this.btnKhuVuc.Id = 235;
            this.btnKhuVuc.ImageOptions.ImageIndex = 72;
            this.btnKhuVuc.Name = "btnKhuVuc";
            this.btnKhuVuc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnKhuVuc_ItemClick);
            // 
            // itemChucVu
            // 
            this.itemChucVu.Caption = "Chức vụ";
            this.itemChucVu.Id = 947;
            this.itemChucVu.ImageOptions.ImageIndex = 72;
            this.itemChucVu.Name = "itemChucVu";
            this.itemChucVu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemChucVu_ItemClick);
            // 
            // itemDMTK
            // 
            this.itemDMTK.Caption = "Tài khoản ngân hàng";
            this.itemDMTK.Id = 391;
            this.itemDMTK.ImageOptions.ImageIndex = 72;
            this.itemDMTK.Name = "itemDMTK";
            this.itemDMTK.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDMTK_ItemClick);
            // 
            // itemNganHang
            // 
            this.itemNganHang.Caption = "Ngân hàng";
            this.itemNganHang.Id = 527;
            this.itemNganHang.ImageOptions.ImageIndex = 72;
            this.itemNganHang.Name = "itemNganHang";
            this.itemNganHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNganHang_ItemClick);
            // 
            // itemQuocTich
            // 
            this.itemQuocTich.Caption = "Quốc tịch";
            this.itemQuocTich.Id = 601;
            this.itemQuocTich.ImageOptions.ImageIndex = 72;
            this.itemQuocTich.Name = "itemQuocTich";
            this.itemQuocTich.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemQuocTich_ItemClick);
            // 
            // itemLoaiYeuCau
            // 
            this.itemLoaiYeuCau.Caption = "Loại yêu cầu";
            this.itemLoaiYeuCau.Id = 602;
            this.itemLoaiYeuCau.ImageOptions.ImageIndex = 72;
            this.itemLoaiYeuCau.Name = "itemLoaiYeuCau";
            this.itemLoaiYeuCau.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLoaiYeuCau_ItemClick);
            // 
            // barSubItemDanhMucTaiSan
            // 
            this.barSubItemDanhMucTaiSan.Caption = "Danh mục";
            this.barSubItemDanhMucTaiSan.Id = 113;
            this.barSubItemDanhMucTaiSan.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.category_orange;
            this.barSubItemDanhMucTaiSan.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemLoaiTaiSan),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemHangSanXuat),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemXuatXu),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTrangThaiTaiSan),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItemKhoHang),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemDVT, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemHeThongKT, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDVSD),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnChatLuong),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnNguonGocHT)});
            this.barSubItemDanhMucTaiSan.Name = "barSubItemDanhMucTaiSan";
            // 
            // barButtonItemKhoHang
            // 
            this.barButtonItemKhoHang.Id = 764;
            this.barButtonItemKhoHang.Name = "barButtonItemKhoHang";
            // 
            // itemDVT
            // 
            this.itemDVT.Id = 788;
            this.itemDVT.Name = "itemDVT";
            // 
            // itemHeThongKT
            // 
            this.itemHeThongKT.Id = 784;
            this.itemHeThongKT.Name = "itemHeThongKT";
            // 
            // itemDVSD
            // 
            this.itemDVSD.Id = 785;
            this.itemDVSD.Name = "itemDVSD";
            // 
            // btnChatLuong
            // 
            this.btnChatLuong.Id = 786;
            this.btnChatLuong.Name = "btnChatLuong";
            // 
            // btnNguonGocHT
            // 
            this.btnNguonGocHT.Id = 787;
            this.btnNguonGocHT.Name = "btnNguonGocHT";
            // 
            // barButtonGroup1
            // 
            this.barButtonGroup1.Caption = "barButtonGroup1";
            this.barButtonGroup1.Id = 115;
            this.barButtonGroup1.Name = "barButtonGroup1";
            // 
            // barSubItem4
            // 
            this.barSubItem4.Caption = "barSubItem4";
            this.barSubItem4.Id = 116;
            this.barSubItem4.Name = "barSubItem4";
            // 
            // barSubItemDanhMucDichVu
            // 
            this.barSubItemDanhMucDichVu.Caption = "Danh mục";
            this.barSubItemDanhMucDichVu.Id = 117;
            this.barSubItemDanhMucDichVu.Name = "barSubItemDanhMucDichVu";
            // 
            // barSubItem6
            // 
            this.barSubItem6.Caption = "barSubItem6";
            this.barSubItem6.Id = 118;
            this.barSubItem6.Name = "barSubItem6";
            // 
            // barButtonGroup2
            // 
            this.barButtonGroup2.Caption = "barButtonGroup2";
            this.barButtonGroup2.Id = 119;
            this.barButtonGroup2.Name = "barButtonGroup2";
            // 
            // barButtonGroup3
            // 
            this.barButtonGroup3.Caption = "barButtonGroup3";
            this.barButtonGroup3.Id = 120;
            this.barButtonGroup3.Name = "barButtonGroup3";
            // 
            // barButtonGroup4
            // 
            this.barButtonGroup4.Caption = "barButtonGroup4";
            this.barButtonGroup4.Id = 121;
            this.barButtonGroup4.Name = "barButtonGroup4";
            // 
            // barSubItem2
            // 
            this.barSubItem2.Caption = "barSubItem2";
            this.barSubItem2.Id = 122;
            this.barSubItem2.Name = "barSubItem2";
            // 
            // groupDanhMucDV
            // 
            this.groupDanhMucDV.Caption = "Danh mục";
            this.groupDanhMucDV.Id = 123;
            this.groupDanhMucDV.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_sorting_answers_filled_50px;
            this.groupDanhMucDV.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemLoaiDichVu, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem34),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBangGiaDichVuCoBan),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemCapNhatBangGiaDichVuCoBan),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemSoDuDauKy),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTXDinhMuc, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemLoaiXe),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemCauHinhAPITheXe),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDien_DinhMuc, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDien3Pha_DinhMuc),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDienDieuHoa_DinhMuc),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDMNuoc, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNuoc_UuDai),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNuocCachTinh),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNuocNong_DongHo),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDongHoDien, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDongHoDienDieuHoa),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDongHoDien3Pha),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDongHoDienLanh),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNuocNong_DinhMuc, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNuocDongHo),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnsmGas, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemCaiDatChietKhau, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemLaiSuatChamNop),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemCaiDatDuyetHoaDon),
            new DevExpress.XtraBars.LinkPersistInfo(this.BtnCauHinhColor),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemCauHinhNhanVienQuanLyNhanMail),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnCauHinhVAT),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDongHoDienLanh)});
            this.groupDanhMucDV.Name = "groupDanhMucDV";
            // 
            // itemLoaiDichVu
            // 
            this.itemLoaiDichVu.Caption = "Loại dịch vụ";
            this.itemLoaiDichVu.Id = 442;
            this.itemLoaiDichVu.ImageOptions.ImageIndex = 72;
            this.itemLoaiDichVu.Name = "itemLoaiDichVu";
            this.itemLoaiDichVu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLoaiDichVu_ItemClick);
            // 
            // barButtonItem34
            // 
            this.barButtonItem34.Caption = "Dịch vụ khấu trừ tự động";
            this.barButtonItem34.Id = 643;
            this.barButtonItem34.ImageOptions.ImageIndex = 72;
            this.barButtonItem34.Name = "barButtonItem34";
            this.barButtonItem34.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem34_ItemClick);
            // 
            // itemBangGiaDichVuCoBan
            // 
            this.itemBangGiaDichVuCoBan.Caption = "Bảng giá dịch vụ cơ bản";
            this.itemBangGiaDichVuCoBan.Id = 515;
            this.itemBangGiaDichVuCoBan.ImageOptions.ImageIndex = 72;
            this.itemBangGiaDichVuCoBan.Name = "itemBangGiaDichVuCoBan";
            this.itemBangGiaDichVuCoBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBangGiaDichVuCoBan_ItemClick);
            // 
            // itemCapNhatBangGiaDichVuCoBan
            // 
            this.itemCapNhatBangGiaDichVuCoBan.Caption = "Cập nhật bảng giá dịch vụ cơ bản";
            this.itemCapNhatBangGiaDichVuCoBan.Id = 622;
            this.itemCapNhatBangGiaDichVuCoBan.ImageOptions.ImageIndex = 72;
            this.itemCapNhatBangGiaDichVuCoBan.Name = "itemCapNhatBangGiaDichVuCoBan";
            this.itemCapNhatBangGiaDichVuCoBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCapNhatBangGiaDichVuCoBan_ItemClick);
            // 
            // itemSoDuDauKy
            // 
            this.itemSoDuDauKy.Caption = "Số dư đầu kỳ";
            this.itemSoDuDauKy.Id = 926;
            this.itemSoDuDauKy.ImageOptions.ImageIndex = 72;
            this.itemSoDuDauKy.Name = "itemSoDuDauKy";
            this.itemSoDuDauKy.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemSoDuDauKy_ItemClick);
            // 
            // itemTXDinhMuc
            // 
            this.itemTXDinhMuc.Caption = "Định mức giữ xe";
            this.itemTXDinhMuc.Id = 309;
            this.itemTXDinhMuc.ImageOptions.ImageIndex = 72;
            this.itemTXDinhMuc.Name = "itemTXDinhMuc";
            this.itemTXDinhMuc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTXDinhMuc_ItemClick);
            // 
            // itemCauHinhAPITheXe
            // 
            this.itemCauHinhAPITheXe.Caption = "Cấu hình API";
            this.itemCauHinhAPITheXe.Id = 702;
            this.itemCauHinhAPITheXe.ImageOptions.ImageIndex = 72;
            this.itemCauHinhAPITheXe.Name = "itemCauHinhAPITheXe";
            this.itemCauHinhAPITheXe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCauHinhAPITheXe_ItemClick);
            // 
            // itemDien3Pha_DinhMuc
            // 
            this.itemDien3Pha_DinhMuc.Caption = "Định mức điện 3 pha";
            this.itemDien3Pha_DinhMuc.Id = 517;
            this.itemDien3Pha_DinhMuc.ImageOptions.ImageIndex = 72;
            this.itemDien3Pha_DinhMuc.Name = "itemDien3Pha_DinhMuc";
            this.itemDien3Pha_DinhMuc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDien3Pha_DinhMuc_ItemClick);
            // 
            // itemDienDieuHoa_DinhMuc
            // 
            this.itemDienDieuHoa_DinhMuc.Caption = "Định mức điện điều hòa";
            this.itemDienDieuHoa_DinhMuc.Id = 564;
            this.itemDienDieuHoa_DinhMuc.ImageOptions.ImageIndex = 72;
            this.itemDienDieuHoa_DinhMuc.Name = "itemDienDieuHoa_DinhMuc";
            this.itemDienDieuHoa_DinhMuc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDienDieuHoa_DinhMuc_ItemClick);
            // 
            // itemDMNuoc
            // 
            this.itemDMNuoc.Caption = "Định mức Nước";
            this.itemDMNuoc.Id = 308;
            this.itemDMNuoc.ImageOptions.ImageIndex = 72;
            this.itemDMNuoc.Name = "itemDMNuoc";
            this.itemDMNuoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDMNuoc_ItemClick);
            // 
            // itemNuoc_UuDai
            // 
            this.itemNuoc_UuDai.Caption = "Định mức ưu đãi nước";
            this.itemNuoc_UuDai.Id = 511;
            this.itemNuoc_UuDai.ImageOptions.ImageIndex = 72;
            this.itemNuoc_UuDai.Name = "itemNuoc_UuDai";
            this.itemNuoc_UuDai.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNuoc_UuDai_ItemClick);
            // 
            // itemNuocCachTinh
            // 
            this.itemNuocCachTinh.Caption = "Cách tính nước";
            this.itemNuocCachTinh.Id = 514;
            this.itemNuocCachTinh.ImageOptions.ImageIndex = 72;
            this.itemNuocCachTinh.Name = "itemNuocCachTinh";
            this.itemNuocCachTinh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNuocCachTinh_ItemClick);
            // 
            // itemNuocNong_DongHo
            // 
            this.itemNuocNong_DongHo.Caption = "Đồng hồ nước nóng";
            this.itemNuocNong_DongHo.Id = 537;
            this.itemNuocNong_DongHo.ImageOptions.ImageIndex = 72;
            this.itemNuocNong_DongHo.Name = "itemNuocNong_DongHo";
            this.itemNuocNong_DongHo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNuocNong_DongHo_ItemClick);
            // 
            // itemDongHoDien
            // 
            this.itemDongHoDien.Caption = "Đồng hồ điện chiếu sáng";
            this.itemDongHoDien.Id = 977;
            this.itemDongHoDien.ImageOptions.ImageIndex = 72;
            this.itemDongHoDien.Name = "itemDongHoDien";
            // 
            // itemDongHoDienDieuHoa
            // 
            this.itemDongHoDienDieuHoa.Caption = "Đồng hồ điện điều hòa";
            this.itemDongHoDienDieuHoa.Id = 978;
            this.itemDongHoDienDieuHoa.ImageOptions.ImageIndex = 72;
            this.itemDongHoDienDieuHoa.Name = "itemDongHoDienDieuHoa";
            // 
            // itemDongHoDien3Pha
            // 
            this.itemDongHoDien3Pha.Caption = "Đồng hồ điện 3 pha";
            this.itemDongHoDien3Pha.Id = 1033;
            this.itemDongHoDien3Pha.ImageOptions.ImageIndex = 72;
            this.itemDongHoDien3Pha.Name = "itemDongHoDien3Pha";
            this.itemDongHoDien3Pha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDongHoDien3Pha_ItemClick);
            // 
            // itemDongHoDienLanh
            // 
            this.itemDongHoDienLanh.Caption = "Đồng hồ điện lạnh";
            this.itemDongHoDienLanh.Id = 1045;
            this.itemDongHoDienLanh.ImageOptions.ImageIndex = 72;
            this.itemDongHoDienLanh.Name = "itemDongHoDienLanh";
            this.itemDongHoDienLanh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDongHoDienLanh_ItemClick);
            // 
            // itemNuocNong_DinhMuc
            // 
            this.itemNuocNong_DinhMuc.Caption = "Định mức nước nóng";
            this.itemNuocNong_DinhMuc.Id = 538;
            this.itemNuocNong_DinhMuc.ImageOptions.ImageIndex = 72;
            this.itemNuocNong_DinhMuc.Name = "itemNuocNong_DinhMuc";
            this.itemNuocNong_DinhMuc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNuocNong_DinhMuc_ItemClick);
            // 
            // itemNuocDongHo
            // 
            this.itemNuocDongHo.Caption = "Đồng hồ nước";
            this.itemNuocDongHo.Id = 525;
            this.itemNuocDongHo.ImageOptions.ImageIndex = 72;
            this.itemNuocDongHo.Name = "itemNuocDongHo";
            this.itemNuocDongHo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNuocDongHo_ItemClick);
            // 
            // btnsmGas
            // 
            this.btnsmGas.Caption = "Định mức Gas";
            this.btnsmGas.Id = 287;
            this.btnsmGas.ImageOptions.ImageIndex = 72;
            this.btnsmGas.Name = "btnsmGas";
            this.btnsmGas.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnsmGas_ItemClick);
            // 
            // itemCaiDatChietKhau
            // 
            this.itemCaiDatChietKhau.Caption = "Cài đặt chiết khấu";
            this.itemCaiDatChietKhau.Id = 443;
            this.itemCaiDatChietKhau.ImageOptions.ImageIndex = 72;
            this.itemCaiDatChietKhau.Name = "itemCaiDatChietKhau";
            this.itemCaiDatChietKhau.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCaiDatChietKhau_ItemClick);
            // 
            // itemLaiSuatChamNop
            // 
            this.itemLaiSuatChamNop.Caption = "Cài đặt lãi suất nộp chậm";
            this.itemLaiSuatChamNop.Id = 362;
            this.itemLaiSuatChamNop.ImageOptions.ImageIndex = 72;
            this.itemLaiSuatChamNop.Name = "itemLaiSuatChamNop";
            this.itemLaiSuatChamNop.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLaiSuatChamNop_ItemClick);
            // 
            // itemCaiDatDuyetHoaDon
            // 
            this.itemCaiDatDuyetHoaDon.Caption = "Cài đặt duyệt hóa đơn";
            this.itemCaiDatDuyetHoaDon.Id = 549;
            this.itemCaiDatDuyetHoaDon.ImageOptions.ImageIndex = 72;
            this.itemCaiDatDuyetHoaDon.Name = "itemCaiDatDuyetHoaDon";
            this.itemCaiDatDuyetHoaDon.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCaiDatDuyetHoaDon_ItemClick);
            // 
            // BtnCauHinhColor
            // 
            this.BtnCauHinhColor.Caption = "Cấu hình Format";
            this.BtnCauHinhColor.Id = 745;
            this.BtnCauHinhColor.ImageOptions.ImageIndex = 72;
            this.BtnCauHinhColor.Name = "BtnCauHinhColor";
            this.BtnCauHinhColor.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.BtnCauHinhColor_ItemClick);
            // 
            // itemCauHinhNhanVienQuanLyNhanMail
            // 
            this.itemCauHinhNhanVienQuanLyNhanMail.Caption = "Nhân viên quản lý nhận mail";
            this.itemCauHinhNhanVienQuanLyNhanMail.Id = 837;
            this.itemCauHinhNhanVienQuanLyNhanMail.ImageOptions.ImageIndex = 72;
            this.itemCauHinhNhanVienQuanLyNhanMail.Name = "itemCauHinhNhanVienQuanLyNhanMail";
            this.itemCauHinhNhanVienQuanLyNhanMail.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCauHinhNhanVienQuanLyNhanMail_ItemClick);
            // 
            // btnCauHinhVAT
            // 
            this.btnCauHinhVAT.Caption = "Cấu hình VAT dịch vụ";
            this.btnCauHinhVAT.Id = 1031;
            this.btnCauHinhVAT.ImageOptions.ImageIndex = 72;
            this.btnCauHinhVAT.Name = "btnCauHinhVAT";
            this.btnCauHinhVAT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnCauHinhVAT_ItemClick);
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Caption = "barButtonItem4";
            this.barButtonItem4.Id = 124;
            this.barButtonItem4.Name = "barButtonItem4";
            // 
            // itemTrangThaiNhanKhau
            // 
            this.itemTrangThaiNhanKhau.Caption = "Trạng thái cư dân";
            this.itemTrangThaiNhanKhau.Id = 125;
            this.itemTrangThaiNhanKhau.ImageOptions.ImageIndex = 72;
            this.itemTrangThaiNhanKhau.Name = "itemTrangThaiNhanKhau";
            this.itemTrangThaiNhanKhau.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTrangThaiNhanKhau_ItemClick);
            // 
            // barButtonItemTaiSan
            // 
            this.barButtonItemTaiSan.Id = 763;
            this.barButtonItemTaiSan.Name = "barButtonItemTaiSan";
            // 
            // btnThongKeTQ
            // 
            this.btnThongKeTQ.Caption = "Thống kê";
            this.btnThongKeTQ.Id = 129;
            this.btnThongKeTQ.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btnThongKeTQ.ImageOptions.LargeImage")));
            this.btnThongKeTQ.Name = "btnThongKeTQ";
            this.btnThongKeTQ.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.btnThongKeTQ.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnThongKeTQ_ItemClick);
            // 
            // butnTkMBTheoTT
            // 
            this.butnTkMBTheoTT.Caption = "Mặt bằng";
            this.butnTkMBTheoTT.Id = 131;
            this.butnTkMBTheoTT.ImageOptions.ImageIndex = 18;
            this.butnTkMBTheoTT.Name = "butnTkMBTheoTT";
            this.butnTkMBTheoTT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.butnTkMBTheoTT_ItemClick);
            // 
            // btnTKDienNuoc
            // 
            this.btnTKDienNuoc.Caption = "Điện - Nước";
            this.btnTKDienNuoc.Id = 134;
            this.btnTKDienNuoc.ImageOptions.ImageIndex = 18;
            this.btnTKDienNuoc.Name = "btnTKDienNuoc";
            this.btnTKDienNuoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnTKDienNuoc_ItemClick);
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Caption = "Giới thiệu";
            this.barButtonItem5.Id = 136;
            this.barButtonItem5.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_gioi_thieu;
            this.barButtonItem5.Name = "barButtonItem5";
            this.barButtonItem5.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem5_ItemClick);
            // 
            // btnTrangThaiTheXe
            // 
            this.btnTrangThaiTheXe.Caption = "Trạng thái thẻ xe";
            this.btnTrangThaiTheXe.Id = 137;
            this.btnTrangThaiTheXe.ImageOptions.ImageIndex = 45;
            this.btnTrangThaiTheXe.Name = "btnTrangThaiTheXe";
            // 
            // btnTrangThaiThangMay
            // 
            this.btnTrangThaiThangMay.Caption = "Trạng thái thẻ thang máy";
            this.btnTrangThaiThangMay.Id = 138;
            this.btnTrangThaiThangMay.ImageOptions.ImageIndex = 45;
            this.btnTrangThaiThangMay.Name = "btnTrangThaiThangMay";
            this.btnTrangThaiThangMay.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnTrangThaiThangMay_ItemClick);
            // 
            // btnTrangThaiYC
            // 
            this.btnTrangThaiYC.Caption = "Trạng thái yêu cầu";
            this.btnTrangThaiYC.Id = 139;
            this.btnTrangThaiYC.ImageOptions.ImageIndex = 72;
            this.btnTrangThaiYC.Name = "btnTrangThaiYC";
            this.btnTrangThaiYC.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnTrangThaiYC_ItemClick);
            // 
            // btnDoUuTienYC
            // 
            this.btnDoUuTienYC.Caption = "Mức độ yêu cầu";
            this.btnDoUuTienYC.Id = 140;
            this.btnDoUuTienYC.ImageOptions.ImageIndex = 72;
            this.btnDoUuTienYC.Name = "btnDoUuTienYC";
            this.btnDoUuTienYC.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnDoUuTienYC_ItemClick);
            // 
            // btnEmail
            // 
            this.btnEmail.Caption = "SMS";
            this.btnEmail.Id = 142;
            this.btnEmail.Name = "btnEmail";
            // 
            // barButtonItem6
            // 
            this.barButtonItem6.Caption = "SMS";
            this.barButtonItem6.Id = 145;
            this.barButtonItem6.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("barButtonItem6.ImageOptions.Image")));
            this.barButtonItem6.Name = "barButtonItem6";
            // 
            // barButtonItem19
            // 
            this.barButtonItem19.Caption = "Email";
            this.barButtonItem19.Id = 146;
            this.barButtonItem19.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("barButtonItem19.ImageOptions.Image")));
            this.barButtonItem19.Name = "barButtonItem19";
            this.barButtonItem19.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem19_ItemClick);
            // 
            // itemCongNoTheoKhachHang
            // 
            this.itemCongNoTheoKhachHang.Caption = "Công nợ theo khách hàng";
            this.itemCongNoTheoKhachHang.Id = 147;
            this.itemCongNoTheoKhachHang.ImageOptions.ImageIndex = 16;
            this.itemCongNoTheoKhachHang.Name = "itemCongNoTheoKhachHang";
            this.itemCongNoTheoKhachHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCongNoTheoKhachHang_ItemClick);
            // 
            // btnBaoCaothu
            // 
            this.btnBaoCaothu.Caption = "Báo cáo thu";
            this.btnBaoCaothu.Id = 148;
            this.btnBaoCaothu.ImageOptions.ImageIndex = 17;
            this.btnBaoCaothu.Name = "btnBaoCaothu";
            this.btnBaoCaothu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnBaoCaothu_ItemClick);
            // 
            // BtnBaoCaoChi
            // 
            this.BtnBaoCaoChi.Caption = "Báo cáo chi";
            this.BtnBaoCaoChi.Id = 149;
            this.BtnBaoCaoChi.ImageOptions.ImageIndex = 17;
            this.BtnBaoCaoChi.Name = "BtnBaoCaoChi";
            this.BtnBaoCaoChi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.BtnBaoCaoChi_ItemClick);
            // 
            // btnBaoCaoCongNoTheoMatBang
            // 
            this.btnBaoCaoCongNoTheoMatBang.Caption = "Công nợ theo mặt bằng";
            this.btnBaoCaoCongNoTheoMatBang.Id = 150;
            this.btnBaoCaoCongNoTheoMatBang.ImageOptions.ImageIndex = 16;
            this.btnBaoCaoCongNoTheoMatBang.Name = "btnBaoCaoCongNoTheoMatBang";
            this.btnBaoCaoCongNoTheoMatBang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnBaoCaoCongNoTheoMatBang_ItemClick);
            // 
            // itemTKThuChi
            // 
            this.itemTKThuChi.Caption = "Thu - Chi";
            this.itemTKThuChi.Id = 151;
            this.itemTKThuChi.ImageOptions.ImageIndex = 18;
            this.itemTKThuChi.Name = "itemTKThuChi";
            this.itemTKThuChi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTKThuChi_ItemClick);
            // 
            // itemTKHDTTT
            // 
            this.itemTKHDTTT.Caption = "Hợp đồng";
            this.itemTKHDTTT.Id = 152;
            this.itemTKHDTTT.ImageOptions.ImageIndex = 18;
            this.itemTKHDTTT.Name = "itemTKHDTTT";
            this.itemTKHDTTT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTKHDTTT_ItemClick);
            // 
            // barStaticItemLogin
            // 
            this.barStaticItemLogin.Caption = "www.dip.vn";
            this.barStaticItemLogin.Id = 166;
            this.barStaticItemLogin.Name = "barStaticItemLogin";
            // 
            // itemDoanhThuHopDongThue
            // 
            this.itemDoanhThuHopDongThue.Caption = "Doanh thu trên hợp đồng thuê";
            this.itemDoanhThuHopDongThue.Id = 167;
            this.itemDoanhThuHopDongThue.ImageOptions.ImageIndex = 16;
            this.itemDoanhThuHopDongThue.Name = "itemDoanhThuHopDongThue";
            this.itemDoanhThuHopDongThue.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDoanhThuHopDongThue_ItemClick);
            // 
            // itemTyGia
            // 
            this.itemTyGia.Caption = "Tỷ giá";
            this.itemTyGia.Id = 168;
            this.itemTyGia.ImageOptions.ImageIndex = 45;
            this.itemTyGia.Name = "itemTyGia";
            // 
            // itemNhacNoKhachHang
            // 
            this.itemNhacNoKhachHang.Caption = "Công nợ";
            this.itemNhacNoKhachHang.Id = 169;
            this.itemNhacNoKhachHang.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_general_ledger_filled_50px;
            this.itemNhacNoKhachHang.Name = "itemNhacNoKhachHang";
            this.itemNhacNoKhachHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhacNoKhachHang_ItemClick);
            // 
            // itemTTNhacNo
            // 
            this.itemTTNhacNo.Caption = "Trạng thái nhắc nợ";
            this.itemTTNhacNo.Id = 170;
            this.itemTTNhacNo.ImageOptions.ImageIndex = 45;
            this.itemTTNhacNo.Name = "itemTTNhacNo";
            this.itemTTNhacNo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTTNhacNo_ItemClick);
            // 
            // exportTS2Excel
            // 
            this.exportTS2Excel.Caption = "Xuất báo cáo tài sản ra file Excel";
            this.exportTS2Excel.Id = 172;
            this.exportTS2Excel.ImageOptions.ImageIndex = 12;
            this.exportTS2Excel.Name = "exportTS2Excel";
            this.exportTS2Excel.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.exportTS2Excel_ItemClick);
            // 
            // btnExportDV2Excel
            // 
            this.btnExportDV2Excel.Caption = "Xuất báo cáo dịch vụ ra file Excel";
            this.btnExportDV2Excel.Id = 173;
            this.btnExportDV2Excel.ImageOptions.ImageIndex = 12;
            this.btnExportDV2Excel.Name = "btnExportDV2Excel";
            this.btnExportDV2Excel.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnExportDV2Excel_ItemClick);
            // 
            // btnCongNohdtn
            // 
            this.btnCongNohdtn.Caption = "Công nợ";
            this.btnCongNohdtn.Id = 174;
            this.btnCongNohdtn.ImageOptions.ImageIndex = 17;
            this.btnCongNohdtn.Name = "btnCongNohdtn";
            this.btnCongNohdtn.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnCongNohdtn_ItemClick);
            // 
            // btnCongNoHDHT
            // 
            this.btnCongNoHDHT.Caption = "Công nợ";
            this.btnCongNoHDHT.Id = 175;
            this.btnCongNoHDHT.ImageOptions.ImageIndex = 17;
            this.btnCongNoHDHT.Name = "btnCongNoHDHT";
            this.btnCongNoHDHT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnCongNoHDHT_ItemClick);
            // 
            // itemThongKeYeuCau
            // 
            this.itemThongKeYeuCau.Caption = "Yêu cầu";
            this.itemThongKeYeuCau.Id = 181;
            this.itemThongKeYeuCau.ImageOptions.ImageIndex = 18;
            this.itemThongKeYeuCau.Name = "itemThongKeYeuCau";
            this.itemThongKeYeuCau.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThongKeYeuCau_ItemClick);
            // 
            // itemCopyRight
            // 
            this.itemCopyRight.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right;
            this.itemCopyRight.Edit = this.repositoryItemPictureEdit3;
            this.itemCopyRight.EditWidth = 100;
            this.itemCopyRight.Id = 204;
            this.itemCopyRight.ItemAppearance.Normal.ForeColor = System.Drawing.Color.Transparent;
            this.itemCopyRight.ItemAppearance.Normal.Options.UseForeColor = true;
            this.itemCopyRight.ItemInMenuAppearance.Normal.BackColor = System.Drawing.Color.Transparent;
            this.itemCopyRight.ItemInMenuAppearance.Normal.Options.UseBackColor = true;
            this.itemCopyRight.Name = "itemCopyRight";
            this.itemCopyRight.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCopyRight_ItemClick);
            // 
            // repositoryItemPictureEdit3
            // 
            this.repositoryItemPictureEdit3.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.repositoryItemPictureEdit3.Appearance.BackColor2 = System.Drawing.Color.Transparent;
            this.repositoryItemPictureEdit3.Appearance.BorderColor = System.Drawing.Color.Transparent;
            this.repositoryItemPictureEdit3.Appearance.Options.UseBackColor = true;
            this.repositoryItemPictureEdit3.Appearance.Options.UseBorderColor = true;
            this.repositoryItemPictureEdit3.AppearanceDisabled.BackColor = System.Drawing.Color.Transparent;
            this.repositoryItemPictureEdit3.AppearanceDisabled.BackColor2 = System.Drawing.Color.Transparent;
            this.repositoryItemPictureEdit3.AppearanceDisabled.BorderColor = System.Drawing.Color.Transparent;
            this.repositoryItemPictureEdit3.AppearanceDisabled.Options.UseBackColor = true;
            this.repositoryItemPictureEdit3.AppearanceDisabled.Options.UseBorderColor = true;
            this.repositoryItemPictureEdit3.AppearanceFocused.BackColor = System.Drawing.Color.Transparent;
            this.repositoryItemPictureEdit3.AppearanceFocused.BackColor2 = System.Drawing.Color.Transparent;
            this.repositoryItemPictureEdit3.AppearanceFocused.BorderColor = System.Drawing.Color.Transparent;
            this.repositoryItemPictureEdit3.AppearanceFocused.Options.UseBackColor = true;
            this.repositoryItemPictureEdit3.AppearanceFocused.Options.UseBorderColor = true;
            this.repositoryItemPictureEdit3.AppearanceReadOnly.BackColor = System.Drawing.Color.Transparent;
            this.repositoryItemPictureEdit3.AppearanceReadOnly.BackColor2 = System.Drawing.Color.Transparent;
            this.repositoryItemPictureEdit3.AppearanceReadOnly.BorderColor = System.Drawing.Color.Transparent;
            this.repositoryItemPictureEdit3.AppearanceReadOnly.Options.UseBackColor = true;
            this.repositoryItemPictureEdit3.AppearanceReadOnly.Options.UseBorderColor = true;
            this.repositoryItemPictureEdit3.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.repositoryItemPictureEdit3.Name = "repositoryItemPictureEdit3";
            this.repositoryItemPictureEdit3.ReadOnly = true;
            this.repositoryItemPictureEdit3.ShowMenu = false;
            // 
            // itemBaoCaoMatBang
            // 
            this.itemBaoCaoMatBang.Caption = "Mặt bằng";
            this.itemBaoCaoMatBang.Id = 208;
            this.itemBaoCaoMatBang.ImageOptions.ImageIndex = 16;
            this.itemBaoCaoMatBang.Name = "itemBaoCaoMatBang";
            this.itemBaoCaoMatBang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoCaoMatBang_ItemClick);
            // 
            // itemThongBaoThuPhi
            // 
            this.itemThongBaoThuPhi.Caption = "Thông báo thu phí";
            this.itemThongBaoThuPhi.Id = 210;
            this.itemThongBaoThuPhi.ImageOptions.ImageIndex = 16;
            this.itemThongBaoThuPhi.Name = "itemThongBaoThuPhi";
            this.itemThongBaoThuPhi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThongBaoThuPhi_ItemClick);
            // 
            // itemThongBaoCatNuoc
            // 
            this.itemThongBaoCatNuoc.Caption = "Thông báo tạm ngưng cấp nước";
            this.itemThongBaoCatNuoc.Id = 211;
            this.itemThongBaoCatNuoc.ImageOptions.ImageIndex = 16;
            this.itemThongBaoCatNuoc.Name = "itemThongBaoCatNuoc";
            this.itemThongBaoCatNuoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThongBaoCatNuoc_ItemClick);
            // 
            // itemBaoCaoTongHop
            // 
            this.itemBaoCaoTongHop.Caption = "Tổng hợp thực thu - Chuyển khoản";
            this.itemBaoCaoTongHop.Id = 212;
            this.itemBaoCaoTongHop.ImageOptions.ImageIndex = 16;
            this.itemBaoCaoTongHop.Name = "itemBaoCaoTongHop";
            this.itemBaoCaoTongHop.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoCaoTongHop_ItemClick);
            // 
            // itemBaoCaoKetQauKinhDoanh
            // 
            this.itemBaoCaoKetQauKinhDoanh.Caption = "Kết quả kinh doanh";
            this.itemBaoCaoKetQauKinhDoanh.Id = 213;
            this.itemBaoCaoKetQauKinhDoanh.ImageOptions.ImageIndex = 16;
            this.itemBaoCaoKetQauKinhDoanh.Name = "itemBaoCaoKetQauKinhDoanh";
            this.itemBaoCaoKetQauKinhDoanh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoCaoKetQauKinhDoanh_ItemClick);
            // 
            // itemChiTietNopTien
            // 
            this.itemChiTietNopTien.Caption = "Chi tiết nộp tiền";
            this.itemChiTietNopTien.Id = 214;
            this.itemChiTietNopTien.ImageOptions.ImageIndex = 16;
            this.itemChiTietNopTien.Name = "itemChiTietNopTien";
            this.itemChiTietNopTien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemChiTietNopTien_ItemClick);
            // 
            // itemChiTietThuPhi
            // 
            this.itemChiTietThuPhi.Caption = "Chi tiết thu phí QL";
            this.itemChiTietThuPhi.Id = 215;
            this.itemChiTietThuPhi.ImageOptions.ImageIndex = 16;
            this.itemChiTietThuPhi.Name = "itemChiTietThuPhi";
            this.itemChiTietThuPhi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemChiTietThuPhi_ItemClick);
            // 
            // itemTheoDoiCongNo
            // 
            this.itemTheoDoiCongNo.Caption = "Theo dõi công nợ";
            this.itemTheoDoiCongNo.Id = 216;
            this.itemTheoDoiCongNo.ImageOptions.ImageIndex = 16;
            this.itemTheoDoiCongNo.Name = "itemTheoDoiCongNo";
            this.itemTheoDoiCongNo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTheoDoiCongNo_ItemClick);
            // 
            // itemCongNoTongHop
            // 
            this.itemCongNoTongHop.Caption = "Công nợ tổng hợp";
            this.itemCongNoTongHop.Id = 217;
            this.itemCongNoTongHop.ImageOptions.ImageIndex = 16;
            this.itemCongNoTongHop.Name = "itemCongNoTongHop";
            this.itemCongNoTongHop.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCongNoTongHop_ItemClick);
            // 
            // itemTheoDoiCongNoPQL
            // 
            this.itemTheoDoiCongNoPQL.Caption = "Theo dõi CN PQL";
            this.itemTheoDoiCongNoPQL.Id = 218;
            this.itemTheoDoiCongNoPQL.ImageOptions.ImageIndex = 16;
            this.itemTheoDoiCongNoPQL.Name = "itemTheoDoiCongNoPQL";
            this.itemTheoDoiCongNoPQL.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTheoDoiCongNoPQL_ItemClick);
            // 
            // itemTQQuanLy
            // 
            this.itemTQQuanLy.Caption = "Danh sách";
            this.itemTQQuanLy.Id = 219;
            this.itemTQQuanLy.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.view_list32;
            this.itemTQQuanLy.Name = "itemTQQuanLy";
            this.itemTQQuanLy.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTQQuanLy_ItemClick);
            // 
            // btnAnhNinh
            // 
            this.btnAnhNinh.Caption = "Danh sách kế hoạch";
            this.btnAnhNinh.Id = 220;
            this.btnAnhNinh.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.choice_48;
            this.btnAnhNinh.Name = "btnAnhNinh";
            this.btnAnhNinh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnAnhNinh_ItemClick);
            // 
            // btnNhatKyAN
            // 
            this.btnNhatKyAN.Caption = "Nhật ký";
            this.btnNhatKyAN.Id = 222;
            this.btnNhatKyAN.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.log;
            this.btnNhatKyAN.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.log;
            this.btnNhatKyAN.Name = "btnNhatKyAN";
            this.btnNhatKyAN.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnNhatKyAN_ItemClick);
            // 
            // btnNVCT
            // 
            this.btnNVCT.Caption = "Nhiệm vụ của tôi";
            this.btnNVCT.Id = 223;
            this.btnNVCT.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.centrejust;
            this.btnNVCT.Name = "btnNVCT";
            this.btnNVCT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnMyMisson_ItemClick);
            // 
            // btnGhiNhanSV
            // 
            this.btnGhiNhanSV.Caption = "Ghi nhận sự việc trong ca";
            this.btnGhiNhanSV.Id = 224;
            this.btnGhiNhanSV.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.add_32;
            this.btnGhiNhanSV.Name = "btnGhiNhanSV";
            this.btnGhiNhanSV.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnGhiNhanSV_ItemClick);
            // 
            // btnAdminLogAN
            // 
            this.btnAdminLogAN.Caption = "Nhật ký an ninh";
            this.btnAdminLogAN.Id = 228;
            this.btnAdminLogAN.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.log;
            this.btnAdminLogAN.Name = "btnAdminLogAN";
            this.btnAdminLogAN.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnAdminLogAN_ItemClick);
            // 
            // barButtonGroup5
            // 
            this.barButtonGroup5.Caption = "barButtonGroup5";
            this.barButtonGroup5.Id = 231;
            this.barButtonGroup5.Name = "barButtonGroup5";
            // 
            // btnChucVuMNG
            // 
            this.btnChucVuMNG.Caption = "Chức vụ";
            this.btnChucVuMNG.Id = 232;
            this.btnChucVuMNG.ImageOptions.ImageIndex = 45;
            this.btnChucVuMNG.Name = "btnChucVuMNG";
            this.btnChucVuMNG.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnChucVuMNG_ItemClick);
            // 
            // btnPhiQuanLy
            // 
            this.btnPhiQuanLy.Caption = "Phí quản lý";
            this.btnPhiQuanLy.Id = 233;
            this.btnPhiQuanLy.ImageOptions.ImageIndex = 45;
            this.btnPhiQuanLy.Name = "btnPhiQuanLy";
            this.btnPhiQuanLy.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnPhiQuanLy_ItemClick);
            // 
            // btnQuyTac
            // 
            this.btnQuyTac.Caption = "Quy tắc mã số";
            this.btnQuyTac.Id = 234;
            this.btnQuyTac.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_code_filled_50px;
            this.btnQuyTac.Name = "btnQuyTac";
            this.btnQuyTac.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnQuyTac_ItemClick);
            // 
            // btnDichVuCongCong
            // 
            this.btnDichVuCongCong.Caption = "Dịch vụ công cộng";
            this.btnDichVuCongCong.Id = 238;
            this.btnDichVuCongCong.ImageOptions.ImageIndex = 45;
            this.btnDichVuCongCong.Name = "btnDichVuCongCong";
            this.btnDichVuCongCong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnDichVuCongCong_ItemClick);
            // 
            // btnDichVuCCManger
            // 
            this.btnDichVuCCManger.Caption = "Dịch vụ công cộng";
            this.btnDichVuCCManger.Id = 243;
            this.btnDichVuCCManger.Name = "btnDichVuCCManger";
            this.btnDichVuCCManger.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnDichVuCCManger_ItemClick);
            // 
            // barSubItemCongNo
            // 
            this.barSubItemCongNo.Caption = "Công nợ";
            this.barSubItemCongNo.Id = 246;
            this.barSubItemCongNo.ImageOptions.ImageIndex = 16;
            this.barSubItemCongNo.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemCongNoTheoKhachHang),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnBaoCaoCongNoTheoMatBang),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemCongNoTongHop),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTheoDoiCongNo),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTheoDoiCongNoPQL),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemChiTietThuPhi),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemChiTietNopTien)});
            this.barSubItemCongNo.Name = "barSubItemCongNo";
            // 
            // barSubItemKinhDoanh
            // 
            this.barSubItemKinhDoanh.Caption = "Kinh doanh";
            this.barSubItemKinhDoanh.Id = 247;
            this.barSubItemKinhDoanh.ImageOptions.ImageIndex = 16;
            this.barSubItemKinhDoanh.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBaoCaoKetQauKinhDoanh),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDoanhThuHopDongThue),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBaoCaoTongHop)});
            this.barSubItemKinhDoanh.Name = "barSubItemKinhDoanh";
            // 
            // barSubItemThongBao
            // 
            this.barSubItemThongBao.Caption = "Thông báo";
            this.barSubItemThongBao.Id = 248;
            this.barSubItemThongBao.ImageOptions.ImageIndex = 16;
            this.barSubItemThongBao.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemThongBaoThuPhi),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemThongBaoCatNuoc)});
            this.barSubItemThongBao.Name = "barSubItemThongBao";
            // 
            // subTaiSan
            // 
            this.subTaiSan.Caption = "Tài sản";
            this.subTaiSan.Id = 249;
            this.subTaiSan.ImageOptions.ImageIndex = 16;
            this.subTaiSan.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btnBangkePhieuXuat),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnBangKePhieuNhap),
            new DevExpress.XtraBars.LinkPersistInfo(this.rptThongKeKhoaHang)});
            this.subTaiSan.Name = "subTaiSan";
            // 
            // btnBangkePhieuXuat
            // 
            this.btnBangkePhieuXuat.Caption = "Bảng kê phiếu xuất";
            this.btnBangkePhieuXuat.Id = 250;
            this.btnBangkePhieuXuat.ImageOptions.ImageIndex = 18;
            this.btnBangkePhieuXuat.Name = "btnBangkePhieuXuat";
            this.btnBangkePhieuXuat.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnBangkePhieuXuat_ItemClick);
            // 
            // btnBangKePhieuNhap
            // 
            this.btnBangKePhieuNhap.Caption = "Bảng kê phiếu nhập";
            this.btnBangKePhieuNhap.Id = 251;
            this.btnBangKePhieuNhap.ImageOptions.ImageIndex = 18;
            this.btnBangKePhieuNhap.Name = "btnBangKePhieuNhap";
            this.btnBangKePhieuNhap.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnBangKePhieuNhap_ItemClick);
            // 
            // rptThongKeKhoaHang
            // 
            this.rptThongKeKhoaHang.Caption = "Bảng thông kê kho hàng";
            this.rptThongKeKhoaHang.Id = 252;
            this.rptThongKeKhoaHang.ImageOptions.ImageIndex = 18;
            this.rptThongKeKhoaHang.Name = "rptThongKeKhoaHang";
            this.rptThongKeKhoaHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.rptThongKeKhoaHang_ItemClick);
            // 
            // itemThueNganHanAdd
            // 
            this.itemThueNganHanAdd.Caption = "Thêm mới";
            this.itemThueNganHanAdd.Id = 253;
            this.itemThueNganHanAdd.ImageOptions.ImageIndex = 31;
            this.itemThueNganHanAdd.Name = "itemThueNganHanAdd";
            this.itemThueNganHanAdd.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThueNganHanAdd_ItemClick);
            // 
            // itemThueNganHan
            // 
            this.itemThueNganHan.Caption = "Danh sách";
            this.itemThueNganHan.Id = 254;
            this.itemThueNganHan.ImageOptions.ImageIndex = 40;
            this.itemThueNganHan.Name = "itemThueNganHan";
            this.itemThueNganHan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThueNganHan_ItemClick);
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "Hợp tác";
            this.barButtonItem3.Id = 258;
            this.barButtonItem3.Name = "barButtonItem3";
            // 
            // barButtonItem20
            // 
            this.barButtonItem20.Caption = "Dịch vụ khác";
            this.barButtonItem20.Id = 259;
            this.barButtonItem20.Name = "barButtonItem20";
            // 
            // barButtonItem21
            // 
            this.barButtonItem21.Caption = "barButtonItem21";
            this.barButtonItem21.Id = 260;
            this.barButtonItem21.Name = "barButtonItem21";
            // 
            // barButtonItem22
            // 
            this.barButtonItem22.Caption = "barButtonItem22";
            this.barButtonItem22.Id = 262;
            this.barButtonItem22.Name = "barButtonItem22";
            // 
            // btnLichThanhToanDien
            // 
            this.btnLichThanhToanDien.Caption = "Danh sách";
            this.btnLichThanhToanDien.Id = 266;
            this.btnLichThanhToanDien.ImageOptions.ImageIndex = 45;
            this.btnLichThanhToanDien.Name = "btnLichThanhToanDien";
            toolTipItem1.Text = "Danh sách lịch thanh toán với nhà cung cấp";
            superToolTip5.Items.Add(toolTipItem1);
            this.btnLichThanhToanDien.SuperTip = superToolTip5;
            this.btnLichThanhToanDien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnLichThanhToanDien_ItemClick);
            // 
            // btnThemLichThanhToanDien
            // 
            this.btnThemLichThanhToanDien.Caption = "Thêm mới";
            this.btnThemLichThanhToanDien.Id = 267;
            this.btnThemLichThanhToanDien.ImageOptions.ImageIndex = 0;
            this.btnThemLichThanhToanDien.Name = "btnThemLichThanhToanDien";
            toolTipItem2.Text = "Thêm mới lịch thanh toán";
            superToolTip6.Items.Add(toolTipItem2);
            this.btnThemLichThanhToanDien.SuperTip = superToolTip6;
            this.btnThemLichThanhToanDien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnThemLichThanhToanDien_ItemClick);
            // 
            // btnNgonNgu
            // 
            this.btnNgonNgu.Caption = "Ngôn ngữ";
            this.btnNgonNgu.Id = 268;
            this.btnNgonNgu.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_europe_filled_50px;
            this.btnNgonNgu.Name = "btnNgonNgu";
            this.btnNgonNgu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnNgonNgu_ItemClick);
            // 
            // btnAddThePhongTap
            // 
            this.btnAddThePhongTap.Caption = "Đăng ký";
            this.btnAddThePhongTap.Id = 269;
            this.btnAddThePhongTap.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btnAddThePhongTap.ImageOptions.LargeImage")));
            this.btnAddThePhongTap.ImageOptions.LargeImageIndex = 0;
            this.btnAddThePhongTap.Name = "btnAddThePhongTap";
            this.btnAddThePhongTap.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnAddThePhongTap_ItemClick);
            // 
            // btnQuanLyThePhongTap
            // 
            this.btnQuanLyThePhongTap.Caption = "Danh sách";
            this.btnQuanLyThePhongTap.Id = 270;
            this.btnQuanLyThePhongTap.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btnQuanLyThePhongTap.ImageOptions.LargeImage")));
            this.btnQuanLyThePhongTap.Name = "btnQuanLyThePhongTap";
            this.btnQuanLyThePhongTap.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnQuanLyThePhongTap_ItemClick);
            // 
            // btnLoaiThePhongTap
            // 
            this.btnLoaiThePhongTap.Caption = "Các loại thẻ phòng tập";
            this.btnLoaiThePhongTap.Id = 271;
            this.btnLoaiThePhongTap.ImageOptions.ImageIndex = 45;
            this.btnLoaiThePhongTap.Name = "btnLoaiThePhongTap";
            this.btnLoaiThePhongTap.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnLoaiThePhongTap_ItemClick);
            // 
            // btnVietPhieuThu
            // 
            this.btnVietPhieuThu.Caption = "Viết phiếu thu";
            this.btnVietPhieuThu.Id = 272;
            this.btnVietPhieuThu.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.add_32;
            this.btnVietPhieuThu.Name = "btnVietPhieuThu";
            this.btnVietPhieuThu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnVietPhieuThu_ItemClick);
            // 
            // btnVietPhieuChi
            // 
            this.btnVietPhieuChi.Caption = "Viết phiếu chi";
            this.btnVietPhieuChi.Id = 273;
            this.btnVietPhieuChi.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.add_32;
            this.btnVietPhieuChi.Name = "btnVietPhieuChi";
            this.btnVietPhieuChi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnVietPhieuChi_ItemClick);
            // 
            // btnHoaDonGiayBao
            // 
            this.btnHoaDonGiayBao.Caption = "Hóa đơn / Giấy báo";
            this.btnHoaDonGiayBao.Id = 274;
            this.btnHoaDonGiayBao.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btnHoaDonGiayBao.ImageOptions.LargeImage")));
            this.btnHoaDonGiayBao.Name = "btnHoaDonGiayBao";
            this.btnHoaDonGiayBao.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnHoaDonGiayBao_ItemClick);
            // 
            // btnKhachHangBaoCao
            // 
            this.btnKhachHangBaoCao.Caption = "BC Khách hàng";
            this.btnKhachHangBaoCao.Id = 275;
            this.btnKhachHangBaoCao.ImageOptions.ImageIndex = 12;
            this.btnKhachHangBaoCao.Name = "btnKhachHangBaoCao";
            this.btnKhachHangBaoCao.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnKhachHangBaoCao_ItemClick);
            // 
            // btnGiuXe
            // 
            this.btnGiuXe.Caption = "BC thẻ xe";
            this.btnGiuXe.Id = 276;
            this.btnGiuXe.ImageOptions.ImageIndex = 12;
            this.btnGiuXe.Name = "btnGiuXe";
            this.btnGiuXe.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.btnGiuXe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnGiuXe_ItemClick);
            // 
            // btnTieuThuDien
            // 
            this.btnTieuThuDien.Caption = "Công nợ";
            this.btnTieuThuDien.Id = 277;
            this.btnTieuThuDien.Name = "btnTieuThuDien";
            this.btnTieuThuDien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnTieuThuDien_ItemClick);
            // 
            // btnTieuThuNuoc
            // 
            this.btnTieuThuNuoc.Caption = "Tiêu thụ nước";
            this.btnTieuThuNuoc.Id = 278;
            this.btnTieuThuNuoc.ImageOptions.ImageIndex = 12;
            this.btnTieuThuNuoc.Name = "btnTieuThuNuoc";
            this.btnTieuThuNuoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnTieuThuNuoc_ItemClick);
            // 
            // btnThongKeTieuThuDienNuoc
            // 
            this.btnThongKeTieuThuDienNuoc.Caption = "Tiêu thụ tổng điện nước";
            this.btnThongKeTieuThuDienNuoc.Id = 279;
            this.btnThongKeTieuThuDienNuoc.ImageOptions.ImageIndex = 12;
            this.btnThongKeTieuThuDienNuoc.Name = "btnThongKeTieuThuDienNuoc";
            this.btnThongKeTieuThuDienNuoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnThongKeTieuThuDienNuoc_ItemClick);
            // 
            // btnDeXuatAdd
            // 
            this.btnDeXuatAdd.Id = 765;
            this.btnDeXuatAdd.Name = "btnDeXuatAdd";
            // 
            // btnDeXuatManager
            // 
            this.btnDeXuatManager.Id = 766;
            this.btnDeXuatManager.Name = "btnDeXuatManager";
            // 
            // btnMuaHangAdd
            // 
            this.btnMuaHangAdd.Id = 767;
            this.btnMuaHangAdd.Name = "btnMuaHangAdd";
            // 
            // btnMuaHangManager
            // 
            this.btnMuaHangManager.Id = 768;
            this.btnMuaHangManager.Name = "btnMuaHangManager";
            // 
            // btnBaoGiaAdd
            // 
            this.btnBaoGiaAdd.Id = 769;
            this.btnBaoGiaAdd.Name = "btnBaoGiaAdd";
            // 
            // btnBaoGiaManager
            // 
            this.btnBaoGiaManager.Id = 770;
            this.btnBaoGiaManager.Name = "btnBaoGiaManager";
            // 
            // btnGas
            // 
            this.btnGas.Caption = "Gas";
            this.btnGas.Id = 286;
            this.btnGas.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_gas;
            this.btnGas.Name = "btnGas";
            this.btnGas.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnGas_ItemClick);
            // 
            // btnSupport
            // 
            this.btnSupport.Caption = "My support";
            this.btnSupport.Id = 288;
            this.btnSupport.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_ho_tro;
            this.btnSupport.Name = "btnSupport";
            this.btnSupport.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.btnSupport.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnSupport_ItemClick);
            // 
            // btnPhiKhac
            // 
            this.btnPhiKhac.Caption = "Phí dịch vụ";
            this.btnPhiKhac.Id = 289;
            this.btnPhiKhac.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.cost;
            this.btnPhiKhac.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btnPhiQuanLy),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnPhiVeSinh, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemPhiBaoTri, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDKThanhToan)});
            this.btnPhiKhac.Name = "btnPhiKhac";
            // 
            // btnPhiVeSinh
            // 
            this.btnPhiVeSinh.Caption = "Phí vệ sinh";
            this.btnPhiVeSinh.Id = 290;
            this.btnPhiVeSinh.ImageOptions.ImageIndex = 45;
            this.btnPhiVeSinh.Name = "btnPhiVeSinh";
            this.btnPhiVeSinh.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.btnPhiVeSinh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnPhiVeSinh_ItemClick);
            // 
            // itemPhiBaoTri
            // 
            this.itemPhiBaoTri.Caption = "Phí bảo trì";
            this.itemPhiBaoTri.Id = 364;
            this.itemPhiBaoTri.ImageOptions.ImageIndex = 45;
            this.itemPhiBaoTri.Name = "itemPhiBaoTri";
            this.itemPhiBaoTri.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemPhiBaoTri.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhiBaoTri_ItemClick);
            // 
            // itemDKThanhToan
            // 
            this.itemDKThanhToan.Caption = "Đăng ký thanh toán";
            this.itemDKThanhToan.Id = 428;
            this.itemDKThanhToan.ImageOptions.ImageIndex = 45;
            this.itemDKThanhToan.Name = "itemDKThanhToan";
            this.itemDKThanhToan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDKThanhToan_ItemClick);
            // 
            // btnChietKhauPQL
            // 
            this.btnChietKhauPQL.Caption = "Tỉ lệ chiết khấu thanh toán PQL";
            this.btnChietKhauPQL.Id = 291;
            this.btnChietKhauPQL.ImageOptions.ImageIndex = 45;
            this.btnChietKhauPQL.Name = "btnChietKhauPQL";
            this.btnChietKhauPQL.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnChietKhauPQL_ItemClick);
            // 
            // itemTongHopDNG
            // 
            this.itemTongHopDNG.Caption = "Tổng hợp";
            this.itemTongHopDNG.Id = 292;
            this.itemTongHopDNG.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemTongHopDNG.ImageOptions.LargeImage")));
            this.itemTongHopDNG.Name = "itemTongHopDNG";
            this.itemTongHopDNG.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemTongHopDNG.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTongHopDNG_ItemClick);
            // 
            // itemSettingPQL
            // 
            this.itemSettingPQL.Caption = "Cài đặt Phí quản lý";
            this.itemSettingPQL.Id = 294;
            this.itemSettingPQL.ImageOptions.ImageIndex = 45;
            this.itemSettingPQL.Name = "itemSettingPQL";
            this.itemSettingPQL.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemSettingPQL_ItemClick);
            // 
            // itemSettingTheXe
            // 
            this.itemSettingTheXe.Caption = "Cài đặt Thẻ xe";
            this.itemSettingTheXe.Id = 295;
            this.itemSettingTheXe.ImageOptions.ImageIndex = 45;
            this.itemSettingTheXe.Name = "itemSettingTheXe";
            // 
            // itemSetupPhiChoThue
            // 
            this.itemSetupPhiChoThue.Caption = "Cài đặt phí cho thuê";
            this.itemSetupPhiChoThue.Id = 296;
            this.itemSetupPhiChoThue.ImageOptions.ImageIndex = 45;
            this.itemSetupPhiChoThue.Name = "itemSetupPhiChoThue";
            this.itemSetupPhiChoThue.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemSetupPhiChoThue_ItemClick);
            // 
            // itemAddProvider
            // 
            this.itemAddProvider.Caption = "Thêm mới";
            this.itemAddProvider.Id = 297;
            this.itemAddProvider.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.add_tag48;
            this.itemAddProvider.Name = "itemAddProvider";
            this.itemAddProvider.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemAddProvider_ItemClick);
            // 
            // itemListProvider
            // 
            this.itemListProvider.Caption = "Danh sách";
            this.itemListProvider.Id = 298;
            this.itemListProvider.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.suppliers;
            this.itemListProvider.Name = "itemListProvider";
            this.itemListProvider.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemListProvider_ItemClick);
            // 
            // navSetupTheXe
            // 
            this.navSetupTheXe.Caption = "Thẻ xe";
            this.navSetupTheXe.Id = 304;
            this.navSetupTheXe.ImageOptions.ImageIndex = 45;
            this.navSetupTheXe.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDMChuKy),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemSettingTheXe),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnTrangThaiTheXe)});
            this.navSetupTheXe.Name = "navSetupTheXe";
            // 
            // itemDMChuKy
            // 
            this.itemDMChuKy.Caption = "Định mức xe theo chu kỳ";
            this.itemDMChuKy.Id = 312;
            this.itemDMChuKy.ImageOptions.ImageIndex = 45;
            this.itemDMChuKy.Name = "itemDMChuKy";
            // 
            // navCaiDatPVS
            // 
            this.navCaiDatPVS.Caption = "Phí quản lý và phí vệ sinh";
            this.navCaiDatPVS.Id = 305;
            this.navCaiDatPVS.ImageOptions.ImageIndex = 45;
            this.navCaiDatPVS.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemSettingPQL),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnChietKhauPQL)});
            this.navCaiDatPVS.Name = "navCaiDatPVS";
            // 
            // ribbonGalleryBarItem1
            // 
            this.ribbonGalleryBarItem1.Caption = "ribbonGalleryBarItem1";
            this.ribbonGalleryBarItem1.Id = 306;
            this.ribbonGalleryBarItem1.Name = "ribbonGalleryBarItem1";
            // 
            // ribbonGalleryBarItem2
            // 
            this.ribbonGalleryBarItem2.Caption = "ribbonGalleryBarItem2";
            // 
            // 
            // 
            galleryItemGroup1.Caption = "Group1";
            galleryItem1.Caption = "Item1";
            galleryItemGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            galleryItem1});
            this.ribbonGalleryBarItem2.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup1});
            this.ribbonGalleryBarItem2.Id = 307;
            this.ribbonGalleryBarItem2.Name = "ribbonGalleryBarItem2";
            // 
            // itemBCBangKeThuChi
            // 
            this.itemBCBangKeThuChi.Caption = "Bảng kê thu chi";
            this.itemBCBangKeThuChi.Id = 310;
            this.itemBCBangKeThuChi.ImageOptions.ImageIndex = 17;
            this.itemBCBangKeThuChi.Name = "itemBCBangKeThuChi";
            this.itemBCBangKeThuChi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCBangKeThuChi_ItemClick);
            // 
            // itemCustomerDeb
            // 
            this.itemCustomerDeb.Caption = "Customer Deb";
            this.itemCustomerDeb.Id = 311;
            this.itemCustomerDeb.ImageOptions.ImageIndex = 17;
            this.itemCustomerDeb.Name = "itemCustomerDeb";
            this.itemCustomerDeb.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCustomerDeb_ItemClick);
            // 
            // itemBCTieuThuGas
            // 
            this.itemBCTieuThuGas.Caption = "Công nợ";
            this.itemBCTieuThuGas.Id = 313;
            this.itemBCTieuThuGas.Name = "itemBCTieuThuGas";
            // 
            // itemBCGas
            // 
            this.itemBCGas.Caption = "Gas";
            this.itemBCGas.Id = 314;
            this.itemBCGas.ImageOptions.ImageIndex = 33;
            this.itemBCGas.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCTieuThuGas),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCGasChiTiet),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCGasPhieuThu),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCGasTTNam)});
            this.itemBCGas.Name = "itemBCGas";
            // 
            // itemBCGasChiTiet
            // 
            this.itemBCGasChiTiet.Caption = "Chi tiết tiêu thụ";
            this.itemBCGasChiTiet.Id = 318;
            this.itemBCGasChiTiet.Name = "itemBCGasChiTiet";
            this.itemBCGasChiTiet.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCGasChiTiet_ItemClick);
            // 
            // itemBCGasPhieuThu
            // 
            this.itemBCGasPhieuThu.Caption = "Phiếu thu";
            this.itemBCGasPhieuThu.Id = 322;
            this.itemBCGasPhieuThu.Name = "itemBCGasPhieuThu";
            this.itemBCGasPhieuThu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCGasPhieuThu_ItemClick);
            // 
            // itemBCGasTTNam
            // 
            this.itemBCGasTTNam.Caption = "Tiêu thụ năm";
            this.itemBCGasTTNam.Id = 333;
            this.itemBCGasTTNam.Name = "itemBCGasTTNam";
            this.itemBCGasTTNam.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCGasTTNam_ItemClick);
            // 
            // itenBCNuoc
            // 
            this.itenBCNuoc.Caption = "Nước";
            this.itenBCNuoc.Id = 315;
            this.itenBCNuoc.ImageOptions.ImageIndex = 33;
            this.itenBCNuoc.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCTieuThuNuoc),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCNuocChiTiet),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCNuocPhieuThu),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCNuocTTNam)});
            this.itenBCNuoc.Name = "itenBCNuoc";
            // 
            // itemBCTieuThuNuoc
            // 
            this.itemBCTieuThuNuoc.Caption = "Công nợ";
            this.itemBCTieuThuNuoc.Id = 317;
            this.itemBCTieuThuNuoc.Name = "itemBCTieuThuNuoc";
            // 
            // itemBCNuocChiTiet
            // 
            this.itemBCNuocChiTiet.Caption = "Chi tiết tiêu thụ";
            this.itemBCNuocChiTiet.Id = 319;
            this.itemBCNuocChiTiet.Name = "itemBCNuocChiTiet";
            // 
            // itemBCNuocPhieuThu
            // 
            this.itemBCNuocPhieuThu.Caption = "Phiếu thu";
            this.itemBCNuocPhieuThu.Id = 323;
            this.itemBCNuocPhieuThu.Name = "itemBCNuocPhieuThu";
            this.itemBCNuocPhieuThu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCNuocPhieuThu_ItemClick);
            // 
            // itemBCNuocTTNam
            // 
            this.itemBCNuocTTNam.Caption = "Tiêu thu năm";
            this.itemBCNuocTTNam.Id = 334;
            this.itemBCNuocTTNam.Name = "itemBCNuocTTNam";
            this.itemBCNuocTTNam.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCNuocTTNam_ItemClick);
            // 
            // itemBCDien
            // 
            this.itemBCDien.Caption = "Điện";
            this.itemBCDien.Id = 316;
            this.itemBCDien.ImageOptions.ImageIndex = 33;
            this.itemBCDien.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btnTieuThuDien),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCDienChiTiet),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCDienTTNam)});
            this.itemBCDien.Name = "itemBCDien";
            // 
            // itemBCDienChiTiet
            // 
            this.itemBCDienChiTiet.Caption = "Chi tiết tiêu thụ";
            this.itemBCDienChiTiet.Id = 320;
            this.itemBCDienChiTiet.Name = "itemBCDienChiTiet";
            this.itemBCDienChiTiet.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCDienChiTiet_ItemClick);
            // 
            // itemBCDienTTNam
            // 
            this.itemBCDienTTNam.Caption = "Tiêu thụ năm";
            this.itemBCDienTTNam.Id = 335;
            this.itemBCDienTTNam.Name = "itemBCDienTTNam";
            this.itemBCDienTTNam.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCDienTTNam_ItemClick);
            // 
            // itemBCDSGasNuoc
            // 
            this.itemBCDSGasNuoc.Caption = "Danh sách gas - nước";
            this.itemBCDSGasNuoc.Id = 321;
            this.itemBCDSGasNuoc.ImageOptions.ImageIndex = 12;
            this.itemBCDSGasNuoc.Name = "itemBCDSGasNuoc";
            this.itemBCDSGasNuoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCDSGasNuoc_ItemClick);
            // 
            // itemBCPhatSinhPQL
            // 
            this.itemBCPhatSinhPQL.Caption = "Chi tiết phát sinh";
            this.itemBCPhatSinhPQL.Id = 324;
            this.itemBCPhatSinhPQL.Name = "itemBCPhatSinhPQL";
            this.itemBCPhatSinhPQL.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCPhatSinhPQL_ItemClick);
            // 
            // itemBCTongHopThu
            // 
            this.itemBCTongHopThu.Caption = "Tổng hợp đã thu";
            this.itemBCTongHopThu.Id = 325;
            this.itemBCTongHopThu.ImageOptions.ImageIndex = 12;
            this.itemBCTongHopThu.Name = "itemBCTongHopThu";
            this.itemBCTongHopThu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCTongHopThu_ItemClick);
            // 
            // itemBCTongPhaiThu
            // 
            this.itemBCTongPhaiThu.Caption = "Tổng hợp phải thu";
            this.itemBCTongPhaiThu.Id = 326;
            this.itemBCTongPhaiThu.ImageOptions.ImageIndex = 12;
            this.itemBCTongPhaiThu.Name = "itemBCTongPhaiThu";
            this.itemBCTongPhaiThu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCTongPhaiThu_ItemClick);
            // 
            // itemBCTongHopChuaThu
            // 
            this.itemBCTongHopChuaThu.Caption = "Tổng hợp chưa thu";
            this.itemBCTongHopChuaThu.Id = 327;
            this.itemBCTongHopChuaThu.ImageOptions.ImageIndex = 12;
            this.itemBCTongHopChuaThu.Name = "itemBCTongHopChuaThu";
            this.itemBCTongHopChuaThu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCTongHopChuaThu_ItemClick);
            // 
            // itemBCDoanhThuTheoNgay
            // 
            this.itemBCDoanhThuTheoNgay.Caption = "Doanh thu theo ngày";
            this.itemBCDoanhThuTheoNgay.Id = 328;
            this.itemBCDoanhThuTheoNgay.ImageOptions.ImageIndex = 12;
            this.itemBCDoanhThuTheoNgay.Name = "itemBCDoanhThuTheoNgay";
            this.itemBCDoanhThuTheoNgay.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCDoanhThuTheoNgay_ItemClick);
            // 
            // itemBCPhiQuanLy
            // 
            this.itemBCPhiQuanLy.Caption = "Phí quản lý";
            this.itemBCPhiQuanLy.Id = 329;
            this.itemBCPhiQuanLy.ImageOptions.ImageIndex = 33;
            this.itemBCPhiQuanLy.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCPhatSinhPQL),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCPQLBangThuPhi),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCPQL_PhieuThu),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemPhieuTHuPVS)});
            this.itemBCPhiQuanLy.Name = "itemBCPhiQuanLy";
            // 
            // itemBCPQLBangThuPhi
            // 
            this.itemBCPQLBangThuPhi.Caption = "Bảng thu phí";
            this.itemBCPQLBangThuPhi.Id = 330;
            this.itemBCPQLBangThuPhi.Name = "itemBCPQLBangThuPhi";
            this.itemBCPQLBangThuPhi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCPQLBangThuPhi_ItemClick);
            // 
            // itemBCPQL_PhieuThu
            // 
            this.itemBCPQL_PhieuThu.Caption = "Phiếu thu";
            this.itemBCPQL_PhieuThu.Id = 337;
            this.itemBCPQL_PhieuThu.Name = "itemBCPQL_PhieuThu";
            this.itemBCPQL_PhieuThu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCPQL_PhieuThu_ItemClick);
            // 
            // itemPhieuTHuPVS
            // 
            this.itemPhieuTHuPVS.Caption = "Phiếu thu phí vệ sinh";
            this.itemPhieuTHuPVS.Id = 341;
            this.itemPhieuTHuPVS.Name = "itemPhieuTHuPVS";
            this.itemPhieuTHuPVS.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhieuTHuPVS_ItemClick);
            // 
            // itemBCPQLChiTietPhatSinh
            // 
            this.itemBCPQLChiTietPhatSinh.Caption = "Chi tiết phát sinh";
            this.itemBCPQLChiTietPhatSinh.Id = 331;
            this.itemBCPQLChiTietPhatSinh.Name = "itemBCPQLChiTietPhatSinh";
            this.itemBCPQLChiTietPhatSinh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCPQLChiTietPhatSinh_ItemClick);
            // 
            // itemBCLuyKeNam
            // 
            this.itemBCLuyKeNam.Caption = "Bảng kê lũy kế năm";
            this.itemBCLuyKeNam.Id = 332;
            this.itemBCLuyKeNam.ImageOptions.ImageIndex = 17;
            this.itemBCLuyKeNam.Name = "itemBCLuyKeNam";
            this.itemBCLuyKeNam.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCLuyKeNam_ItemClick);
            // 
            // itemNgungCungCapDV
            // 
            this.itemNgungCungCapDV.Caption = "Ngưng CCDV";
            this.itemNgungCungCapDV.Id = 336;
            this.itemNgungCungCapDV.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.stop;
            this.itemNgungCungCapDV.Name = "itemNgungCungCapDV";
            toolTipItem3.Text = "Ngưng cung cấp dịch vụ";
            superToolTip7.Items.Add(toolTipItem3);
            this.itemNgungCungCapDV.SuperTip = superToolTip7;
            this.itemNgungCungCapDV.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemNgungCungCapDV.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNgungCungCapDV_ItemClick);
            // 
            // itemKhoaSoAdd
            // 
            this.itemKhoaSoAdd.Caption = "Thêm mới";
            this.itemKhoaSoAdd.Id = 338;
            this.itemKhoaSoAdd.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.add_tag48;
            this.itemKhoaSoAdd.Name = "itemKhoaSoAdd";
            this.itemKhoaSoAdd.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKhoaSoAdd_ItemClick);
            // 
            // itemKhoaSoList
            // 
            this.itemKhoaSoList.Caption = "Danh sách";
            this.itemKhoaSoList.Id = 340;
            this.itemKhoaSoList.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.key_basic_yellow;
            this.itemKhoaSoList.Name = "itemKhoaSoList";
            this.itemKhoaSoList.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKhoaSoList_ItemClick);
            // 
            // subBCTheXe
            // 
            this.subBCTheXe.Caption = "Thẻ xe";
            this.subBCTheXe.Id = 342;
            this.subBCTheXe.ImageOptions.ImageIndex = 33;
            this.subBCTheXe.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btnGiuXe),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCTX_DanhSachDangKy),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCTX_ChiTietPhatSinh),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCTX_PhieuThu),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCTX_ChuaThanhToan)});
            this.subBCTheXe.Name = "subBCTheXe";
            // 
            // itemBCTX_DanhSachDangKy
            // 
            this.itemBCTX_DanhSachDangKy.Caption = "Danh sách khách hàng đăng ký xe";
            this.itemBCTX_DanhSachDangKy.Id = 343;
            this.itemBCTX_DanhSachDangKy.Name = "itemBCTX_DanhSachDangKy";
            this.itemBCTX_DanhSachDangKy.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCTX_DanhSachDangKy_ItemClick);
            // 
            // itemBCTX_ChiTietPhatSinh
            // 
            this.itemBCTX_ChiTietPhatSinh.Caption = "Chi tiết phát sinh";
            this.itemBCTX_ChiTietPhatSinh.Id = 344;
            this.itemBCTX_ChiTietPhatSinh.Name = "itemBCTX_ChiTietPhatSinh";
            this.itemBCTX_ChiTietPhatSinh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCTX_ChiTietPhatSinh_ItemClick);
            // 
            // itemBCTX_PhieuThu
            // 
            this.itemBCTX_PhieuThu.Caption = "Phiếu thu";
            this.itemBCTX_PhieuThu.Id = 345;
            this.itemBCTX_PhieuThu.Name = "itemBCTX_PhieuThu";
            this.itemBCTX_PhieuThu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCTX_PhieuThu_ItemClick);
            // 
            // itemBCTX_ChuaThanhToan
            // 
            this.itemBCTX_ChuaThanhToan.Caption = "Khách hàng chưa thanh toán";
            this.itemBCTX_ChuaThanhToan.Id = 346;
            this.itemBCTX_ChuaThanhToan.Name = "itemBCTX_ChuaThanhToan";
            this.itemBCTX_ChuaThanhToan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCTX_ChuaThanhToan_ItemClick);
            // 
            // itemTXList
            // 
            this.itemTXList.Caption = "Thẻ xe";
            this.itemTXList.Id = 347;
            this.itemTXList.Name = "itemTXList";
            this.itemTXList.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTXList_ItemClick);
            // 
            // itemTXDoiChuThe
            // 
            this.itemTXDoiChuThe.Caption = "Đổi chủ thẻ";
            this.itemTXDoiChuThe.Id = 348;
            this.itemTXDoiChuThe.Name = "itemTXDoiChuThe";
            // 
            // itemTXGiaHan
            // 
            this.itemTXGiaHan.Caption = "Gia hạn thẻ";
            this.itemTXGiaHan.Id = 349;
            this.itemTXGiaHan.Name = "itemTXGiaHan";
            // 
            // itemTXHetHan
            // 
            this.itemTXHetHan.Caption = "Thẻ sắp hết hạn";
            this.itemTXHetHan.Id = 350;
            this.itemTXHetHan.Name = "itemTXHetHan";
            // 
            // itemTXDangKy
            // 
            this.itemTXDangKy.Caption = "Đăng ký gửi xe";
            this.itemTXDangKy.Id = 351;
            this.itemTXDangKy.Name = "itemTXDangKy";
            // 
            // itemTXCongNo
            // 
            this.itemTXCongNo.Caption = "Công nợ";
            this.itemTXCongNo.Id = 352;
            this.itemTXCongNo.Name = "itemTXCongNo";
            // 
            // itemConfigFTP
            // 
            this.itemConfigFTP.Caption = "Cấu hình FTP";
            this.itemConfigFTP.Id = 353;
            this.itemConfigFTP.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_wifi_lock_filled_50px;
            this.itemConfigFTP.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_wifi_lock_filled_50px1;
            this.itemConfigFTP.Name = "itemConfigFTP";
            this.itemConfigFTP.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemConfigFTP_ItemClick);
            // 
            // itemDKUuDai_Add
            // 
            this.itemDKUuDai_Add.Caption = "Thêm mới";
            this.itemDKUuDai_Add.Id = 354;
            this.itemDKUuDai_Add.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.add_tag48;
            this.itemDKUuDai_Add.Name = "itemDKUuDai_Add";
            this.itemDKUuDai_Add.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDKUuDai_Add_ItemClick);
            // 
            // itemDKUuDai_List
            // 
            this.itemDKUuDai_List.Caption = "Danh sách";
            this.itemDKUuDai_List.Id = 355;
            this.itemDKUuDai_List.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.tag_64;
            this.itemDKUuDai_List.Name = "itemDKUuDai_List";
            this.itemDKUuDai_List.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDKUuDai_List_ItemClick);
            // 
            // itemHoBoi_add
            // 
            this.itemHoBoi_add.Caption = "Thêm mới";
            this.itemHoBoi_add.Id = 356;
            this.itemHoBoi_add.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.add_tag48;
            this.itemHoBoi_add.Name = "itemHoBoi_add";
            // 
            // itemHoBoi_list
            // 
            this.itemHoBoi_list.Caption = "Danh sách";
            this.itemHoBoi_list.Id = 357;
            this.itemHoBoi_list.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.Swimming_Pool;
            this.itemHoBoi_list.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemHoBoiThe_list),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemHoBoiCongNo),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemHoiBoiLoaiThe, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemHoBoiDinhMuc)});
            this.itemHoBoi_list.Name = "itemHoBoi_list";
            // 
            // itemHoBoiThe_list
            // 
            this.itemHoBoiThe_list.Caption = "Thẻ bơi";
            this.itemHoBoiThe_list.Id = 358;
            this.itemHoBoiThe_list.Name = "itemHoBoiThe_list";
            this.itemHoBoiThe_list.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHoBoiThe_list_ItemClick);
            // 
            // itemHoBoiCongNo
            // 
            this.itemHoBoiCongNo.Caption = "Công nợ";
            this.itemHoBoiCongNo.Id = 359;
            this.itemHoBoiCongNo.Name = "itemHoBoiCongNo";
            this.itemHoBoiCongNo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHoBoiCongNo_ItemClick);
            // 
            // itemHoiBoiLoaiThe
            // 
            this.itemHoiBoiLoaiThe.Caption = "Loại thẻ";
            this.itemHoiBoiLoaiThe.Id = 361;
            this.itemHoiBoiLoaiThe.Name = "itemHoiBoiLoaiThe";
            this.itemHoiBoiLoaiThe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHoiBoiLoaiThe_ItemClick);
            // 
            // itemHoBoiDinhMuc
            // 
            this.itemHoBoiDinhMuc.Caption = "Định mức thẻ";
            this.itemHoBoiDinhMuc.Id = 360;
            this.itemHoBoiDinhMuc.Name = "itemHoBoiDinhMuc";
            this.itemHoBoiDinhMuc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHoBoiDinhMuc_ItemClick);
            // 
            // itemCaiDatTTCanhBao
            // 
            this.itemCaiDatTTCanhBao.Caption = "Cài đặt tình trạng cảnh báo";
            this.itemCaiDatTTCanhBao.Id = 363;
            this.itemCaiDatTTCanhBao.ImageOptions.ImageIndex = 45;
            this.itemCaiDatTTCanhBao.Name = "itemCaiDatTTCanhBao";
            this.itemCaiDatTTCanhBao.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCaiDatTTCanhBao_ItemClick);
            // 
            // itemThemGhiTang
            // 
            this.itemThemGhiTang.Id = 771;
            this.itemThemGhiTang.Name = "itemThemGhiTang";
            // 
            // itemDSGhiTang
            // 
            this.itemDSGhiTang.Id = 772;
            this.itemDSGhiTang.Name = "itemDSGhiTang";
            // 
            // itemThemDGL
            // 
            this.itemThemDGL.Id = 773;
            this.itemThemDGL.Name = "itemThemDGL";
            // 
            // itemDSDanhGiaLai
            // 
            this.itemDSDanhGiaLai.Id = 774;
            this.itemDSDanhGiaLai.Name = "itemDSDanhGiaLai";
            // 
            // itemThemDC
            // 
            this.itemThemDC.Id = 775;
            this.itemThemDC.Name = "itemThemDC";
            // 
            // itemDSDieuChuyen
            // 
            this.itemDSDieuChuyen.Id = 776;
            this.itemDSDieuChuyen.Name = "itemDSDieuChuyen";
            // 
            // itemThemGhiGiam
            // 
            this.itemThemGhiGiam.Id = 777;
            this.itemThemGhiGiam.Name = "itemThemGhiGiam";
            // 
            // itemDSGhiGiam
            // 
            this.itemDSGhiGiam.Id = 778;
            this.itemDSGhiGiam.Name = "itemDSGhiGiam";
            // 
            // itemTinhKH
            // 
            this.itemTinhKH.Id = 779;
            this.itemTinhKH.Name = "itemTinhKH";
            // 
            // itemDSKhauHao
            // 
            this.itemDSKhauHao.Id = 780;
            this.itemDSKhauHao.Name = "itemDSKhauHao";
            // 
            // itemThemThongKe
            // 
            this.itemThemThongKe.Id = 781;
            this.itemThemThongKe.Name = "itemThemThongKe";
            // 
            // itemDSThognKe
            // 
            this.itemDSThognKe.Id = 782;
            this.itemDSThognKe.Name = "itemDSThognKe";
            // 
            // itemThemBC
            // 
            this.itemThemBC.Id = 783;
            this.itemThemBC.Name = "itemThemBC";
            // 
            // itemDSBaoCao
            // 
            this.itemDSBaoCao.Caption = "Thẻ tài sản";
            this.itemDSBaoCao.Id = 379;
            this.itemDSBaoCao.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.tag_64;
            this.itemDSBaoCao.Name = "itemDSBaoCao";
            // 
            // itemDSCVLuoi
            // 
            this.itemDSCVLuoi.Caption = "Danh sách dạng lưới";
            this.itemDSCVLuoi.Id = 380;
            this.itemDSCVLuoi.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.add_32;
            this.itemDSCVLuoi.Name = "itemDSCVLuoi";
            this.itemDSCVLuoi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDSCVLuoi_ItemClick);
            // 
            // itemDSCVLich
            // 
            this.itemDSCVLich.Caption = "Danh sách dạng lịch";
            this.itemDSCVLich.Id = 381;
            this.itemDSCVLich.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.scheduler;
            this.itemDSCVLich.Name = "itemDSCVLich";
            this.itemDSCVLich.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDSCVLich_ItemClick);
            // 
            // itemDSCongViecDG
            // 
            this.itemDSCongViecDG.Caption = "Công việc được giao";
            this.itemDSCongViecDG.Id = 382;
            this.itemDSCongViecDG.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.service;
            this.itemDSCongViecDG.Name = "itemDSCongViecDG";
            this.itemDSCongViecDG.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDSCongViecDG_ItemClick);
            // 
            // itemDSCVDGLich
            // 
            this.itemDSCVDGLich.Caption = "Danh sách dạng lịch";
            this.itemDSCVDGLich.Id = 383;
            this.itemDSCVDGLich.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.scheduler;
            this.itemDSCVDGLich.Name = "itemDSCVDGLich";
            this.itemDSCVDGLich.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDSCVDGLich_ItemClick);
            // 
            // itemTyGiaTN
            // 
            this.itemTyGiaTN.Caption = "Tỷ giá";
            this.itemTyGiaTN.Id = 386;
            this.itemTyGiaTN.ImageOptions.ImageIndex = 45;
            this.itemTyGiaTN.Name = "itemTyGiaTN";
            // 
            // itemTNTyGia
            // 
            this.itemTNTyGia.Caption = "Tỷ giá ngoại tệ";
            this.itemTNTyGia.Id = 387;
            this.itemTNTyGia.ImageOptions.ImageIndex = 45;
            this.itemTNTyGia.Name = "itemTNTyGia";
            this.itemTNTyGia.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTNTyGia_ItemClick);
            // 
            // itemNHThem
            // 
            this.itemNHThem.Caption = "Thêm mới";
            this.itemNHThem.Id = 393;
            this.itemNHThem.ImageOptions.ImageIndex = 0;
            this.itemNHThem.Name = "itemNHThem";
            // 
            // itemNHCongNo
            // 
            this.itemNHCongNo.Caption = "Công nợ";
            this.itemNHCongNo.Id = 396;
            this.itemNHCongNo.ImageOptions.ImageIndex = 17;
            this.itemNHCongNo.Name = "itemNHCongNo";
            // 
            // itemMayDieuHoa
            // 
            this.itemMayDieuHoa.Caption = "Máy điều hòa";
            this.itemMayDieuHoa.Id = 397;
            this.itemMayDieuHoa.ImageOptions.ImageIndex = 45;
            this.itemMayDieuHoa.Name = "itemMayDieuHoa";
            this.itemMayDieuHoa.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemMayDieuHoa_ItemClick);
            // 
            // itemThemDHNG
            // 
            this.itemThemDHNG.Caption = "Thêm mới chỉ số";
            this.itemThemDHNG.Id = 399;
            this.itemThemDHNG.ImageOptions.ImageIndex = 0;
            this.itemThemDHNG.Name = "itemThemDHNG";
            this.itemThemDHNG.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThemDHNG_ItemClick);
            // 
            // itemDSDHNG
            // 
            this.itemDSDHNG.Caption = "Điện điều hóa ngoài giờ";
            this.itemDSDHNG.Id = 400;
            this.itemDSDHNG.ImageOptions.ImageIndex = 72;
            this.itemDSDHNG.Name = "itemDSDHNG";
            this.itemDSDHNG.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDSDHNG_ItemClick);
            // 
            // itemCNDHNG
            // 
            this.itemCNDHNG.Caption = "Công nợ";
            this.itemCNDHNG.Id = 401;
            this.itemCNDHNG.ImageOptions.ImageIndex = 17;
            this.itemCNDHNG.Name = "itemCNDHNG";
            // 
            // itemBKThuPhiCC
            // 
            this.itemBKThuPhiCC.Caption = "BC CTM";
            this.itemBKThuPhiCC.Id = 402;
            this.itemBKThuPhiCC.ImageOptions.ImageIndex = 17;
            this.itemBKThuPhiCC.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBanCDPSCN),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBangKeCT),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem23),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem24),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemSoCTCN),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemKhoanThuHDT),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCCacKhoanPhiDV),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCCacKhoanTon),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBCTongHopCN),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDCChiTietCN)});
            this.itemBKThuPhiCC.Name = "itemBKThuPhiCC";
            // 
            // itemBanCDPSCN
            // 
            this.itemBanCDPSCN.Caption = "Bảng cân đối PS CN";
            this.itemBanCDPSCN.Id = 404;
            this.itemBanCDPSCN.Name = "itemBanCDPSCN";
            this.itemBanCDPSCN.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemBanCDPSCN.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBanCDPSCN_ItemClick);
            // 
            // itemBangKeCT
            // 
            this.itemBangKeCT.Caption = "Bảng kê chứng từ";
            this.itemBangKeCT.Id = 405;
            this.itemBangKeCT.Name = "itemBangKeCT";
            this.itemBangKeCT.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemBangKeCT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBangKeCT_ItemClick);
            // 
            // barButtonItem23
            // 
            this.barButtonItem23.Caption = "Bảng kê thu phí chung cư";
            this.barButtonItem23.Id = 406;
            this.barButtonItem23.Name = "barButtonItem23";
            this.barButtonItem23.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.barButtonItem23.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem23_ItemClick);
            // 
            // barButtonItem24
            // 
            this.barButtonItem24.Caption = "Bảng kê DS Hộ nợ phí chung cư";
            this.barButtonItem24.Id = 407;
            this.barButtonItem24.Name = "barButtonItem24";
            this.barButtonItem24.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.barButtonItem24.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem24_ItemClick);
            // 
            // itemSoCTCN
            // 
            this.itemSoCTCN.Caption = "Sổ chi tiết công nợ";
            this.itemSoCTCN.Id = 408;
            this.itemSoCTCN.Name = "itemSoCTCN";
            this.itemSoCTCN.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemSoCTCN.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemSoCTCN_ItemClick);
            // 
            // itemKhoanThuHDT
            // 
            this.itemKhoanThuHDT.Caption = "Các khoản thu theo hợp đồng thuê";
            this.itemKhoanThuHDT.Id = 409;
            this.itemKhoanThuHDT.Name = "itemKhoanThuHDT";
            this.itemKhoanThuHDT.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemKhoanThuHDT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKhoanThuHDT_ItemClick);
            // 
            // itemBCCacKhoanPhiDV
            // 
            this.itemBCCacKhoanPhiDV.Caption = "BC Các khoản thu phí dịch vụ";
            this.itemBCCacKhoanPhiDV.Id = 410;
            this.itemBCCacKhoanPhiDV.Name = "itemBCCacKhoanPhiDV";
            this.itemBCCacKhoanPhiDV.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemBCCacKhoanPhiDV.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCCacKhoanPhiDV_ItemClick);
            // 
            // itemBCCacKhoanTon
            // 
            this.itemBCCacKhoanTon.Caption = "BC Các khoản tồn đọng";
            this.itemBCCacKhoanTon.Id = 411;
            this.itemBCCacKhoanTon.Name = "itemBCCacKhoanTon";
            this.itemBCCacKhoanTon.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemBCCacKhoanTon.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCCacKhoanTon_ItemClick);
            // 
            // itemBCTongHopCN
            // 
            this.itemBCTongHopCN.Caption = "Tổng hợp công nợ";
            this.itemBCTongHopCN.Id = 414;
            this.itemBCTongHopCN.Name = "itemBCTongHopCN";
            this.itemBCTongHopCN.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBCTongHopCN_ItemClick);
            // 
            // itemDCChiTietCN
            // 
            this.itemDCChiTietCN.Caption = "Chi tiết công nợ";
            this.itemDCChiTietCN.Id = 416;
            this.itemDCChiTietCN.Name = "itemDCChiTietCN";
            this.itemDCChiTietCN.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDCChiTietCN_ItemClick);
            // 
            // itemLoaiHDTN
            // 
            this.itemLoaiHDTN.Caption = "Loại hợp đồng thuê ngoài";
            this.itemLoaiHDTN.Id = 413;
            this.itemLoaiHDTN.ImageOptions.ImageIndex = 45;
            this.itemLoaiHDTN.Name = "itemLoaiHDTN";
            this.itemLoaiHDTN.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLoaiHDTN_ItemClick);
            // 
            // itemTHemDVGS
            // 
            this.itemTHemDVGS.Caption = "Thêm mới";
            this.itemTHemDVGS.Id = 417;
            this.itemTHemDVGS.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.add_tag48;
            this.itemTHemDVGS.Name = "itemTHemDVGS";
            this.itemTHemDVGS.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTHemDVGS_ItemClick);
            // 
            // itemDSGS
            // 
            this.itemDSGS.Caption = "Danh sách";
            this.itemDSGS.Id = 418;
            this.itemDSGS.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.key_basic_yellow;
            this.itemDSGS.Name = "itemDSGS";
            this.itemDSGS.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDSGS_ItemClick);
            // 
            // itemLSDCCongNo
            // 
            this.itemLSDCCongNo.Caption = "Lịch sử điều chỉnh CN";
            this.itemLSDCCongNo.Id = 429;
            this.itemLSDCCongNo.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.History_Folder_Blue_icon;
            this.itemLSDCCongNo.Name = "itemLSDCCongNo";
            this.itemLSDCCongNo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLSDCCongNo_ItemClick);
            // 
            // itemHoaDonAdd
            // 
            this.itemHoaDonAdd.Caption = "Lập hóa đơn tự động";
            this.itemHoaDonAdd.Id = 435;
            this.itemHoaDonAdd.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_plus_filled_50px;
            this.itemHoaDonAdd.Name = "itemHoaDonAdd";
            this.itemHoaDonAdd.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHoaDonAdd_ItemClick);
            // 
            // barButtonItem26
            // 
            this.barButtonItem26.Caption = "Cài đặt lãi suất trễ hạn";
            this.barButtonItem26.Id = 444;
            this.barButtonItem26.Name = "barButtonItem26";
            // 
            // barButtonItem25
            // 
            this.barButtonItem25.Caption = "barButtonItem25";
            this.barButtonItem25.Id = 491;
            this.barButtonItem25.Name = "barButtonItem25";
            // 
            // itemTheXe
            // 
            this.itemTheXe.Caption = "Thẻ xe";
            this.itemTheXe.Id = 495;
            this.itemTheXe.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_bank_card_back_side_filled_50px;
            this.itemTheXe.ImageOptions.LargeImageIndex = 44;
            this.itemTheXe.Name = "itemTheXe";
            this.itemTheXe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTheXe_ItemClick);
            // 
            // itemDichVuKhacAdd
            // 
            this.itemDichVuKhacAdd.Caption = "Thêm mới";
            this.itemDichVuKhacAdd.Id = 500;
            this.itemDichVuKhacAdd.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_them;
            this.itemDichVuKhacAdd.ImageOptions.LargeImageIndex = 0;
            this.itemDichVuKhacAdd.Name = "itemDichVuKhacAdd";
            this.itemDichVuKhacAdd.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemDichVuKhacAdd.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDichVuKhacAdd_ItemClick);
            // 
            // itemReport_BaoCaoDatCoc
            // 
            this.itemReport_BaoCaoDatCoc.Caption = "Công nợ tiền đặt cọc";
            this.itemReport_BaoCaoDatCoc.Id = 505;
            this.itemReport_BaoCaoDatCoc.ImageOptions.ImageIndex = 73;
            this.itemReport_BaoCaoDatCoc.Name = "itemReport_BaoCaoDatCoc";
            this.itemReport_BaoCaoDatCoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemReport_BaoCaoDatCoc_ItemClick);
            // 
            // itemReport_HopDongChoThue
            // 
            this.itemReport_HopDongChoThue.Caption = "Hợp đồng cho thuê";
            this.itemReport_HopDongChoThue.Id = 506;
            this.itemReport_HopDongChoThue.ImageOptions.ImageIndex = 73;
            this.itemReport_HopDongChoThue.Name = "itemReport_HopDongChoThue";
            this.itemReport_HopDongChoThue.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemReport_HopDongChoThue_ItemClick);
            // 
            // itemRreport_DienDieuHoa
            // 
            this.itemRreport_DienDieuHoa.Caption = "Điện điều hòa";
            this.itemRreport_DienDieuHoa.Id = 509;
            this.itemRreport_DienDieuHoa.ImageOptions.ImageIndex = 73;
            this.itemRreport_DienDieuHoa.Name = "itemRreport_DienDieuHoa";
            // 
            // barButtonItem27
            // 
            this.barButtonItem27.Caption = "barButtonItem27";
            this.barButtonItem27.Id = 513;
            this.barButtonItem27.Name = "barButtonItem27";
            // 
            // itemDien3Pha
            // 
            this.itemDien3Pha.Caption = "Điện 3 pha";
            this.itemDien3Pha.Id = 516;
            this.itemDien3Pha.ImageOptions.ImageIndex = 72;
            this.itemDien3Pha.Name = "itemDien3Pha";
            this.itemDien3Pha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDien3Pha_ItemClick);
            // 
            // itemThanhLyChoThue
            // 
            this.itemThanhLyChoThue.Caption = "Thanh lý";
            this.itemThanhLyChoThue.Id = 518;
            this.itemThanhLyChoThue.ImageOptions.ImageIndex = 72;
            this.itemThanhLyChoThue.ImageOptions.LargeImageIndex = 10;
            this.itemThanhLyChoThue.Name = "itemThanhLyChoThue";
            this.itemThanhLyChoThue.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThanhLyChoThue_ItemClick);
            // 
            // itemChoThue_MatBang
            // 
            this.itemChoThue_MatBang.Caption = "Mặt bằng đang thuê";
            this.itemChoThue_MatBang.Id = 519;
            this.itemChoThue_MatBang.ImageOptions.ImageIndex = 72;
            this.itemChoThue_MatBang.ImageOptions.LargeImageIndex = 33;
            this.itemChoThue_MatBang.Name = "itemChoThue_MatBang";
            this.itemChoThue_MatBang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemChoThue_LTT_ItemClick);
            // 
            // itemBieuMau
            // 
            this.itemBieuMau.Caption = "Mẫu in, báo cáo";
            this.itemBieuMau.Id = 520;
            this.itemBieuMau.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_mau_in;
            this.itemBieuMau.ImageOptions.LargeImageIndex = 33;
            this.itemBieuMau.Name = "itemBieuMau";
            this.itemBieuMau.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBieuMau_ItemClick);
            // 
            // itemNhomMatBang
            // 
            this.itemNhomMatBang.Caption = "Nhóm mặt bằng";
            this.itemNhomMatBang.Id = 522;
            this.itemNhomMatBang.ImageOptions.ImageIndex = 45;
            this.itemNhomMatBang.Name = "itemNhomMatBang";
            // 
            // itemPhanNhomMatBang
            // 
            this.itemPhanNhomMatBang.Caption = "Phân nhóm căn hộ";
            this.itemPhanNhomMatBang.Id = 523;
            this.itemPhanNhomMatBang.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_can_ho;
            this.itemPhanNhomMatBang.ImageOptions.LargeImageIndex = 45;
            this.itemPhanNhomMatBang.Name = "itemPhanNhomMatBang";
            this.itemPhanNhomMatBang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhanNhomMatBang_ItemClick);
            // 
            // itemDienDongHo
            // 
            this.itemDienDongHo.Caption = "Đồng hồ điện";
            this.itemDienDongHo.Id = 524;
            this.itemDienDongHo.ImageOptions.ImageIndex = 45;
            this.itemDienDongHo.Name = "itemDienDongHo";
            this.itemDienDongHo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDienDongHo_ItemClick);
            // 
            // barCheckItem1
            // 
            this.barCheckItem1.Caption = "barCheckItem1";
            this.barCheckItem1.Id = 526;
            this.barCheckItem1.Name = "barCheckItem1";
            // 
            // itemPhieuThuAdd
            // 
            this.itemPhieuThuAdd.Caption = "Lập phiếu thu";
            this.itemPhieuThuAdd.Id = 528;
            this.itemPhieuThuAdd.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_them;
            this.itemPhieuThuAdd.ImageOptions.LargeImageIndex = 4;
            this.itemPhieuThuAdd.Name = "itemPhieuThuAdd";
            this.itemPhieuThuAdd.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemPhieuThuAdd.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhieuThuAdd_ItemClick);
            // 
            // itemPhieuThu
            // 
            this.itemPhieuThu.Caption = "Quản lý phiếu thu";
            this.itemPhieuThu.Id = 529;
            this.itemPhieuThu.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_request_money_filled_50px;
            this.itemPhieuThu.ImageOptions.LargeImageIndex = 16;
            this.itemPhieuThu.Name = "itemPhieuThu";
            this.itemPhieuThu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhieuThu_ItemClick);
            // 
            // itemPhieuChiAdd
            // 
            this.itemPhieuChiAdd.Caption = "Lập phiếu chi";
            this.itemPhieuChiAdd.Id = 530;
            this.itemPhieuChiAdd.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_them;
            this.itemPhieuChiAdd.ImageOptions.LargeImageIndex = 4;
            this.itemPhieuChiAdd.Name = "itemPhieuChiAdd";
            this.itemPhieuChiAdd.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemPhieuChiAdd.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhieuChiAdd_ItemClick);
            // 
            // itemPhieuChi
            // 
            this.itemPhieuChi.Caption = "Quản lý phiếu chi";
            this.itemPhieuChi.Id = 531;
            this.itemPhieuChi.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_initiate_money_transfer_filled_50px;
            this.itemPhieuChi.ImageOptions.LargeImageIndex = 16;
            this.itemPhieuChi.Name = "itemPhieuChi";
            this.itemPhieuChi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhieuChi_ItemClick);
            // 
            // itemKhauTruAdd
            // 
            this.itemKhauTruAdd.Caption = "Lập khấu trừ";
            this.itemKhauTruAdd.Id = 532;
            this.itemKhauTruAdd.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_them;
            this.itemKhauTruAdd.Name = "itemKhauTruAdd";
            this.itemKhauTruAdd.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemKhauTruAdd.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKhauTruAdd_ItemClick);
            // 
            // itemKhauTru
            // 
            this.itemKhauTru.Caption = "Quản lý khấu trừ";
            this.itemKhauTru.Id = 533;
            this.itemKhauTru.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_discount_filled_50px;
            this.itemKhauTru.Name = "itemKhauTru";
            this.itemKhauTru.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKhauTru_ItemClick);
            // 
            // itemDichVuThongKeKhac
            // 
            this.itemDichVuThongKeKhac.Caption = "Khác";
            this.itemDichVuThongKeKhac.Id = 534;
            this.itemDichVuThongKeKhac.ImageOptions.LargeImageIndex = 74;
            this.itemDichVuThongKeKhac.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBaoCaoHDThueGianHangThueKHTHue),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemReport_KeHoachThuTien),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemReport_BaoCaoDatCoc),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemReport_HopDongChoThue)});
            this.itemDichVuThongKeKhac.Name = "itemDichVuThongKeKhac";
            // 
            // itemBaoCaoHDThueGianHangThueKHTHue
            // 
            this.itemBaoCaoHDThueGianHangThueKHTHue.Caption = "Báo cáo hợp đồng thuê mặt bằng";
            this.itemBaoCaoHDThueGianHangThueKHTHue.Id = 595;
            this.itemBaoCaoHDThueGianHangThueKHTHue.ImageOptions.ImageIndex = 73;
            this.itemBaoCaoHDThueGianHangThueKHTHue.Name = "itemBaoCaoHDThueGianHangThueKHTHue";
            this.itemBaoCaoHDThueGianHangThueKHTHue.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoCaoHDThueGianHangThueKHTHue_ItemClick);
            // 
            // itemReport_KeHoachThuTien
            // 
            this.itemReport_KeHoachThuTien.Caption = "Kế hoạch thu tiền cho thuê";
            this.itemReport_KeHoachThuTien.Id = 565;
            this.itemReport_KeHoachThuTien.ImageOptions.ImageIndex = 73;
            this.itemReport_KeHoachThuTien.Name = "itemReport_KeHoachThuTien";
            this.itemReport_KeHoachThuTien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemReport_KeHoachThuTien_ItemClick);
            // 
            // itemDichVu_Report_KhauTru
            // 
            this.itemDichVu_Report_KhauTru.Caption = "Báo cáo các khoản đã khấu trừ";
            this.itemDichVu_Report_KhauTru.Id = 535;
            this.itemDichVu_Report_KhauTru.ImageOptions.ImageIndex = 73;
            this.itemDichVu_Report_KhauTru.Name = "itemDichVu_Report_KhauTru";
            // 
            // barSubItem3
            // 
            this.barSubItem3.Caption = "Nước nóng";
            this.barSubItem3.Id = 536;
            this.barSubItem3.Name = "barSubItem3";
            // 
            // itemNuocNong
            // 
            this.itemNuocNong.Caption = "Nước nóng";
            this.itemNuocNong.Id = 539;
            this.itemNuocNong.ImageOptions.ImageIndex = 72;
            this.itemNuocNong.Name = "itemNuocNong";
            this.itemNuocNong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNuocNong_ItemClick);
            // 
            // itemNuocSinhHoat
            // 
            this.itemNuocSinhHoat.Caption = "Nước sinh hoạt";
            this.itemNuocSinhHoat.Id = 540;
            this.itemNuocSinhHoat.ImageOptions.ImageIndex = 72;
            this.itemNuocSinhHoat.Name = "itemNuocSinhHoat";
            this.itemNuocSinhHoat.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNuocSinhHoat_ItemClick);
            // 
            // itemEmail_Config
            // 
            this.itemEmail_Config.Caption = "Cấu hình email gửi";
            this.itemEmail_Config.Id = 541;
            this.itemEmail_Config.ImageOptions.ImageIndex = 68;
            this.itemEmail_Config.Name = "itemEmail_Config";
            this.itemEmail_Config.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemEmail_Config_ItemClick);
            // 
            // itemEmail_SettingStaff
            // 
            this.itemEmail_SettingStaff.Caption = "Cài đặt email nhận";
            this.itemEmail_SettingStaff.Id = 542;
            this.itemEmail_SettingStaff.ImageOptions.ImageIndex = 68;
            this.itemEmail_SettingStaff.Name = "itemEmail_SettingStaff";
            this.itemEmail_SettingStaff.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemEmail_SettingStaff_ItemClick);
            // 
            // itemEmail_Category
            // 
            this.itemEmail_Category.Caption = "Phân loại mẫu";
            this.itemEmail_Category.Id = 543;
            this.itemEmail_Category.ImageOptions.ImageIndex = 75;
            this.itemEmail_Category.Name = "itemEmail_Category";
            this.itemEmail_Category.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemEmail_Category_ItemClick);
            // 
            // itemEmail_Templates
            // 
            this.itemEmail_Templates.Caption = "Danh sách mẫu";
            this.itemEmail_Templates.Id = 544;
            this.itemEmail_Templates.ImageOptions.ImageIndex = 76;
            this.itemEmail_Templates.Name = "itemEmail_Templates";
            this.itemEmail_Templates.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemEmail_Templates_ItemClick);
            // 
            // itemReport_PhieuThu
            // 
            this.itemReport_PhieuThu.Caption = "Phiếu thu";
            this.itemReport_PhieuThu.Id = 545;
            this.itemReport_PhieuThu.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_pie_chart_report_filled_50px;
            this.itemReport_PhieuThu.Name = "itemReport_PhieuThu";
            this.itemReport_PhieuThu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemReport_PhieuThu_ItemClick);
            // 
            // itemReport_PhieuChi
            // 
            this.itemReport_PhieuChi.Caption = "Phiếu chi";
            this.itemReport_PhieuChi.Id = 546;
            this.itemReport_PhieuChi.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_pie_chart_report_filled_50px;
            this.itemReport_PhieuChi.Name = "itemReport_PhieuChi";
            this.itemReport_PhieuChi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemReport_PhieuChi_ItemClick);
            // 
            // itemReport_PhieuKhauTru
            // 
            this.itemReport_PhieuKhauTru.Caption = "Phiếu khấu trừ";
            this.itemReport_PhieuKhauTru.Id = 547;
            this.itemReport_PhieuKhauTru.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_pie_chart_report_filled_50px;
            this.itemReport_PhieuKhauTru.Name = "itemReport_PhieuKhauTru";
            this.itemReport_PhieuKhauTru.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemReport_PhieuKhauTru.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemReport_PhieuKhauTru_ItemClick);
            // 
            // itemNhomKhachHang
            // 
            this.itemNhomKhachHang.Caption = "Nhóm khách hàng";
            this.itemNhomKhachHang.Id = 548;
            this.itemNhomKhachHang.ImageOptions.ImageIndex = 72;
            this.itemNhomKhachHang.Name = "itemNhomKhachHang";
            this.itemNhomKhachHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhomKhachHang_ItemClick);
            // 
            // itemQuanHe
            // 
            this.itemQuanHe.Caption = "Quan hệ";
            this.itemQuanHe.Id = 550;
            this.itemQuanHe.ImageOptions.ImageIndex = 72;
            this.itemQuanHe.Name = "itemQuanHe";
            this.itemQuanHe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemQuanHe_ItemClick);
            // 
            // barDanhMuc
            // 
            this.barDanhMuc.Caption = "Danh mục";
            this.barDanhMuc.Id = 551;
            this.barDanhMuc.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_sorting_answers_filled_50px;
            this.barDanhMuc.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemLoaiKhachHang),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNhomKhachHang),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNguonDen),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnDoUuTienYC),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnTrangThaiYC),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTrangThaiNhanKhau, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemMucDoLeTan),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTrangThaiLeTan),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemYeuCau_CaiDat, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNhomCongViec),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemCauHinhNgayNghi),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemCauHinhNgayNghiTheoToaNha),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemQuanHe),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBoPhanLienHe, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNhomLienHe)});
            this.barDanhMuc.Name = "barDanhMuc";
            // 
            // itemLoaiKhachHang
            // 
            this.itemLoaiKhachHang.Caption = "Loại khách hàng";
            this.itemLoaiKhachHang.Id = 610;
            this.itemLoaiKhachHang.ImageOptions.ImageIndex = 72;
            this.itemLoaiKhachHang.Name = "itemLoaiKhachHang";
            this.itemLoaiKhachHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLoaiKhachHang_ItemClick);
            // 
            // itemNguonDen
            // 
            this.itemNguonDen.Caption = "Nguồn tiếp nhận";
            this.itemNguonDen.Id = 553;
            this.itemNguonDen.ImageOptions.ImageIndex = 72;
            this.itemNguonDen.Name = "itemNguonDen";
            this.itemNguonDen.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNguonDen_ItemClick);
            // 
            // itemMucDoLeTan
            // 
            this.itemMucDoLeTan.Caption = "Mức độ cư dân";
            this.itemMucDoLeTan.Id = 603;
            this.itemMucDoLeTan.ImageOptions.ImageIndex = 72;
            this.itemMucDoLeTan.Name = "itemMucDoLeTan";
            this.itemMucDoLeTan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemMucDoLeTan_ItemClick);
            // 
            // itemTrangThaiLeTan
            // 
            this.itemTrangThaiLeTan.Caption = "Trạng thái lễ tân";
            this.itemTrangThaiLeTan.Id = 604;
            this.itemTrangThaiLeTan.ImageOptions.ImageIndex = 72;
            this.itemTrangThaiLeTan.Name = "itemTrangThaiLeTan";
            this.itemTrangThaiLeTan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTrangThaiLeTan_ItemClick);
            // 
            // itemYeuCau_CaiDat
            // 
            this.itemYeuCau_CaiDat.Caption = "Cài đặt";
            this.itemYeuCau_CaiDat.Id = 552;
            this.itemYeuCau_CaiDat.ImageOptions.ImageIndex = 72;
            this.itemYeuCau_CaiDat.Name = "itemYeuCau_CaiDat";
            this.itemYeuCau_CaiDat.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemYeuCau_CaiDat_ItemClick);
            // 
            // itemNhomCongViec
            // 
            this.itemNhomCongViec.Caption = "Nhóm công việc";
            this.itemNhomCongViec.Id = 717;
            this.itemNhomCongViec.ImageOptions.ImageIndex = 72;
            this.itemNhomCongViec.Name = "itemNhomCongViec";
            this.itemNhomCongViec.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhomCongViec_ItemClick_1);
            // 
            // itemCauHinhNgayNghi
            // 
            this.itemCauHinhNgayNghi.Caption = "Cấu hình ngày nghỉ";
            this.itemCauHinhNgayNghi.Id = 714;
            this.itemCauHinhNgayNghi.ImageOptions.ImageIndex = 72;
            this.itemCauHinhNgayNghi.Name = "itemCauHinhNgayNghi";
            this.itemCauHinhNgayNghi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCauHinhNgayNghi_ItemClick);
            // 
            // itemCauHinhNgayNghiTheoToaNha
            // 
            this.itemCauHinhNgayNghiTheoToaNha.Caption = "Cấu hình ngày nghỉ theo tòa nhà";
            this.itemCauHinhNgayNghiTheoToaNha.Id = 715;
            this.itemCauHinhNgayNghiTheoToaNha.ImageOptions.ImageIndex = 72;
            this.itemCauHinhNgayNghiTheoToaNha.Name = "itemCauHinhNgayNghiTheoToaNha";
            this.itemCauHinhNgayNghiTheoToaNha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCauHinhNgayNghiTheoToaNha_ItemClick);
            // 
            // itemBoPhanLienHe
            // 
            this.itemBoPhanLienHe.Caption = "Bộ phận liên hệ";
            this.itemBoPhanLienHe.Id = 1034;
            this.itemBoPhanLienHe.ImageOptions.ImageIndex = 72;
            this.itemBoPhanLienHe.Name = "itemBoPhanLienHe";
            this.itemBoPhanLienHe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBoPhanLienHe_ItemClick);
            // 
            // itemNhomLienHe
            // 
            this.itemNhomLienHe.Caption = "Nhóm liên hệ";
            this.itemNhomLienHe.Id = 1035;
            this.itemNhomLienHe.ImageOptions.ImageIndex = 72;
            this.itemNhomLienHe.Name = "itemNhomLienHe";
            this.itemNhomLienHe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhomLienHe_ItemClick);
            // 
            // itemLeTan_Add
            // 
            this.itemLeTan_Add.Caption = "Thêm mới";
            this.itemLeTan_Add.Id = 554;
            this.itemLeTan_Add.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_plus_filled_50px;
            this.itemLeTan_Add.Name = "itemLeTan_Add";
            this.itemLeTan_Add.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemLeTan_Add.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLeTan_Add_ItemClick);
            // 
            // itemLenTan_List
            // 
            this.itemLenTan_List.Caption = "Danh sách";
            this.itemLenTan_List.Id = 555;
            this.itemLenTan_List.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_front_desk_filled_50px;
            this.itemLenTan_List.Name = "itemLenTan_List";
            this.itemLenTan_List.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLenTan_List_ItemClick);
            // 
            // itemChoThue_LTT
            // 
            this.itemChoThue_LTT.Caption = "Lịch thanh toán cho thuê";
            this.itemChoThue_LTT.Id = 557;
            this.itemChoThue_LTT.ImageOptions.ImageIndex = 72;
            this.itemChoThue_LTT.Name = "itemChoThue_LTT";
            this.itemChoThue_LTT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemChoThue_LTT_ItemClick_1);
            // 
            // barSubItem5
            // 
            this.barSubItem5.Caption = "Hợp đồng cho thuê";
            this.barSubItem5.Id = 558;
            this.barSubItem5.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_diploma_1_filled_50px;
            this.barSubItem5.ImageOptions.LargeImageIndex = 16;
            this.barSubItem5.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemChoThue),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemChoThue_MatBang),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemChoThue_LTT),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemGanHetHan, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDaHetHan),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemThanhLyChoThue, true)});
            this.barSubItem5.Name = "barSubItem5";
            // 
            // itemGanHetHan
            // 
            this.itemGanHetHan.Caption = "Hợp đồng gần hết hạn";
            this.itemGanHetHan.Id = 593;
            this.itemGanHetHan.ImageOptions.ImageIndex = 72;
            this.itemGanHetHan.Name = "itemGanHetHan";
            this.itemGanHetHan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemGanHetHan_ItemClick);
            // 
            // itemDaHetHan
            // 
            this.itemDaHetHan.Caption = "Hợp đồng đã hết hạn";
            this.itemDaHetHan.Id = 594;
            this.itemDaHetHan.ImageOptions.ImageIndex = 72;
            this.itemDaHetHan.Name = "itemDaHetHan";
            this.itemDaHetHan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDaHetHan_ItemClick);
            // 
            // barSubItem7
            // 
            this.barSubItem7.Caption = "Điện";
            this.barSubItem7.Id = 559;
            this.barSubItem7.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_electricity_filled_50px;
            this.barSubItem7.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDien),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDien3Pha),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDienDieuHoa),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDSDHNG),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDienLanh)});
            this.barSubItem7.Name = "barSubItem7";
            // 
            // itemDienDieuHoa
            // 
            this.itemDienDieuHoa.Caption = "Điện điều hòa";
            this.itemDienDieuHoa.Id = 560;
            this.itemDienDieuHoa.ImageOptions.ImageIndex = 72;
            this.itemDienDieuHoa.Name = "itemDienDieuHoa";
            this.itemDienDieuHoa.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDienDieuHoa_ItemClick);
            // 
            // itemDienLanh
            // 
            this.itemDienLanh.Caption = "Điện Lạnh";
            this.itemDienLanh.Id = 1040;
            this.itemDienLanh.ImageOptions.ImageIndex = 72;
            this.itemDienLanh.Name = "itemDienLanh";
            this.itemDienLanh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDienLanh_ItemClick);
            // 
            // barSubItem8
            // 
            this.barSubItem8.Caption = "Nước";
            this.barSubItem8.Id = 562;
            this.barSubItem8.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_piping_filled_50px;
            this.barSubItem8.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNuoc),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNuocNong),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNuocSinhHoat)});
            this.barSubItem8.Name = "barSubItem8";
            // 
            // barButtonItem28
            // 
            this.barButtonItem28.Caption = "Đồng hồ điện điều hòa";
            this.barButtonItem28.Id = 563;
            this.barButtonItem28.Name = "barButtonItem28";
            // 
            // itemReport_ChiTietCongNo
            // 
            this.itemReport_ChiTietCongNo.Caption = "Chi tiết công nợ khách hàng";
            this.itemReport_ChiTietCongNo.Id = 566;
            this.itemReport_ChiTietCongNo.ImageOptions.ImageIndex = 73;
            this.itemReport_ChiTietCongNo.Name = "itemReport_ChiTietCongNo";
            // 
            // itemGiuXe_CongNoTheXe
            // 
            this.itemGiuXe_CongNoTheXe.Caption = "Sổ công nợ thẻ xe";
            this.itemGiuXe_CongNoTheXe.Id = 567;
            this.itemGiuXe_CongNoTheXe.ImageOptions.ImageIndex = 73;
            this.itemGiuXe_CongNoTheXe.Name = "itemGiuXe_CongNoTheXe";
            // 
            // itemGAS_Report_BieuDo
            // 
            this.itemGAS_Report_BieuDo.Caption = "Biểu đồ tiêu thụ GAS";
            this.itemGAS_Report_BieuDo.Id = 568;
            this.itemGAS_Report_BieuDo.ImageOptions.ImageIndex = 73;
            this.itemGAS_Report_BieuDo.Name = "itemGAS_Report_BieuDo";
            // 
            // itemDien_BieuDo
            // 
            this.itemDien_BieuDo.Caption = "Biểu đồ tiêu thụ điện";
            this.itemDien_BieuDo.Id = 569;
            this.itemDien_BieuDo.ImageOptions.ImageIndex = 73;
            this.itemDien_BieuDo.Name = "itemDien_BieuDo";
            // 
            // itemDien3Pha_BieuDo
            // 
            this.itemDien3Pha_BieuDo.Caption = "Biểu đồ tiêu thụ điện 3 pha";
            this.itemDien3Pha_BieuDo.Id = 570;
            this.itemDien3Pha_BieuDo.ImageOptions.ImageIndex = 73;
            this.itemDien3Pha_BieuDo.Name = "itemDien3Pha_BieuDo";
            // 
            // itemDienDieuHoa_BieuDo
            // 
            this.itemDienDieuHoa_BieuDo.Caption = "Biểu đồ tiêu thụ điện điều hòa";
            this.itemDienDieuHoa_BieuDo.Id = 571;
            this.itemDienDieuHoa_BieuDo.ImageOptions.ImageIndex = 73;
            this.itemDienDieuHoa_BieuDo.Name = "itemDienDieuHoa_BieuDo";
            // 
            // itemNuoc_BieuDo
            // 
            this.itemNuoc_BieuDo.Caption = "Biểu đồ tiêu thụ nước";
            this.itemNuoc_BieuDo.Id = 572;
            this.itemNuoc_BieuDo.ImageOptions.ImageIndex = 73;
            this.itemNuoc_BieuDo.Name = "itemNuoc_BieuDo";
            // 
            // itemNuocNong_BieuDo
            // 
            this.itemNuocNong_BieuDo.Caption = "Biểu đồ tiêu thụ nước nóng";
            this.itemNuocNong_BieuDo.Id = 573;
            this.itemNuocNong_BieuDo.ImageOptions.ImageIndex = 73;
            this.itemNuocNong_BieuDo.Name = "itemNuocNong_BieuDo";
            // 
            // itemNuocSinhHoat_BieuDo
            // 
            this.itemNuocSinhHoat_BieuDo.Caption = "Biểu đồ tiêu thụ nước sinh hoạt";
            this.itemNuocSinhHoat_BieuDo.Id = 574;
            this.itemNuocSinhHoat_BieuDo.ImageOptions.ImageIndex = 73;
            this.itemNuocSinhHoat_BieuDo.Name = "itemNuocSinhHoat_BieuDo";
            // 
            // barButtonItem32
            // 
            this.barButtonItem32.Caption = "Biểu đồ tiêu thụ nươc";
            this.barButtonItem32.Id = 575;
            this.barButtonItem32.Name = "barButtonItem32";
            // 
            // itemPhanLoaiLich
            // 
            this.itemPhanLoaiLich.Caption = "Phân loại";
            this.itemPhanLoaiLich.Id = 576;
            this.itemPhanLoaiLich.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_sorting_answers_filled_50px;
            this.itemPhanLoaiLich.Name = "itemPhanLoaiLich";
            this.itemPhanLoaiLich.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhanLoaiLich_ItemClick);
            // 
            // itemThoiDiemLich
            // 
            this.itemThoiDiemLich.Caption = "Thời điểm";
            this.itemThoiDiemLich.Id = 577;
            this.itemThoiDiemLich.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_calendar_10_filled_50px;
            this.itemThoiDiemLich.Name = "itemThoiDiemLich";
            this.itemThoiDiemLich.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThoiDiemLich_ItemClick);
            // 
            // itemDanhSachLich
            // 
            this.itemDanhSachLich.Caption = "Danh sách";
            this.itemDanhSachLich.Id = 579;
            this.itemDanhSachLich.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_alarm_filled_50px;
            this.itemDanhSachLich.Name = "itemDanhSachLich";
            this.itemDanhSachLich.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDanhSachLich_ItemClick);
            // 
            // itemPhanLoai
            // 
            this.itemPhanLoai.Caption = "Phân loại";
            this.itemPhanLoai.Id = 582;
            this.itemPhanLoai.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_sorting_answers_filled_50px;
            this.itemPhanLoai.Name = "itemPhanLoai";
            this.itemPhanLoai.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhanLoai_ItemClick);
            // 
            // itemTrangThai
            // 
            this.itemTrangThai.Caption = "Trạng thái";
            this.itemTrangThai.Id = 583;
            this.itemTrangThai.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_comment_discussion_filled_50px;
            this.itemTrangThai.Name = "itemTrangThai";
            this.itemTrangThai.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTrangThai_ItemClick_1);
            // 
            // itemMucDo
            // 
            this.itemMucDo.Caption = "Mức độ";
            this.itemMucDo.Id = 584;
            this.itemMucDo.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_stairs_up_filled_50px;
            this.itemMucDo.Name = "itemMucDo";
            this.itemMucDo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemMucDo_ItemClick);
            // 
            // itemTienDo
            // 
            this.itemTienDo.Caption = "Tiến độ";
            this.itemTienDo.Id = 585;
            this.itemTienDo.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_bullish_filled_50px;
            this.itemTienDo.Name = "itemTienDo";
            this.itemTienDo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTienDo_ItemClick);
            // 
            // itemThemMoi
            // 
            this.itemThemMoi.Caption = "Thêm mới";
            this.itemThemMoi.Id = 586;
            this.itemThemMoi.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_plus_filled_50px;
            this.itemThemMoi.Name = "itemThemMoi";
            this.itemThemMoi.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemThemMoi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThemMoi_ItemClick);
            // 
            // itemDanhSach
            // 
            this.itemDanhSach.Caption = "Danh sách";
            this.itemDanhSach.Id = 587;
            this.itemDanhSach.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_shortlist_filled_50px;
            this.itemDanhSach.Name = "itemDanhSach";
            this.itemDanhSach.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDanhSach_ItemClick);
            // 
            // itemTaiLieu
            // 
            this.itemTaiLieu.Caption = "Tài liệu";
            this.itemTaiLieu.Id = 588;
            this.itemTaiLieu.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_tai_lieu;
            this.itemTaiLieu.ImageOptions.LargeImageIndex = 10;
            this.itemTaiLieu.Name = "itemTaiLieu";
            this.itemTaiLieu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTaiLieu_ItemClick);
            // 
            // itemTaiLieu_Loai
            // 
            this.itemTaiLieu_Loai.Caption = "Nhóm biểu mẫu";
            this.itemTaiLieu_Loai.Id = 589;
            this.itemTaiLieu_Loai.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_product_documents_filled_50px;
            this.itemTaiLieu_Loai.Name = "itemTaiLieu_Loai";
            this.itemTaiLieu_Loai.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTaiLieu_Loai_ItemClick);
            // 
            // itemReport_DaThuTheXe
            // 
            this.itemReport_DaThuTheXe.Caption = "Báo cáo đã thu thẻ xe phát sinh";
            this.itemReport_DaThuTheXe.Id = 590;
            this.itemReport_DaThuTheXe.ImageOptions.ImageIndex = 73;
            this.itemReport_DaThuTheXe.Name = "itemReport_DaThuTheXe";
            // 
            // itemPhanQuyenBaoCao
            // 
            this.itemPhanQuyenBaoCao.Caption = "Phân quyền báo cáo";
            this.itemPhanQuyenBaoCao.Id = 591;
            this.itemPhanQuyenBaoCao.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_graph_report_script_filled_50px;
            this.itemPhanQuyenBaoCao.Name = "itemPhanQuyenBaoCao";
            this.itemPhanQuyenBaoCao.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemPhanQuyenBaoCao.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhanQuyenBaoCao_ItemClick);
            // 
            // itemHoaDonDaXoa
            // 
            this.itemHoaDonDaXoa.Caption = "Hóa đơn đã xóa";
            this.itemHoaDonDaXoa.Id = 597;
            this.itemHoaDonDaXoa.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_delete_file_filled_50px;
            this.itemHoaDonDaXoa.Name = "itemHoaDonDaXoa";
            this.itemHoaDonDaXoa.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemHoaDonDaXoa.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHoaDonDaXoa_ItemClick);
            // 
            // itemPhieuThuDaXoa
            // 
            this.itemPhieuThuDaXoa.Caption = "Phiếu thu đã xóa";
            this.itemPhieuThuDaXoa.Id = 598;
            this.itemPhieuThuDaXoa.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_full_trash_filled_50px;
            this.itemPhieuThuDaXoa.ImageOptions.LargeImageIndex = 3;
            this.itemPhieuThuDaXoa.Name = "itemPhieuThuDaXoa";
            this.itemPhieuThuDaXoa.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhieuThuDaXoa_ItemClick);
            // 
            // itemTheXeDaXoa
            // 
            this.itemTheXeDaXoa.Caption = "Thẻ xe đã xóa";
            this.itemTheXeDaXoa.Id = 599;
            this.itemTheXeDaXoa.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_no_credit_cards_filled_50px;
            this.itemTheXeDaXoa.ImageOptions.LargeImageIndex = 3;
            this.itemTheXeDaXoa.Name = "itemTheXeDaXoa";
            this.itemTheXeDaXoa.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTheXeDaXoa_ItemClick);
            // 
            // itemBaoCaoCongNoTongHopTheoThang
            // 
            this.itemBaoCaoCongNoTongHopTheoThang.Caption = "Báo cáo công nợ tổng hợp theo tháng";
            this.itemBaoCaoCongNoTongHopTheoThang.Id = 600;
            this.itemBaoCaoCongNoTongHopTheoThang.ImageOptions.ImageIndex = 73;
            this.itemBaoCaoCongNoTongHopTheoThang.Name = "itemBaoCaoCongNoTongHopTheoThang";
            // 
            // itemTheThangMay
            // 
            this.itemTheThangMay.Caption = "Thẻ thang máy";
            this.itemTheThangMay.Id = 605;
            this.itemTheThangMay.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_elevator_filled_50px;
            this.itemTheThangMay.Name = "itemTheThangMay";
            this.itemTheThangMay.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemTheThangMay.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTheThangMay_ItemClick);
            // 
            // itemKhoThe
            // 
            this.itemKhoThe.Caption = "Kho thẻ";
            this.itemKhoThe.Id = 607;
            this.itemKhoThe.ImageOptions.LargeImageIndex = 44;
            this.itemKhoThe.Name = "itemKhoThe";
            this.itemKhoThe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKhoThe_ItemClick);
            // 
            // itemDSCapThe
            // 
            this.itemDSCapThe.Caption = "Danh sách cấp thẻ";
            this.itemDSCapThe.Id = 608;
            this.itemDSCapThe.ImageOptions.LargeImageIndex = 44;
            this.itemDSCapThe.Name = "itemDSCapThe";
            this.itemDSCapThe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDSCapThe_ItemClick);
            // 
            // itemConfigPhone
            // 
            this.itemConfigPhone.Caption = "Tổng đài";
            this.itemConfigPhone.Id = 611;
            this.itemConfigPhone.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_phone_not_being_used_filled_50px;
            this.itemConfigPhone.Name = "itemConfigPhone";
            this.itemConfigPhone.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemConfigPhone.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemConfigPhone_ItemClick);
            // 
            // itemNhatKyCuocGoi
            // 
            this.itemNhatKyCuocGoi.Caption = "Nhật ký cuộc gọi";
            this.itemNhatKyCuocGoi.Id = 612;
            this.itemNhatKyCuocGoi.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_last_24_hours_filled_50px;
            this.itemNhatKyCuocGoi.Name = "itemNhatKyCuocGoi";
            this.itemNhatKyCuocGoi.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemNhatKyCuocGoi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhatKyCuocGoi_ItemClick);
            // 
            // barSubItem9
            // 
            this.barSubItem9.Caption = "Danh sách yêu cầu";
            this.barSubItem9.Id = 613;
            this.barSubItem9.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.yeu_cau;
            this.barSubItem9.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiDanhSachYeuCau),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiCongViecCuaToi)});
            this.barSubItem9.Name = "barSubItem9";
            // 
            // bbiDanhSachYeuCau
            // 
            this.bbiDanhSachYeuCau.Caption = "Danh sách yêu cầu";
            this.bbiDanhSachYeuCau.Id = 614;
            this.bbiDanhSachYeuCau.ImageOptions.ImageIndex = 72;
            this.bbiDanhSachYeuCau.Name = "bbiDanhSachYeuCau";
            this.bbiDanhSachYeuCau.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiDanhSachYeuCau_ItemClick);
            // 
            // bbiCongViecCuaToi
            // 
            this.bbiCongViecCuaToi.Caption = "Công việc yêu cầu";
            this.bbiCongViecCuaToi.Id = 615;
            this.bbiCongViecCuaToi.ImageOptions.ImageIndex = 72;
            this.bbiCongViecCuaToi.Name = "bbiCongViecCuaToi";
            this.bbiCongViecCuaToi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiCongViecCuaToi_ItemClick);
            // 
            // itemMauMail
            // 
            this.itemMauMail.Caption = "Mẫu mail";
            this.itemMauMail.Id = 616;
            this.itemMauMail.ImageOptions.ImageIndex = 45;
            this.itemMauMail.Name = "itemMauMail";
            this.itemMauMail.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem29_ItemClick);
            // 
            // itemDanhSachNhan
            // 
            this.itemDanhSachNhan.Caption = "Danh sách nhận mail";
            this.itemDanhSachNhan.Id = 617;
            this.itemDanhSachNhan.ImageOptions.ImageIndex = 45;
            this.itemDanhSachNhan.Name = "itemDanhSachNhan";
            this.itemDanhSachNhan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDanhSachNhan_ItemClick);
            // 
            // itemThuongHieu
            // 
            this.itemThuongHieu.Caption = "Thương hiệu";
            this.itemThuongHieu.Id = 618;
            this.itemThuongHieu.ImageOptions.ImageIndex = 45;
            this.itemThuongHieu.Name = "itemThuongHieu";
            this.itemThuongHieu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThuongHieu_ItemClick);
            // 
            // itemDanhSachGui
            // 
            this.itemDanhSachGui.Caption = "Danh sách gửi mail";
            this.itemDanhSachGui.Id = 619;
            this.itemDanhSachGui.ImageOptions.ImageIndex = 58;
            this.itemDanhSachGui.Name = "itemDanhSachGui";
            this.itemDanhSachGui.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDanhSachGui_ItemClick);
            // 
            // itemCheckTaiKhoan
            // 
            this.itemCheckTaiKhoan.Caption = "Kiểm tra số dư";
            this.itemCheckTaiKhoan.Id = 620;
            this.itemCheckTaiKhoan.ImageOptions.ImageIndex = 59;
            this.itemCheckTaiKhoan.Name = "itemCheckTaiKhoan";
            this.itemCheckTaiKhoan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCheckTaiKhoan_ItemClick);
            // 
            // barButtonItem29
            // 
            this.barButtonItem29.Caption = "Lịch sử gửi mail";
            this.barButtonItem29.Id = 621;
            this.barButtonItem29.ImageOptions.ImageIndex = 77;
            this.barButtonItem29.Name = "barButtonItem29";
            this.barButtonItem29.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem29_ItemClick_1);
            // 
            // barButtonItem31
            // 
            this.barButtonItem31.Caption = "Thêm tài liệu";
            this.barButtonItem31.Id = 632;
            this.barButtonItem31.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_tai_lieu;
            this.barButtonItem31.Name = "barButtonItem31";
            this.barButtonItem31.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.barButtonItem31.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem31_ItemClick);
            // 
            // itemHDCTNSapHetHan
            // 
            this.itemHDCTNSapHetHan.Caption = "Hợp đồng sắp hết hạn";
            this.itemHDCTNSapHetHan.Id = 637;
            this.itemHDCTNSapHetHan.Name = "itemHDCTNSapHetHan";
            this.itemHDCTNSapHetHan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHDCTNSapHetHan_ItemClick);
            // 
            // itemHDCTN
            // 
            this.itemHDCTN.Caption = "Danh sách Thanh lý";
            this.itemHDCTN.Id = 640;
            this.itemHDCTN.Name = "itemHDCTN";
            // 
            // barButtonItem33
            // 
            this.barButtonItem33.Caption = "Dịch vụ khấu trừ tự động";
            this.barButtonItem33.Id = 642;
            this.barButtonItem33.ImageOptions.ImageIndex = 45;
            this.barButtonItem33.Name = "barButtonItem33";
            // 
            // itemCongNoDongTien
            // 
            this.itemCongNoDongTien.Caption = "Công nợ dòng tiền";
            this.itemCongNoDongTien.Id = 644;
            this.itemCongNoDongTien.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_cashflow_filled_50px;
            this.itemCongNoDongTien.Name = "itemCongNoDongTien";
            this.itemCongNoDongTien.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemCongNoDongTien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCongNoDongTien_ItemClick);
            // 
            // itemDSChuyenTien
            // 
            this.itemDSChuyenTien.Caption = "Chuyển tiền";
            this.itemDSChuyenTien.Id = 646;
            this.itemDSChuyenTien.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_money_transfer_filled_50px;
            this.itemDSChuyenTien.Name = "itemDSChuyenTien";
            this.itemDSChuyenTien.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemDSChuyenTien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDSChuyenTien_ItemClick);
            // 
            // itemPhieuChiKyQuy
            // 
            this.itemPhieuChiKyQuy.Caption = "Phiếu chi ký quỹ";
            this.itemPhieuChiKyQuy.Id = 647;
            this.itemPhieuChiKyQuy.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_autograph_filled_50px;
            this.itemPhieuChiKyQuy.Name = "itemPhieuChiKyQuy";
            this.itemPhieuChiKyQuy.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemPhieuChiKyQuy.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhieuChiKyQuy_ItemClick);
            // 
            // itemBieuDoMotToaNha
            // 
            this.itemBieuDoMotToaNha.Caption = "THEO MỘT TÒA NHÀ";
            this.itemBieuDoMotToaNha.Id = 648;
            this.itemBieuDoMotToaNha.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_building32;
            this.itemBieuDoMotToaNha.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemThongKeTheoNhomCongViec),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBDTinhTrangXuLy),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTheoDanhGiaCuaCuDan),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTheoNguonPhanAnh),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDoUuTien),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemPhanAnhTheoToaNha),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemViewBieuDoAll),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemThongKeThoiGian),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemSubTinTuc),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemSubApp)});
            this.itemBieuDoMotToaNha.Name = "itemBieuDoMotToaNha";
            // 
            // itemThongKeTheoNhomCongViec
            // 
            this.itemThongKeTheoNhomCongViec.Caption = "NHÓM CÔNG VIỆC";
            this.itemThongKeTheoNhomCongViec.Id = 649;
            this.itemThongKeTheoNhomCongViec.ImageOptions.ImageIndex = 73;
            this.itemThongKeTheoNhomCongViec.Name = "itemThongKeTheoNhomCongViec";
            this.itemThongKeTheoNhomCongViec.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThongKeTheoNhomCongViec_ItemClick);
            // 
            // itemBDTinhTrangXuLy
            // 
            this.itemBDTinhTrangXuLy.Caption = "TÌNH TRẠNG XỬ LÝ";
            this.itemBDTinhTrangXuLy.Id = 650;
            this.itemBDTinhTrangXuLy.ImageOptions.ImageIndex = 73;
            this.itemBDTinhTrangXuLy.Name = "itemBDTinhTrangXuLy";
            this.itemBDTinhTrangXuLy.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBDTinhTrangXuLy_ItemClick);
            // 
            // itemTheoDanhGiaCuaCuDan
            // 
            this.itemTheoDanhGiaCuaCuDan.Caption = "ĐÁNH GIÁ SAO";
            this.itemTheoDanhGiaCuaCuDan.Id = 651;
            this.itemTheoDanhGiaCuaCuDan.ImageOptions.ImageIndex = 73;
            this.itemTheoDanhGiaCuaCuDan.Name = "itemTheoDanhGiaCuaCuDan";
            this.itemTheoDanhGiaCuaCuDan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTheoDanhGiaCuaCuDan_ItemClick);
            // 
            // itemTheoNguonPhanAnh
            // 
            this.itemTheoNguonPhanAnh.Caption = "NGUỒN PHẢN ÁNH";
            this.itemTheoNguonPhanAnh.Id = 652;
            this.itemTheoNguonPhanAnh.ImageOptions.ImageIndex = 73;
            this.itemTheoNguonPhanAnh.Name = "itemTheoNguonPhanAnh";
            this.itemTheoNguonPhanAnh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTheoNguonPhanAnh_ItemClick);
            // 
            // itemDoUuTien
            // 
            this.itemDoUuTien.Caption = "ĐỘ ƯU TIÊN";
            this.itemDoUuTien.Id = 653;
            this.itemDoUuTien.ImageOptions.ImageIndex = 73;
            this.itemDoUuTien.Name = "itemDoUuTien";
            this.itemDoUuTien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDoUuTien_ItemClick);
            // 
            // itemPhanAnhTheoToaNha
            // 
            this.itemPhanAnhTheoToaNha.Caption = "PHẢN ÁNH THEO TÒA NHÀ";
            this.itemPhanAnhTheoToaNha.Id = 654;
            this.itemPhanAnhTheoToaNha.ImageOptions.ImageIndex = 73;
            this.itemPhanAnhTheoToaNha.Name = "itemPhanAnhTheoToaNha";
            this.itemPhanAnhTheoToaNha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhanAnhTheoToaNha_ItemClick);
            // 
            // itemViewBieuDoAll
            // 
            this.itemViewBieuDoAll.Caption = "BIỂU ĐỒ TỔNG HỢP";
            this.itemViewBieuDoAll.Id = 660;
            this.itemViewBieuDoAll.ImageOptions.ImageIndex = 73;
            this.itemViewBieuDoAll.Name = "itemViewBieuDoAll";
            this.itemViewBieuDoAll.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemViewBieuDoAll_ItemClick);
            // 
            // itemThongKeThoiGian
            // 
            this.itemThongKeThoiGian.Caption = "THỐNG KÊ THỜI GIAN CHÊNH LỆCH";
            this.itemThongKeThoiGian.Id = 716;
            this.itemThongKeThoiGian.ImageOptions.ImageIndex = 73;
            this.itemThongKeThoiGian.Name = "itemThongKeThoiGian";
            this.itemThongKeThoiGian.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThongKeThoiGian_ItemClick);
            // 
            // itemSubTinTuc
            // 
            this.itemSubTinTuc.Caption = "TIN TỨC";
            this.itemSubTinTuc.Id = 725;
            this.itemSubTinTuc.ImageOptions.ImageIndex = 74;
            this.itemSubTinTuc.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTinTuc_TyLeDangTin),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTinTuc_ThongKeTheoTungToaNha),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTinTuc_ThongKeTheoTongToaNha),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTinTuc_ThongKeTongHop)});
            this.itemSubTinTuc.Name = "itemSubTinTuc";
            // 
            // itemTinTuc_TyLeDangTin
            // 
            this.itemTinTuc_TyLeDangTin.Caption = "TỶ LỆ ĐĂNG TIN";
            this.itemTinTuc_TyLeDangTin.Id = 727;
            this.itemTinTuc_TyLeDangTin.ImageOptions.ImageIndex = 73;
            this.itemTinTuc_TyLeDangTin.Name = "itemTinTuc_TyLeDangTin";
            this.itemTinTuc_TyLeDangTin.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTinTuc_TyLeDangTin_ItemClick);
            // 
            // itemTinTuc_ThongKeTheoTungToaNha
            // 
            this.itemTinTuc_ThongKeTheoTungToaNha.Caption = "THEO TỪNG TÒA NHÀ";
            this.itemTinTuc_ThongKeTheoTungToaNha.Id = 728;
            this.itemTinTuc_ThongKeTheoTungToaNha.ImageOptions.ImageIndex = 73;
            this.itemTinTuc_ThongKeTheoTungToaNha.Name = "itemTinTuc_ThongKeTheoTungToaNha";
            this.itemTinTuc_ThongKeTheoTungToaNha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTinTuc_ThongKeTheoTungToaNha_ItemClick);
            // 
            // itemTinTuc_ThongKeTheoTongToaNha
            // 
            this.itemTinTuc_ThongKeTheoTongToaNha.Caption = "THEO TỔNG TÒA NHÀ";
            this.itemTinTuc_ThongKeTheoTongToaNha.Id = 729;
            this.itemTinTuc_ThongKeTheoTongToaNha.ImageOptions.ImageIndex = 73;
            this.itemTinTuc_ThongKeTheoTongToaNha.Name = "itemTinTuc_ThongKeTheoTongToaNha";
            this.itemTinTuc_ThongKeTheoTongToaNha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTinTuc_ThongKeTheoTongToaNha_ItemClick);
            // 
            // itemTinTuc_ThongKeTongHop
            // 
            this.itemTinTuc_ThongKeTongHop.Caption = "TIN TỨC TỔNG";
            this.itemTinTuc_ThongKeTongHop.Id = 730;
            this.itemTinTuc_ThongKeTongHop.ImageOptions.ImageIndex = 73;
            this.itemTinTuc_ThongKeTongHop.Name = "itemTinTuc_ThongKeTongHop";
            this.itemTinTuc_ThongKeTongHop.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTinTuc_ThongKeTongHop_ItemClick);
            // 
            // itemSubApp
            // 
            this.itemSubApp.Caption = "APP";
            this.itemSubApp.Id = 726;
            this.itemSubApp.ImageOptions.ImageIndex = 74;
            this.itemSubApp.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemApp_TyLeSuDungTheoTungToaNha),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemApp_TyLeSuDungTongToaNha),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemApp_ThongKeSuDungTungToaNha),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemApp_ThongKeSuDungCacToaNha)});
            this.itemSubApp.Name = "itemSubApp";
            // 
            // itemApp_TyLeSuDungTheoTungToaNha
            // 
            this.itemApp_TyLeSuDungTheoTungToaNha.Caption = "TỶ LỆ SỬ DỤNG TỪNG TÒA NHÀ";
            this.itemApp_TyLeSuDungTheoTungToaNha.Id = 731;
            this.itemApp_TyLeSuDungTheoTungToaNha.ImageOptions.ImageIndex = 73;
            this.itemApp_TyLeSuDungTheoTungToaNha.Name = "itemApp_TyLeSuDungTheoTungToaNha";
            this.itemApp_TyLeSuDungTheoTungToaNha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemApp_TyLeSuDungTheoTungToaNha_ItemClick);
            // 
            // itemApp_TyLeSuDungTongToaNha
            // 
            this.itemApp_TyLeSuDungTongToaNha.Caption = "TỶ LỆ SỬ DỤNG TỔNG TÒA NHÀ";
            this.itemApp_TyLeSuDungTongToaNha.Id = 732;
            this.itemApp_TyLeSuDungTongToaNha.ImageOptions.ImageIndex = 73;
            this.itemApp_TyLeSuDungTongToaNha.Name = "itemApp_TyLeSuDungTongToaNha";
            this.itemApp_TyLeSuDungTongToaNha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemApp_TyLeSuDungTongToaNha_ItemClick);
            // 
            // itemApp_ThongKeSuDungTungToaNha
            // 
            this.itemApp_ThongKeSuDungTungToaNha.Caption = "THỐNG KÊ SỬ DỤNG TỪNG TÒA NHÀ";
            this.itemApp_ThongKeSuDungTungToaNha.Id = 733;
            this.itemApp_ThongKeSuDungTungToaNha.ImageOptions.ImageIndex = 73;
            this.itemApp_ThongKeSuDungTungToaNha.Name = "itemApp_ThongKeSuDungTungToaNha";
            this.itemApp_ThongKeSuDungTungToaNha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemApp_ThongKeSuDungTungToaNha_ItemClick);
            // 
            // itemApp_ThongKeSuDungCacToaNha
            // 
            this.itemApp_ThongKeSuDungCacToaNha.Caption = "THỐNG KÊ SỬ DỤNG CÁC TÒA NHÀ";
            this.itemApp_ThongKeSuDungCacToaNha.Id = 734;
            this.itemApp_ThongKeSuDungCacToaNha.ImageOptions.ImageIndex = 73;
            this.itemApp_ThongKeSuDungCacToaNha.Name = "itemApp_ThongKeSuDungCacToaNha";
            this.itemApp_ThongKeSuDungCacToaNha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemApp_ThongKeSuDungCacToaNha_ItemClick);
            // 
            // itemTheoNhieuToaNha
            // 
            this.itemTheoNhieuToaNha.Caption = "NHIỀU TÒA NHÀ";
            this.itemTheoNhieuToaNha.Id = 655;
            this.itemTheoNhieuToaNha.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_toa_nha;
            this.itemTheoNhieuToaNha.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNhomCongViecMuiltiTN),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTinhTrangXuLyTheoNhieuToaNha),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDanhGiaCuaCuDanTheoMuiltiToaNha),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNguonTiepNhanTheoMuilti),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNhieuTN_PhanAnhTheoThang, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNhieuTN_TongPhanAnh),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNhieuTN_BaoCaoTongHop)});
            this.itemTheoNhieuToaNha.Name = "itemTheoNhieuToaNha";
            // 
            // itemNhomCongViecMuiltiTN
            // 
            this.itemNhomCongViecMuiltiTN.Caption = "NHÓM CÔNG VIỆC";
            this.itemNhomCongViecMuiltiTN.Id = 656;
            this.itemNhomCongViecMuiltiTN.ImageOptions.ImageIndex = 73;
            this.itemNhomCongViecMuiltiTN.Name = "itemNhomCongViecMuiltiTN";
            this.itemNhomCongViecMuiltiTN.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhomCongViecMuiltiTN_ItemClick);
            // 
            // itemTinhTrangXuLyTheoNhieuToaNha
            // 
            this.itemTinhTrangXuLyTheoNhieuToaNha.Caption = "TÌNH TRẠNG XỬ LÝ";
            this.itemTinhTrangXuLyTheoNhieuToaNha.Id = 657;
            this.itemTinhTrangXuLyTheoNhieuToaNha.ImageOptions.ImageIndex = 73;
            this.itemTinhTrangXuLyTheoNhieuToaNha.Name = "itemTinhTrangXuLyTheoNhieuToaNha";
            this.itemTinhTrangXuLyTheoNhieuToaNha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTinhTrangXuLyTheoNhieuToaNha_ItemClick);
            // 
            // itemDanhGiaCuaCuDanTheoMuiltiToaNha
            // 
            this.itemDanhGiaCuaCuDanTheoMuiltiToaNha.Caption = "ĐÁNH GIÁ SAO";
            this.itemDanhGiaCuaCuDanTheoMuiltiToaNha.Id = 658;
            this.itemDanhGiaCuaCuDanTheoMuiltiToaNha.ImageOptions.ImageIndex = 73;
            this.itemDanhGiaCuaCuDanTheoMuiltiToaNha.Name = "itemDanhGiaCuaCuDanTheoMuiltiToaNha";
            this.itemDanhGiaCuaCuDanTheoMuiltiToaNha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDanhGiaCuaCuDanTheoMuiltiToaNha_ItemClick);
            // 
            // itemNguonTiepNhanTheoMuilti
            // 
            this.itemNguonTiepNhanTheoMuilti.Caption = "NGUỒN TIẾP NHẬN";
            this.itemNguonTiepNhanTheoMuilti.Id = 659;
            this.itemNguonTiepNhanTheoMuilti.ImageOptions.ImageIndex = 73;
            this.itemNguonTiepNhanTheoMuilti.Name = "itemNguonTiepNhanTheoMuilti";
            this.itemNguonTiepNhanTheoMuilti.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNguonTiepNhanTheoMuilti_ItemClick);
            // 
            // itemNhieuTN_PhanAnhTheoThang
            // 
            this.itemNhieuTN_PhanAnhTheoThang.Caption = "PHẢN ÁNH THEO THÁNG";
            this.itemNhieuTN_PhanAnhTheoThang.Id = 737;
            this.itemNhieuTN_PhanAnhTheoThang.ImageOptions.ImageIndex = 73;
            this.itemNhieuTN_PhanAnhTheoThang.Name = "itemNhieuTN_PhanAnhTheoThang";
            this.itemNhieuTN_PhanAnhTheoThang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhieuTN_PhanAnhTheoThang_ItemClick);
            // 
            // itemNhieuTN_TongPhanAnh
            // 
            this.itemNhieuTN_TongPhanAnh.Caption = "TỔNG PHẢN ÁNH";
            this.itemNhieuTN_TongPhanAnh.Id = 738;
            this.itemNhieuTN_TongPhanAnh.ImageOptions.ImageIndex = 73;
            this.itemNhieuTN_TongPhanAnh.Name = "itemNhieuTN_TongPhanAnh";
            this.itemNhieuTN_TongPhanAnh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhieuTN_TongPhanAnh_ItemClick);
            // 
            // itemNhieuTN_BaoCaoTongHop
            // 
            this.itemNhieuTN_BaoCaoTongHop.Caption = "BÁO CÁO TỔNG HỢP";
            this.itemNhieuTN_BaoCaoTongHop.Id = 739;
            this.itemNhieuTN_BaoCaoTongHop.ImageOptions.ImageIndex = 73;
            this.itemNhieuTN_BaoCaoTongHop.Name = "itemNhieuTN_BaoCaoTongHop";
            this.itemNhieuTN_BaoCaoTongHop.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhieuTN_BaoCaoTongHop_ItemClick);
            // 
            // barSubItem10
            // 
            this.barSubItem10.Caption = "DANH MỤC";
            this.barSubItem10.Id = 661;
            this.barSubItem10.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_sorting_answers_filled_50px;
            this.barSubItem10.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTTTaiSan),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNhaCCTS),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDMHeThong),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDMLoaiTaiSan)});
            this.barSubItem10.Name = "barSubItem10";
            this.barSubItem10.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // itemTTTaiSan
            // 
            this.itemTTTaiSan.Caption = "TÌNH TRẠNG TÀI SẢN";
            this.itemTTTaiSan.Id = 662;
            this.itemTTTaiSan.ImageOptions.ImageIndex = 72;
            this.itemTTTaiSan.Name = "itemTTTaiSan";
            this.itemTTTaiSan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTTTaiSan_ItemClick);
            // 
            // itemNhaCCTS
            // 
            this.itemNhaCCTS.Caption = "NHÀ CUNG CẤP TÀI SẢN";
            this.itemNhaCCTS.Id = 663;
            this.itemNhaCCTS.ImageOptions.ImageIndex = 72;
            this.itemNhaCCTS.Name = "itemNhaCCTS";
            this.itemNhaCCTS.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhaCCTS_ItemClick);
            // 
            // itemDMHeThong
            // 
            this.itemDMHeThong.Caption = "DANH MỤC HỆ THỐNG";
            this.itemDMHeThong.Id = 664;
            this.itemDMHeThong.ImageOptions.ImageIndex = 72;
            this.itemDMHeThong.Name = "itemDMHeThong";
            this.itemDMHeThong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDMHeThong_ItemClick);
            // 
            // itemDMLoaiTaiSan
            // 
            this.itemDMLoaiTaiSan.Caption = "LOẠI TÀI SẢN";
            this.itemDMLoaiTaiSan.Id = 665;
            this.itemDMLoaiTaiSan.ImageOptions.ImageIndex = 72;
            this.itemDMLoaiTaiSan.Name = "itemDMLoaiTaiSan";
            this.itemDMLoaiTaiSan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDMLoaiTaiSan_ItemClick);
            // 
            // itemDMTenTaiSan
            // 
            this.itemDMTenTaiSan.Caption = "TÊN TÀI SẢN";
            this.itemDMTenTaiSan.Id = 666;
            this.itemDMTenTaiSan.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_bank_building_filled_50px;
            this.itemDMTenTaiSan.Name = "itemDMTenTaiSan";
            this.itemDMTenTaiSan.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemDMTenTaiSan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDMTenTaiSan_ItemClick);
            // 
            // ItemCaiDatHeThongChoToaNha
            // 
            this.ItemCaiDatHeThongChoToaNha.Caption = "CÀI ĐẶT HỆ THỐNG CHO TÒA NHÀ";
            this.ItemCaiDatHeThongChoToaNha.Id = 667;
            this.ItemCaiDatHeThongChoToaNha.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_dich_vu;
            this.ItemCaiDatHeThongChoToaNha.Name = "ItemCaiDatHeThongChoToaNha";
            this.ItemCaiDatHeThongChoToaNha.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.ItemCaiDatHeThongChoToaNha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemCaiDatHeThongChoToaNha_ItemClick);
            // 
            // itemDMChiTietTaiSan
            // 
            this.itemDMChiTietTaiSan.Caption = "CHI TIẾT TÀI SẢN";
            this.itemDMChiTietTaiSan.Id = 668;
            this.itemDMChiTietTaiSan.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_car_dealership_building_filled_50px;
            this.itemDMChiTietTaiSan.Name = "itemDMChiTietTaiSan";
            this.itemDMChiTietTaiSan.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemDMChiTietTaiSan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDMChiTietTaiSan_ItemClick);
            // 
            // ItemDMVanHanh
            // 
            this.ItemDMVanHanh.Caption = "DANH MỤC";
            this.ItemDMVanHanh.Id = 669;
            this.ItemDMVanHanh.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_sorting_answers_filled_50px;
            this.ItemDMVanHanh.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.ItemTanSuat),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemLoaiCaTruc),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemCongCuThietBi),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNhomProfile),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemCauHinhCapDuyet),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemCauHinhTinhTrangPhieu)});
            this.ItemDMVanHanh.Name = "ItemDMVanHanh";
            this.ItemDMVanHanh.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // ItemTanSuat
            // 
            this.ItemTanSuat.Caption = "TẦN SUẤT";
            this.ItemTanSuat.Id = 671;
            this.ItemTanSuat.ImageOptions.ImageIndex = 72;
            this.ItemTanSuat.Name = "ItemTanSuat";
            this.ItemTanSuat.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemTanSuat_ItemClick);
            // 
            // itemLoaiCaTruc
            // 
            this.itemLoaiCaTruc.Caption = "LOẠI CA TRỰC";
            this.itemLoaiCaTruc.Id = 674;
            this.itemLoaiCaTruc.ImageOptions.ImageIndex = 72;
            this.itemLoaiCaTruc.Name = "itemLoaiCaTruc";
            this.itemLoaiCaTruc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLoaiCaTruc_ItemClick);
            // 
            // itemCongCuThietBi
            // 
            this.itemCongCuThietBi.Caption = "CÔNG CỤ, THIẾT BỊ";
            this.itemCongCuThietBi.Id = 675;
            this.itemCongCuThietBi.ImageOptions.ImageIndex = 72;
            this.itemCongCuThietBi.Name = "itemCongCuThietBi";
            this.itemCongCuThietBi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCongCuThietBi_ItemClick);
            // 
            // itemNhomProfile
            // 
            this.itemNhomProfile.Caption = "NHÓM PROFILE";
            this.itemNhomProfile.Id = 689;
            this.itemNhomProfile.ImageOptions.ImageIndex = 72;
            this.itemNhomProfile.Name = "itemNhomProfile";
            this.itemNhomProfile.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhomProfile_ItemClick);
            // 
            // itemCauHinhCapDuyet
            // 
            this.itemCauHinhCapDuyet.Caption = "CẤU HÌNH CẤP DUYỆT";
            this.itemCauHinhCapDuyet.Id = 690;
            this.itemCauHinhCapDuyet.ImageOptions.ImageIndex = 72;
            this.itemCauHinhCapDuyet.Name = "itemCauHinhCapDuyet";
            this.itemCauHinhCapDuyet.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCauHinhCapDuyet_ItemClick);
            // 
            // itemCauHinhTinhTrangPhieu
            // 
            this.itemCauHinhTinhTrangPhieu.Caption = "CẤU HÌNH TÌNH TRẠNG PHIẾU";
            this.itemCauHinhTinhTrangPhieu.Id = 718;
            this.itemCauHinhTinhTrangPhieu.ImageOptions.ImageIndex = 72;
            this.itemCauHinhTinhTrangPhieu.Name = "itemCauHinhTinhTrangPhieu";
            this.itemCauHinhTinhTrangPhieu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCauHinhTinhTrangPhieu_ItemClick);
            // 
            // ItemKeHoachVanHanh
            // 
            this.ItemKeHoachVanHanh.Caption = "KẾ HOẠCH VẬN HÀNH";
            this.ItemKeHoachVanHanh.Id = 676;
            this.ItemKeHoachVanHanh.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_tear_off_calendar_filled_50px;
            this.ItemKeHoachVanHanh.Name = "ItemKeHoachVanHanh";
            this.ItemKeHoachVanHanh.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.ItemKeHoachVanHanh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemKeHoachVanHanh_ItemClick);
            // 
            // itemPhieuVanHanh
            // 
            this.itemPhieuVanHanh.Caption = "PHIẾU VẬN HÀNH";
            this.itemPhieuVanHanh.Id = 677;
            this.itemPhieuVanHanh.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_treatment_plan_filled_50px;
            this.itemPhieuVanHanh.Name = "itemPhieuVanHanh";
            this.itemPhieuVanHanh.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemPhieuVanHanh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhieuVanHanh_ItemClick);
            // 
            // itemProfile
            // 
            this.itemProfile.Caption = "PROFILE TÒA NHÀ";
            this.itemProfile.Id = 678;
            this.itemProfile.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_mau_in;
            this.itemProfile.Name = "itemProfile";
            this.itemProfile.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemProfile.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemProfile_ItemClick);
            // 
            // itemGiaoNhanCa
            // 
            this.itemGiaoNhanCa.Caption = "GIAO NHẬN - CA";
            this.itemGiaoNhanCa.Id = 679;
            this.itemGiaoNhanCa.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_key_exchange_filled_50px;
            this.itemGiaoNhanCa.Name = "itemGiaoNhanCa";
            this.itemGiaoNhanCa.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemGiaoNhanCa.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemGiaoNhanCa.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemGiaoNhanCa_ItemClick);
            // 
            // itemDeXuatDoiCa
            // 
            this.itemDeXuatDoiCa.Caption = "ĐỀ XUẤT ĐỔI CA";
            this.itemDeXuatDoiCa.Id = 680;
            this.itemDeXuatDoiCa.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_collaboration_filled_50px;
            this.itemDeXuatDoiCa.Name = "itemDeXuatDoiCa";
            this.itemDeXuatDoiCa.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemDeXuatDoiCa.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDeXuatDoiCa_ItemClick);
            // 
            // itemBangPhanCong
            // 
            this.itemBangPhanCong.Caption = "BẢNG PHÂN CÔNG";
            this.itemBangPhanCong.Id = 681;
            this.itemBangPhanCong.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_tear_off_calendar_filled_50px;
            this.itemBangPhanCong.Name = "itemBangPhanCong";
            this.itemBangPhanCong.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemBangPhanCong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBangPhanCong_ItemClick);
            // 
            // itemLichTruc
            // 
            this.itemLichTruc.Caption = "LỊCH TRỰC";
            this.itemLichTruc.Id = 682;
            this.itemLichTruc.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_overtime_filled_50px;
            this.itemLichTruc.Name = "itemLichTruc";
            this.itemLichTruc.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemLichTruc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLichTruc_ItemClick);
            // 
            // itemVHKeHoachBaoTri
            // 
            this.itemVHKeHoachBaoTri.Caption = "KẾ HOẠCH BẢO TRÌ";
            this.itemVHKeHoachBaoTri.Id = 683;
            this.itemVHKeHoachBaoTri.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_tear_off_calendar_filled_50px;
            this.itemVHKeHoachBaoTri.Name = "itemVHKeHoachBaoTri";
            this.itemVHKeHoachBaoTri.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemVHKeHoachBaoTri.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemVHKeHoachBaoTri_ItemClick);
            // 
            // itemVHPhieuBaoTri
            // 
            this.itemVHPhieuBaoTri.Caption = "PHIẾU BẢO TRÌ";
            this.itemVHPhieuBaoTri.Id = 684;
            this.itemVHPhieuBaoTri.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_treatment_plan_filled_50px;
            this.itemVHPhieuBaoTri.Name = "itemVHPhieuBaoTri";
            this.itemVHPhieuBaoTri.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemVHPhieuBaoTri.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemVHPhieuBaoTri_ItemClick);
            // 
            // itemGanProFileChoHeThong
            // 
            this.itemGanProFileChoHeThong.Caption = "GÁN PROFILE CHO HỆ THỐNG";
            this.itemGanProFileChoHeThong.Id = 686;
            this.itemGanProFileChoHeThong.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_ubuntu_filled_50px;
            this.itemGanProFileChoHeThong.Name = "itemGanProFileChoHeThong";
            this.itemGanProFileChoHeThong.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemGanProFileChoHeThong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemGanProFileChoHeThong_ItemClick);
            // 
            // itemDanhMucProfile
            // 
            this.itemDanhMucProfile.Caption = "DANH MỤC PROFILE";
            this.itemDanhMucProfile.Id = 687;
            this.itemDanhMucProfile.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_documents_folder_filled_50px;
            this.itemDanhMucProfile.Name = "itemDanhMucProfile";
            this.itemDanhMucProfile.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemDanhMucProfile.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDanhMucProfile_ItemClick);
            // 
            // itemGanProfileChoToaNha
            // 
            this.itemGanProfileChoToaNha.Caption = "GÁN PROFILE CHO TÒA NHÀ";
            this.itemGanProfileChoToaNha.Id = 688;
            this.itemGanProfileChoToaNha.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_sell_filled_50px;
            this.itemGanProfileChoToaNha.Name = "itemGanProfileChoToaNha";
            this.itemGanProfileChoToaNha.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemGanProfileChoToaNha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemGanProfileChoToaNha_ItemClick);
            // 
            // barDanhMucVatTu
            // 
            this.barDanhMucVatTu.Caption = "DANH MỤC";
            this.barDanhMucVatTu.Id = 691;
            this.barDanhMucVatTu.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_sorting_answers_filled_50px;
            this.barDanhMucVatTu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemVTDonViTinh),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemVTDanhMucKhoHang),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemVTDanhMucLoaiNhapKho),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemVTDanhMucLoaiXuatKho)});
            this.barDanhMucVatTu.Name = "barDanhMucVatTu";
            // 
            // itemVTDonViTinh
            // 
            this.itemVTDonViTinh.Caption = "ĐƠN VỊ TÍNH";
            this.itemVTDonViTinh.Id = 692;
            this.itemVTDonViTinh.ImageOptions.ImageIndex = 72;
            this.itemVTDonViTinh.Name = "itemVTDonViTinh";
            this.itemVTDonViTinh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemVTDonViTinh_ItemClick);
            // 
            // itemVTDanhMucKhoHang
            // 
            this.itemVTDanhMucKhoHang.Caption = "KHO HÀNG";
            this.itemVTDanhMucKhoHang.Id = 694;
            this.itemVTDanhMucKhoHang.ImageOptions.ImageIndex = 72;
            this.itemVTDanhMucKhoHang.Name = "itemVTDanhMucKhoHang";
            this.itemVTDanhMucKhoHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemVTDanhMucKhoHang_ItemClick);
            // 
            // itemVTDanhMucLoaiNhapKho
            // 
            this.itemVTDanhMucLoaiNhapKho.Caption = "LOẠI NHẬP KHO";
            this.itemVTDanhMucLoaiNhapKho.Id = 695;
            this.itemVTDanhMucLoaiNhapKho.ImageOptions.ImageIndex = 72;
            this.itemVTDanhMucLoaiNhapKho.Name = "itemVTDanhMucLoaiNhapKho";
            this.itemVTDanhMucLoaiNhapKho.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemVTDanhMucLoaiNhapKho_ItemClick);
            // 
            // itemVTDanhMucLoaiXuatKho
            // 
            this.itemVTDanhMucLoaiXuatKho.Caption = "LOẠI XUẤT KHO";
            this.itemVTDanhMucLoaiXuatKho.Id = 696;
            this.itemVTDanhMucLoaiXuatKho.ImageOptions.ImageIndex = 72;
            this.itemVTDanhMucLoaiXuatKho.Name = "itemVTDanhMucLoaiXuatKho";
            this.itemVTDanhMucLoaiXuatKho.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemVTDanhMucLoaiXuatKho_ItemClick);
            // 
            // itemVTDanhMucVatTu
            // 
            this.itemVTDanhMucVatTu.Caption = "VẬT TƯ";
            this.itemVTDanhMucVatTu.Id = 693;
            this.itemVTDanhMucVatTu.ImageOptions.ImageIndex = 44;
            this.itemVTDanhMucVatTu.Name = "itemVTDanhMucVatTu";
            this.itemVTDanhMucVatTu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemVTDanhMucVatTu_ItemClick);
            // 
            // itemDeXuatMuaHang
            // 
            this.itemDeXuatMuaHang.Caption = "ĐỀ XUẤT MUA HÀNG";
            this.itemDeXuatMuaHang.Id = 697;
            this.itemDeXuatMuaHang.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_voice_presentation_filled_50px;
            this.itemDeXuatMuaHang.Name = "itemDeXuatMuaHang";
            this.itemDeXuatMuaHang.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemDeXuatMuaHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDeXuatMuaHang_ItemClick);
            // 
            // itemDanhSachMuaHang
            // 
            this.itemDanhSachMuaHang.Caption = "DANH SÁCH MUA HÀNG";
            this.itemDanhSachMuaHang.Id = 698;
            this.itemDanhSachMuaHang.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_buy_filled_50px;
            this.itemDanhSachMuaHang.Name = "itemDanhSachMuaHang";
            this.itemDanhSachMuaHang.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemDanhSachMuaHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDanhSachMuaHang_ItemClick);
            // 
            // itemVTNhapKho
            // 
            this.itemVTNhapKho.Caption = "NHẬP KHO";
            this.itemVTNhapKho.Id = 699;
            this.itemVTNhapKho.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_shipped_filled_50px;
            this.itemVTNhapKho.Name = "itemVTNhapKho";
            this.itemVTNhapKho.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemVTNhapKho_ItemClick);
            // 
            // itemVTXuatKho
            // 
            this.itemVTXuatKho.Caption = "XUẤT KHO";
            this.itemVTXuatKho.Id = 700;
            this.itemVTXuatKho.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_airport_transfer_filled_50px;
            this.itemVTXuatKho.Name = "itemVTXuatKho";
            this.itemVTXuatKho.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemVTXuatKho_ItemClick);
            // 
            // itemVTTonKho
            // 
            this.itemVTTonKho.Caption = "TỒN KHO";
            this.itemVTTonKho.Id = 701;
            this.itemVTTonKho.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_depot_filled_50px;
            this.itemVTTonKho.Name = "itemVTTonKho";
            this.itemVTTonKho.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemVTTonKho.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemVTTonKho_ItemClick);
            // 
            // barSubQuanLyHoSo
            // 
            this.barSubQuanLyHoSo.Caption = "DANH MỤC";
            this.barSubQuanLyHoSo.Id = 704;
            this.barSubQuanLyHoSo.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_sorting_answers_filled_50px;
            this.barSubQuanLyHoSo.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemQLHS_LoaiVanBan),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemQLHS_MucDoBaoMat),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemQLHS_MucDoKhanCap),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemQLHS_HoSo),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNoiBanHanh),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemPhanLoaiDiDen),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem37),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem38)});
            this.barSubQuanLyHoSo.Name = "barSubQuanLyHoSo";
            this.barSubQuanLyHoSo.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // itemQLHS_LoaiVanBan
            // 
            this.itemQLHS_LoaiVanBan.Caption = "LOẠI VĂN BẢN";
            this.itemQLHS_LoaiVanBan.Id = 707;
            this.itemQLHS_LoaiVanBan.ImageOptions.ImageIndex = 72;
            this.itemQLHS_LoaiVanBan.Name = "itemQLHS_LoaiVanBan";
            this.itemQLHS_LoaiVanBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemQLHS_LoaiVanBan_ItemClick);
            // 
            // itemQLHS_MucDoBaoMat
            // 
            this.itemQLHS_MucDoBaoMat.Caption = "MỨC ĐỘ BẢO MẬT";
            this.itemQLHS_MucDoBaoMat.Id = 708;
            this.itemQLHS_MucDoBaoMat.ImageOptions.ImageIndex = 72;
            this.itemQLHS_MucDoBaoMat.Name = "itemQLHS_MucDoBaoMat";
            this.itemQLHS_MucDoBaoMat.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemQLHS_MucDoBaoMat_ItemClick);
            // 
            // itemQLHS_MucDoKhanCap
            // 
            this.itemQLHS_MucDoKhanCap.Caption = "MỨC ĐỘ KHẨN CẤP";
            this.itemQLHS_MucDoKhanCap.Id = 709;
            this.itemQLHS_MucDoKhanCap.ImageOptions.ImageIndex = 72;
            this.itemQLHS_MucDoKhanCap.Name = "itemQLHS_MucDoKhanCap";
            this.itemQLHS_MucDoKhanCap.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemQLHS_MucDoKhanCap_ItemClick);
            // 
            // itemQLHS_HoSo
            // 
            this.itemQLHS_HoSo.Caption = "HỒ SƠ";
            this.itemQLHS_HoSo.Id = 711;
            this.itemQLHS_HoSo.ImageOptions.ImageIndex = 72;
            this.itemQLHS_HoSo.Name = "itemQLHS_HoSo";
            this.itemQLHS_HoSo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemQLHS_HoSo_ItemClick);
            // 
            // itemNoiBanHanh
            // 
            this.itemNoiBanHanh.Caption = "NƠI BAN HÀNH";
            this.itemNoiBanHanh.Id = 942;
            this.itemNoiBanHanh.ImageOptions.ImageIndex = 72;
            this.itemNoiBanHanh.Name = "itemNoiBanHanh";
            this.itemNoiBanHanh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemNoiBanHanh_ItemClick);
            // 
            // itemPhanLoaiDiDen
            // 
            this.itemPhanLoaiDiDen.Caption = "PHÂN LOẠI ĐI ĐẾN";
            this.itemPhanLoaiDiDen.Id = 943;
            this.itemPhanLoaiDiDen.ImageOptions.ImageIndex = 72;
            this.itemPhanLoaiDiDen.Name = "itemPhanLoaiDiDen";
            this.itemPhanLoaiDiDen.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhanLoaiDiDen_ItemClick);
            // 
            // barButtonItem37
            // 
            this.barButtonItem37.Caption = "DÃY KỆ";
            this.barButtonItem37.Id = 948;
            this.barButtonItem37.ImageOptions.ImageIndex = 72;
            this.barButtonItem37.Name = "barButtonItem37";
            this.barButtonItem37.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem37_ItemClick);
            // 
            // barButtonItem38
            // 
            this.barButtonItem38.Caption = "KHỔ GIẤY";
            this.barButtonItem38.Id = 949;
            this.barButtonItem38.ImageOptions.ImageIndex = 72;
            this.barButtonItem38.Name = "barButtonItem38";
            this.barButtonItem38.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem38_ItemClick);
            // 
            // itemQuanLyHoSo
            // 
            this.itemQuanLyHoSo.Caption = "HỒ SƠ NỘI BỘ";
            this.itemQuanLyHoSo.Id = 705;
            this.itemQuanLyHoSo.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_blog_filled_50px;
            this.itemQuanLyHoSo.Name = "itemQuanLyHoSo";
            this.itemQuanLyHoSo.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemQuanLyHoSo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemQuanLyHoSo_ItemClick);
            // 
            // itemQLHS_KhoGiay
            // 
            this.itemQLHS_KhoGiay.Caption = "KHỔ GIẤY";
            this.itemQLHS_KhoGiay.Id = 706;
            this.itemQLHS_KhoGiay.ImageOptions.ImageIndex = 44;
            this.itemQLHS_KhoGiay.Name = "itemQLHS_KhoGiay";
            this.itemQLHS_KhoGiay.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemQLHS_KhoGiay_ItemClick);
            // 
            // itemQLHS_DayKe
            // 
            this.itemQLHS_DayKe.Caption = "DÃY - KỆ";
            this.itemQLHS_DayKe.Id = 710;
            this.itemQLHS_DayKe.ImageOptions.ImageIndex = 44;
            this.itemQLHS_DayKe.Name = "itemQLHS_DayKe";
            this.itemQLHS_DayKe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemQLHS_DayKe_ItemClick);
            // 
            // itemXuatKhoSuDung
            // 
            this.itemXuatKhoSuDung.Caption = "XUẤT KHO SỬ DỤNG";
            this.itemXuatKhoSuDung.Id = 712;
            this.itemXuatKhoSuDung.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_in_transit_filled_50px;
            this.itemXuatKhoSuDung.Name = "itemXuatKhoSuDung";
            this.itemXuatKhoSuDung.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemXuatKhoSuDung.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemXuatKhoSuDung_ItemClick);
            // 
            // itemDeXuatSuaChua
            // 
            this.itemDeXuatSuaChua.Caption = "ĐỀ XUẤT SỬA CHỮA";
            this.itemDeXuatSuaChua.Id = 713;
            this.itemDeXuatSuaChua.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_critical_thinking_filled_50px;
            this.itemDeXuatSuaChua.Name = "itemDeXuatSuaChua";
            this.itemDeXuatSuaChua.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemDeXuatSuaChua.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDeXuatSuaChua_ItemClick);
            // 
            // itemThongKeSoLieuVH
            // 
            this.itemThongKeSoLieuVH.Caption = "THỐNG KÊ";
            this.itemThongKeSoLieuVH.Id = 719;
            this.itemThongKeSoLieuVH.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_summary_list_filled_50px;
            this.itemThongKeSoLieuVH.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTKTinhHinhThucHien),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTKTinhHinhKiemTraDinhKy),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTKKiemTraDinhKy)});
            this.itemThongKeSoLieuVH.Name = "itemThongKeSoLieuVH";
            // 
            // itemTKTinhHinhThucHien
            // 
            this.itemTKTinhHinhThucHien.Caption = "Tình hình thực hiện";
            this.itemTKTinhHinhThucHien.Id = 721;
            this.itemTKTinhHinhThucHien.ImageOptions.ImageIndex = 73;
            this.itemTKTinhHinhThucHien.Name = "itemTKTinhHinhThucHien";
            this.itemTKTinhHinhThucHien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTKTinhHinhThucHien_ItemClick);
            // 
            // itemTKTinhHinhKiemTraDinhKy
            // 
            this.itemTKTinhHinhKiemTraDinhKy.Caption = "Tình hình kiểm tra định kỳ";
            this.itemTKTinhHinhKiemTraDinhKy.Id = 722;
            this.itemTKTinhHinhKiemTraDinhKy.ImageOptions.ImageIndex = 73;
            this.itemTKTinhHinhKiemTraDinhKy.Name = "itemTKTinhHinhKiemTraDinhKy";
            this.itemTKTinhHinhKiemTraDinhKy.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTKTinhHinhKiemTraDinhKy_ItemClick);
            // 
            // itemTKKiemTraDinhKy
            // 
            this.itemTKKiemTraDinhKy.Caption = "Kế hoạch kiểm tra định kỳ";
            this.itemTKKiemTraDinhKy.Id = 723;
            this.itemTKKiemTraDinhKy.ImageOptions.ImageIndex = 73;
            this.itemTKKiemTraDinhKy.Name = "itemTKKiemTraDinhKy";
            this.itemTKKiemTraDinhKy.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // itemTKCheckList
            // 
            this.itemTKCheckList.Caption = "Checklist hàng ngày";
            this.itemTKCheckList.Id = 720;
            this.itemTKCheckList.ImageOptions.ImageIndex = 71;
            this.itemTKCheckList.Name = "itemTKCheckList";
            this.itemTKCheckList.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTKCheckList_ItemClick);
            // 
            // itemViewPhieuBaoTri
            // 
            this.itemViewPhieuBaoTri.Caption = "VIEW PHIẾU BẢO TRÌ";
            this.itemViewPhieuBaoTri.Id = 724;
            this.itemViewPhieuBaoTri.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_view_shedule_filled_50px;
            this.itemViewPhieuBaoTri.Name = "itemViewPhieuBaoTri";
            this.itemViewPhieuBaoTri.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemViewKeHoachBaoTri_ItemClick);
            // 
            // itemNhieuTN_SoLuongNhomCongViec
            // 
            this.itemNhieuTN_SoLuongNhomCongViec.Caption = "SỐ LƯỢNG NHÓM CÔNG VIỆC";
            this.itemNhieuTN_SoLuongNhomCongViec.Id = 736;
            this.itemNhieuTN_SoLuongNhomCongViec.ImageOptions.ImageIndex = 18;
            this.itemNhieuTN_SoLuongNhomCongViec.Name = "itemNhieuTN_SoLuongNhomCongViec";
            this.itemNhieuTN_SoLuongNhomCongViec.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhieuTN_SoLuongNhomCongViec_ItemClick);
            // 
            // itemViewKeHoachBaoTri
            // 
            this.itemViewKeHoachBaoTri.Caption = "VIEW KẾ HOẠCH BẢO TRÌ";
            this.itemViewKeHoachBaoTri.Id = 740;
            this.itemViewKeHoachBaoTri.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_view_shedule_filled_50px;
            this.itemViewKeHoachBaoTri.Name = "itemViewKeHoachBaoTri";
            this.itemViewKeHoachBaoTri.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemViewKeHoachBaoTri_ItemClick_1);
            // 
            // itemSMSSoDuTaiKhoan
            // 
            this.itemSMSSoDuTaiKhoan.Caption = "Số dư tài khoản";
            this.itemSMSSoDuTaiKhoan.Id = 742;
            this.itemSMSSoDuTaiKhoan.ImageOptions.ImageIndex = 80;
            this.itemSMSSoDuTaiKhoan.Name = "itemSMSSoDuTaiKhoan";
            this.itemSMSSoDuTaiKhoan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemSMSSoDuTaiKhoan_ItemClick);
            // 
            // itemSMSLichSu
            // 
            this.itemSMSLichSu.Caption = "Lịch sử gửi SMS";
            this.itemSMSLichSu.Id = 743;
            this.itemSMSLichSu.ImageOptions.ImageIndex = 77;
            this.itemSMSLichSu.Name = "itemSMSLichSu";
            this.itemSMSLichSu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemSMSLichSu_ItemClick);
            // 
            // itemSMS_Mau
            // 
            this.itemSMS_Mau.Caption = "Mẫu SMS";
            this.itemSMS_Mau.Id = 744;
            this.itemSMS_Mau.ImageOptions.ImageIndex = 79;
            this.itemSMS_Mau.Name = "itemSMS_Mau";
            this.itemSMS_Mau.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemSMS_Mau_ItemClick);
            // 
            // itemCaiDatBieuMau
            // 
            this.itemCaiDatBieuMau.Caption = "Biểu mẫu";
            this.itemCaiDatBieuMau.Id = 746;
            this.itemCaiDatBieuMau.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_blog_filled_50px;
            this.itemCaiDatBieuMau.Name = "itemCaiDatBieuMau";
            this.itemCaiDatBieuMau.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemCaiDatBieuMau_ItemClick);
            // 
            // itemScheduleComfirm
            // 
            this.itemScheduleComfirm.Caption = "Trạng thái xác nhận";
            this.itemScheduleComfirm.Id = 749;
            this.itemScheduleComfirm.ImageOptions.ImageIndex = 72;
            this.itemScheduleComfirm.Name = "itemScheduleComfirm";
            this.itemScheduleComfirm.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemScheduleComfirm_ItemClick);
            // 
            // itemEmailSetup
            // 
            this.itemEmailSetup.Caption = "Cài đặt gửi Email";
            this.itemEmailSetup.Id = 798;
            this.itemEmailSetup.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_email_document_filled_50px;
            this.itemEmailSetup.Name = "itemEmailSetup";
            this.itemEmailSetup.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemEmailSetup_ItemClick);
            // 
            // itemBcThuChiTm
            // 
            this.itemBcThuChiTm.Caption = "BC Thu Chi TM";
            this.itemBcThuChiTm.Id = 799;
            this.itemBcThuChiTm.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_pie_chart_report_filled_50px;
            this.itemBcThuChiTm.Name = "itemBcThuChiTm";
            this.itemBcThuChiTm.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBcThuChiTm_ItemClick);
            // 
            // itemBcCongNoDichVu
            // 
            this.itemBcCongNoDichVu.Caption = "Báo cáo tổng hợp công nợ dịch vụ";
            this.itemBcCongNoDichVu.Id = 800;
            this.itemBcCongNoDichVu.ImageOptions.ImageIndex = 73;
            this.itemBcCongNoDichVu.Name = "itemBcCongNoDichVu";
            // 
            // barButtonGroup6
            // 
            this.barButtonGroup6.Caption = "barButtonGroup6";
            this.barButtonGroup6.Id = 801;
            this.barButtonGroup6.Name = "barButtonGroup6";
            // 
            // itemBaoCaoDaThu
            // 
            this.itemBaoCaoDaThu.Caption = "Báo cáo đã thu";
            this.itemBaoCaoDaThu.Id = 802;
            this.itemBaoCaoDaThu.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_pie_chart_report_filled_50px;
            this.itemBaoCaoDaThu.Name = "itemBaoCaoDaThu";
            this.itemBaoCaoDaThu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoCaoDaThu_ItemClick);
            // 
            // barSubItem11
            // 
            this.barSubItem11.Caption = "Công nợ";
            this.barSubItem11.Id = 803;
            this.barSubItem11.Name = "barSubItem11";
            // 
            // barButtonItem30
            // 
            this.barButtonItem30.Caption = "Báo cáo công nợ";
            this.barButtonItem30.Id = 804;
            this.barButtonItem30.Name = "barButtonItem30";
            // 
            // barButtonItem35
            // 
            this.barButtonItem35.Caption = "Báo cáo đã thu";
            this.barButtonItem35.Id = 805;
            this.barButtonItem35.Name = "barButtonItem35";
            // 
            // barSubItem12
            // 
            this.barSubItem12.Caption = "Phí quản lý";
            this.barSubItem12.Id = 806;
            this.barSubItem12.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_client_company_filled_50px;
            this.barSubItem12.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBcChiTietThuPqlThang)});
            this.barSubItem12.Name = "barSubItem12";
            // 
            // itemBcChiTietThuPqlThang
            // 
            this.itemBcChiTietThuPqlThang.Caption = "Báo cáo chi tiết thu PQL tháng";
            this.itemBcChiTietThuPqlThang.Id = 807;
            this.itemBcChiTietThuPqlThang.ImageOptions.ImageIndex = 73;
            this.itemBcChiTietThuPqlThang.Name = "itemBcChiTietThuPqlThang";
            this.itemBcChiTietThuPqlThang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemBcChiTietThuPqlThang_ItemClick);
            // 
            // itemGroupBcCongNoTongHop
            // 
            this.itemGroupBcCongNoTongHop.Caption = "Công nợ tổng hợp";
            this.itemGroupBcCongNoTongHop.Id = 808;
            this.itemGroupBcCongNoTongHop.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_general_ledger_filled_50px;
            this.itemGroupBcCongNoTongHop.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBaoCaoCongNoAll),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemPhiPhaiThuTrongThang),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemHoaDonThongKe),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBaoCaoCongNoDichVu),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemReportPhiDaThu),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBaoCaoTongHopCongNoDichVu),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBcCongNoTongHopTheoThang),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBaoCaoCacKhoanDaKhauTru),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem68),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem69),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem70)});
            this.itemGroupBcCongNoTongHop.Name = "itemGroupBcCongNoTongHop";
            // 
            // itemBaoCaoCongNoAll
            // 
            this.itemBaoCaoCongNoAll.Caption = "Báo cáo công nợ All";
            this.itemBaoCaoCongNoAll.Id = 940;
            this.itemBaoCaoCongNoAll.ImageOptions.ImageIndex = 73;
            this.itemBaoCaoCongNoAll.Name = "itemBaoCaoCongNoAll";
            this.itemBaoCaoCongNoAll.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoCaoCongNoAll_ItemClick);
            // 
            // itemPhiPhaiThuTrongThang
            // 
            this.itemPhiPhaiThuTrongThang.Caption = "Phí phải thu trong tháng";
            this.itemPhiPhaiThuTrongThang.Id = 941;
            this.itemPhiPhaiThuTrongThang.ImageOptions.ImageIndex = 73;
            this.itemPhiPhaiThuTrongThang.Name = "itemPhiPhaiThuTrongThang";
            this.itemPhiPhaiThuTrongThang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhiPhaiThuTrongThang_ItemClick);
            // 
            // itemHoaDonThongKe
            // 
            this.itemHoaDonThongKe.Caption = "Báo cáo công nợ";
            this.itemHoaDonThongKe.Id = 809;
            this.itemHoaDonThongKe.ImageOptions.ImageIndex = 73;
            this.itemHoaDonThongKe.Name = "itemHoaDonThongKe";
            this.itemHoaDonThongKe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHoaDonThongKe_ItemClick);
            // 
            // itemBaoCaoCongNoDichVu
            // 
            this.itemBaoCaoCongNoDichVu.Caption = "Báo cáo công nợ dịch vụ";
            this.itemBaoCaoCongNoDichVu.Id = 860;
            this.itemBaoCaoCongNoDichVu.ImageOptions.ImageIndex = 73;
            this.itemBaoCaoCongNoDichVu.Name = "itemBaoCaoCongNoDichVu";
            this.itemBaoCaoCongNoDichVu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoCaoCongNoDichVu_ItemClick);
            // 
            // itemReportPhiDaThu
            // 
            this.itemReportPhiDaThu.Caption = "Báo cáo đã thu";
            this.itemReportPhiDaThu.Id = 810;
            this.itemReportPhiDaThu.ImageOptions.ImageIndex = 73;
            this.itemReportPhiDaThu.Name = "itemReportPhiDaThu";
            this.itemReportPhiDaThu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemReportPhiDaThu_ItemClick);
            // 
            // itemBaoCaoTongHopCongNoDichVu
            // 
            this.itemBaoCaoTongHopCongNoDichVu.Caption = "Báo cáo tổng hợp công nợ dịch vụ";
            this.itemBaoCaoTongHopCongNoDichVu.Id = 811;
            this.itemBaoCaoTongHopCongNoDichVu.ImageOptions.ImageIndex = 73;
            this.itemBaoCaoTongHopCongNoDichVu.Name = "itemBaoCaoTongHopCongNoDichVu";
            this.itemBaoCaoTongHopCongNoDichVu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemBaoCaoTongHopCongNoDichVu_ItemClick);
            // 
            // itemBcCongNoTongHopTheoThang
            // 
            this.itemBcCongNoTongHopTheoThang.Caption = "Báo cáo tổng hợp công nợ theo tháng";
            this.itemBcCongNoTongHopTheoThang.Id = 812;
            this.itemBcCongNoTongHopTheoThang.ImageOptions.ImageIndex = 73;
            this.itemBcCongNoTongHopTheoThang.Name = "itemBcCongNoTongHopTheoThang";
            this.itemBcCongNoTongHopTheoThang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemBcCongNoTongHopTheoThang_ItemClick);
            // 
            // itemBaoCaoCacKhoanDaKhauTru
            // 
            this.itemBaoCaoCacKhoanDaKhauTru.Caption = "Báo cáo các khoản đã khấu trừ";
            this.itemBaoCaoCacKhoanDaKhauTru.Id = 814;
            this.itemBaoCaoCacKhoanDaKhauTru.ImageOptions.ImageIndex = 73;
            this.itemBaoCaoCacKhoanDaKhauTru.Name = "itemBaoCaoCacKhoanDaKhauTru";
            this.itemBaoCaoCacKhoanDaKhauTru.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemBaoCaoCacKhoanDaKhauTru_ItemClick);
            // 
            // barButtonItem68
            // 
            this.barButtonItem68.Caption = "Báo cáo công nợ theo tuổi nợ";
            this.barButtonItem68.Id = 1020;
            this.barButtonItem68.ImageOptions.ImageIndex = 73;
            this.barButtonItem68.Name = "barButtonItem68";
            this.barButtonItem68.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem68_ItemClick);
            // 
            // barButtonItem69
            // 
            this.barButtonItem69.Caption = "Báo cáo tính lãi chậm nộp phí";
            this.barButtonItem69.Id = 1021;
            this.barButtonItem69.ImageOptions.ImageIndex = 73;
            this.barButtonItem69.Name = "barButtonItem69";
            this.barButtonItem69.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem69_ItemClick);
            // 
            // barButtonItem70
            // 
            this.barButtonItem70.Caption = "Báo cáo tổng hợp lãi vay khách hàng";
            this.barButtonItem70.Id = 1022;
            this.barButtonItem70.ImageOptions.ImageIndex = 73;
            this.barButtonItem70.Name = "barButtonItem70";
            this.barButtonItem70.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem70_ItemClick);
            // 
            // barSubItem13
            // 
            this.barSubItem13.Caption = "Điện";
            this.barSubItem13.Id = 815;
            this.barSubItem13.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_electricity_filled_50px;
            this.barSubItem13.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemReportBaoCaoTienDien),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemRreportDienDieuHoa),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBieuDoTieuThuDien, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBieuDoTieuThuDien3Pha),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBieuDoTieuThuDienDieuHoa)});
            this.barSubItem13.Name = "barSubItem13";
            // 
            // itemReportBaoCaoTienDien
            // 
            this.itemReportBaoCaoTienDien.Caption = "Báo cáo dịch vụ điện";
            this.itemReportBaoCaoTienDien.Id = 816;
            this.itemReportBaoCaoTienDien.ImageOptions.ImageIndex = 73;
            this.itemReportBaoCaoTienDien.Name = "itemReportBaoCaoTienDien";
            this.itemReportBaoCaoTienDien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemReportBaoCaoTienDien_ItemClick);
            // 
            // itemRreportDienDieuHoa
            // 
            this.itemRreportDienDieuHoa.Caption = "Báo cáo điện điều hòa";
            this.itemRreportDienDieuHoa.Id = 817;
            this.itemRreportDienDieuHoa.ImageOptions.ImageIndex = 73;
            this.itemRreportDienDieuHoa.Name = "itemRreportDienDieuHoa";
            this.itemRreportDienDieuHoa.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemRreportDienDieuHoa_ItemClick);
            // 
            // itemBieuDoTieuThuDien
            // 
            this.itemBieuDoTieuThuDien.Caption = "Biểu đồ tiêu thụ điện";
            this.itemBieuDoTieuThuDien.Id = 818;
            this.itemBieuDoTieuThuDien.ImageOptions.ImageIndex = 73;
            this.itemBieuDoTieuThuDien.Name = "itemBieuDoTieuThuDien";
            this.itemBieuDoTieuThuDien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemBieuDoTieuThuDien_ItemClick);
            // 
            // itemBieuDoTieuThuDien3Pha
            // 
            this.itemBieuDoTieuThuDien3Pha.Caption = "Biểu đồ tiêu thụ điện 3 pha";
            this.itemBieuDoTieuThuDien3Pha.Id = 819;
            this.itemBieuDoTieuThuDien3Pha.ImageOptions.ImageIndex = 73;
            this.itemBieuDoTieuThuDien3Pha.Name = "itemBieuDoTieuThuDien3Pha";
            this.itemBieuDoTieuThuDien3Pha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemBieuDoTieuThuDien3Pha_ItemClick);
            // 
            // itemBieuDoTieuThuDienDieuHoa
            // 
            this.itemBieuDoTieuThuDienDieuHoa.Caption = "Biểu đồ tiêu thụ điện điều hòa";
            this.itemBieuDoTieuThuDienDieuHoa.Id = 820;
            this.itemBieuDoTieuThuDienDieuHoa.ImageOptions.ImageIndex = 73;
            this.itemBieuDoTieuThuDienDieuHoa.Name = "itemBieuDoTieuThuDienDieuHoa";
            this.itemBieuDoTieuThuDienDieuHoa.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBieuDoTieuThuDienDieuHoa_ItemClick);
            // 
            // barSubItem14
            // 
            this.barSubItem14.Caption = "Nước";
            this.barSubItem14.Id = 821;
            this.barSubItem14.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_piping_filled_50px;
            this.barSubItem14.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBaoCaoDichVuNuoc),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBieuDoTieuThuNuoc, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBieuDoTieuThuNuocNong),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBieuDoTieuThuNuocSinhHoat)});
            this.barSubItem14.Name = "barSubItem14";
            // 
            // itemBaoCaoDichVuNuoc
            // 
            this.itemBaoCaoDichVuNuoc.Caption = "Báo cáo dịch vụ nước";
            this.itemBaoCaoDichVuNuoc.Id = 822;
            this.itemBaoCaoDichVuNuoc.ImageOptions.ImageIndex = 73;
            this.itemBaoCaoDichVuNuoc.Name = "itemBaoCaoDichVuNuoc";
            this.itemBaoCaoDichVuNuoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoCaoDichVuNuoc_ItemClick);
            // 
            // itemBieuDoTieuThuNuoc
            // 
            this.itemBieuDoTieuThuNuoc.Caption = "Biểu đồ tiêu thụ nước";
            this.itemBieuDoTieuThuNuoc.Id = 823;
            this.itemBieuDoTieuThuNuoc.ImageOptions.ImageIndex = 73;
            this.itemBieuDoTieuThuNuoc.Name = "itemBieuDoTieuThuNuoc";
            this.itemBieuDoTieuThuNuoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBieuDoTieuThuNuoc_ItemClick);
            // 
            // itemBieuDoTieuThuNuocNong
            // 
            this.itemBieuDoTieuThuNuocNong.Caption = "Biểu đồ tiêu thụ nước nóng";
            this.itemBieuDoTieuThuNuocNong.Id = 824;
            this.itemBieuDoTieuThuNuocNong.ImageOptions.ImageIndex = 73;
            this.itemBieuDoTieuThuNuocNong.Name = "itemBieuDoTieuThuNuocNong";
            this.itemBieuDoTieuThuNuocNong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBieuDoTieuThuNuocNong_ItemClick);
            // 
            // itemBieuDoTieuThuNuocSinhHoat
            // 
            this.itemBieuDoTieuThuNuocSinhHoat.Caption = "Biểu đồ tiêu thụ nước sinh hoạt";
            this.itemBieuDoTieuThuNuocSinhHoat.Id = 825;
            this.itemBieuDoTieuThuNuocSinhHoat.ImageOptions.ImageIndex = 73;
            this.itemBieuDoTieuThuNuocSinhHoat.Name = "itemBieuDoTieuThuNuocSinhHoat";
            this.itemBieuDoTieuThuNuocSinhHoat.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBieuDoTieuThuNuocSinhHoat_ItemClick);
            // 
            // barSubItem15
            // 
            this.barSubItem15.Caption = "Gas";
            this.barSubItem15.Id = 826;
            this.barSubItem15.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_gas;
            this.barSubItem15.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBaoCaoDichVuGas),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBieuDoTieuThuGas, true)});
            this.barSubItem15.Name = "barSubItem15";
            // 
            // itemBaoCaoDichVuGas
            // 
            this.itemBaoCaoDichVuGas.Caption = "Báo cáo dịch vụ GAS";
            this.itemBaoCaoDichVuGas.Id = 827;
            this.itemBaoCaoDichVuGas.ImageOptions.ImageIndex = 73;
            this.itemBaoCaoDichVuGas.Name = "itemBaoCaoDichVuGas";
            this.itemBaoCaoDichVuGas.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoCaoDichVuGas_ItemClick);
            // 
            // itemBieuDoTieuThuGas
            // 
            this.itemBieuDoTieuThuGas.Caption = "Biểu đồ tiêu thụ Gas";
            this.itemBieuDoTieuThuGas.Id = 828;
            this.itemBieuDoTieuThuGas.ImageOptions.ImageIndex = 73;
            this.itemBieuDoTieuThuGas.Name = "itemBieuDoTieuThuGas";
            this.itemBieuDoTieuThuGas.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBieuDoTieuThuGas_ItemClick);
            // 
            // barSubItem16
            // 
            this.barSubItem16.Caption = "Xe";
            this.barSubItem16.Id = 829;
            this.barSubItem16.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_valet_parking_filled_50px;
            this.barSubItem16.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBaoCaoDichVuGuiXe),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemSoCongNoTheXe),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBaoCaoDaThuTheXePhatSinh),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBaoCaoChiTietPhiGiuXeThang),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBaoCaoDoanhThuGiuXeOTo),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBaoCaoDoanhThuGiuXeMay),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBaoCaoDoanhThuGiuXeDap)});
            this.barSubItem16.Name = "barSubItem16";
            // 
            // itemBaoCaoDichVuGuiXe
            // 
            this.itemBaoCaoDichVuGuiXe.Caption = "Báo cáo dịch vụ gửi xe";
            this.itemBaoCaoDichVuGuiXe.Id = 830;
            this.itemBaoCaoDichVuGuiXe.ImageOptions.ImageIndex = 73;
            this.itemBaoCaoDichVuGuiXe.Name = "itemBaoCaoDichVuGuiXe";
            this.itemBaoCaoDichVuGuiXe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoCaoDichVuGuiXe_ItemClick);
            // 
            // itemSoCongNoTheXe
            // 
            this.itemSoCongNoTheXe.Caption = "Sổ công nợ thẻ xe";
            this.itemSoCongNoTheXe.Id = 831;
            this.itemSoCongNoTheXe.ImageOptions.ImageIndex = 73;
            this.itemSoCongNoTheXe.Name = "itemSoCongNoTheXe";
            this.itemSoCongNoTheXe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemSoCongNoTheXe_ItemClick);
            // 
            // itemBaoCaoDaThuTheXePhatSinh
            // 
            this.itemBaoCaoDaThuTheXePhatSinh.Caption = "Báo cáo đã thu thẻ xe phát sinh";
            this.itemBaoCaoDaThuTheXePhatSinh.Id = 832;
            this.itemBaoCaoDaThuTheXePhatSinh.ImageOptions.ImageIndex = 73;
            this.itemBaoCaoDaThuTheXePhatSinh.Name = "itemBaoCaoDaThuTheXePhatSinh";
            this.itemBaoCaoDaThuTheXePhatSinh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoCaoDaThuTheXePhatSinh_ItemClick);
            // 
            // itemBaoCaoChiTietPhiGiuXeThang
            // 
            this.itemBaoCaoChiTietPhiGiuXeThang.Caption = "Báo cáo chi tiết phí giữ xe tháng";
            this.itemBaoCaoChiTietPhiGiuXeThang.Id = 833;
            this.itemBaoCaoChiTietPhiGiuXeThang.ImageOptions.ImageIndex = 73;
            this.itemBaoCaoChiTietPhiGiuXeThang.Name = "itemBaoCaoChiTietPhiGiuXeThang";
            this.itemBaoCaoChiTietPhiGiuXeThang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoCaoChiTietPhiGiuXeThang_ItemClick);
            // 
            // itemBaoCaoDoanhThuGiuXeOTo
            // 
            this.itemBaoCaoDoanhThuGiuXeOTo.Caption = "Báo cáo doanh thu giữ Oto";
            this.itemBaoCaoDoanhThuGiuXeOTo.Id = 834;
            this.itemBaoCaoDoanhThuGiuXeOTo.ImageOptions.ImageIndex = 73;
            this.itemBaoCaoDoanhThuGiuXeOTo.Name = "itemBaoCaoDoanhThuGiuXeOTo";
            this.itemBaoCaoDoanhThuGiuXeOTo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoCaoDoanhThuGiuXeOTo_ItemClick);
            // 
            // itemBaoCaoDoanhThuGiuXeMay
            // 
            this.itemBaoCaoDoanhThuGiuXeMay.Caption = "Báo cáo doanh thu giữ xe máy";
            this.itemBaoCaoDoanhThuGiuXeMay.Id = 835;
            this.itemBaoCaoDoanhThuGiuXeMay.ImageOptions.ImageIndex = 73;
            this.itemBaoCaoDoanhThuGiuXeMay.Name = "itemBaoCaoDoanhThuGiuXeMay";
            this.itemBaoCaoDoanhThuGiuXeMay.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoCaoDoanhThuGiuXeMay_ItemClick);
            // 
            // itemBaoCaoDoanhThuGiuXeDap
            // 
            this.itemBaoCaoDoanhThuGiuXeDap.Caption = "Báo cáo doanh thu giữ xe đạp";
            this.itemBaoCaoDoanhThuGiuXeDap.Id = 836;
            this.itemBaoCaoDoanhThuGiuXeDap.ImageOptions.ImageIndex = 73;
            this.itemBaoCaoDoanhThuGiuXeDap.Name = "itemBaoCaoDoanhThuGiuXeDap";
            this.itemBaoCaoDoanhThuGiuXeDap.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoCaoDoanhThuGiuXeDap_ItemClick);
            // 
            // barSubItem18
            // 
            this.barSubItem18.Caption = "Danh mục";
            this.barSubItem18.Id = 839;
            this.barSubItem18.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_sorting_answers_filled_50px;
            this.barSubItem18.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemScheduleStatus),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemScheduleComfirm1),
            new DevExpress.XtraBars.LinkPersistInfo(this.ItemScheduleGroup),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemUserHandover),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDuty),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemStatus),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTrangThaiDuyetDeXuat),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTieuDeThongBao),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNoiDungThongBao),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemUnit, true),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemAssetGroups, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemStatusAsset),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemCarTyle, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNewsTyle, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemGroupChecklist, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemBlockChecklist)});
            this.barSubItem18.Name = "barSubItem18";
            // 
            // itemScheduleStatus
            // 
            this.itemScheduleStatus.Caption = "Trạng thái gửi lịch";
            this.itemScheduleStatus.Id = 840;
            this.itemScheduleStatus.ImageOptions.ImageIndex = 72;
            this.itemScheduleStatus.Name = "itemScheduleStatus";
            this.itemScheduleStatus.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemScheduleStatus_ItemClick);
            // 
            // itemScheduleComfirm1
            // 
            this.itemScheduleComfirm1.Caption = "Trạng thái xác nhận";
            this.itemScheduleComfirm1.Id = 841;
            this.itemScheduleComfirm1.ImageOptions.ImageIndex = 72;
            this.itemScheduleComfirm1.Name = "itemScheduleComfirm1";
            this.itemScheduleComfirm1.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemScheduleComfirm_ItemClick);
            // 
            // ItemScheduleGroup
            // 
            this.ItemScheduleGroup.Caption = "Nhóm lịch bàn giao";
            this.ItemScheduleGroup.Id = 842;
            this.ItemScheduleGroup.ImageOptions.ImageIndex = 72;
            this.ItemScheduleGroup.Name = "ItemScheduleGroup";
            this.ItemScheduleGroup.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemScheduleGroup_ItemClick);
            // 
            // itemUserHandover
            // 
            this.itemUserHandover.Caption = "Nhân viên bàn giao";
            this.itemUserHandover.Id = 867;
            this.itemUserHandover.ImageOptions.ImageIndex = 72;
            this.itemUserHandover.Name = "itemUserHandover";
            this.itemUserHandover.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemUserHandover_ItemClick);
            // 
            // itemDuty
            // 
            this.itemDuty.Caption = "Ca bàn giao";
            this.itemDuty.Id = 871;
            this.itemDuty.ImageOptions.ImageIndex = 72;
            this.itemDuty.Name = "itemDuty";
            this.itemDuty.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemDuty_ItemClick);
            // 
            // itemStatus
            // 
            this.itemStatus.Caption = "Trạng thái bàn giao";
            this.itemStatus.Id = 872;
            this.itemStatus.ImageOptions.ImageIndex = 72;
            this.itemStatus.Name = "itemStatus";
            this.itemStatus.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemStatus_ItemClick);
            // 
            // itemTrangThaiDuyetDeXuat
            // 
            this.itemTrangThaiDuyetDeXuat.Caption = "Trạng thái duyệt đề xuất";
            this.itemTrangThaiDuyetDeXuat.Id = 908;
            this.itemTrangThaiDuyetDeXuat.ImageOptions.ImageIndex = 72;
            this.itemTrangThaiDuyetDeXuat.Name = "itemTrangThaiDuyetDeXuat";
            this.itemTrangThaiDuyetDeXuat.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTrangThaiDuyetDeXuat_ItemClick);
            // 
            // itemTieuDeThongBao
            // 
            this.itemTieuDeThongBao.Caption = "Tiêu đề thông báo";
            this.itemTieuDeThongBao.Id = 909;
            this.itemTieuDeThongBao.ImageOptions.ImageIndex = 72;
            this.itemTieuDeThongBao.Name = "itemTieuDeThongBao";
            this.itemTieuDeThongBao.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTieuDeThongBao_ItemClick);
            // 
            // itemNoiDungThongBao
            // 
            this.itemNoiDungThongBao.Caption = "Nội dung thông báo";
            this.itemNoiDungThongBao.Id = 910;
            this.itemNoiDungThongBao.ImageOptions.ImageIndex = 72;
            this.itemNoiDungThongBao.Name = "itemNoiDungThongBao";
            this.itemNoiDungThongBao.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNoiDungThongBao_ItemClick);
            // 
            // itemUnit
            // 
            this.itemUnit.Caption = "Đơn vị tính";
            this.itemUnit.Id = 877;
            this.itemUnit.ImageOptions.ImageIndex = 72;
            this.itemUnit.Name = "itemUnit";
            this.itemUnit.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemUnit_ItemClick);
            // 
            // itemAssetGroups
            // 
            this.itemAssetGroups.Caption = "Nhóm tài sản";
            this.itemAssetGroups.Id = 876;
            this.itemAssetGroups.ImageOptions.ImageIndex = 72;
            this.itemAssetGroups.Name = "itemAssetGroups";
            this.itemAssetGroups.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemAssetGroups_ItemClick);
            // 
            // itemStatusAsset
            // 
            this.itemStatusAsset.Caption = "Tình trạng tài sản";
            this.itemStatusAsset.Id = 878;
            this.itemStatusAsset.ImageOptions.ImageIndex = 72;
            this.itemStatusAsset.Name = "itemStatusAsset";
            this.itemStatusAsset.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemStatusAsset_ItemClick);
            // 
            // itemCarTyle
            // 
            this.itemCarTyle.Caption = "Loại xe";
            this.itemCarTyle.Id = 843;
            this.itemCarTyle.ImageOptions.ImageIndex = 72;
            this.itemCarTyle.Name = "itemCarTyle";
            this.itemCarTyle.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCarTyle_ItemClick);
            // 
            // itemNewsTyle
            // 
            this.itemNewsTyle.Caption = "Loại tin tức";
            this.itemNewsTyle.Id = 844;
            this.itemNewsTyle.ImageOptions.ImageIndex = 72;
            this.itemNewsTyle.Name = "itemNewsTyle";
            this.itemNewsTyle.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNewsTyle_ItemClick);
            // 
            // itemGroupChecklist
            // 
            this.itemGroupChecklist.Caption = "Nhóm (Checklist)";
            this.itemGroupChecklist.Id = 879;
            this.itemGroupChecklist.ImageOptions.ImageIndex = 72;
            this.itemGroupChecklist.Name = "itemGroupChecklist";
            this.itemGroupChecklist.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemGroupChecklist_ItemClick);
            // 
            // itemBlockChecklist
            // 
            this.itemBlockChecklist.Caption = "Tầng (Checklist)";
            this.itemBlockChecklist.Id = 880;
            this.itemBlockChecklist.ImageOptions.ImageIndex = 72;
            this.itemBlockChecklist.Name = "itemBlockChecklist";
            this.itemBlockChecklist.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemBlockChecklist_ItemClick);
            // 
            // itemSchedule
            // 
            this.itemSchedule.Caption = "Lịch bàn giao";
            this.itemSchedule.Id = 845;
            this.itemSchedule.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_overtime_filled_50px;
            this.itemSchedule.Name = "itemSchedule";
            this.itemSchedule.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemSchedule_ItemClick);
            // 
            // itemHandover
            // 
            this.itemHandover.Caption = "Kế hoạch bàn giao";
            this.itemHandover.Id = 846;
            this.itemHandover.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_client_company_filled_50px;
            this.itemHandover.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_Enterprise_Resource_Planning_50px;
            this.itemHandover.Name = "itemHandover";
            this.itemHandover.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKeHoachBanGiao_ItemClick);
            // 
            // itemHandoverHistory
            // 
            this.itemHandoverHistory.Caption = "Lịch sử";
            this.itemHandoverHistory.Id = 849;
            this.itemHandoverHistory.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.LichSu1;
            this.itemHandoverHistory.Name = "itemHandoverHistory";
            this.itemHandoverHistory.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHandoverHistory_ItemClick);
            // 
            // itemCarSetup
            // 
            this.itemCarSetup.Caption = "Cấu hình phương tiện";
            this.itemCarSetup.Id = 850;
            this.itemCarSetup.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_car_dealership_building_filled_50px;
            this.itemCarSetup.Name = "itemCarSetup";
            this.itemCarSetup.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCarSetup_ItemClick);
            // 
            // itemCarSchedule
            // 
            this.itemCarSchedule.Caption = "Lịch di chuyển";
            this.itemCarSchedule.Id = 851;
            this.itemCarSchedule.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_rescheduling_a_task_filled_50px;
            this.itemCarSchedule.Name = "itemCarSchedule";
            this.itemCarSchedule.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCarSchedule_ItemClick);
            // 
            // itemNewsManager
            // 
            this.itemNewsManager.Caption = "Quản lý tin tức";
            this.itemNewsManager.Id = 852;
            this.itemNewsManager.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_uk_news_filled_50px;
            this.itemNewsManager.Name = "itemNewsManager";
            this.itemNewsManager.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNewsManager_ItemClick);
            // 
            // barSubItem19
            // 
            this.barSubItem19.Caption = "Danh  mục";
            this.barSubItem19.Id = 853;
            this.barSubItem19.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_sorting_answers_filled_50px;
            this.barSubItem19.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemSendMailToManager)});
            this.barSubItem19.Name = "barSubItem19";
            // 
            // itemSendMailToManager
            // 
            this.itemSendMailToManager.Caption = "Nhân viên quản lý nhận mail";
            this.itemSendMailToManager.Id = 854;
            this.itemSendMailToManager.ImageOptions.ImageIndex = 72;
            this.itemSendMailToManager.Name = "itemSendMailToManager";
            this.itemSendMailToManager.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCauHinhNhanVienQuanLyNhanMail_ItemClick);
            // 
            // itemDeposit
            // 
            this.itemDeposit.Caption = "Phiếu thu tiền phạt";
            this.itemDeposit.Id = 855;
            this.itemDeposit.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_request_money_filled_50px;
            this.itemDeposit.Name = "itemDeposit";
            this.itemDeposit.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemDeposit_ItemClick);
            // 
            // itemDepositDelete
            // 
            this.itemDepositDelete.Caption = "Phiếu thu đã xóa";
            this.itemDepositDelete.Id = 856;
            this.itemDepositDelete.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_full_trash_filled_50px;
            this.itemDepositDelete.Name = "itemDepositDelete";
            this.itemDepositDelete.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDepositDelete_ItemClick);
            // 
            // itemWithDraw
            // 
            this.itemWithDraw.Caption = "Phiếu chi hoàn tiền";
            this.itemWithDraw.Id = 857;
            this.itemWithDraw.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_initiate_money_transfer_filled_50px;
            this.itemWithDraw.Name = "itemWithDraw";
            this.itemWithDraw.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemWithDraw_ItemClick);
            // 
            // barSubItem20
            // 
            this.barSubItem20.Caption = "Danh mục";
            this.barSubItem20.Id = 858;
            this.barSubItem20.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_sorting_answers_filled_50px;
            this.barSubItem20.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDrTyle)});
            this.barSubItem20.Name = "barSubItem20";
            // 
            // itemDrTyle
            // 
            this.itemDrTyle.Caption = "Loại đặt cọc";
            this.itemDrTyle.Id = 859;
            this.itemDrTyle.ImageOptions.ImageIndex = 72;
            this.itemDrTyle.Name = "itemDrTyle";
            this.itemDrTyle.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDrTyle_ItemClick);
            // 
            // itemDepositManager
            // 
            this.itemDepositManager.Caption = "Phiếu thu tiền cọc";
            this.itemDepositManager.Id = 861;
            this.itemDepositManager.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_refund_filled_50px;
            this.itemDepositManager.Name = "itemDepositManager";
            this.itemDepositManager.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDepositManager_ItemClick);
            // 
            // itemSoQuyDatCoc
            // 
            this.itemSoQuyDatCoc.Caption = "Sổ quỹ đặt cọc";
            this.itemSoQuyDatCoc.Id = 862;
            this.itemSoQuyDatCoc.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_pie_chart_report_filled_50px;
            this.itemSoQuyDatCoc.Name = "itemSoQuyDatCoc";
            this.itemSoQuyDatCoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemSoQuyDatCoc_ItemClick);
            // 
            // itemHangMuc
            // 
            this.itemHangMuc.Caption = "Hạng mục chi tiết";
            this.itemHangMuc.Id = 863;
            this.itemHangMuc.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.list4;
            this.itemHangMuc.Name = "itemHangMuc";
            this.itemHangMuc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHangMuc_ItemClick);
            // 
            // itemChecklist
            // 
            this.itemChecklist.Caption = "Mẫu Checklist";
            this.itemChecklist.Id = 864;
            this.itemChecklist.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.Checklist2;
            this.itemChecklist.Name = "itemChecklist";
            this.itemChecklist.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemChecklist_ItemClick);
            // 
            // itemChecklistToaNha
            // 
            this.itemChecklistToaNha.Caption = "Checklist Tòa nhà";
            this.itemChecklistToaNha.Id = 865;
            this.itemChecklistToaNha.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.Checklist5;
            this.itemChecklistToaNha.Name = "itemChecklistToaNha";
            this.itemChecklistToaNha.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemChecklistToaNha_ItemClick);
            // 
            // itemHandoverLocal
            // 
            this.itemHandoverLocal.Caption = "Bàn giao nội bộ";
            this.itemHandoverLocal.Id = 866;
            this.itemHandoverLocal.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.Checklist4;
            this.itemHandoverLocal.Name = "itemHandoverLocal";
            this.itemHandoverLocal.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemHandoverLocal_ItemClick);
            // 
            // itemPlanCustomer
            // 
            this.itemPlanCustomer.Caption = "Kế hoạch bàn giao";
            this.itemPlanCustomer.Id = 868;
            this.itemPlanCustomer.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_client_company_filled_50px;
            this.itemPlanCustomer.Name = "itemPlanCustomer";
            this.itemPlanCustomer.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemPlanCustomer_ItemClick);
            // 
            // itemScheduleCustomer
            // 
            this.itemScheduleCustomer.Caption = "Lịch bàn giao";
            this.itemScheduleCustomer.Id = 869;
            this.itemScheduleCustomer.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_tear_off_calendar_filled_50px;
            this.itemScheduleCustomer.Name = "itemScheduleCustomer";
            this.itemScheduleCustomer.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemScheduleCustomer_ItemClick);
            // 
            // itemHandoverCustomer
            // 
            this.itemHandoverCustomer.Caption = "Bàn giao khách hàng";
            this.itemHandoverCustomer.Id = 870;
            this.itemHandoverCustomer.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_permanent_job_filled_50px;
            this.itemHandoverCustomer.Name = "itemHandoverCustomer";
            this.itemHandoverCustomer.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemHandoverCustomer_ItemClick);
            // 
            // itemHistoryCustomer
            // 
            this.itemHistoryCustomer.Caption = "Lịch sử";
            this.itemHistoryCustomer.Id = 873;
            this.itemHistoryCustomer.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_past_filled_50px;
            this.itemHistoryCustomer.Name = "itemHistoryCustomer";
            this.itemHistoryCustomer.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemHistoryCustomer_ItemClick);
            // 
            // itemAssetCategory
            // 
            this.itemAssetCategory.Caption = "Danh mục tài sản";
            this.itemAssetCategory.Id = 875;
            this.itemAssetCategory.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_coins_filled_50px;
            this.itemAssetCategory.Name = "itemAssetCategory";
            this.itemAssetCategory.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemAssetCategory_ItemClick);
            // 
            // itemDeXuatThayCa
            // 
            this.itemDeXuatThayCa.Caption = "ĐỀ XUẤT THAY CA";
            this.itemDeXuatThayCa.Id = 881;
            this.itemDeXuatThayCa.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_collaboration_filled_50px;
            this.itemDeXuatThayCa.Name = "itemDeXuatThayCa";
            this.itemDeXuatThayCa.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDeXuatThayCa_ItemClick);
            // 
            // itemDienTichLapDay
            // 
            this.itemDienTichLapDay.Caption = "Thống kê diện tích lắp đầy";
            this.itemDienTichLapDay.Id = 883;
            this.itemDienTichLapDay.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.ic_mau_in;
            this.itemDienTichLapDay.Name = "itemDienTichLapDay";
            this.itemDienTichLapDay.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDienTichLapDay_ItemClick);
            // 
            // itemBieuMauHDT
            // 
            this.itemBieuMauHDT.Caption = "Biểu mẫu hợp đồng thuê";
            this.itemBieuMauHDT.Id = 884;
            this.itemBieuMauHDT.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_blog_filled_50px;
            this.itemBieuMauHDT.Name = "itemBieuMauHDT";
            this.itemBieuMauHDT.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemBieuMauHDT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBieuMauHDT_ItemClick);
            // 
            // itemTruongTronHDT
            // 
            this.itemTruongTronHDT.Caption = "Trường trộn";
            this.itemTruongTronHDT.Id = 885;
            this.itemTruongTronHDT.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_code_filled_50px;
            this.itemTruongTronHDT.Name = "itemTruongTronHDT";
            this.itemTruongTronHDT.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemTruongTronHDT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTruongTronHDT_ItemClick);
            // 
            // itemMauHDT
            // 
            this.itemMauHDT.Caption = "Mẫu";
            this.itemMauHDT.Id = 886;
            this.itemMauHDT.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_email_document_filled_50px;
            this.itemMauHDT.Name = "itemMauHDT";
            this.itemMauHDT.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemMauHDT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemMauHDT_ItemClick);
            // 
            // itemLapHoaDonHDT
            // 
            this.itemLapHoaDonHDT.Caption = "Lập hóa đơn tự động";
            this.itemLapHoaDonHDT.Id = 887;
            this.itemLapHoaDonHDT.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_plus_filled_50px;
            this.itemLapHoaDonHDT.Name = "itemLapHoaDonHDT";
            this.itemLapHoaDonHDT.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemLapHoaDonHDT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLapHoaDonHDT_ItemClick);
            // 
            // itemHoaDonHDT
            // 
            this.itemHoaDonHDT.Caption = "Hóa đơn";
            this.itemHoaDonHDT.Id = 888;
            this.itemHoaDonHDT.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_paid_bill_filled_50px;
            this.itemHoaDonHDT.Name = "itemHoaDonHDT";
            this.itemHoaDonHDT.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemHoaDonHDT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHoaDonHDT_ItemClick);
            // 
            // itemHoaDonDaXoaHDT
            // 
            this.itemHoaDonDaXoaHDT.Caption = "Hóa đơn đã xóa";
            this.itemHoaDonDaXoaHDT.Id = 889;
            this.itemHoaDonDaXoaHDT.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_delete_file_filled_50px;
            this.itemHoaDonDaXoaHDT.Name = "itemHoaDonDaXoaHDT";
            this.itemHoaDonDaXoaHDT.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemHoaDonDaXoaHDT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHoaDonDaXoaHDT_ItemClick);
            // 
            // itemCongNoHDT
            // 
            this.itemCongNoHDT.Caption = "Công Nợ";
            this.itemCongNoHDT.Id = 890;
            this.itemCongNoHDT.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_general_ledger_filled_50px;
            this.itemCongNoHDT.Name = "itemCongNoHDT";
            this.itemCongNoHDT.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemCongNoHDT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCongNoHDT_ItemClick);
            // 
            // itemPhieuThuHDT
            // 
            this.itemPhieuThuHDT.Caption = "Phiếu Thu";
            this.itemPhieuThuHDT.Id = 891;
            this.itemPhieuThuHDT.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_request_money_filled_50px;
            this.itemPhieuThuHDT.Name = "itemPhieuThuHDT";
            this.itemPhieuThuHDT.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemPhieuThuHDT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhieuThuHDT_ItemClick);
            // 
            // itemPhieuThuDaXoaHDT
            // 
            this.itemPhieuThuDaXoaHDT.Caption = "Phiếu Thu Đã Xóa";
            this.itemPhieuThuDaXoaHDT.Id = 892;
            this.itemPhieuThuDaXoaHDT.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_full_trash_filled_50px;
            this.itemPhieuThuDaXoaHDT.Name = "itemPhieuThuDaXoaHDT";
            this.itemPhieuThuDaXoaHDT.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemPhieuThuDaXoaHDT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhieuThuDaXoaHDT_ItemClick);
            // 
            // itemPhieuDieuChuyenHDT
            // 
            this.itemPhieuDieuChuyenHDT.Caption = "Phiếu Điều Chuyển";
            this.itemPhieuDieuChuyenHDT.Id = 893;
            this.itemPhieuDieuChuyenHDT.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_cashflow_filled_50px;
            this.itemPhieuDieuChuyenHDT.Name = "itemPhieuDieuChuyenHDT";
            this.itemPhieuDieuChuyenHDT.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemPhieuDieuChuyenHDT.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // itemPhieuChiHDT
            // 
            this.itemPhieuChiHDT.Caption = "Phiếu Chi";
            this.itemPhieuChiHDT.Id = 894;
            this.itemPhieuChiHDT.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_initiate_money_transfer_filled_50px;
            this.itemPhieuChiHDT.Name = "itemPhieuChiHDT";
            this.itemPhieuChiHDT.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemPhieuChiHDT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhieuChiHDT_ItemClick);
            // 
            // itemPhieuKhauTruHDT
            // 
            this.itemPhieuKhauTruHDT.Caption = "Phiếu khấu trừ";
            this.itemPhieuKhauTruHDT.Id = 895;
            this.itemPhieuKhauTruHDT.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_duration_finance_filled_50px;
            this.itemPhieuKhauTruHDT.Name = "itemPhieuKhauTruHDT";
            this.itemPhieuKhauTruHDT.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.itemPhieuKhauTruHDT.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemPhieuKhauTruHDT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhieuKhauTruHDT_ItemClick);
            // 
            // itemMoneyPurpose
            // 
            this.itemMoneyPurpose.Caption = "Kinh phí cả năm";
            this.itemMoneyPurpose.Id = 896;
            this.itemMoneyPurpose.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_bank_building_filled_50px;
            this.itemMoneyPurpose.Name = "itemMoneyPurpose";
            this.itemMoneyPurpose.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemMoneyPurpose_ItemClick);
            // 
            // itemMoneyPurposeItems
            // 
            this.itemMoneyPurposeItems.Caption = "Kinh phí hạng mục";
            this.itemMoneyPurposeItems.Id = 897;
            this.itemMoneyPurposeItems.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_crowdfunding_filled_50px;
            this.itemMoneyPurposeItems.Name = "itemMoneyPurposeItems";
            this.itemMoneyPurposeItems.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemMoneyPurposeItems_ItemClick);
            // 
            // itemHopDongDatCoc
            // 
            this.itemHopDongDatCoc.Caption = "Hợp đồng đặt cọc";
            this.itemHopDongDatCoc.Id = 900;
            this.itemHopDongDatCoc.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_diploma_1_filled_50px;
            this.itemHopDongDatCoc.Name = "itemHopDongDatCoc";
            this.itemHopDongDatCoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHopDongDatCoc_ItemClick);
            // 
            // itemKhachHangTiemNang
            // 
            this.itemKhachHangTiemNang.Caption = "Khách hàng tiềm năng";
            this.itemKhachHangTiemNang.Id = 901;
            this.itemKhachHangTiemNang.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_multicultural_people_filled_50px;
            this.itemKhachHangTiemNang.Name = "itemKhachHangTiemNang";
            this.itemKhachHangTiemNang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemKhachHangTiemNang_ItemClick);
            // 
            // itemDanhSachCongViec
            // 
            this.itemDanhSachCongViec.Caption = "Cài đặt nhóm công việc";
            this.itemDanhSachCongViec.Id = 902;
            this.itemDanhSachCongViec.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.Checklist4;
            this.itemDanhSachCongViec.Name = "itemDanhSachCongViec";
            this.itemDanhSachCongViec.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDanhSachCongViec_ItemClick);
            // 
            // itemHopDongThueNgoai
            // 
            this.itemHopDongThueNgoai.Caption = "Hợp đồng";
            this.itemHopDongThueNgoai.Id = 903;
            this.itemHopDongThueNgoai.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_diploma_1_filled_50px;
            this.itemHopDongThueNgoai.Name = "itemHopDongThueNgoai";
            this.itemHopDongThueNgoai.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHopDongThueNgoai_ItemClick);
            // 
            // itemDeXuatDoiLich
            // 
            this.itemDeXuatDoiLich.Caption = "Đề xuất đổi lịch";
            this.itemDeXuatDoiLich.Id = 904;
            this.itemDeXuatDoiLich.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_classroom_filled_50px;
            this.itemDeXuatDoiLich.Name = "itemDeXuatDoiLich";
            this.itemDeXuatDoiLich.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDeXuatDoiLich_ItemClick);
            // 
            // itemDanhSachThanhCong
            // 
            this.itemDanhSachThanhCong.Caption = "Danh sách thành công";
            this.itemDanhSachThanhCong.Id = 905;
            this.itemDanhSachThanhCong.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.Checklist4;
            this.itemDanhSachThanhCong.Name = "itemDanhSachThanhCong";
            this.itemDanhSachThanhCong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDanhSachThanhCong_ItemClick);
            // 
            // itemDanhSachSuaChua
            // 
            this.itemDanhSachSuaChua.Caption = "Danh sách sửa chữa";
            this.itemDanhSachSuaChua.Id = 906;
            this.itemDanhSachSuaChua.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.Checklist4;
            this.itemDanhSachSuaChua.Name = "itemDanhSachSuaChua";
            this.itemDanhSachSuaChua.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDanhSachSuaChua_ItemClick);
            // 
            // barButtonItem36
            // 
            this.barButtonItem36.Caption = "Trạng thái duyệt đề xuất";
            this.barButtonItem36.Id = 907;
            this.barButtonItem36.Name = "barButtonItem36";
            // 
            // itemHdtnGanHetHan
            // 
            this.itemHdtnGanHetHan.Caption = "Hợp đồng gần hết hạn";
            this.itemHdtnGanHetHan.Id = 911;
            this.itemHdtnGanHetHan.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_diploma_1_50px_1;
            this.itemHdtnGanHetHan.Name = "itemHdtnGanHetHan";
            this.itemHdtnGanHetHan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHopDongThueNgoaiGanHetHan_ItemClick);
            // 
            // itemHdtnHetHan
            // 
            this.itemHdtnHetHan.Caption = "Hợp đồng đã hết hạn";
            this.itemHdtnHetHan.Id = 912;
            this.itemHdtnHetHan.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_agreement_50px;
            this.itemHdtnHetHan.Name = "itemHdtnHetHan";
            this.itemHdtnHetHan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHopDongThueNgoaiDaHetHan_ItemClick);
            // 
            // itemThanhLyHdtn
            // 
            this.itemThanhLyHdtn.Caption = "Thanh lý";
            this.itemThanhLyHdtn.Id = 913;
            this.itemThanhLyHdtn.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_policy_document_filled_50px;
            this.itemThanhLyHdtn.Name = "itemThanhLyHdtn";
            this.itemThanhLyHdtn.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThanhLy_ItemClick);
            // 
            // itemCongNoTienDatCoc
            // 
            this.itemCongNoTienDatCoc.Caption = "Công nợ tiền đặt cọc";
            this.itemCongNoTienDatCoc.Id = 914;
            this.itemCongNoTienDatCoc.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_pie_chart_report_filled_50px;
            this.itemCongNoTienDatCoc.Name = "itemCongNoTienDatCoc";
            this.itemCongNoTienDatCoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCongNoTienDatCoc_ItemClick);
            // 
            // barSubItem21
            // 
            this.barSubItem21.Caption = "Danh mục";
            this.barSubItem21.Id = 916;
            this.barSubItem21.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_sorting_answers_filled_50px;
            this.barSubItem21.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNoiDungCongViec),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNoiDungNhomCongViec)});
            this.barSubItem21.Name = "barSubItem21";
            // 
            // itemNoiDungCongViec
            // 
            this.itemNoiDungCongViec.Caption = "Nội dung công việc";
            this.itemNoiDungCongViec.Id = 917;
            this.itemNoiDungCongViec.ImageOptions.ImageIndex = 72;
            this.itemNoiDungCongViec.Name = "itemNoiDungCongViec";
            this.itemNoiDungCongViec.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNoiDungCongViec_ItemClick);
            // 
            // itemNoiDungNhomCongViec
            // 
            this.itemNoiDungNhomCongViec.Caption = "Nội dung nhóm công việc";
            this.itemNoiDungNhomCongViec.Id = 918;
            this.itemNoiDungNhomCongViec.ImageOptions.ImageIndex = 72;
            this.itemNoiDungNhomCongViec.Name = "itemNoiDungNhomCongViec";
            this.itemNoiDungNhomCongViec.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNoiDungNhomCongViec_ItemClick);
            // 
            // itemTruongTron
            // 
            this.itemTruongTron.Caption = "Trường Trộn";
            this.itemTruongTron.Id = 919;
            this.itemTruongTron.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_code_filled_50px;
            this.itemTruongTron.Name = "itemTruongTron";
            this.itemTruongTron.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTruongTron_ItemClick);
            // 
            // itemTruongTronHdtn
            // 
            this.itemTruongTronHdtn.Caption = "Trường trộn";
            this.itemTruongTronHdtn.Id = 920;
            this.itemTruongTronHdtn.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_code_filled_50px;
            this.itemTruongTronHdtn.Name = "itemTruongTronHdtn";
            this.itemTruongTronHdtn.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTruongTronHdtn_ItemClick);
            // 
            // itemBieuMauHdtn
            // 
            this.itemBieuMauHdtn.Caption = "Biểu mẫu";
            this.itemBieuMauHdtn.Id = 921;
            this.itemBieuMauHdtn.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_blog_filled_50px;
            this.itemBieuMauHdtn.Name = "itemBieuMauHdtn";
            this.itemBieuMauHdtn.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBieuMauHdtn_ItemClick);
            // 
            // btnPhanQuyenBieuMauHdtn
            // 
            this.btnPhanQuyenBieuMauHdtn.Caption = "Phân quyền biểu mẫu";
            this.btnPhanQuyenBieuMauHdtn.Id = 922;
            this.btnPhanQuyenBieuMauHdtn.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_graph_report_script_filled_50px;
            this.btnPhanQuyenBieuMauHdtn.Name = "btnPhanQuyenBieuMauHdtn";
            this.btnPhanQuyenBieuMauHdtn.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnPhanQuyenBieuMauHdtn_ItemClick);
            // 
            // itemCongNoDoiTac
            // 
            this.itemCongNoDoiTac.Caption = "Công nợ đối tác";
            this.itemCongNoDoiTac.Id = 924;
            this.itemCongNoDoiTac.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_general_ledger_filled_50px;
            this.itemCongNoDoiTac.Name = "itemCongNoDoiTac";
            this.itemCongNoDoiTac.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCongNoDoiTac_ItemClick);
            // 
            // itemBaoCaoThongKeKinhPhi
            // 
            this.itemBaoCaoThongKeKinhPhi.Caption = "Thống kê kinh phí";
            this.itemBaoCaoThongKeKinhPhi.Id = 925;
            this.itemBaoCaoThongKeKinhPhi.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_pie_chart_report_filled_50px;
            this.itemBaoCaoThongKeKinhPhi.Name = "itemBaoCaoThongKeKinhPhi";
            this.itemBaoCaoThongKeKinhPhi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoCaoThongKeKinhPhi_ItemClick);
            // 
            // itemCongNoTongHopHdtn
            // 
            this.itemCongNoTongHopHdtn.Caption = "Công nợ tổng hợp";
            this.itemCongNoTongHopHdtn.Id = 927;
            this.itemCongNoTongHopHdtn.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_general_ledger_filled_50px;
            this.itemCongNoTongHopHdtn.Name = "itemCongNoTongHopHdtn";
            this.itemCongNoTongHopHdtn.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCongNoTongHopHdtn_ItemClick);
            // 
            // itemTienTrinhThucHien
            // 
            this.itemTienTrinhThucHien.Caption = "Lịch sử thực hiện";
            this.itemTienTrinhThucHien.Id = 928;
            this.itemTienTrinhThucHien.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_work_light_filled_50px;
            this.itemTienTrinhThucHien.Name = "itemTienTrinhThucHien";
            this.itemTienTrinhThucHien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTienTrinhThucHien_ItemClick);
            // 
            // itemLichThanhToan
            // 
            this.itemLichThanhToan.Caption = "Lịch thanh toán";
            this.itemLichThanhToan.Id = 929;
            this.itemLichThanhToan.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_overtime_filled_50px;
            this.itemLichThanhToan.Name = "itemLichThanhToan";
            this.itemLichThanhToan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLichThanhToan_ItemClick);
            // 
            // itemDanhGiaHdtn
            // 
            this.itemDanhGiaHdtn.Caption = "Đánh giá";
            this.itemDanhGiaHdtn.Id = 930;
            this.itemDanhGiaHdtn.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_ballot_50px;
            this.itemDanhGiaHdtn.Name = "itemDanhGiaHdtn";
            this.itemDanhGiaHdtn.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDanhGiaHdtn_ItemClick);
            // 
            // itemPhanQuyenBieuDoMain
            // 
            this.itemPhanQuyenBieuDoMain.Caption = "Phân quyền biểu đồ Main";
            this.itemPhanQuyenBieuDoMain.Id = 931;
            this.itemPhanQuyenBieuDoMain.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_pie_chart_report_filled_50px;
            this.itemPhanQuyenBieuDoMain.Name = "itemPhanQuyenBieuDoMain";
            this.itemPhanQuyenBieuDoMain.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemPhanQuyenBieuDoMain_ItemClick);
            // 
            // itemCapNhatItemMain
            // 
            this.itemCapNhatItemMain.Caption = "Cập nhật ItemMain";
            this.itemCapNhatItemMain.Id = 932;
            this.itemCapNhatItemMain.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_shortlist_filled_50px;
            this.itemCapNhatItemMain.Name = "itemCapNhatItemMain";
            this.itemCapNhatItemMain.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCapNhatItemMain_ItemClick);
            // 
            // itemPhanQuyenItem
            // 
            this.itemPhanQuyenItem.Caption = "Phân quyền ItemMain";
            this.itemPhanQuyenItem.Id = 933;
            this.itemPhanQuyenItem.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_move_node_down_filled_50px;
            this.itemPhanQuyenItem.Name = "itemPhanQuyenItem";
            this.itemPhanQuyenItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ItemPhanQuyenItem_ItemClick);
            // 
            // itemCoPhanQuyen
            // 
            this.itemCoPhanQuyen.Caption = "Chưa Phân Quyền";
            this.itemCoPhanQuyen.Id = 934;
            this.itemCoPhanQuyen.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_genealogy_50px;
            this.itemCoPhanQuyen.Name = "itemCoPhanQuyen";
            this.itemCoPhanQuyen.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCoPhanQuyen_ItemClick);
            // 
            // itemTruongTronDatCocThiCong
            // 
            this.itemTruongTronDatCocThiCong.Caption = "Trường trộn";
            this.itemTruongTronDatCocThiCong.Id = 936;
            this.itemTruongTronDatCocThiCong.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_code_filled_50px;
            this.itemTruongTronDatCocThiCong.Name = "itemTruongTronDatCocThiCong";
            this.itemTruongTronDatCocThiCong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTruongTronDatCocThiCong_ItemClick);
            // 
            // itemBieuMauDatCocThiCong
            // 
            this.itemBieuMauDatCocThiCong.Caption = "Biểu mẫu";
            this.itemBieuMauDatCocThiCong.Id = 937;
            this.itemBieuMauDatCocThiCong.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_blog_filled_50px;
            this.itemBieuMauDatCocThiCong.Name = "itemBieuMauDatCocThiCong";
            this.itemBieuMauDatCocThiCong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBieuMauDatCocThiCong_ItemClick);
            // 
            // itemPhanQuyenBieuMauDatCocThiCong
            // 
            this.itemPhanQuyenBieuMauDatCocThiCong.Caption = "Phân quyền biểu mẫu";
            this.itemPhanQuyenBieuMauDatCocThiCong.Id = 938;
            this.itemPhanQuyenBieuMauDatCocThiCong.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_graph_report_script_filled_50px;
            this.itemPhanQuyenBieuMauDatCocThiCong.Name = "itemPhanQuyenBieuMauDatCocThiCong";
            this.itemPhanQuyenBieuMauDatCocThiCong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPhanQuyenBieuMauDatCocThiCong_ItemClick);
            // 
            // itemVanBanDen
            // 
            this.itemVanBanDen.Caption = "VĂN BẢN ĐẾN";
            this.itemVanBanDen.Id = 944;
            this.itemVanBanDen.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_open_document_50px;
            this.itemVanBanDen.Name = "itemVanBanDen";
            this.itemVanBanDen.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemVanBanDen_ItemClick);
            // 
            // itemVanBanDi
            // 
            this.itemVanBanDi.Caption = "VĂN BẢN ĐI";
            this.itemVanBanDi.Id = 945;
            this.itemVanBanDi.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_upload_document_50px;
            this.itemVanBanDi.Name = "itemVanBanDi";
            this.itemVanBanDi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemVanBanDi_ItemClick);
            // 
            // barSubItem22
            // 
            this.barSubItem22.Caption = "HƯỚNG DẪN";
            this.barSubItem22.Id = 946;
            this.barSubItem22.Name = "barSubItem22";
            // 
            // barSubItem23
            // 
            this.barSubItem23.Caption = "Danh mục";
            this.barSubItem23.Id = 951;
            this.barSubItem23.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_sorting_answers_filled_50px;
            this.barSubItem23.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem39),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem40)});
            this.barSubItem23.Name = "barSubItem23";
            // 
            // barButtonItem39
            // 
            this.barButtonItem39.Caption = "BrandName";
            this.barButtonItem39.Id = 952;
            this.barButtonItem39.ImageOptions.ImageIndex = 72;
            this.barButtonItem39.Name = "barButtonItem39";
            this.barButtonItem39.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem39_ItemClick);
            // 
            // barButtonItem40
            // 
            this.barButtonItem40.Caption = "Cài đặt nhân viên nhận SMS";
            this.barButtonItem40.Id = 953;
            this.barButtonItem40.ImageOptions.ImageIndex = 72;
            this.barButtonItem40.Name = "barButtonItem40";
            this.barButtonItem40.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem40_ItemClick);
            // 
            // barButtonItem41
            // 
            this.barButtonItem41.Caption = "Mẫu SMS";
            this.barButtonItem41.Id = 954;
            this.barButtonItem41.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.yeu_cau;
            this.barButtonItem41.Name = "barButtonItem41";
            this.barButtonItem41.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem41_ItemClick);
            // 
            // barButtonItem42
            // 
            this.barButtonItem42.Caption = "Biểu mẫu tòa nhà";
            this.barButtonItem42.Id = 955;
            this.barButtonItem42.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.Setting1;
            this.barButtonItem42.Name = "barButtonItem42";
            this.barButtonItem42.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem42_ItemClick);
            // 
            // itemSoDoPhanLo
            // 
            this.itemSoDoPhanLo.Caption = "Sơ đồ phân lô";
            this.itemSoDoPhanLo.Id = 956;
            this.itemSoDoPhanLo.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_collage_50px;
            this.itemSoDoPhanLo.Name = "itemSoDoPhanLo";
            this.itemSoDoPhanLo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemSoDoPhanLo_ItemClick);
            // 
            // barButtonItem43
            // 
            this.barButtonItem43.Caption = "HƯỚNG DẪN";
            this.barButtonItem43.Id = 957;
            this.barButtonItem43.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.Open2;
            this.barButtonItem43.Name = "barButtonItem43";
            this.barButtonItem43.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem43_ItemClick);
            // 
            // barSubItem24
            // 
            this.barSubItem24.Caption = "Mẫu sơ đồ phân lô";
            this.barSubItem24.Id = 958;
            this.barSubItem24.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem44),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem45),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem47),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem48),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem49),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem50)});
            this.barSubItem24.Name = "barSubItem24";
            // 
            // barButtonItem44
            // 
            this.barButtonItem44.Caption = "Mẫu 1";
            this.barButtonItem44.Id = 959;
            this.barButtonItem44.Name = "barButtonItem44";
            this.barButtonItem44.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem44_ItemClick);
            // 
            // barButtonItem45
            // 
            this.barButtonItem45.Caption = "Mẫu 2";
            this.barButtonItem45.Id = 960;
            this.barButtonItem45.Name = "barButtonItem45";
            this.barButtonItem45.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem45_ItemClick);
            // 
            // barButtonItem47
            // 
            this.barButtonItem47.Caption = "Mẫu 3";
            this.barButtonItem47.Id = 962;
            this.barButtonItem47.Name = "barButtonItem47";
            this.barButtonItem47.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem47_ItemClick);
            // 
            // barButtonItem48
            // 
            this.barButtonItem48.Caption = "Mẫu 4";
            this.barButtonItem48.Id = 963;
            this.barButtonItem48.Name = "barButtonItem48";
            this.barButtonItem48.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem48_ItemClick);
            // 
            // barButtonItem49
            // 
            this.barButtonItem49.Caption = "Mẫu 5";
            this.barButtonItem49.Id = 964;
            this.barButtonItem49.Name = "barButtonItem49";
            this.barButtonItem49.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem49_ItemClick);
            // 
            // barButtonItem50
            // 
            this.barButtonItem50.Caption = "Mẫu 6";
            this.barButtonItem50.Id = 970;
            this.barButtonItem50.Name = "barButtonItem50";
            this.barButtonItem50.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem50_ItemClick);
            // 
            // itemCauHinhPage
            // 
            this.itemCauHinhPage.Caption = "Cấu hình trang zalo";
            this.itemCauHinhPage.Id = 965;
            this.itemCauHinhPage.ImageOptions.ImageIndex = 68;
            this.itemCauHinhPage.Name = "itemCauHinhPage";
            this.itemCauHinhPage.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCauHinhPage_ItemClick);
            // 
            // itemDanhSachMau
            // 
            this.itemDanhSachMau.Caption = "Mẫu gửi khách hàng";
            this.itemDanhSachMau.Id = 966;
            this.itemDanhSachMau.ImageOptions.ImageIndex = 72;
            this.itemDanhSachMau.Name = "itemDanhSachMau";
            this.itemDanhSachMau.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDanhSachMau_ItemClick);
            // 
            // itemLayDanhSachKhachHang
            // 
            this.itemLayDanhSachKhachHang.Caption = "Khách hàng quan tâm";
            this.itemLayDanhSachKhachHang.Id = 967;
            this.itemLayDanhSachKhachHang.ImageOptions.ImageIndex = 72;
            this.itemLayDanhSachKhachHang.Name = "itemLayDanhSachKhachHang";
            this.itemLayDanhSachKhachHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLayDanhSachKhachHang_ItemClick);
            // 
            // IiemDanhsachkhachhangquantam
            // 
            this.IiemDanhsachkhachhangquantam.Caption = "Danh sách khách hàng";
            this.IiemDanhsachkhachhangquantam.Id = 968;
            this.IiemDanhsachkhachhangquantam.ImageOptions.ImageIndex = 72;
            this.IiemDanhsachkhachhangquantam.Name = "IiemDanhsachkhachhangquantam";
            this.IiemDanhsachkhachhangquantam.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.IiemDanhsachkhachhangquantam_ItemClick);
            // 
            // istemLichSuGuiSms
            // 
            this.istemLichSuGuiSms.Caption = "Lịch sử gửi khách hàng";
            this.istemLichSuGuiSms.Id = 969;
            this.istemLichSuGuiSms.ImageOptions.ImageIndex = 72;
            this.istemLichSuGuiSms.Name = "istemLichSuGuiSms";
            this.istemLichSuGuiSms.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.istemLichSuGuiSms_ItemClick);
            // 
            // itemDuTinh
            // 
            this.itemDuTinh.Caption = "Dự tính";
            this.itemDuTinh.Id = 971;
            this.itemDuTinh.ImageOptions.LargeImageIndex = 75;
            this.itemDuTinh.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDuTinhHDT),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDuTinhPQL),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDuTinhXe)});
            this.itemDuTinh.Name = "itemDuTinh";
            // 
            // itemDuTinhHDT
            // 
            this.itemDuTinhHDT.Caption = "BC Dự tính doanh thu hợp đồng thuê";
            this.itemDuTinhHDT.Id = 976;
            this.itemDuTinhHDT.ImageOptions.ImageIndex = 45;
            this.itemDuTinhHDT.Name = "itemDuTinhHDT";
            this.itemDuTinhHDT.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDuTinhHDT_ItemClick);
            // 
            // itemDuTinhPQL
            // 
            this.itemDuTinhPQL.Caption = "BC Dự tính doanh thu phí quản lý";
            this.itemDuTinhPQL.Id = 975;
            this.itemDuTinhPQL.ImageOptions.ImageIndex = 45;
            this.itemDuTinhPQL.Name = "itemDuTinhPQL";
            this.itemDuTinhPQL.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDuTinhPQL_ItemClick);
            // 
            // itemDuTinhXe
            // 
            this.itemDuTinhXe.Caption = "BC Dự tính doanh thu xe";
            this.itemDuTinhXe.Id = 974;
            this.itemDuTinhXe.ImageOptions.ImageIndex = 45;
            this.itemDuTinhXe.Name = "itemDuTinhXe";
            this.itemDuTinhXe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDuTinhXe_ItemClick);
            // 
            // barButtonItem51
            // 
            this.barButtonItem51.Caption = "BC Dự tính doanh thu hợp đồng thuê";
            this.barButtonItem51.Id = 972;
            this.barButtonItem51.Name = "barButtonItem51";
            // 
            // barButtonItem52
            // 
            this.barButtonItem52.Caption = "BC Dự tính phí quản lý";
            this.barButtonItem52.Id = 973;
            this.barButtonItem52.Name = "barButtonItem52";
            // 
            // itemNhanVienQuanTam
            // 
            this.itemNhanVienQuanTam.Caption = "Danh sách nhân viên quan tâm";
            this.itemNhanVienQuanTam.Id = 979;
            this.itemNhanVienQuanTam.ImageOptions.ImageIndex = 72;
            this.itemNhanVienQuanTam.Name = "itemNhanVienQuanTam";
            this.itemNhanVienQuanTam.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhanVienQuanTam_ItemClick);
            // 
            // itemMauGuiNhanVien
            // 
            this.itemMauGuiNhanVien.Caption = "Mẫu gửi nhân viên";
            this.itemMauGuiNhanVien.Id = 980;
            this.itemMauGuiNhanVien.ImageOptions.ImageIndex = 1;
            this.itemMauGuiNhanVien.Name = "itemMauGuiNhanVien";
            // 
            // itemLichSuGuiNhanVien
            // 
            this.itemLichSuGuiNhanVien.Caption = "Lịch sử gửi nhân viên";
            this.itemLichSuGuiNhanVien.Id = 981;
            this.itemLichSuGuiNhanVien.ImageOptions.ImageIndex = 77;
            this.itemLichSuGuiNhanVien.Name = "itemLichSuGuiNhanVien";
            this.itemLichSuGuiNhanVien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLichSuGuiNhanVien_ItemClick);
            // 
            // barButtonItem53
            // 
            this.barButtonItem53.Caption = "CẤU HÌNH API";
            this.barButtonItem53.Id = 982;
            this.barButtonItem53.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_api_settings_filled_50px;
            this.barButtonItem53.Name = "barButtonItem53";
            this.barButtonItem53.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem53_ItemClick);
            // 
            // barButtonItem54
            // 
            this.barButtonItem54.Caption = "CẤU HÌNH PAGE";
            this.barButtonItem54.Id = 983;
            this.barButtonItem54.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_webpage_filled_50px;
            this.barButtonItem54.Name = "barButtonItem54";
            this.barButtonItem54.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem54_ItemClick);
            // 
            // barButtonItem55
            // 
            this.barButtonItem55.Caption = "ĐĂNG KÝ NHÂN VIÊN";
            this.barButtonItem55.Id = 984;
            this.barButtonItem55.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_friends_filled_50px;
            this.barButtonItem55.Name = "barButtonItem55";
            this.barButtonItem55.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem55_ItemClick);
            // 
            // barButtonItem56
            // 
            this.barButtonItem56.Caption = "ĐĂNG KÝ KHÁCH HÀNG";
            this.barButtonItem56.Id = 985;
            this.barButtonItem56.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_multicultural_people_filled_50px;
            this.barButtonItem56.Name = "barButtonItem56";
            this.barButtonItem56.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem56_ItemClick);
            // 
            // barButtonItem57
            // 
            this.barButtonItem57.Caption = "TIN TỨC CHUNG";
            this.barButtonItem57.Id = 986;
            this.barButtonItem57.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_news_filled_50px;
            this.barButtonItem57.Name = "barButtonItem57";
            this.barButtonItem57.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem57_ItemClick);
            // 
            // barButtonItem58
            // 
            this.barButtonItem58.Caption = "TIN TỨC MỖI TÒA";
            this.barButtonItem58.Id = 987;
            this.barButtonItem58.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_google_news_filled_50px;
            this.barButtonItem58.Name = "barButtonItem58";
            this.barButtonItem58.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem58_ItemClick);
            // 
            // barButtonItem59
            // 
            this.barButtonItem59.Caption = "DỊCH VỤ APP";
            this.barButtonItem59.Id = 988;
            this.barButtonItem59.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_phonelink_setup_filled_50px;
            this.barButtonItem59.Name = "barButtonItem59";
            this.barButtonItem59.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem59_ItemClick);
            // 
            // barButtonItem60
            // 
            this.barButtonItem60.Caption = "DỊCH VỤ CỘNG THÊM";
            this.barButtonItem60.Id = 989;
            this.barButtonItem60.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_Taxi_Mobile_App_50px;
            this.barButtonItem60.Name = "barButtonItem60";
            this.barButtonItem60.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem60_ItemClick);
            // 
            // barButtonItem61
            // 
            this.barButtonItem61.Caption = "TIỆN ÍCH";
            this.barButtonItem61.Id = 990;
            this.barButtonItem61.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_sell_filled_50px;
            this.barButtonItem61.Name = "barButtonItem61";
            this.barButtonItem61.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem61_ItemClick);
            // 
            // barSubItem25
            // 
            this.barSubItem25.Caption = "Danh mục";
            this.barSubItem25.Id = 991;
            this.barSubItem25.ImageOptions.ImageUri.Uri = "AlignJustify;Office2013";
            this.barSubItem25.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNguonKH),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemQuyMo),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemLocation),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemHTTX),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNhuCauThue),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemCauHinhTiemNang),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemLoaiBaoGia),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTrangThaiCSKH),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemNgheNghiep)});
            this.barSubItem25.Name = "barSubItem25";
            // 
            // itemNguonKH
            // 
            this.itemNguonKH.Caption = "Nguồn khách hàng";
            this.itemNguonKH.Id = 1000;
            this.itemNguonKH.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemNguonKH.ImageOptions.Image")));
            this.itemNguonKH.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemNguonKH.ImageOptions.LargeImage")));
            this.itemNguonKH.Name = "itemNguonKH";
            this.itemNguonKH.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNguonKH_ItemClick);
            // 
            // itemQuyMo
            // 
            this.itemQuyMo.Caption = "Quy mô công ty";
            this.itemQuyMo.Id = 1001;
            this.itemQuyMo.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemQuyMo.ImageOptions.Image")));
            this.itemQuyMo.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemQuyMo.ImageOptions.LargeImage")));
            this.itemQuyMo.Name = "itemQuyMo";
            this.itemQuyMo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemQuyMo_ItemClick);
            // 
            // itemLocation
            // 
            this.itemLocation.Caption = "Vị trí địa lý";
            this.itemLocation.Id = 1003;
            this.itemLocation.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemLocation.ImageOptions.Image")));
            this.itemLocation.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemLocation.ImageOptions.LargeImage")));
            this.itemLocation.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemXa),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemHuyen),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTinh)});
            this.itemLocation.Name = "itemLocation";
            // 
            // itemXa
            // 
            this.itemXa.Caption = "Xã/Phường";
            this.itemXa.Id = 1009;
            this.itemXa.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemXa.ImageOptions.Image")));
            this.itemXa.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemXa.ImageOptions.LargeImage")));
            this.itemXa.Name = "itemXa";
            this.itemXa.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemXa_ItemClick);
            // 
            // itemHuyen
            // 
            this.itemHuyen.Caption = "Quận/ Huyện";
            this.itemHuyen.Id = 1010;
            this.itemHuyen.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemHuyen.ImageOptions.Image")));
            this.itemHuyen.Name = "itemHuyen";
            this.itemHuyen.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHuyen_ItemClick);
            // 
            // itemTinh
            // 
            this.itemTinh.Caption = "Tỉnh/Thành Phố";
            this.itemTinh.Id = 1011;
            this.itemTinh.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemTinh.ImageOptions.Image")));
            this.itemTinh.Name = "itemTinh";
            this.itemTinh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTinh_ItemClick);
            // 
            // itemHTTX
            // 
            this.itemHTTX.Caption = "Hình thức tiếp xúc";
            this.itemHTTX.Id = 1005;
            this.itemHTTX.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemHTTX.ImageOptions.Image")));
            this.itemHTTX.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemHTTX.ImageOptions.LargeImage")));
            this.itemHTTX.Name = "itemHTTX";
            this.itemHTTX.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHTTX_ItemClick);
            // 
            // itemNhuCauThue
            // 
            this.itemNhuCauThue.Caption = "Nhu cầu thuê";
            this.itemNhuCauThue.Id = 1006;
            this.itemNhuCauThue.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemNhuCauThue.ImageOptions.Image")));
            this.itemNhuCauThue.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemNhuCauThue.ImageOptions.LargeImage")));
            this.itemNhuCauThue.Name = "itemNhuCauThue";
            this.itemNhuCauThue.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNhuCauThue_ItemClick);
            // 
            // itemCauHinhTiemNang
            // 
            this.itemCauHinhTiemNang.Caption = "Cấu hình tiềm năng";
            this.itemCauHinhTiemNang.Id = 1007;
            this.itemCauHinhTiemNang.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemCauHinhTiemNang.ImageOptions.Image")));
            this.itemCauHinhTiemNang.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemCauHinhTiemNang.ImageOptions.LargeImage")));
            this.itemCauHinhTiemNang.Name = "itemCauHinhTiemNang";
            this.itemCauHinhTiemNang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCauHinhTiemNang_ItemClick);
            // 
            // itemLoaiBaoGia
            // 
            this.itemLoaiBaoGia.Caption = "Loại báo giá";
            this.itemLoaiBaoGia.Id = 1008;
            this.itemLoaiBaoGia.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemLoaiBaoGia.ImageOptions.Image")));
            this.itemLoaiBaoGia.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemLoaiBaoGia.ImageOptions.LargeImage")));
            this.itemLoaiBaoGia.Name = "itemLoaiBaoGia";
            this.itemLoaiBaoGia.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLoaiBaoGia_ItemClick);
            // 
            // itemTrangThaiCSKH
            // 
            this.itemTrangThaiCSKH.Caption = "Trạng thái";
            this.itemTrangThaiCSKH.Id = 1004;
            this.itemTrangThaiCSKH.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemTrangThaiCSKH.ImageOptions.Image")));
            this.itemTrangThaiCSKH.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemTrangThaiCSKH.ImageOptions.LargeImage")));
            this.itemTrangThaiCSKH.Name = "itemTrangThaiCSKH";
            this.itemTrangThaiCSKH.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTrangThaiCSKH_ItemClick);
            // 
            // itemNgheNghiep
            // 
            this.itemNgheNghiep.Caption = "Nghề nghiệp";
            this.itemNgheNghiep.Id = 1012;
            this.itemNgheNghiep.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemNgheNghiep.ImageOptions.Image")));
            this.itemNgheNghiep.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemNgheNghiep.ImageOptions.LargeImage")));
            this.itemNgheNghiep.Name = "itemNgheNghiep";
            this.itemNgheNghiep.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNgheNghiep_ItemClick);
            // 
            // itemCSKH
            // 
            this.itemCSKH.Caption = "Chăm sóc khách hàng";
            this.itemCSKH.Id = 992;
            this.itemCSKH.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemCSKH.ImageOptions.Image")));
            this.itemCSKH.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemCSKH.ImageOptions.LargeImage")));
            this.itemCSKH.Name = "itemCSKH";
            this.itemCSKH.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCSKH_ItemClick);
            // 
            // itemCSKHChinhThuc
            // 
            this.itemCSKHChinhThuc.Caption = "Khách hàng chính thức";
            this.itemCSKHChinhThuc.Id = 993;
            this.itemCSKHChinhThuc.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemCSKHChinhThuc.ImageOptions.Image")));
            this.itemCSKHChinhThuc.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemCSKHChinhThuc.ImageOptions.LargeImage")));
            this.itemCSKHChinhThuc.Name = "itemCSKHChinhThuc";
            this.itemCSKHChinhThuc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCSKHChinhThuc_ItemClick);
            // 
            // itemTraCuuDoanhNghiep
            // 
            this.itemTraCuuDoanhNghiep.Caption = "Tra cứu doanh nghiệp";
            this.itemTraCuuDoanhNghiep.Id = 994;
            this.itemTraCuuDoanhNghiep.ImageOptions.ImageUri.Uri = "Zoom;Office2013";
            this.itemTraCuuDoanhNghiep.Name = "itemTraCuuDoanhNghiep";
            this.itemTraCuuDoanhNghiep.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemTraCuuDoanhNghiep_ItemClick);
            // 
            // barButtonItem65
            // 
            this.barButtonItem65.Caption = "Danh mục";
            this.barButtonItem65.Id = 995;
            this.barButtonItem65.Name = "barButtonItem65";
            // 
            // barButtonItem66
            // 
            this.barButtonItem66.Caption = "Báo giá";
            this.barButtonItem66.Id = 996;
            this.barButtonItem66.Name = "barButtonItem66";
            // 
            // itemBaoGia
            // 
            this.itemBaoGia.Caption = "Báo giá";
            this.itemBaoGia.Id = 997;
            this.itemBaoGia.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemBaoGia.ImageOptions.Image")));
            this.itemBaoGia.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemBaoGia.ImageOptions.LargeImage")));
            this.itemBaoGia.Name = "itemBaoGia";
            this.itemBaoGia.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemBaoGia_ItemClick);
            // 
            // itemCoHoi
            // 
            this.itemCoHoi.Caption = "Cơ hội";
            this.itemCoHoi.Id = 998;
            this.itemCoHoi.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemCoHoi.ImageOptions.Image")));
            this.itemCoHoi.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemCoHoi.ImageOptions.LargeImage")));
            this.itemCoHoi.Name = "itemCoHoi";
            this.itemCoHoi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemCoHoi_ItemClick);
            // 
            // itemNguoiLienHe
            // 
            this.itemNguoiLienHe.Caption = "Người liên hệ";
            this.itemNguoiLienHe.Id = 1013;
            this.itemNguoiLienHe.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("itemNguoiLienHe.ImageOptions.Image")));
            this.itemNguoiLienHe.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemNguoiLienHe.ImageOptions.LargeImage")));
            this.itemNguoiLienHe.Name = "itemNguoiLienHe";
            this.itemNguoiLienHe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNguoiLienHe_ItemClick);
            // 
            // barButtonItem62
            // 
            this.barButtonItem62.Caption = "HÓA ĐƠN";
            this.barButtonItem62.Id = 1014;
            this.barButtonItem62.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_paid_bill_filled_50px;
            this.barButtonItem62.Name = "barButtonItem62";
            this.barButtonItem62.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem62_ItemClick);
            // 
            // barButtonItem63
            // 
            this.barButtonItem63.Caption = "CÔNG NỢ";
            this.barButtonItem63.Id = 1015;
            this.barButtonItem63.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_general_ledger_filled_50px;
            this.barButtonItem63.Name = "barButtonItem63";
            this.barButtonItem63.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem63_ItemClick);
            // 
            // barButtonItem64
            // 
            this.barButtonItem64.Caption = "BÁO CÁO CÔNG NỢ";
            this.barButtonItem64.Id = 1016;
            this.barButtonItem64.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_pie_chart_report_filled_50px;
            this.barButtonItem64.Name = "barButtonItem64";
            this.barButtonItem64.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem64_ItemClick);
            // 
            // barButtonItem67
            // 
            this.barButtonItem67.Caption = "BÁO CÁO ĐÃ THU";
            this.barButtonItem67.Id = 1017;
            this.barButtonItem67.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_pie_chart_report_filled_50px;
            this.barButtonItem67.Name = "barButtonItem67";
            this.barButtonItem67.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem67_ItemClick);
            // 
            // itemKhaoSat
            // 
            this.itemKhaoSat.Caption = "Phiếu khảo sát";
            this.itemKhaoSat.Id = 1018;
            this.itemKhaoSat.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemKhaoSat.ImageOptions.LargeImage")));
            this.itemKhaoSat.Name = "itemKhaoSat";
            this.itemKhaoSat.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKhaoSat_ItemClick);
            // 
            // itemThongKeKhaoSat
            // 
            this.itemThongKeKhaoSat.Caption = "Thống kê khảo sát";
            this.itemThongKeKhaoSat.Id = 1019;
            this.itemThongKeKhaoSat.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemThongKeKhaoSat.ImageOptions.LargeImage")));
            this.itemThongKeKhaoSat.ImageOptions.LargeImageIndex = 87;
            this.itemThongKeKhaoSat.Name = "itemThongKeKhaoSat";
            this.itemThongKeKhaoSat.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThongKeKhaoSat_ItemClick);
            // 
            // barButtonItem71
            // 
            this.barButtonItem71.Caption = "Danh sách";
            this.barButtonItem71.Id = 1023;
            this.barButtonItem71.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_shortlist_filled_50px;
            this.barButtonItem71.Name = "barButtonItem71";
            this.barButtonItem71.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem71_ItemClick);
            // 
            // barButtonItem72
            // 
            this.barButtonItem72.Caption = "NHÓM DỊCH VỤ";
            this.barButtonItem72.Id = 1024;
            this.barButtonItem72.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_phonelink_setup_filled_50px;
            this.barButtonItem72.Name = "barButtonItem72";
            this.barButtonItem72.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem72_ItemClick);
            // 
            // itemVer
            // 
            this.itemVer.Caption = "VERSION";
            this.itemVer.Id = 1025;
            this.itemVer.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.update__2_;
            this.itemVer.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.update__2_;
            this.itemVer.Name = "itemVer";
            this.itemVer.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemVer_ItemClick);
            // 
            // btnBCDienTichChoThue
            // 
            this.btnBCDienTichChoThue.Caption = "Báo cáo TH diện tích cho thuê";
            this.btnBCDienTichChoThue.Id = 1027;
            this.btnBCDienTichChoThue.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.ic_can_ho;
            this.btnBCDienTichChoThue.Name = "btnBCDienTichChoThue";
            this.btnBCDienTichChoThue.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btnBCDienTichChoThue.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnBCDienTichChoThue_ItemClick);
            // 
            // btnBaoCaoDienNuoc
            // 
            this.btnBaoCaoDienNuoc.Caption = "Báo cáo tổng hợp chỉ số điện";
            this.btnBaoCaoDienNuoc.Id = 1028;
            this.btnBaoCaoDienNuoc.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_genealogy_50px;
            this.btnBaoCaoDienNuoc.Name = "btnBaoCaoDienNuoc";
            this.btnBaoCaoDienNuoc.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btnBaoCaoDienNuoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnBaoCaoDienNuoc_ItemClick);
            // 
            // btnBCTongHopNuoc
            // 
            this.btnBCTongHopNuoc.Caption = "Báo cáo tổng hợp chỉ số nước";
            this.btnBCTongHopNuoc.Id = 1029;
            this.btnBCTongHopNuoc.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_genealogy_filled_50px;
            this.btnBCTongHopNuoc.Name = "btnBCTongHopNuoc";
            this.btnBCTongHopNuoc.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btnBCTongHopNuoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnBCTongHopNuoc_ItemClick);
            // 
            // btnLienHe
            // 
            this.btnLienHe.Caption = "LIÊN HỆ";
            this.btnLienHe.Id = 1030;
            this.btnLienHe.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_collaboration_filled_50px;
            this.btnLienHe.Name = "btnLienHe";
            this.btnLienHe.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btnLienHe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnLienHe_ItemClick);
            // 
            // btnBanner
            // 
            this.btnBanner.Caption = "Quản lý banner";
            this.btnBanner.Id = 1032;
            this.btnBanner.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_google_news_filled_50px;
            this.btnBanner.Name = "btnBanner";
            this.btnBanner.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btnBanner.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnBanner_ItemClick);
            // 
            // barButtonItem73
            // 
            this.barButtonItem73.Caption = "Điện Lạnh";
            this.barButtonItem73.Id = 1039;
            this.barButtonItem73.Name = "barButtonItem73";
            // 
            // btnMenuDVMoi
            // 
            this.btnMenuDVMoi.Caption = "Các dịch vụ khác";
            this.btnMenuDVMoi.Id = 1041;
            this.btnMenuDVMoi.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.ic_danh_muc;
            this.btnMenuDVMoi.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btnchuyendo),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnDSDangKyNV),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnLamNgoaiGio)});
            this.btnMenuDVMoi.Name = "btnMenuDVMoi";
            this.btnMenuDVMoi.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btnchuyendo
            // 
            this.btnchuyendo.Caption = "DS đăng ký vận chuyển";
            this.btnchuyendo.Id = 1042;
            this.btnchuyendo.Name = "btnchuyendo";
            this.btnchuyendo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnchuyendo_ItemClick);
            // 
            // btnDSDangKyNV
            // 
            this.btnDSDangKyNV.Caption = "DS đăng ký nhân viên";
            this.btnDSDangKyNV.Id = 1043;
            this.btnDSDangKyNV.Name = "btnDSDangKyNV";
            this.btnDSDangKyNV.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnDSDangKyNV_ItemClick);
            // 
            // btnLamNgoaiGio
            // 
            this.btnLamNgoaiGio.Caption = "DS yêu cầu ngoài giờ";
            this.btnLamNgoaiGio.Id = 1044;
            this.btnLamNgoaiGio.Name = "btnLamNgoaiGio";
            this.btnLamNgoaiGio.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnLamNgoaiGio_ItemClick);
            // 
            // itemKeHoachXitConTrung
            // 
            this.itemKeHoachXitConTrung.Caption = "KẾ HOẠCH";
            this.itemKeHoachXitConTrung.Id = 1046;
            this.itemKeHoachXitConTrung.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.Checklist4;
            this.itemKeHoachXitConTrung.Name = "itemKeHoachXitConTrung";
            this.itemKeHoachXitConTrung.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKeHoachXitConTrung_ItemClick);
            // 
            // itemLichBaoTri_Lich
            // 
            this.itemLichBaoTri_Lich.Caption = "LỊCH";
            this.itemLichBaoTri_Lich.Id = 1047;
            this.itemLichBaoTri_Lich.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_overtime_filled_50px;
            this.itemLichBaoTri_Lich.Name = "itemLichBaoTri_Lich";
            this.itemLichBaoTri_Lich.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLichBaoTri_Lich_ItemClick);
            // 
            // ribbonPage4
            // 
            this.ribbonPage4.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroupHeThong,
            this.ribbonGroupToaNha,
            this.ribbonPageGroup22,
            this.ribbonPageGroupBieuMau,
            this.groupGiaoDien,
            this.ribbonPageGroup24});
            this.ribbonPage4.ImageOptions.ImageIndex = 62;
            this.ribbonPage4.Name = "ribbonPage4";
            this.ribbonPage4.Tag = "Ribbon Page Hệ Thống";
            this.ribbonPage4.Text = "HỆ THỐNG";
            // 
            // ribbonPageGroupHeThong
            // 
            this.ribbonPageGroupHeThong.ItemLinks.Add(this.btnNgonNgu);
            this.ribbonPageGroupHeThong.ItemLinks.Add(this.itemConfigFTP);
            this.ribbonPageGroupHeThong.ItemLinks.Add(this.btnQuyTac);
            this.ribbonPageGroupHeThong.ItemLinks.Add(this.btnBanner);
            this.ribbonPageGroupHeThong.Name = "ribbonPageGroupHeThong";
            this.ribbonPageGroupHeThong.ShowCaptionButton = false;
            this.ribbonPageGroupHeThong.Text = "HỆ THỐNG";
            // 
            // ribbonGroupToaNha
            // 
            this.ribbonGroupToaNha.ItemLinks.Add(this.itemToaNha);
            this.ribbonGroupToaNha.Name = "ribbonGroupToaNha";
            this.ribbonGroupToaNha.ShowCaptionButton = false;
            this.ribbonGroupToaNha.Text = "DỰ ÁN";
            // 
            // ribbonPageGroup22
            // 
            this.ribbonPageGroup22.ItemLinks.Add(this.itemTaiLieu_Loai);
            this.ribbonPageGroup22.ItemLinks.Add(this.itemTruongTron);
            this.ribbonPageGroup22.ItemLinks.Add(this.itemTaiLieu);
            this.ribbonPageGroup22.ItemLinks.Add(this.itemCaiDatBieuMau);
            this.ribbonPageGroup22.Name = "ribbonPageGroup22";
            this.ribbonPageGroup22.ShowCaptionButton = false;
            this.ribbonPageGroup22.Text = "TÀI LIỆU";
            // 
            // ribbonPageGroupBieuMau
            // 
            this.ribbonPageGroupBieuMau.AllowTextClipping = false;
            this.ribbonPageGroupBieuMau.ItemLinks.Add(this.itemBieuMau);
            this.ribbonPageGroupBieuMau.Name = "ribbonPageGroupBieuMau";
            this.ribbonPageGroupBieuMau.ShowCaptionButton = false;
            this.ribbonPageGroupBieuMau.Text = "MẪU IN, BÁO CÁO";
            // 
            // groupGiaoDien
            // 
            this.groupGiaoDien.ItemLinks.Add(this.itemSkins);
            this.groupGiaoDien.Name = "groupGiaoDien";
            this.groupGiaoDien.ShowCaptionButton = false;
            this.groupGiaoDien.Tag = "Ribbon Group quản lý giao diện trên form main";
            this.groupGiaoDien.Text = "GIAO DIỆN";
            // 
            // ribbonPageGroup24
            // 
            this.ribbonPageGroup24.ItemLinks.Add(this.barButtonItem1);
            this.ribbonPageGroup24.ItemLinks.Add(this.barButtonItem2);
            this.ribbonPageGroup24.Name = "ribbonPageGroup24";
            this.ribbonPageGroup24.ShowCaptionButton = false;
            this.ribbonPageGroup24.Text = "KẾT THÚC";
            // 
            // ribbonPageToaNha
            // 
            this.ribbonPageToaNha.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroupToaNha,
            this.ribbonPageGroupNhanVien,
            this.ribbonPageGroup46,
            this.ribbonPageGroupMatBang,
            this.ribbonPageGroup39});
            this.ribbonPageToaNha.ImageOptions.ImageIndex = 63;
            this.ribbonPageToaNha.Name = "ribbonPageToaNha";
            this.ribbonPageToaNha.Tag = "Ribbon Page Dự án";
            this.ribbonPageToaNha.Text = "DỰ ÁN";
            // 
            // ribbonPageGroupToaNha
            // 
            this.ribbonPageGroupToaNha.ItemLinks.Add(this.barSubItemDanhMucToaNha);
            this.ribbonPageGroupToaNha.Name = "ribbonPageGroupToaNha";
            this.ribbonPageGroupToaNha.ShowCaptionButton = false;
            this.ribbonPageGroupToaNha.Text = "DANH MỤC";
            // 
            // ribbonPageGroupNhanVien
            // 
            this.ribbonPageGroupNhanVien.ItemLinks.Add(this.btnNhanVienManager);
            this.ribbonPageGroupNhanVien.ItemLinks.Add(this.btnPhanQuyenNV);
            this.ribbonPageGroupNhanVien.ItemLinks.Add(this.itemPhanQuyenBaoCao);
            this.ribbonPageGroupNhanVien.Name = "ribbonPageGroupNhanVien";
            this.ribbonPageGroupNhanVien.ShowCaptionButton = false;
            this.ribbonPageGroupNhanVien.Text = "NHÂN VIÊN";
            // 
            // ribbonPageGroup46
            // 
            this.ribbonPageGroup46.ItemLinks.Add(this.itemPhanQuyenBieuDoMain);
            this.ribbonPageGroup46.ItemLinks.Add(this.itemCapNhatItemMain);
            this.ribbonPageGroup46.ItemLinks.Add(this.itemPhanQuyenItem);
            this.ribbonPageGroup46.ItemLinks.Add(this.itemCoPhanQuyen);
            this.ribbonPageGroup46.Name = "ribbonPageGroup46";
            this.ribbonPageGroup46.Text = "ADMIN";
            // 
            // ribbonPageGroupMatBang
            // 
            this.ribbonPageGroupMatBang.ItemLinks.Add(this.itemMatBang);
            this.ribbonPageGroupMatBang.ItemLinks.Add(this.itemMatBang_View);
            this.ribbonPageGroupMatBang.ItemLinks.Add(this.itemPhanNhomMatBang);
            this.ribbonPageGroupMatBang.ItemLinks.Add(this.itemDienTichLapDay);
            this.ribbonPageGroupMatBang.ItemLinks.Add(this.itemSoDoPhanLo);
            this.ribbonPageGroupMatBang.ItemLinks.Add(this.barSubItem24);
            this.ribbonPageGroupMatBang.ItemLinks.Add(this.btnBCDienTichChoThue);
            this.ribbonPageGroupMatBang.Name = "ribbonPageGroupMatBang";
            this.ribbonPageGroupMatBang.ShowCaptionButton = false;
            this.ribbonPageGroupMatBang.Text = "CĂN HỘ";
            // 
            // ribbonPageGroup39
            // 
            this.ribbonPageGroup39.ItemLinks.Add(this.itemMoneyPurpose);
            this.ribbonPageGroup39.ItemLinks.Add(this.itemMoneyPurposeItems);
            this.ribbonPageGroup39.ItemLinks.Add(this.itemBaoCaoThongKeKinhPhi);
            this.ribbonPageGroup39.Name = "ribbonPageGroup39";
            this.ribbonPageGroup39.Text = "KINH PHÍ DỰ TRÙ";
            // 
            // ribbonPage3
            // 
            this.ribbonPage3.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup11,
            this.ribbonPageGroup35,
            this.ribbonPageGroup33,
            this.ribbonPageGroup12,
            this.ribbonPageGroup34,
            this.ribbonPageGroup25,
            this.ribbonPageGroup29});
            this.ribbonPage3.ImageOptions.ImageIndex = 82;
            this.ribbonPage3.Name = "ribbonPage3";
            this.ribbonPage3.Text = "BÀN GIAO MẶT BẰNG";
            // 
            // ribbonPageGroup11
            // 
            this.ribbonPageGroup11.ItemLinks.Add(this.barSubItem18);
            this.ribbonPageGroup11.Name = "ribbonPageGroup11";
            this.ribbonPageGroup11.Text = "DANH MỤC";
            // 
            // ribbonPageGroup35
            // 
            this.ribbonPageGroup35.ItemLinks.Add(this.itemAssetCategory);
            this.ribbonPageGroup35.Name = "ribbonPageGroup35";
            this.ribbonPageGroup35.Text = "TS";
            // 
            // ribbonPageGroup33
            // 
            this.ribbonPageGroup33.ItemLinks.Add(this.itemHangMuc);
            this.ribbonPageGroup33.ItemLinks.Add(this.itemChecklist);
            this.ribbonPageGroup33.ItemLinks.Add(this.itemChecklistToaNha);
            this.ribbonPageGroup33.Name = "ribbonPageGroup33";
            this.ribbonPageGroup33.Text = "CHECKLIST";
            // 
            // ribbonPageGroup12
            // 
            this.ribbonPageGroup12.ItemLinks.Add(this.itemHandover);
            this.ribbonPageGroup12.ItemLinks.Add(this.itemSchedule);
            this.ribbonPageGroup12.ItemLinks.Add(this.itemHandoverLocal);
            this.ribbonPageGroup12.ItemLinks.Add(this.itemHandoverHistory);
            this.ribbonPageGroup12.ItemLinks.Add(this.itemDanhSachThanhCong);
            this.ribbonPageGroup12.ItemLinks.Add(this.itemDanhSachSuaChua);
            this.ribbonPageGroup12.Name = "ribbonPageGroup12";
            this.ribbonPageGroup12.Text = "BÀN GIAO NỘI BỘ";
            // 
            // ribbonPageGroup34
            // 
            this.ribbonPageGroup34.ItemLinks.Add(this.itemPlanCustomer);
            this.ribbonPageGroup34.ItemLinks.Add(this.itemScheduleCustomer);
            this.ribbonPageGroup34.ItemLinks.Add(this.itemDeXuatDoiLich);
            this.ribbonPageGroup34.ItemLinks.Add(this.itemHandoverCustomer);
            this.ribbonPageGroup34.ItemLinks.Add(this.itemHistoryCustomer);
            this.ribbonPageGroup34.Name = "ribbonPageGroup34";
            this.ribbonPageGroup34.Text = "BÀN GIAO KHÁCH HÀNG";
            // 
            // ribbonPageGroup25
            // 
            this.ribbonPageGroup25.ItemLinks.Add(this.itemCarSetup);
            this.ribbonPageGroup25.ItemLinks.Add(this.itemCarSchedule);
            this.ribbonPageGroup25.Name = "ribbonPageGroup25";
            this.ribbonPageGroup25.Text = "PHƯƠNG TIỆN";
            // 
            // ribbonPageGroup29
            // 
            this.ribbonPageGroup29.ItemLinks.Add(this.itemNewsManager);
            this.ribbonPageGroup29.Name = "ribbonPageGroup29";
            this.ribbonPageGroup29.Text = "TT";
            // 
            // ribbonPageKhachHang
            // 
            this.ribbonPageKhachHang.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup18,
            this.ribbonPageGroupKhachHang,
            this.ribbonPageGroupCuDan,
            this.ribbonPageGroupYeuCau,
            this.ribbonPageGroup19,
            this.ribbonPageGroup5,
            this.ribbonPageGroup40,
            this.ribbonPageGroup27});
            this.ribbonPageKhachHang.ImageOptions.ImageIndex = 64;
            this.ribbonPageKhachHang.Name = "ribbonPageKhachHang";
            this.ribbonPageKhachHang.Tag = "Ribbon Page Khách Hàng";
            this.ribbonPageKhachHang.Text = "KHÁCH HÀNG";
            // 
            // ribbonPageGroup18
            // 
            this.ribbonPageGroup18.ItemLinks.Add(this.barDanhMuc);
            this.ribbonPageGroup18.Name = "ribbonPageGroup18";
            this.ribbonPageGroup18.ShowCaptionButton = false;
            this.ribbonPageGroup18.Text = "DANH MỤC";
            // 
            // ribbonPageGroupKhachHang
            // 
            this.ribbonPageGroupKhachHang.ItemLinks.Add(this.itemKhachHang);
            this.ribbonPageGroupKhachHang.Name = "ribbonPageGroupKhachHang";
            this.ribbonPageGroupKhachHang.ShowCaptionButton = false;
            this.ribbonPageGroupKhachHang.Text = "KHÁCH HÀNG";
            // 
            // ribbonPageGroupCuDan
            // 
            this.ribbonPageGroupCuDan.ItemLinks.Add(this.itemNhanKhau);
            this.ribbonPageGroupCuDan.Name = "ribbonPageGroupCuDan";
            this.ribbonPageGroupCuDan.ShowCaptionButton = false;
            this.ribbonPageGroupCuDan.Text = "CƯ DÂN";
            // 
            // ribbonPageGroupYeuCau
            // 
            this.ribbonPageGroupYeuCau.ItemLinks.Add(this.itemEmailSetup);
            this.ribbonPageGroupYeuCau.ItemLinks.Add(this.barSubItem9);
            this.ribbonPageGroupYeuCau.Name = "ribbonPageGroupYeuCau";
            this.ribbonPageGroupYeuCau.ShowCaptionButton = false;
            this.ribbonPageGroupYeuCau.Text = "YÊU CẦU";
            // 
            // ribbonPageGroup19
            // 
            this.ribbonPageGroup19.ItemLinks.Add(this.itemLenTan_List);
            this.ribbonPageGroup19.Name = "ribbonPageGroup19";
            this.ribbonPageGroup19.ShowCaptionButton = false;
            this.ribbonPageGroup19.Text = "LỄ TÂN";
            // 
            // ribbonPageGroup5
            // 
            this.ribbonPageGroup5.ItemLinks.Add(this.itemBieuDoMotToaNha);
            this.ribbonPageGroup5.ItemLinks.Add(this.itemTheoNhieuToaNha);
            this.ribbonPageGroup5.Name = "ribbonPageGroup5";
            this.ribbonPageGroup5.Text = "BÁO CÁO && THỐNG KÊ";
            // 
            // ribbonPageGroup40
            // 
            this.ribbonPageGroup40.ItemLinks.Add(this.itemKhachHangTiemNang);
            this.ribbonPageGroup40.Name = "ribbonPageGroup40";
            this.ribbonPageGroup40.Text = "CƠ HỘI";
            // 
            // ribbonPageGroup27
            // 
            this.ribbonPageGroup27.ItemLinks.Add(this.barSubItem25);
            this.ribbonPageGroup27.ItemLinks.Add(this.itemCSKH);
            this.ribbonPageGroup27.ItemLinks.Add(this.itemCSKHChinhThuc);
            this.ribbonPageGroup27.ItemLinks.Add(this.itemNguoiLienHe);
            this.ribbonPageGroup27.ItemLinks.Add(this.itemTraCuuDoanhNghiep);
            this.ribbonPageGroup27.ItemLinks.Add(this.itemCoHoi);
            this.ribbonPageGroup27.ItemLinks.Add(this.itemBaoGia);
            this.ribbonPageGroup27.Name = "ribbonPageGroup27";
            this.ribbonPageGroup27.Text = "CHĂM SÓC KHÁCH HÀNG";
            // 
            // ribbonPage7
            // 
            this.ribbonPage7.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup49,
            this.ribbonPageGroup50,
            this.ribbonPageGroup51,
            this.ribbonPageGroup52,
            this.ribbonPageGroup53,
            this.ribbonPageGroup54,
            this.ribbonPageGroup55,
            this.ribbonPageGroup57});
            this.ribbonPage7.ImageOptions.ImageIndex = 86;
            this.ribbonPage7.Name = "ribbonPage7";
            this.ribbonPage7.Text = "APP";
            // 
            // ribbonPageGroup49
            // 
            this.ribbonPageGroup49.ItemLinks.Add(this.barButtonItem53);
            this.ribbonPageGroup49.ItemLinks.Add(this.barButtonItem54);
            this.ribbonPageGroup49.ItemLinks.Add(this.itemVer);
            this.ribbonPageGroup49.Name = "ribbonPageGroup49";
            this.ribbonPageGroup49.Text = "CẤU HÌNH";
            // 
            // ribbonPageGroup50
            // 
            this.ribbonPageGroup50.ItemLinks.Add(this.barButtonItem55);
            this.ribbonPageGroup50.ItemLinks.Add(this.barButtonItem56);
            this.ribbonPageGroup50.Name = "ribbonPageGroup50";
            this.ribbonPageGroup50.Text = "ĐĂNG KÝ";
            // 
            // ribbonPageGroup51
            // 
            this.ribbonPageGroup51.ItemLinks.Add(this.barButtonItem57);
            this.ribbonPageGroup51.ItemLinks.Add(this.barButtonItem58);
            this.ribbonPageGroup51.Name = "ribbonPageGroup51";
            this.ribbonPageGroup51.Text = "TIN TỨC";
            // 
            // ribbonPageGroup52
            // 
            this.ribbonPageGroup52.ItemLinks.Add(this.barButtonItem59);
            this.ribbonPageGroup52.ItemLinks.Add(this.barButtonItem60);
            this.ribbonPageGroup52.Name = "ribbonPageGroup52";
            this.ribbonPageGroup52.Text = "DỊCH VỤ";
            // 
            // ribbonPageGroup53
            // 
            this.ribbonPageGroup53.ItemLinks.Add(this.barButtonItem61);
            this.ribbonPageGroup53.Name = "ribbonPageGroup53";
            this.ribbonPageGroup53.Text = "TIỆN ÍCH";
            // 
            // ribbonPageGroup54
            // 
            this.ribbonPageGroup54.ItemLinks.Add(this.barButtonItem62);
            this.ribbonPageGroup54.ItemLinks.Add(this.barButtonItem63);
            this.ribbonPageGroup54.Name = "ribbonPageGroup54";
            this.ribbonPageGroup54.Text = "CÔNG NỢ APP";
            // 
            // ribbonPageGroup55
            // 
            this.ribbonPageGroup55.ItemLinks.Add(this.barButtonItem64);
            this.ribbonPageGroup55.ItemLinks.Add(this.barButtonItem67);
            this.ribbonPageGroup55.Name = "ribbonPageGroup55";
            this.ribbonPageGroup55.Text = "BÁO CÁO";
            // 
            // ribbonPageGroup57
            // 
            this.ribbonPageGroup57.ItemLinks.Add(this.barButtonItem72);
            this.ribbonPageGroup57.ItemLinks.Add(this.btnLienHe);
            this.ribbonPageGroup57.Name = "ribbonPageGroup57";
            this.ribbonPageGroup57.Text = "QUẢN LÝ DỊCH VỤ";
            // 
            // ribbonPage6
            // 
            this.ribbonPage6.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup36,
            this.ribbonPageGroup37,
            this.ribbonPageGroup38});
            this.ribbonPage6.ImageOptions.ImageIndex = 85;
            this.ribbonPage6.Name = "ribbonPage6";
            this.ribbonPage6.Text = "HỢP ĐỒNG THUÊ";
            // 
            // ribbonPageGroup36
            // 
            this.ribbonPageGroup36.ItemLinks.Add(this.barSubItem5);
            this.ribbonPageGroup36.ItemLinks.Add(this.itemBieuMauHDT);
            this.ribbonPageGroup36.ItemLinks.Add(this.itemTruongTronHDT);
            this.ribbonPageGroup36.ItemLinks.Add(this.itemMauHDT);
            this.ribbonPageGroup36.Name = "ribbonPageGroup36";
            this.ribbonPageGroup36.Text = "HỢP ĐỒNG";
            // 
            // ribbonPageGroup37
            // 
            this.ribbonPageGroup37.ItemLinks.Add(this.itemLapHoaDonHDT);
            this.ribbonPageGroup37.ItemLinks.Add(this.itemHoaDonHDT);
            this.ribbonPageGroup37.ItemLinks.Add(this.itemHoaDonDaXoaHDT);
            this.ribbonPageGroup37.ItemLinks.Add(this.itemCongNoHDT);
            this.ribbonPageGroup37.Name = "ribbonPageGroup37";
            this.ribbonPageGroup37.Text = "HÓA ĐƠN";
            // 
            // ribbonPageGroup38
            // 
            this.ribbonPageGroup38.ItemLinks.Add(this.itemPhieuThuHDT);
            this.ribbonPageGroup38.ItemLinks.Add(this.itemPhieuThuDaXoaHDT);
            this.ribbonPageGroup38.ItemLinks.Add(this.itemPhieuDieuChuyenHDT);
            this.ribbonPageGroup38.ItemLinks.Add(this.itemPhieuChiHDT);
            this.ribbonPageGroup38.ItemLinks.Add(this.itemPhieuKhauTruHDT);
            this.ribbonPageGroup38.Name = "ribbonPageGroup38";
            this.ribbonPageGroup38.Text = "SỔ QUỸ";
            // 
            // ribbonPage9
            // 
            this.ribbonPage9.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup58});
            this.ribbonPage9.ImageOptions.ImageIndex = 69;
            this.ribbonPage9.Name = "ribbonPage9";
            this.ribbonPage9.Text = "LỊCH BẢO TRÌ";
            // 
            // ribbonPageGroup58
            // 
            this.ribbonPageGroup58.ItemLinks.Add(this.itemKeHoachXitConTrung);
            this.ribbonPageGroup58.ItemLinks.Add(this.itemLichBaoTri_Lich);
            this.ribbonPageGroup58.ItemLinks.Add(this.itemLichBaoTri_KhachHangXacNhan);
            this.ribbonPageGroup58.Name = "ribbonPageGroup58";
            this.ribbonPageGroup58.Text = "LỊCH BẢO TRÌ MÁY LẠNH && CÔN TRÙNG";
            // 
            // pageHopDongThueNgoai
            // 
            this.pageHopDongThueNgoai.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup44,
            this.ribbonPageGroup41,
            this.groupHopDong,
            this.groupTienTrinh,
            this.ribbonPageGroup43,
            this.ribbonPageGroup42,
            this.ribbonPageGroup45,
            this.groupBaoCaoHdtn});
            this.pageHopDongThueNgoai.ImageOptions.ImageIndex = 84;
            this.pageHopDongThueNgoai.Name = "pageHopDongThueNgoai";
            this.pageHopDongThueNgoai.Text = "HỢP ĐỒNG THUÊ NGOÀI";
            // 
            // ribbonPageGroup44
            // 
            this.ribbonPageGroup44.ItemLinks.Add(this.barSubItem21);
            this.ribbonPageGroup44.Name = "ribbonPageGroup44";
            this.ribbonPageGroup44.Text = "DANH MỤC";
            // 
            // ribbonPageGroup41
            // 
            this.ribbonPageGroup41.ItemLinks.Add(this.itemDanhSachCongViec);
            this.ribbonPageGroup41.Name = "ribbonPageGroup41";
            this.ribbonPageGroup41.Text = "CV";
            // 
            // groupHopDong
            // 
            this.groupHopDong.ItemLinks.Add(this.itemHopDongThueNgoai);
            this.groupHopDong.ItemLinks.Add(this.itemHdtnGanHetHan);
            this.groupHopDong.ItemLinks.Add(this.itemHdtnHetHan);
            this.groupHopDong.Name = "groupHopDong";
            this.groupHopDong.Text = "HỢP ĐỒNG/ PHỤ LỤC";
            // 
            // groupTienTrinh
            // 
            this.groupTienTrinh.ItemLinks.Add(this.itemLichThanhToan);
            this.groupTienTrinh.ItemLinks.Add(this.itemTienTrinhThucHien);
            this.groupTienTrinh.Name = "groupTienTrinh";
            this.groupTienTrinh.Text = "TIẾN TRÌNH";
            // 
            // ribbonPageGroup43
            // 
            this.ribbonPageGroup43.ItemLinks.Add(this.itemThanhLyHdtn);
            this.ribbonPageGroup43.Name = "ribbonPageGroup43";
            this.ribbonPageGroup43.Text = "TL";
            // 
            // ribbonPageGroup42
            // 
            this.ribbonPageGroup42.ItemLinks.Add(this.itemDanhGiaHdtn);
            this.ribbonPageGroup42.Name = "ribbonPageGroup42";
            this.ribbonPageGroup42.Text = "ĐÁNH GIÁ";
            // 
            // ribbonPageGroup45
            // 
            this.ribbonPageGroup45.ItemLinks.Add(this.itemTruongTronHdtn);
            this.ribbonPageGroup45.ItemLinks.Add(this.itemBieuMauHdtn);
            this.ribbonPageGroup45.ItemLinks.Add(this.btnPhanQuyenBieuMauHdtn);
            this.ribbonPageGroup45.Name = "ribbonPageGroup45";
            this.ribbonPageGroup45.Text = "BIỂU MẪU";
            // 
            // groupBaoCaoHdtn
            // 
            this.groupBaoCaoHdtn.ItemLinks.Add(this.itemCongNoDoiTac);
            this.groupBaoCaoHdtn.ItemLinks.Add(this.itemCongNoTongHopHdtn);
            this.groupBaoCaoHdtn.Name = "groupBaoCaoHdtn";
            this.groupBaoCaoHdtn.Text = "BÁO CÁO";
            // 
            // ribbonPageDichVu
            // 
            this.ribbonPageDichVu.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroupDMDV,
            this.GroupDichVuKhac,
            this.ribbonPageGroup14,
            this.ribbonPageGroupDienNuoc,
            this.ribbonPageGroup23,
            this.ribbonPageGroupHoaDon,
            this.ribbonPageGroup15});
            this.ribbonPageDichVu.ImageOptions.ImageIndex = 65;
            this.ribbonPageDichVu.Name = "ribbonPageDichVu";
            this.ribbonPageDichVu.Tag = "Ribbon Page Dịch Vụ";
            this.ribbonPageDichVu.Text = "DỊCH VỤ";
            // 
            // ribbonPageGroupDMDV
            // 
            this.ribbonPageGroupDMDV.ItemLinks.Add(this.groupDanhMucDV, true);
            this.ribbonPageGroupDMDV.Name = "ribbonPageGroupDMDV";
            this.ribbonPageGroupDMDV.ShowCaptionButton = false;
            this.ribbonPageGroupDMDV.Text = "DANH MỤC";
            // 
            // GroupDichVuKhac
            // 
            this.GroupDichVuKhac.ItemLinks.Add(this.itemDichVuKhac);
            this.GroupDichVuKhac.ItemLinks.Add(this.btnMenuDVMoi);
            this.GroupDichVuKhac.Name = "GroupDichVuKhac";
            this.GroupDichVuKhac.ShowCaptionButton = false;
            this.GroupDichVuKhac.Text = "CƠ BẢN";
            // 
            // ribbonPageGroup14
            // 
            this.ribbonPageGroup14.ItemLinks.Add(this.itemTheXe);
            this.ribbonPageGroup14.ItemLinks.Add(this.itemTheXeDaXoa);
            this.ribbonPageGroup14.Name = "ribbonPageGroup14";
            this.ribbonPageGroup14.ShowCaptionButton = false;
            this.ribbonPageGroup14.State = DevExpress.XtraBars.Ribbon.RibbonPageGroupState.Expanded;
            this.ribbonPageGroup14.Text = "GIỮ XE";
            // 
            // ribbonPageGroupDienNuoc
            // 
            this.ribbonPageGroupDienNuoc.ItemLinks.Add(this.barSubItem7);
            this.ribbonPageGroupDienNuoc.ItemLinks.Add(this.barSubItem8);
            this.ribbonPageGroupDienNuoc.ItemLinks.Add(this.btnGas);
            this.ribbonPageGroupDienNuoc.Name = "ribbonPageGroupDienNuoc";
            this.ribbonPageGroupDienNuoc.ShowCaptionButton = false;
            this.ribbonPageGroupDienNuoc.Text = "ĐIỆN - NƯỚC - GAS";
            // 
            // ribbonPageGroup23
            // 
            this.ribbonPageGroup23.ItemLinks.Add(this.itemTheThangMay);
            this.ribbonPageGroup23.Name = "ribbonPageGroup23";
            this.ribbonPageGroup23.Text = "TM";
            // 
            // ribbonPageGroupHoaDon
            // 
            this.ribbonPageGroupHoaDon.ItemLinks.Add(this.itemHoaDonAdd);
            this.ribbonPageGroupHoaDon.ItemLinks.Add(this.btnHoaDon);
            this.ribbonPageGroupHoaDon.ItemLinks.Add(this.itemHoaDonDaXoa);
            this.ribbonPageGroupHoaDon.ItemLinks.Add(this.itemNhacNoKhachHang);
            this.ribbonPageGroupHoaDon.Name = "ribbonPageGroupHoaDon";
            this.ribbonPageGroupHoaDon.ShowCaptionButton = false;
            this.ribbonPageGroupHoaDon.Text = "HÓA ĐƠN";
            // 
            // ribbonPageGroup15
            // 
            this.ribbonPageGroup15.ItemLinks.Add(this.itemGroupBcCongNoTongHop);
            this.ribbonPageGroup15.ItemLinks.Add(this.barSubItem12);
            this.ribbonPageGroup15.ItemLinks.Add(this.barSubItem13);
            this.ribbonPageGroup15.ItemLinks.Add(this.barSubItem14);
            this.ribbonPageGroup15.ItemLinks.Add(this.barSubItem15);
            this.ribbonPageGroup15.ItemLinks.Add(this.barSubItem16);
            this.ribbonPageGroup15.ItemLinks.Add(this.itemDichVuThongKeKhac);
            this.ribbonPageGroup15.ItemLinks.Add(this.itemDuTinh);
            this.ribbonPageGroup15.ItemLinks.Add(this.btnBaoCaoDienNuoc);
            this.ribbonPageGroup15.ItemLinks.Add(this.btnBCTongHopNuoc);
            this.ribbonPageGroup15.Name = "ribbonPageGroup15";
            this.ribbonPageGroup15.ShowCaptionButton = false;
            this.ribbonPageGroup15.Text = "BÁO CÁO - THỐNG KÊ";
            // 
            // pageSoQuy
            // 
            this.pageSoQuy.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup8,
            this.ribbonPageGroup1,
            this.ribbonPageGroup2,
            this.ribbonPageGroup13,
            this.pageGroupChuyenTienvaKyQuy,
            this.ribbonPageGroup17});
            this.pageSoQuy.ImageOptions.ImageIndex = 66;
            this.pageSoQuy.Name = "pageSoQuy";
            this.pageSoQuy.Text = "SỔ QUỸ";
            // 
            // ribbonPageGroup8
            // 
            this.ribbonPageGroup8.ItemLinks.Add(this.barSubItem19);
            this.ribbonPageGroup8.Name = "ribbonPageGroup8";
            this.ribbonPageGroup8.Text = "DANH MỤC";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.itemPhieuThu);
            this.ribbonPageGroup1.ItemLinks.Add(this.itemPhieuThuDaXoa);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.ShowCaptionButton = false;
            this.ribbonPageGroup1.Text = "PHIẾU THU";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.ItemLinks.Add(this.itemPhieuChi);
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.ShowCaptionButton = false;
            this.ribbonPageGroup2.Text = "PC";
            // 
            // ribbonPageGroup13
            // 
            this.ribbonPageGroup13.ItemLinks.Add(this.itemKhauTru);
            this.ribbonPageGroup13.Name = "ribbonPageGroup13";
            this.ribbonPageGroup13.ShowCaptionButton = false;
            this.ribbonPageGroup13.Text = "KT";
            // 
            // pageGroupChuyenTienvaKyQuy
            // 
            this.pageGroupChuyenTienvaKyQuy.ItemLinks.Add(this.itemDSChuyenTien);
            this.pageGroupChuyenTienvaKyQuy.ItemLinks.Add(this.itemPhieuChiKyQuy);
            this.pageGroupChuyenTienvaKyQuy.Name = "pageGroupChuyenTienvaKyQuy";
            this.pageGroupChuyenTienvaKyQuy.Text = "CT";
            // 
            // ribbonPageGroup17
            // 
            this.ribbonPageGroup17.ItemLinks.Add(this.itemReport_PhieuThu);
            this.ribbonPageGroup17.ItemLinks.Add(this.itemReport_PhieuChi);
            this.ribbonPageGroup17.ItemLinks.Add(this.itemReport_PhieuKhauTru);
            this.ribbonPageGroup17.ItemLinks.Add(this.itemCongNoDongTien);
            this.ribbonPageGroup17.ItemLinks.Add(this.itemBcThuChiTm);
            this.ribbonPageGroup17.ItemLinks.Add(this.itemBaoCaoDaThu);
            this.ribbonPageGroup17.Name = "ribbonPageGroup17";
            this.ribbonPageGroup17.ShowCaptionButton = false;
            this.ribbonPageGroup17.Text = "THỐNG KÊ - BÁO CÁO";
            // 
            // ribbonPage5
            // 
            this.ribbonPage5.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup30,
            this.ribbonPageGroup56,
            this.ribbonPageGroup31,
            this.ribbonPageGroup9,
            this.ribbonPageGroup10,
            this.groupBieuMauDatCocThiCong,
            this.ribbonPageGroup32});
            this.ribbonPage5.ImageOptions.ImageIndex = 83;
            this.ribbonPage5.Name = "ribbonPage5";
            this.ribbonPage5.Text = "ĐẶT CỌC THI CÔNG";
            // 
            // ribbonPageGroup30
            // 
            this.ribbonPageGroup30.ItemLinks.Add(this.barSubItem20);
            this.ribbonPageGroup30.Name = "ribbonPageGroup30";
            this.ribbonPageGroup30.Text = "DANH MỤC";
            // 
            // ribbonPageGroup56
            // 
            this.ribbonPageGroup56.ItemLinks.Add(this.barButtonItem71);
            this.ribbonPageGroup56.Name = "ribbonPageGroup56";
            this.ribbonPageGroup56.Text = "ĐĂNG KÝ";
            // 
            // ribbonPageGroup31
            // 
            this.ribbonPageGroup31.ItemLinks.Add(this.itemHopDongDatCoc);
            this.ribbonPageGroup31.Name = "ribbonPageGroup31";
            this.ribbonPageGroup31.Text = "HD";
            // 
            // ribbonPageGroup9
            // 
            this.ribbonPageGroup9.ItemLinks.Add(this.itemDepositManager);
            this.ribbonPageGroup9.ItemLinks.Add(this.itemDeposit);
            this.ribbonPageGroup9.ItemLinks.Add(this.itemDepositDelete);
            this.ribbonPageGroup9.Name = "ribbonPageGroup9";
            this.ribbonPageGroup9.Text = "PHIẾU THU";
            // 
            // ribbonPageGroup10
            // 
            this.ribbonPageGroup10.ItemLinks.Add(this.itemWithDraw);
            this.ribbonPageGroup10.Name = "ribbonPageGroup10";
            this.ribbonPageGroup10.Text = "PC";
            // 
            // groupBieuMauDatCocThiCong
            // 
            this.groupBieuMauDatCocThiCong.ItemLinks.Add(this.itemTruongTronDatCocThiCong);
            this.groupBieuMauDatCocThiCong.ItemLinks.Add(this.itemBieuMauDatCocThiCong);
            this.groupBieuMauDatCocThiCong.ItemLinks.Add(this.itemPhanQuyenBieuMauDatCocThiCong);
            this.groupBieuMauDatCocThiCong.Name = "groupBieuMauDatCocThiCong";
            this.groupBieuMauDatCocThiCong.Text = "BIỂU MẪU";
            // 
            // ribbonPageGroup32
            // 
            this.ribbonPageGroup32.ItemLinks.Add(this.itemSoQuyDatCoc);
            this.ribbonPageGroup32.ItemLinks.Add(this.itemCongNoTienDatCoc);
            this.ribbonPageGroup32.Name = "ribbonPageGroup32";
            this.ribbonPageGroup32.Text = "BÁO CÁO";
            // 
            // ribbonPageTaiSan
            // 
            this.ribbonPageTaiSan.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup3,
            this.pageGroupVatTu,
            this.ribbonPageGroup7});
            this.ribbonPageTaiSan.ImageOptions.ImageIndex = 67;
            this.ribbonPageTaiSan.Name = "ribbonPageTaiSan";
            this.ribbonPageTaiSan.Text = "TÀI SẢN";
            // 
            // ribbonPageGroup3
            // 
            this.ribbonPageGroup3.ItemLinks.Add(this.barSubItem10);
            this.ribbonPageGroup3.ItemLinks.Add(this.ItemCaiDatHeThongChoToaNha);
            this.ribbonPageGroup3.ItemLinks.Add(this.itemDMTenTaiSan);
            this.ribbonPageGroup3.ItemLinks.Add(this.itemDMChiTietTaiSan);
            this.ribbonPageGroup3.Name = "ribbonPageGroup3";
            this.ribbonPageGroup3.Text = "TÀI SẢN";
            // 
            // pageGroupVatTu
            // 
            this.pageGroupVatTu.ItemLinks.Add(this.barDanhMucVatTu);
            this.pageGroupVatTu.ItemLinks.Add(this.itemDeXuatMuaHang);
            this.pageGroupVatTu.ItemLinks.Add(this.itemDanhSachMuaHang);
            this.pageGroupVatTu.ItemLinks.Add(this.itemVTNhapKho);
            this.pageGroupVatTu.ItemLinks.Add(this.itemVTXuatKho);
            this.pageGroupVatTu.ItemLinks.Add(this.itemXuatKhoSuDung);
            this.pageGroupVatTu.ItemLinks.Add(this.itemVTTonKho);
            this.pageGroupVatTu.Name = "pageGroupVatTu";
            this.pageGroupVatTu.Text = "VẬT TƯ";
            // 
            // ribbonPageGroup7
            // 
            this.ribbonPageGroup7.ItemLinks.Add(this.barSubQuanLyHoSo);
            this.ribbonPageGroup7.ItemLinks.Add(this.itemQuanLyHoSo);
            this.ribbonPageGroup7.ItemLinks.Add(this.itemVanBanDen);
            this.ribbonPageGroup7.ItemLinks.Add(this.itemVanBanDi);
            this.ribbonPageGroup7.Name = "ribbonPageGroup7";
            this.ribbonPageGroup7.Text = "QUẢN LÝ HỒ SƠ";
            // 
            // ribbonPageVanHanh
            // 
            this.ribbonPageVanHanh.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageDMVanHanh,
            this.ribbonPageGroup4,
            this.pageSuaChua,
            this.ribbonPageGroupVanHanh,
            this.ribbonPageGroup6,
            this.ribbonPageGroup_BaoCaoVanHanh});
            this.ribbonPageVanHanh.ImageOptions.ImageIndex = 68;
            this.ribbonPageVanHanh.Name = "ribbonPageVanHanh";
            this.ribbonPageVanHanh.Text = "VẬN HÀNH";
            // 
            // ribbonPageDMVanHanh
            // 
            this.ribbonPageDMVanHanh.ItemLinks.Add(this.ItemDMVanHanh);
            this.ribbonPageDMVanHanh.ItemLinks.Add(this.itemDanhMucProfile);
            this.ribbonPageDMVanHanh.ItemLinks.Add(this.itemGanProfileChoToaNha);
            this.ribbonPageDMVanHanh.ItemLinks.Add(this.itemProfile);
            this.ribbonPageDMVanHanh.ItemLinks.Add(this.itemGanProFileChoHeThong);
            this.ribbonPageDMVanHanh.Name = "ribbonPageDMVanHanh";
            this.ribbonPageDMVanHanh.Text = "DANH MỤC";
            // 
            // ribbonPageGroup4
            // 
            this.ribbonPageGroup4.ItemLinks.Add(this.itemGiaoNhanCa);
            this.ribbonPageGroup4.ItemLinks.Add(this.itemBangPhanCong);
            this.ribbonPageGroup4.ItemLinks.Add(this.itemLichTruc);
            this.ribbonPageGroup4.ItemLinks.Add(this.itemDeXuatDoiCa);
            this.ribbonPageGroup4.ItemLinks.Add(this.itemDeXuatThayCa);
            this.ribbonPageGroup4.Name = "ribbonPageGroup4";
            this.ribbonPageGroup4.Text = "CA TRỰC";
            // 
            // pageSuaChua
            // 
            this.pageSuaChua.ItemLinks.Add(this.itemDeXuatSuaChua);
            this.pageSuaChua.Name = "pageSuaChua";
            this.pageSuaChua.Text = "SC";
            // 
            // ribbonPageGroupVanHanh
            // 
            this.ribbonPageGroupVanHanh.ItemLinks.Add(this.ItemKeHoachVanHanh);
            this.ribbonPageGroupVanHanh.ItemLinks.Add(this.itemPhieuVanHanh);
            this.ribbonPageGroupVanHanh.Name = "ribbonPageGroupVanHanh";
            this.ribbonPageGroupVanHanh.Text = "VẬN HÀNH";
            // 
            // ribbonPageGroup6
            // 
            this.ribbonPageGroup6.ItemLinks.Add(this.itemViewKeHoachBaoTri);
            this.ribbonPageGroup6.ItemLinks.Add(this.itemViewPhieuBaoTri);
            this.ribbonPageGroup6.ItemLinks.Add(this.itemVHKeHoachBaoTri);
            this.ribbonPageGroup6.ItemLinks.Add(this.itemVHPhieuBaoTri);
            this.ribbonPageGroup6.Name = "ribbonPageGroup6";
            this.ribbonPageGroup6.Text = "BẢO TRÌ";
            // 
            // ribbonPageGroup_BaoCaoVanHanh
            // 
            this.ribbonPageGroup_BaoCaoVanHanh.ItemLinks.Add(this.itemThongKeSoLieuVH);
            this.ribbonPageGroup_BaoCaoVanHanh.Name = "ribbonPageGroup_BaoCaoVanHanh";
            this.ribbonPageGroup_BaoCaoVanHanh.Text = "BÁO CÁO";
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup20,
            this.ribbonPageGroup21,
            this.itemPageKhaoSat});
            this.ribbonPage2.ImageOptions.ImageIndex = 69;
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "LỊCH LÀM VIỆC";
            // 
            // ribbonPageGroup20
            // 
            this.ribbonPageGroup20.ItemLinks.Add(this.itemPhanLoaiLich);
            this.ribbonPageGroup20.ItemLinks.Add(this.itemThoiDiemLich);
            this.ribbonPageGroup20.ItemLinks.Add(this.itemDanhSachLich);
            this.ribbonPageGroup20.Name = "ribbonPageGroup20";
            this.ribbonPageGroup20.ShowCaptionButton = false;
            this.ribbonPageGroup20.Text = "LỊCH HẸN";
            // 
            // ribbonPageGroup21
            // 
            this.ribbonPageGroup21.ItemLinks.Add(this.itemPhanLoai);
            this.ribbonPageGroup21.ItemLinks.Add(this.itemTrangThai);
            this.ribbonPageGroup21.ItemLinks.Add(this.itemMucDo);
            this.ribbonPageGroup21.ItemLinks.Add(this.itemTienDo);
            this.ribbonPageGroup21.ItemLinks.Add(this.itemThemMoi);
            this.ribbonPageGroup21.ItemLinks.Add(this.itemDanhSach);
            this.ribbonPageGroup21.Name = "ribbonPageGroup21";
            this.ribbonPageGroup21.ShowCaptionButton = false;
            this.ribbonPageGroup21.Text = "NHIỆM VỤ";
            // 
            // itemPageKhaoSat
            // 
            this.itemPageKhaoSat.ItemLinks.Add(this.itemKhaoSat);
            this.itemPageKhaoSat.ItemLinks.Add(this.itemThongKeKhaoSat);
            this.itemPageKhaoSat.Name = "itemPageKhaoSat";
            this.itemPageKhaoSat.Text = "Khảo sát";
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup16,
            this.ribbonPageGroup26,
            this.ribbonPageGroup_SMS,
            this.ribbonPageGroup28,
            this.ribbonPageGroup48});
            this.ribbonPage1.ImageOptions.ImageIndex = 70;
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "MARKETING";
            // 
            // ribbonPageGroup16
            // 
            this.ribbonPageGroup16.ItemLinks.Add(this.itemEmail_Config);
            this.ribbonPageGroup16.ItemLinks.Add(this.itemEmail_SettingStaff);
            this.ribbonPageGroup16.ItemLinks.Add(this.itemEmail_Category);
            this.ribbonPageGroup16.ItemLinks.Add(this.itemEmail_Templates);
            this.ribbonPageGroup16.ItemLinks.Add(this.barButtonItem29);
            this.ribbonPageGroup16.Name = "ribbonPageGroup16";
            this.ribbonPageGroup16.ShowCaptionButton = false;
            this.ribbonPageGroup16.Text = "EMAIL";
            // 
            // ribbonPageGroup26
            // 
            this.ribbonPageGroup26.ItemLinks.Add(this.itemMauMail);
            this.ribbonPageGroup26.ItemLinks.Add(this.itemDanhSachNhan);
            this.ribbonPageGroup26.ItemLinks.Add(this.itemThuongHieu);
            this.ribbonPageGroup26.ItemLinks.Add(this.itemDanhSachGui);
            this.ribbonPageGroup26.ItemLinks.Add(this.itemCheckTaiKhoan);
            this.ribbonPageGroup26.Name = "ribbonPageGroup26";
            this.ribbonPageGroup26.Text = "AMAZON";
            this.ribbonPageGroup26.Visible = false;
            // 
            // ribbonPageGroup_SMS
            // 
            this.ribbonPageGroup_SMS.ItemLinks.Add(this.itemSMSSoDuTaiKhoan);
            this.ribbonPageGroup_SMS.ItemLinks.Add(this.itemSMSLichSu);
            this.ribbonPageGroup_SMS.ItemLinks.Add(this.itemSMS_Mau);
            this.ribbonPageGroup_SMS.Name = "ribbonPageGroup_SMS";
            this.ribbonPageGroup_SMS.Text = "SMS";
            // 
            // ribbonPageGroup28
            // 
            this.ribbonPageGroup28.ItemLinks.Add(this.barSubItem23);
            this.ribbonPageGroup28.ItemLinks.Add(this.barButtonItem41);
            this.ribbonPageGroup28.ItemLinks.Add(this.barButtonItem42);
            this.ribbonPageGroup28.Name = "ribbonPageGroup28";
            this.ribbonPageGroup28.Text = "SMS dịch vụ";
            // 
            // ribbonPageGroup48
            // 
            this.ribbonPageGroup48.ItemLinks.Add(this.itemCauHinhPage);
            this.ribbonPageGroup48.ItemLinks.Add(this.itemDanhSachMau);
            this.ribbonPageGroup48.ItemLinks.Add(this.IiemDanhsachkhachhangquantam);
            this.ribbonPageGroup48.ItemLinks.Add(this.istemLichSuGuiSms);
            this.ribbonPageGroup48.ItemLinks.Add(this.itemNhanVienQuanTam);
            this.ribbonPageGroup48.ItemLinks.Add(this.itemLichSuGuiNhanVien);
            this.ribbonPageGroup48.Name = "ribbonPageGroup48";
            this.ribbonPageGroup48.Text = "Zalo khách hàng";
            // 
            // pageAbout
            // 
            this.pageAbout.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.pgAbout,
            this.ribbonPageGroup47});
            this.pageAbout.ImageOptions.ImageIndex = 71;
            this.pageAbout.Name = "pageAbout";
            this.pageAbout.Text = "TRỢ GIÚP";
            // 
            // pgAbout
            // 
            this.pgAbout.ItemLinks.Add(this.barButtonItem5);
            this.pgAbout.ItemLinks.Add(this.btnSupport);
            this.pgAbout.ItemLinks.Add(this.barButtonItem31);
            this.pgAbout.Name = "pgAbout";
            this.pgAbout.ShowCaptionButton = false;
            this.pgAbout.Text = "HỖ TRỢ";
            // 
            // ribbonPageGroup47
            // 
            this.ribbonPageGroup47.ItemLinks.Add(this.barButtonItem43);
            this.ribbonPageGroup47.Name = "ribbonPageGroup47";
            this.ribbonPageGroup47.Text = "HƯỚNG DẪN SỬ DỤNG";
            // 
            // ribbonStatusBar
            // 
            this.ribbonStatusBar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ribbonStatusBar.ItemLinks.Add(this.barStaticItemLogin);
            this.ribbonStatusBar.ItemLinks.Add(this.itemCopyRight, false, "", "", true);
            this.ribbonStatusBar.Location = new System.Drawing.Point(0, 587);
            this.ribbonStatusBar.Name = "ribbonStatusBar";
            this.ribbonStatusBar.Ribbon = this.ribbon;
            this.ribbonStatusBar.Size = new System.Drawing.Size(1376, 31);
            // 
            // repositoryItemPopupContainerEdit1
            // 
            this.repositoryItemPopupContainerEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemPopupContainerEdit1.Name = "repositoryItemPopupContainerEdit1";
            // 
            // btnGiayBao
            // 
            this.btnGiayBao.Caption = "Hóa đơn";
            this.btnGiayBao.Id = 106;
            this.btnGiayBao.ImageOptions.LargeImageIndex = 1;
            this.btnGiayBao.Name = "btnGiayBao";
            this.btnGiayBao.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnGiayBao_ItemClick);
            // 
            // barButtonItem7
            // 
            this.barButtonItem7.Caption = "Hóa đơn";
            this.barButtonItem7.Id = 106;
            this.barButtonItem7.ImageOptions.LargeImageIndex = 1;
            this.barButtonItem7.Name = "barButtonItem7";
            // 
            // dockManager1
            // 
            this.dockManager1.AutoHideContainers.AddRange(new DevExpress.XtraBars.Docking.AutoHideContainer[] {
            this.hideContainerRight});
            this.dockManager1.DockingOptions.HideImmediatelyOnAutoHide = true;
            this.dockManager1.Form = this;
            this.dockManager1.Images = this.imageCollection1;
            this.dockManager1.MenuManager = this.ribbon;
            this.dockManager1.TopZIndexControls.AddRange(new string[] {
            "DevExpress.XtraBars.BarDockControl",
            "DevExpress.XtraBars.StandaloneBarDockControl",
            "System.Windows.Forms.StatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonStatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonControl"});
            // 
            // hideContainerRight
            // 
            this.hideContainerRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(236)))), ((int)(((byte)(239)))));
            this.hideContainerRight.Controls.Add(this.dockPanelThongBao);
            this.hideContainerRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.hideContainerRight.Location = new System.Drawing.Point(1356, 146);
            this.hideContainerRight.Name = "hideContainerRight";
            this.hideContainerRight.Size = new System.Drawing.Size(20, 441);
            // 
            // dockPanelThongBao
            // 
            this.dockPanelThongBao.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(236)))), ((int)(((byte)(239)))));
            this.dockPanelThongBao.Appearance.Options.UseBackColor = true;
            this.dockPanelThongBao.Controls.Add(this.dockPanel2_Container);
            this.dockPanelThongBao.Dock = DevExpress.XtraBars.Docking.DockingStyle.Right;
            this.dockPanelThongBao.ID = new System.Guid("875144f8-36bb-4117-ad60-d2bd172d5462");
            this.dockPanelThongBao.Location = new System.Drawing.Point(1053, 146);
            this.dockPanelThongBao.Name = "dockPanelThongBao";
            this.dockPanelThongBao.Options.AllowDockBottom = false;
            this.dockPanelThongBao.Options.AllowDockFill = false;
            this.dockPanelThongBao.Options.AllowDockLeft = false;
            this.dockPanelThongBao.Options.AllowDockTop = false;
            this.dockPanelThongBao.Options.ShowCloseButton = false;
            this.dockPanelThongBao.Options.ShowMaximizeButton = false;
            this.dockPanelThongBao.OriginalSize = new System.Drawing.Size(303, 200);
            this.dockPanelThongBao.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Right;
            this.dockPanelThongBao.SavedIndex = 0;
            this.dockPanelThongBao.Size = new System.Drawing.Size(303, 441);
            this.dockPanelThongBao.Text = "Thông báo";
            this.dockPanelThongBao.Visibility = DevExpress.XtraBars.Docking.DockVisibility.AutoHide;
            // 
            // dockPanel2_Container
            // 
            this.dockPanel2_Container.Controls.Add(this.splitContainerControlRightPanel);
            this.dockPanel2_Container.Location = new System.Drawing.Point(5, 23);
            this.dockPanel2_Container.Name = "dockPanel2_Container";
            this.dockPanel2_Container.Size = new System.Drawing.Size(294, 414);
            this.dockPanel2_Container.TabIndex = 0;
            // 
            // splitContainerControlRightPanel
            // 
            this.splitContainerControlRightPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControlRightPanel.Horizontal = false;
            this.splitContainerControlRightPanel.Location = new System.Drawing.Point(0, 0);
            this.splitContainerControlRightPanel.Name = "splitContainerControlRightPanel";
            this.splitContainerControlRightPanel.Panel1.Controls.Add(this.gcthongbao);
            this.splitContainerControlRightPanel.Panel1.Text = "pnlThongBao";
            this.splitContainerControlRightPanel.Panel2.Controls.Add(this.gcNhacViec);
            this.splitContainerControlRightPanel.Panel2.Text = "Panel2";
            this.splitContainerControlRightPanel.Size = new System.Drawing.Size(294, 414);
            this.splitContainerControlRightPanel.SplitterPosition = 207;
            this.splitContainerControlRightPanel.TabIndex = 0;
            this.splitContainerControlRightPanel.Text = "splitContainerControl1";
            // 
            // gcthongbao
            // 
            this.gcthongbao.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcthongbao.Location = new System.Drawing.Point(0, 0);
            this.gcthongbao.MainView = this.grvthongbao;
            this.gcthongbao.MenuManager = this.ribbon;
            this.gcthongbao.Name = "gcthongbao";
            this.gcthongbao.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit1});
            this.gcthongbao.Size = new System.Drawing.Size(294, 207);
            this.gcthongbao.TabIndex = 5;
            this.gcthongbao.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvthongbao});
            // 
            // grvthongbao
            // 
            this.grvthongbao.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn2});
            this.grvthongbao.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.None;
            this.grvthongbao.GridControl = this.gcthongbao;
            this.grvthongbao.Name = "grvthongbao";
            this.grvthongbao.OptionsCustomization.AllowGroup = false;
            this.grvthongbao.OptionsCustomization.AllowRowSizing = true;
            this.grvthongbao.OptionsMenu.EnableFooterMenu = false;
            this.grvthongbao.OptionsMenu.EnableGroupPanelMenu = false;
            this.grvthongbao.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.grvthongbao.OptionsSelection.EnableAppearanceFocusedRow = false;
            this.grvthongbao.OptionsSelection.UseIndicatorForSelection = false;
            this.grvthongbao.OptionsView.EnableAppearanceEvenRow = true;
            this.grvthongbao.OptionsView.EnableAppearanceOddRow = true;
            this.grvthongbao.OptionsView.RowAutoHeight = true;
            this.grvthongbao.OptionsView.ShowColumnHeaders = false;
            this.grvthongbao.OptionsView.ShowGroupPanel = false;
            this.grvthongbao.OptionsView.ShowIndicator = false;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "Nội dung";
            this.gridColumn2.ColumnEdit = this.repositoryItemMemoEdit1;
            this.gridColumn2.FieldName = "NoiDung";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.FixedWidth = true;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 0;
            this.gridColumn2.Width = 20;
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.AllowHtmlDraw = DevExpress.Utils.DefaultBoolean.True;
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            this.repositoryItemMemoEdit1.ReadOnly = true;
            // 
            // gcNhacViec
            // 
            this.gcNhacViec.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcNhacViec.Location = new System.Drawing.Point(0, 0);
            this.gcNhacViec.MainView = this.grvNhacViec;
            this.gcNhacViec.MenuManager = this.ribbon;
            this.gcNhacViec.Name = "gcNhacViec";
            this.gcNhacViec.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.checkIsRead,
            this.txtNoiDung,
            this.repositoryItemPopupContainerEdit1});
            this.gcNhacViec.Size = new System.Drawing.Size(294, 202);
            this.gcNhacViec.TabIndex = 0;
            this.gcNhacViec.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvNhacViec});
            // 
            // grvNhacViec
            // 
            this.grvNhacViec.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colDD,
            this.gridColumn3});
            this.grvNhacViec.GridControl = this.gcNhacViec;
            this.grvNhacViec.Name = "grvNhacViec";
            this.grvNhacViec.OptionsCustomization.AllowGroup = false;
            this.grvNhacViec.OptionsView.ShowGroupPanel = false;
            this.grvNhacViec.OptionsView.ShowIndicator = false;
            this.grvNhacViec.CellValueChanging += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.grvNhacViec_CellValueChanging);
            // 
            // colDD
            // 
            this.colDD.Caption = "Đã đọc";
            this.colDD.ColumnEdit = this.checkIsRead;
            this.colDD.Name = "colDD";
            this.colDD.Visible = true;
            this.colDD.VisibleIndex = 0;
            this.colDD.Width = 50;
            // 
            // checkIsRead
            // 
            this.checkIsRead.AutoHeight = false;
            this.checkIsRead.Caption = "";
            this.checkIsRead.Name = "checkIsRead";
            this.checkIsRead.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.checkIsRead.CheckedChanged += new System.EventHandler(this.checkIsRead_CheckedChanged);
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "Nội dung";
            this.gridColumn3.ColumnEdit = this.repositoryItemPopupContainerEdit1;
            this.gridColumn3.FieldName = "NoiDung";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.ReadOnly = true;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 1;
            this.gridColumn3.Width = 227;
            // 
            // txtNoiDung
            // 
            this.txtNoiDung.Name = "txtNoiDung";
            // 
            // timerCapNhat
            // 
            this.timerCapNhat.Interval = 300000;
            this.timerCapNhat.Tick += new System.EventHandler(this.timerCapNhat_Tick);
            // 
            // itemThamQuan
            // 
            this.itemThamQuan.Caption = "Quản lý";
            this.itemThamQuan.Id = 2;
            this.itemThamQuan.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("itemThamQuan.ImageOptions.LargeImage")));
            this.itemThamQuan.ImageOptions.LargeImageIndex = 1;
            this.itemThamQuan.Name = "itemThamQuan";
            this.itemThamQuan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThamQuan_ItemClick);
            // 
            // barSubItem17
            // 
            this.barSubItem17.Caption = "barSubItem17";
            this.barSubItem17.Id = 165;
            this.barSubItem17.Name = "barSubItem17";
            // 
            // alertControlNhacViec
            // 
            this.alertControlNhacViec.AllowHotTrack = false;
            this.alertControlNhacViec.AllowHtmlText = true;
            this.alertControlNhacViec.AutoHeight = true;
            alertButton1.Hint = "Đánh dấu thông báo này đã đọc";
            alertButton1.ImageOptions.ImageDownIndex = 8;
            alertButton1.ImageOptions.ImageIndex = 9;
            alertButton1.Name = "alertButtonIsRead";
            alertButton1.Style = DevExpress.XtraBars.Alerter.AlertButtonStyle.CheckButton;
            alertButton1.Visible = false;
            alertButton2.Hint = "Xem yêu cầu";
            alertButton2.ImageOptions.ImageDownIndex = 8;
            alertButton2.ImageOptions.ImageIndex = 9;
            alertButton2.Name = "btnView";
            this.alertControlNhacViec.Buttons.Add(alertButton1);
            this.alertControlNhacViec.Buttons.Add(alertButton2);
            this.alertControlNhacViec.Images = this.imageCollection1;
            this.alertControlNhacViec.AlertClick += new DevExpress.XtraBars.Alerter.AlertClickEventHandler(this.alertControlNhacViec_AlertClick);
            // 
            // pageMain
            // 
            this.pageMain.AppearancePage.HeaderActive.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.pageMain.AppearancePage.HeaderActive.Options.UseFont = true;
            this.pageMain.ClosePageButtonShowMode = DevExpress.XtraTab.ClosePageButtonShowMode.InActiveTabPageHeaderAndOnMouseHover;
            this.pageMain.HeaderButtons = ((DevExpress.XtraTab.TabButtons)((((DevExpress.XtraTab.TabButtons.Prev | DevExpress.XtraTab.TabButtons.Next) 
            | DevExpress.XtraTab.TabButtons.Close) 
            | DevExpress.XtraTab.TabButtons.Default)));
            this.pageMain.MdiParent = this;
            this.pageMain.SetNextMdiChildMode = DevExpress.XtraTabbedMdi.SetNextMdiChildMode.TabControl;
            // 
            // alertControlKeHoachBaoTri
            // 
            this.alertControlKeHoachBaoTri.AllowHotTrack = false;
            this.alertControlKeHoachBaoTri.AllowHtmlText = true;
            this.alertControlKeHoachBaoTri.AutoHeight = true;
            alertButton3.Hint = "Đánh dấu thông báo này đã đọc";
            alertButton3.ImageOptions.ImageDownIndex = 8;
            alertButton3.ImageOptions.ImageIndex = 9;
            alertButton3.Name = "alertButtonIsRead";
            alertButton3.Style = DevExpress.XtraBars.Alerter.AlertButtonStyle.CheckButton;
            this.alertControlKeHoachBaoTri.Buttons.Add(alertButton3);
            this.alertControlKeHoachBaoTri.Images = this.imageCollection1;
            this.alertControlKeHoachBaoTri.AlertClick += new DevExpress.XtraBars.Alerter.AlertClickEventHandler(this.alertControlKeHoachBaoTri_AlertClick);
            // 
            // timerReminder
            // 
            this.timerReminder.Interval = 6000;
            this.timerReminder.Tick += new System.EventHandler(this.timerReminder_Tick);
            // 
            // alctAltert
            // 
            this.alctAltert.AllowHtmlText = true;
            this.alctAltert.AutoFormDelay = 10000;
            this.alctAltert.AutoHeight = true;
            alertButton4.Hint = "Không nhắc lại";
            alertButton4.ImageOptions.ImageIndex = 53;
            alertButton4.Name = "Stop";
            alertButton5.Hint = "Tắt nhạc";
            alertButton5.ImageOptions.ImageIndex = 51;
            alertButton5.Name = "Muted";
            alertButton6.Hint = "Đóng";
            alertButton6.ImageOptions.ImageIndex = 54;
            alertButton6.Name = "Close";
            this.alctAltert.Buttons.Add(alertButton4);
            this.alctAltert.Buttons.Add(alertButton5);
            this.alctAltert.Buttons.Add(alertButton6);
            this.alctAltert.Images = this.imageCollection1;
            this.alctAltert.AlertClick += new DevExpress.XtraBars.Alerter.AlertClickEventHandler(this.alctAltert_AlertClick);
            this.alctAltert.ButtonClick += new DevExpress.XtraBars.Alerter.AlertButtonClickEventHandler(this.alctAltert_ButtonClick);
            this.alctAltert.FormClosing += new DevExpress.XtraBars.Alerter.AlertFormClosingEventHandler(this.alctAltert_FormClosing);
            // 
            // ribbonPage8
            // 
            this.ribbonPage8.Name = "ribbonPage8";
            this.ribbonPage8.Text = "ribbonPage8";
            // 
            // barButtonItem46
            // 
            this.barButtonItem46.Caption = "3";
            this.barButtonItem46.Id = 961;
            this.barButtonItem46.Name = "barButtonItem46";
            this.barButtonItem46.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem46_ItemClick);
            // 
            // btnDangKyChuyenDo
            // 
            this.btnDangKyChuyenDo.Caption = "DS đăng ký vận chuyển";
            this.btnDangKyChuyenDo.Id = 1036;
            this.btnDangKyChuyenDo.ImageOptions.Image = global::LandSoftBuildingMain.Properties.Resources.icons8_in_transit_filled_50px;
            this.btnDangKyChuyenDo.Name = "btnDangKyChuyenDo";
            // 
            // itemLichBaoTri_KhachHangXacNhan
            // 
            this.itemLichBaoTri_KhachHangXacNhan.Caption = "KHÁCH HÀNG XÁC NHẬN";
            this.itemLichBaoTri_KhachHangXacNhan.Id = 1048;
            this.itemLichBaoTri_KhachHangXacNhan.ImageOptions.LargeImage = global::LandSoftBuildingMain.Properties.Resources.icons8_paid_bill_filled_50px;
            this.itemLichBaoTri_KhachHangXacNhan.Name = "itemLichBaoTri_KhachHangXacNhan";
            this.itemLichBaoTri_KhachHangXacNhan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemLichBaoTri_KhachHangXacNhan_ItemClick);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1376, 618);
            this.Controls.Add(this.hideContainerRight);
            this.Controls.Add(this.ribbonStatusBar);
            this.Controls.Add(this.ribbon);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Name = "frmMain";
            this.Ribbon = this.ribbon;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.StatusBar = this.ribbonStatusBar;
            this.Text = "LANDSOFT BUILDING";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.SizeChanged += new System.EventHandler(this.frmMain_SizeChanged);
            ((System.ComponentModel.ISupportInitialize)(this.ribbon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.applicationMenu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPopupContainerEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dockManager1)).EndInit();
            this.hideContainerRight.ResumeLayout(false);
            this.dockPanelThongBao.ResumeLayout(false);
            this.dockPanel2_Container.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControlRightPanel)).EndInit();
            this.splitContainerControlRightPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gcthongbao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvthongbao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcNhacViec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvNhacViec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkIsRead)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNoiDung)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pageMain)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonControl ribbon;
        private DevExpress.XtraBars.Ribbon.RibbonStatusBar ribbonStatusBar;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPageDichVu;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPageToaNha;
        private DevExpress.XtraBars.BarButtonItem itemThamQuan_Them;
        private DevExpress.XtraBars.BarButtonItem itemToaNha;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage4;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupMatBang;
        private DevExpress.XtraBars.BarButtonItem itemMatBang;
        private DevExpress.XtraBars.BarButtonItem itemLoaiTaiSan;
        private DevExpress.XtraBars.BarButtonItem itemHangSanXuat;
        private DevExpress.XtraBars.BarButtonItem itemXuatXu;
        private DevExpress.XtraBars.BarButtonItem itemTrangThaiTaiSan;
        private DevExpress.XtraBars.BarButtonItem itemNhaCungCap;
        private DevExpress.XtraBars.BarButtonItem itemTaiSanDangSuDung;
        private DevExpress.XtraBars.BarButtonItem itemKeHoachBaoTri_Them;
        private DevExpress.XtraBars.BarButtonItem itemKeHoachBaoTri;
        private DevExpress.XtraBars.BarButtonItem itemBaoTri_Them;
        private DevExpress.XtraBars.BarButtonItem itemBaoTri;
        private DevExpress.XtraBars.BarButtonItem itemDXMS_Them;
        private DevExpress.XtraBars.BarButtonItem itemDXMS;
        private DevExpress.XtraBars.BarButtonItem itemDatHang_Them;
        private DevExpress.XtraBars.BarButtonItem itemDatHang;
        private DevExpress.XtraBars.BarButtonItem itemMuaHang_Them;
        private DevExpress.XtraBars.BarButtonItem itemMuaHang;
        private DevExpress.XtraBars.BarButtonItem itemNhapKho_Them;
        private DevExpress.XtraBars.BarButtonItem itemNhapKho;
        private DevExpress.XtraBars.BarButtonItem itemXuatKho;
        private DevExpress.XtraBars.BarButtonItem itemXuatKho_Them;
        private DevExpress.XtraBars.BarButtonItem itemMatBang_TrangThai;
        private DevExpress.XtraBars.BarButtonItem itemChoThue_Them;
        private DevExpress.XtraBars.BarButtonItem itemChoThue;
        private DevExpress.XtraBars.BarButtonItem itemTheXe_Them;
        private DevExpress.XtraBars.BarButtonItem itemLoaiXe;
        private DevExpress.XtraBars.BarButtonItem itemThangMay_Them;
        private DevExpress.XtraBars.BarButtonItem itemThangMay;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupCuDan;
        private DevExpress.XtraBars.BarButtonItem itemNhanKhau;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupDienNuoc;
        private DevExpress.XtraBars.BarButtonItem itemDien;
        private DevExpress.XtraBars.BarButtonItem itemNuoc;
        private DevExpress.XtraBars.BarButtonItem itemDien_DinhMuc;
        private DevExpress.XtraBars.BarButtonItem itemNuoc_DinhMuc;
        private DevExpress.XtraBars.BarButtonItem itemThueNgoai_Them;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup GroupDichVuKhac;
        private DevExpress.XtraBars.BarButtonItem itemThueNgoai;
        private DevExpress.XtraBars.BarButtonItem itemHopTac_Them;
        private DevExpress.XtraBars.BarButtonItem itemHopTac;
        private DevExpress.XtraBars.BarButtonItem itemDichVuKhac_Loai;
        private DevExpress.XtraBars.BarButtonItem itemDichVuKhac;
        private DevExpress.XtraBars.BarButtonItem itemSuaChua_Them;
        private DevExpress.XtraBars.BarButtonItem itemSuaChua;
        private DevExpress.XtraBars.BarButtonItem itemYeuCau;
        private DevExpress.XtraBars.BarButtonItem itemYeuCau_Them;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPageKhachHang;
        private DevExpress.XtraBars.BarButtonItem itemKhachHang_Them;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupKhachHang;
        private DevExpress.XtraBars.BarButtonItem itemKhachHang;
        private DevExpress.Utils.ImageCollection imageCollection1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonGroupToaNha;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup groupGiaoDien;
        private DevExpress.XtraBars.RibbonGalleryBarItem itemSkins;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup24;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupYeuCau;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupToaNha;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupNhanVien;
        private DevExpress.XtraBars.BarButtonItem btnThemNhanVien;
        private DevExpress.XtraBars.BarButtonItem btnNhanVienManager;
        private DevExpress.XtraBars.BarButtonItem btnPhanQuyenNV;
        private DevExpress.XtraBars.BarButtonItem itemMatBang_Them;
        private DevExpress.XtraBars.BarButtonItem itemKhoiNha;
        private DevExpress.XtraBars.BarButtonItem itemMatBang_View;
        private DevExpress.XtraBars.BarButtonItem itemTangLau;
        private DevExpress.XtraBars.BarButtonItem itemTrangThaiKHBT;
        private DevExpress.XtraBars.BarButtonItem itemTrangThaiChoThue;
        private DevExpress.XtraBars.BarButtonItem itemTrangThaiThueNgoai;
        private DevExpress.XtraBars.BarButtonItem itemTrangThaiHopTac;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupDMDV;
        private DevExpress.XtraBars.BarButtonItem xtrbtnDangKyKhachHang;
        private DevExpress.XtraBars.BarButtonItem barButtonItem10;
        private DevExpress.XtraBars.BarButtonItem barButtonItem17;
        private DevExpress.XtraBars.BarButtonItem barButtonItem16;
        private DevExpress.XtraBars.BarButtonItem barButtonItem11;
        private DevExpress.XtraBars.BarButtonItem barButtonItem14;
        private DevExpress.XtraBars.BarButtonItem barButtonItem9;
        private DevExpress.XtraBars.BarButtonItem barButtonItem12;
        private DevExpress.XtraBars.BarButtonItem barButtonItem13;
        private DevExpress.XtraBars.BarButtonItem barButtonItem15;
        private DevExpress.XtraBars.BarSubItem barSubItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem18;
        private DevExpress.XtraBars.BarButtonItem btnbieumau;
        private DevExpress.XtraBars.BarButtonItem itemNhanKhau_Them;
        private DevExpress.XtraBars.Ribbon.ApplicationMenu applicationMenu1;
        private DevExpress.XtraBars.BarButtonItem btnchangepass;
        private DevExpress.XtraBars.BarButtonItem btnlogout;
        private DevExpress.XtraBars.BarButtonItem btnexit;
        private DevExpress.XtraBars.BarButtonItem barButtonItem8;
        private DevExpress.XtraBars.BarButtonItem btnHoaDon;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupHoaDon;
        private DevExpress.XtraBars.BarButtonItem btnGiayBao;
        private DevExpress.XtraBars.BarButtonItem barButtonItem7;
        private DevExpress.XtraBars.BarButtonItem btnLoaiMatBang;
        private DevExpress.XtraBars.BarButtonItem btnKhoManager;
        private DevExpress.XtraBars.BarButtonItem btnPhongBan;
        private DevExpress.XtraBars.BarSubItem barSubItemDanhMucToaNha;
        private DevExpress.XtraBars.BarSubItem barSubItemDanhMucTaiSan;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup1;
        private DevExpress.XtraBars.BarSubItem barSubItem4;
        private DevExpress.XtraBars.BarSubItem barSubItemDanhMucDichVu;
        private DevExpress.XtraBars.BarSubItem barSubItem6;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup2;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup3;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup4;
        private DevExpress.XtraBars.BarSubItem barSubItem2;
        private DevExpress.XtraBars.BarSubItem groupDanhMucDV;
        private DevExpress.XtraBars.Docking.DockManager dockManager1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraBars.BarButtonItem itemTrangThaiNhanKhau;
        private DevExpress.XtraBars.BarButtonItem barButtonItemTaiSan;
        private DevExpress.XtraBars.BarButtonItem butnTkMBTheoTT;
        private DevExpress.XtraBars.BarButtonItem btnTKDienNuoc;
        private DevExpress.XtraBars.Ribbon.RibbonPage pageAbout;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup pgAbout;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarButtonItem btnTrangThaiTheXe;
        private DevExpress.XtraBars.BarButtonItem btnTrangThaiThangMay;
        private DevExpress.XtraBars.BarButtonItem btnTrangThaiYC;
        private DevExpress.XtraBars.BarButtonItem btnDoUuTienYC;
        private DevExpress.XtraBars.Docking.DockPanel dockPanelThongBao;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel2_Container;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControlRightPanel;
        private DevExpress.XtraGrid.GridControl gcthongbao;
        private DevExpress.XtraGrid.Views.Grid.GridView grvthongbao;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private System.Windows.Forms.Timer timerCapNhat;
        private DevExpress.XtraBars.BarButtonItem btnEmail;
        private DevExpress.XtraBars.BarButtonItem barButtonItem6;
        private DevExpress.XtraBars.BarButtonItem barButtonItem19;
        private DevExpress.XtraBars.BarButtonItem itemCongNoTheoKhachHang;
        private DevExpress.XtraBars.BarButtonItem btnBaoCaothu;
        private DevExpress.XtraBars.BarButtonItem BtnBaoCaoChi;
        private DevExpress.XtraBars.BarButtonItem btnBaoCaoCongNoTheoMatBang;
        private DevExpress.XtraBars.BarButtonItem itemTKThuChi;
        private DevExpress.XtraBars.BarButtonItem itemTKHDTTT;
        private DevExpress.XtraBars.BarButtonItem itemThamQuan;
        private DevExpress.XtraBars.BarSubItem barSubItem17;
        private DevExpress.XtraBars.BarStaticItem barStaticItemLogin;
        private DevExpress.XtraBars.BarButtonItem itemDoanhThuHopDongThue;
        private DevExpress.XtraBars.BarButtonItem itemTyGia;
        private DevExpress.XtraBars.BarButtonItem itemNhacNoKhachHang;
        private DevExpress.XtraBars.BarButtonItem itemTTNhacNo;
        private DevExpress.XtraBars.BarButtonItem exportTS2Excel;
        private DevExpress.XtraBars.BarButtonItem btnExportDV2Excel;
        private DevExpress.XtraBars.BarButtonItem btnCongNohdtn;
        private DevExpress.XtraBars.BarButtonItem btnCongNoHDHT;
        private DevExpress.XtraBars.Alerter.AlertControl alertControlNhacViec;
        private DevExpress.XtraGrid.GridControl gcNhacViec;
        private DevExpress.XtraGrid.Views.Grid.GridView grvNhacViec;
        private DevExpress.XtraGrid.Columns.GridColumn colDD;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit checkIsRead;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit txtNoiDung;
        private DevExpress.XtraEditors.Repository.RepositoryItemPopupContainerEdit repositoryItemPopupContainerEdit1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupHeThong;
        private DevExpress.XtraBars.BarButtonItem itemThongKeYeuCau;
        private DevExpress.XtraBars.BarEditItem itemCopyRight;
        private DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit repositoryItemPictureEdit3;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoMatBang;
        private DevExpress.XtraBars.BarButtonItem itemThongBaoThuPhi;
        private DevExpress.XtraBars.BarButtonItem itemThongBaoCatNuoc;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoTongHop;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoKetQauKinhDoanh;
        private DevExpress.XtraBars.BarButtonItem itemChiTietNopTien;
        private DevExpress.XtraBars.BarButtonItem itemChiTietThuPhi;
        private DevExpress.XtraBars.BarButtonItem itemTheoDoiCongNo;
        private DevExpress.XtraBars.BarButtonItem itemCongNoTongHop;
        private DevExpress.XtraBars.BarButtonItem itemTheoDoiCongNoPQL;
        private DevExpress.XtraBars.BarButtonItem itemTQQuanLy;
        private DevExpress.XtraBars.BarButtonItem btnAnhNinh;
        private DevExpress.XtraBars.BarButtonItem btnNhatKyAN;
        private DevExpress.XtraBars.BarButtonItem btnNVCT;
        private DevExpress.XtraBars.BarButtonItem btnGhiNhanSV;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupBieuMau;
        private DevExpress.XtraBars.BarButtonItem btnAdminLogAN;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup5;
        private DevExpress.XtraBars.BarButtonItem btnChucVuMNG;
        private DevExpress.XtraBars.BarButtonItem btnPhiQuanLy;
        private DevExpress.XtraBars.BarButtonItem btnQuyTac;
        private DevExpress.XtraBars.BarButtonItem btnKhuVuc;
        private DevExpress.XtraTabbedMdi.XtraTabbedMdiManager pageMain;
        private DevExpress.XtraBars.BarButtonItem btnDichVuCongCong;
        private DevExpress.XtraBars.BarButtonItem btnDichVuCCManger;
        private DevExpress.XtraBars.Alerter.AlertControl alertControlKeHoachBaoTri;
        private DevExpress.XtraBars.BarButtonItem barButtonItemKhoHang;
        private DevExpress.XtraBars.BarSubItem barSubItemCongNo;
        private DevExpress.XtraBars.BarSubItem barSubItemKinhDoanh;
        private DevExpress.XtraBars.BarSubItem barSubItemThongBao;
        private DevExpress.XtraBars.BarSubItem subTaiSan;
        private DevExpress.XtraBars.BarButtonItem btnBangkePhieuXuat;
        private DevExpress.XtraBars.BarButtonItem btnBangKePhieuNhap;
        private DevExpress.XtraBars.BarButtonItem rptThongKeKhoaHang;
        private DevExpress.XtraBars.BarButtonItem itemThueNganHanAdd;
        private DevExpress.XtraBars.BarButtonItem itemThueNganHan;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraBars.BarButtonItem barButtonItem20;
        private DevExpress.XtraBars.BarButtonItem barButtonItem21;
        private DevExpress.XtraBars.BarButtonItem barButtonItem22;
        private DevExpress.XtraBars.BarButtonItem btnThemLichThanhToanDien;
        private DevExpress.XtraBars.BarButtonItem btnLichThanhToanDien;
        private DevExpress.XtraBars.BarButtonItem btnNgonNgu;
        private DevExpress.XtraBars.BarButtonItem btnAddThePhongTap;
        private DevExpress.XtraBars.BarButtonItem btnQuanLyThePhongTap;
        private DevExpress.XtraBars.BarButtonItem btnLoaiThePhongTap;
        private DevExpress.XtraBars.BarButtonItem btnVietPhieuThu;
        private DevExpress.XtraBars.BarButtonItem btnVietPhieuChi;
        private DevExpress.XtraBars.BarButtonItem btnHoaDonGiayBao;
        private DevExpress.XtraBars.BarButtonItem btnKhachHangBaoCao;
        private DevExpress.XtraBars.BarButtonItem btnGiuXe;
        private DevExpress.XtraBars.BarButtonItem btnTieuThuDien;
        private DevExpress.XtraBars.BarButtonItem btnTieuThuNuoc;
        private DevExpress.XtraBars.BarButtonItem btnThongKeTieuThuDienNuoc;
        private DevExpress.XtraBars.BarButtonItem btnThongKeTQ;
        private DevExpress.XtraBars.BarButtonItem btnDeXuatAdd;
        private DevExpress.XtraBars.BarButtonItem btnDeXuatManager;
        private DevExpress.XtraBars.BarButtonItem btnMuaHangAdd;
        private DevExpress.XtraBars.BarButtonItem btnMuaHangManager;
        private DevExpress.XtraBars.BarButtonItem btnBaoGiaAdd;
        private DevExpress.XtraBars.BarButtonItem btnBaoGiaManager;
        private DevExpress.XtraBars.BarButtonItem btnGas;
        private DevExpress.XtraBars.BarButtonItem btnsmGas;
        private DevExpress.XtraBars.BarButtonItem btnSupport;
        private DevExpress.XtraBars.BarSubItem btnPhiKhac;
        private DevExpress.XtraBars.BarButtonItem btnPhiVeSinh;
        private DevExpress.XtraBars.BarButtonItem btnChietKhauPQL;
        private DevExpress.XtraBars.BarButtonItem itemTongHopDNG;
        private DevExpress.XtraBars.BarButtonItem itemSettingPQL;
        private DevExpress.XtraBars.BarButtonItem itemSettingTheXe;
        private DevExpress.XtraBars.BarButtonItem itemSetupPhiChoThue;
        private DevExpress.XtraBars.BarButtonItem itemAddProvider;
        private DevExpress.XtraBars.BarButtonItem itemListProvider;
        private DevExpress.XtraBars.BarSubItem navSetupTheXe;
        private DevExpress.XtraBars.BarSubItem navCaiDatPVS;
        private DevExpress.XtraBars.RibbonGalleryBarItem ribbonGalleryBarItem1;
        private DevExpress.XtraBars.RibbonGalleryBarItem ribbonGalleryBarItem2;
        private DevExpress.XtraBars.BarButtonItem itemDMNuoc;
        private DevExpress.XtraBars.BarButtonItem itemTXDinhMuc;
        private DevExpress.XtraBars.BarButtonItem itemBCBangKeThuChi;
        private DevExpress.XtraBars.BarButtonItem itemCustomerDeb;
        private DevExpress.XtraBars.BarButtonItem itemDMChuKy;
        private DevExpress.XtraBars.BarButtonItem itemBCTieuThuGas;
        private DevExpress.XtraBars.BarSubItem itemBCGas;
        private DevExpress.XtraBars.BarSubItem itenBCNuoc;
        private DevExpress.XtraBars.BarButtonItem itemBCTieuThuNuoc;
        private DevExpress.XtraBars.BarSubItem itemBCDien;
        private DevExpress.XtraBars.BarButtonItem itemBCGasChiTiet;
        private DevExpress.XtraBars.BarButtonItem itemBCNuocChiTiet;
        private DevExpress.XtraBars.BarButtonItem itemBCDienChiTiet;
        private DevExpress.XtraBars.BarButtonItem itemBCDSGasNuoc;
        private DevExpress.XtraBars.BarButtonItem itemBCGasPhieuThu;
        private DevExpress.XtraBars.BarButtonItem itemBCNuocPhieuThu;
        private DevExpress.XtraBars.BarButtonItem itemBCPhatSinhPQL;
        private DevExpress.XtraBars.BarButtonItem itemBCTongHopThu;
        private DevExpress.XtraBars.BarButtonItem itemBCTongPhaiThu;
        private DevExpress.XtraBars.BarButtonItem itemBCTongHopChuaThu;
        private DevExpress.XtraBars.BarButtonItem itemBCDoanhThuTheoNgay;
        private DevExpress.XtraBars.BarSubItem itemBCPhiQuanLy;
        private DevExpress.XtraBars.BarButtonItem itemBCPQLBangThuPhi;
        private DevExpress.XtraBars.BarButtonItem itemBCPQLChiTietPhatSinh;
        private DevExpress.XtraBars.BarButtonItem itemBCLuyKeNam;
        private DevExpress.XtraBars.BarButtonItem itemBCGasTTNam;
        private DevExpress.XtraBars.BarButtonItem itemBCNuocTTNam;
        private DevExpress.XtraBars.BarButtonItem itemBCDienTTNam;
        private DevExpress.XtraBars.BarButtonItem itemNgungCungCapDV;
        private DevExpress.XtraBars.BarButtonItem itemBCPQL_PhieuThu;
        private DevExpress.XtraBars.BarButtonItem itemKhoaSoAdd;
        private DevExpress.XtraBars.BarButtonItem itemKhoaSoList;
        private DevExpress.XtraBars.BarButtonItem itemPhieuTHuPVS;
        private DevExpress.XtraBars.BarSubItem subBCTheXe;
        private DevExpress.XtraBars.BarButtonItem itemBCTX_DanhSachDangKy;
        private DevExpress.XtraBars.BarButtonItem itemBCTX_ChiTietPhatSinh;
        private DevExpress.XtraBars.BarButtonItem itemBCTX_PhieuThu;
        private DevExpress.XtraBars.BarButtonItem itemBCTX_ChuaThanhToan;
        private DevExpress.XtraBars.BarButtonItem itemTXList;
        private DevExpress.XtraBars.BarButtonItem itemTXDoiChuThe;
        private DevExpress.XtraBars.BarButtonItem itemTXGiaHan;
        private DevExpress.XtraBars.BarButtonItem itemTXHetHan;
        private DevExpress.XtraBars.BarButtonItem itemTXDangKy;
        private DevExpress.XtraBars.BarButtonItem itemTXCongNo;
        private DevExpress.XtraBars.BarButtonItem itemConfigFTP;
        private DevExpress.XtraBars.BarButtonItem itemDKUuDai_Add;
        private DevExpress.XtraBars.BarButtonItem itemDKUuDai_List;
        private DevExpress.XtraBars.BarButtonItem itemHoBoi_add;
        private DevExpress.XtraBars.BarSubItem itemHoBoi_list;
        private DevExpress.XtraBars.BarButtonItem itemHoBoiThe_list;
        private DevExpress.XtraBars.BarButtonItem itemHoBoiCongNo;
        private DevExpress.XtraBars.BarButtonItem itemHoiBoiLoaiThe;
        private DevExpress.XtraBars.BarButtonItem itemHoBoiDinhMuc;
        private DevExpress.XtraBars.BarButtonItem itemLaiSuatChamNop;
        private DevExpress.XtraBars.BarButtonItem itemCaiDatTTCanhBao;
        private DevExpress.XtraBars.BarButtonItem itemPhiBaoTri;
        private DevExpress.XtraBars.BarButtonItem itemThemGhiTang;
        private DevExpress.XtraBars.BarButtonItem itemDSGhiTang;
        private DevExpress.XtraBars.BarButtonItem itemThemDGL;
        private DevExpress.XtraBars.BarButtonItem itemDSDanhGiaLai;
        private DevExpress.XtraBars.BarButtonItem itemThemDC;
        private DevExpress.XtraBars.BarButtonItem itemDSDieuChuyen;
        private DevExpress.XtraBars.BarButtonItem itemThemGhiGiam;
        private DevExpress.XtraBars.BarButtonItem itemDSGhiGiam;
        private DevExpress.XtraBars.BarButtonItem itemTinhKH;
        private DevExpress.XtraBars.BarButtonItem itemDSKhauHao;
        private DevExpress.XtraBars.BarButtonItem itemThemThongKe;
        private DevExpress.XtraBars.BarButtonItem itemDSThognKe;
        private DevExpress.XtraBars.BarButtonItem itemThemBC;
        private DevExpress.XtraBars.BarButtonItem itemDSBaoCao;
        private DevExpress.XtraBars.BarButtonItem itemDSCVLuoi;
        private DevExpress.XtraBars.BarButtonItem itemDSCVLich;
        private DevExpress.XtraBars.BarButtonItem itemDSCongViecDG;
        private DevExpress.XtraBars.BarButtonItem itemDSCVDGLich;
        private DevExpress.XtraBars.BarButtonItem itemHeThongKT;
        private DevExpress.XtraBars.BarButtonItem itemDVSD;
        private DevExpress.XtraBars.BarButtonItem itemTyGiaTN;
        private DevExpress.XtraBars.BarButtonItem itemTNTyGia;
        private DevExpress.XtraBars.BarButtonItem btnChatLuong;
        private DevExpress.XtraBars.BarButtonItem btnNguonGocHT;
        private DevExpress.XtraBars.BarButtonItem itemDMTK;
        private DevExpress.XtraBars.BarButtonItem itemNHThem;
        private DevExpress.XtraBars.BarButtonItem itemNHCongNo;
        private DevExpress.XtraBars.BarButtonItem itemMayDieuHoa;
        private DevExpress.XtraBars.BarButtonItem itemThemDHNG;
        private DevExpress.XtraBars.BarButtonItem itemDSDHNG;
        private DevExpress.XtraBars.BarButtonItem itemCNDHNG;
        private DevExpress.XtraBars.BarSubItem itemBKThuPhiCC;
        private DevExpress.XtraBars.BarButtonItem itemBanCDPSCN;
        private DevExpress.XtraBars.BarButtonItem itemBangKeCT;
        private DevExpress.XtraBars.BarButtonItem barButtonItem23;
        private DevExpress.XtraBars.BarButtonItem barButtonItem24;
        private DevExpress.XtraBars.BarButtonItem itemSoCTCN;
        private DevExpress.XtraBars.BarButtonItem itemKhoanThuHDT;
        private DevExpress.XtraBars.BarButtonItem itemBCCacKhoanPhiDV;
        private DevExpress.XtraBars.BarButtonItem itemBCCacKhoanTon;
        private DevExpress.XtraBars.BarButtonItem itemLoaiHDTN;
        private DevExpress.XtraBars.BarButtonItem itemBCTongHopCN;
        private DevExpress.XtraBars.BarButtonItem itemDVT;
        private DevExpress.XtraBars.BarButtonItem itemDCChiTietCN;
        private DevExpress.XtraBars.BarButtonItem itemTHemDVGS;
        private DevExpress.XtraBars.BarButtonItem itemDSGS;
        private DevExpress.XtraBars.BarButtonItem itemDKThanhToan;
        private DevExpress.XtraBars.BarButtonItem itemLSDCCongNo;
        private DevExpress.XtraBars.BarButtonItem itemLoaiTien;
        private DevExpress.XtraBars.BarButtonItem itemLoaiGiaThue;
        private DevExpress.XtraBars.BarButtonItem itemHoaDonAdd;
        private DevExpress.XtraBars.BarButtonItem itemLoaiDichVu;
        private DevExpress.XtraBars.BarButtonItem itemCaiDatChietKhau;
        private DevExpress.XtraBars.BarButtonItem barButtonItem26;
        private DevExpress.XtraBars.BarButtonItem barButtonItem25;
        private DevExpress.XtraBars.BarButtonItem itemTheXe;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup14;
        private DevExpress.XtraBars.BarButtonItem itemDichVuKhacAdd;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup15;
        private DevExpress.XtraBars.BarButtonItem itemReport_BaoCaoDatCoc;
        private DevExpress.XtraBars.BarButtonItem itemReport_HopDongChoThue;
        private DevExpress.XtraBars.BarButtonItem itemRreport_DienDieuHoa;
        private DevExpress.XtraBars.BarButtonItem itemNuoc_UuDai;
        private DevExpress.XtraBars.BarButtonItem itemDonViTinh;
        private DevExpress.XtraBars.BarButtonItem barButtonItem27;
        private DevExpress.XtraBars.BarButtonItem itemBangGiaDichVuCoBan;
        private DevExpress.XtraBars.BarButtonItem itemNuocCachTinh;
        private DevExpress.XtraBars.BarButtonItem itemDien3Pha;
        private DevExpress.XtraBars.BarButtonItem itemDien3Pha_DinhMuc;
        private DevExpress.XtraBars.BarButtonItem itemThanhLyChoThue;
        private DevExpress.XtraBars.BarButtonItem itemChoThue_MatBang;
        private DevExpress.XtraBars.BarButtonItem itemBieuMau;
        private DevExpress.XtraBars.BarButtonItem itemNhomMatBang;
        private DevExpress.XtraBars.BarButtonItem itemPhanNhomMatBang;
        private DevExpress.XtraBars.BarButtonItem itemDienDongHo;
        private DevExpress.XtraBars.BarButtonItem itemNuocDongHo;
        private DevExpress.XtraBars.BarButtonItem itemNganHang;
        private DevExpress.XtraBars.BarCheckItem barCheckItem1;
        private DevExpress.XtraBars.Ribbon.RibbonPage pageSoQuy;
        private DevExpress.XtraBars.BarButtonItem itemPhieuThuAdd;
        private DevExpress.XtraBars.BarButtonItem itemPhieuThu;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup13;
        private DevExpress.XtraBars.Docking.AutoHideContainer hideContainerRight;
        private DevExpress.XtraBars.BarButtonItem itemPhieuChiAdd;
        private DevExpress.XtraBars.BarButtonItem itemPhieuChi;
        private DevExpress.XtraBars.BarButtonItem itemKhauTruAdd;
        private DevExpress.XtraBars.BarButtonItem itemKhauTru;
        private DevExpress.XtraBars.BarSubItem itemDichVuThongKeKhac;
        private DevExpress.XtraBars.BarButtonItem itemDichVu_Report_KhauTru;
        private DevExpress.XtraBars.BarButtonItem itemNuocNong_DongHo;
        private DevExpress.XtraBars.BarButtonItem itemNuocNong_DinhMuc;
        private DevExpress.XtraBars.BarSubItem barSubItem3;
        private DevExpress.XtraBars.BarButtonItem itemNuocNong;
        private DevExpress.XtraBars.BarButtonItem itemNuocSinhHoat;
        private DevExpress.XtraBars.BarButtonItem itemEmail_Config;
        private DevExpress.XtraBars.BarButtonItem itemEmail_SettingStaff;
        private DevExpress.XtraBars.BarButtonItem itemEmail_Category;
        private DevExpress.XtraBars.BarButtonItem itemEmail_Templates;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup16;
        private DevExpress.XtraBars.BarButtonItem itemReport_PhieuThu;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup17;
        private DevExpress.XtraBars.BarButtonItem itemReport_PhieuChi;
        private DevExpress.XtraBars.BarButtonItem itemReport_PhieuKhauTru;
        private DevExpress.XtraBars.BarButtonItem itemNhomKhachHang;
        private DevExpress.XtraBars.BarButtonItem itemCaiDatDuyetHoaDon;
        private DevExpress.XtraBars.BarButtonItem itemQuanHe;
        private DevExpress.XtraBars.BarSubItem barDanhMuc;
        private System.Windows.Forms.Timer timerReminder;
        private DevExpress.XtraBars.Alerter.AlertControl alctAltert;
        private DevExpress.XtraBars.BarButtonItem itemYeuCau_CaiDat;
        private DevExpress.XtraBars.BarButtonItem itemNguonDen;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup18;
        private DevExpress.XtraBars.BarButtonItem itemLeTan_Add;
        private DevExpress.XtraBars.BarButtonItem itemLenTan_List;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup19;
        private DevExpress.XtraBars.BarButtonItem itemChoThue_LTT;
        private DevExpress.XtraBars.BarSubItem barSubItem5;
        private DevExpress.XtraBars.BarSubItem barSubItem7;
        private DevExpress.XtraBars.BarButtonItem itemDienDieuHoa;
        private DevExpress.XtraBars.BarSubItem barSubItem8;
        private DevExpress.XtraBars.BarButtonItem itemDienDieuHoa_DinhMuc;
        private DevExpress.XtraBars.BarButtonItem barButtonItem28;
        private DevExpress.XtraBars.BarButtonItem itemReport_KeHoachThuTien;
        private DevExpress.XtraBars.BarButtonItem itemReport_ChiTietCongNo;
        private DevExpress.XtraBars.BarButtonItem itemGiuXe_CongNoTheXe;
        private DevExpress.XtraBars.BarButtonItem itemGAS_Report_BieuDo;
        private DevExpress.XtraBars.BarButtonItem itemDien_BieuDo;
        private DevExpress.XtraBars.BarButtonItem itemDien3Pha_BieuDo;
        private DevExpress.XtraBars.BarButtonItem itemDienDieuHoa_BieuDo;
        private DevExpress.XtraBars.BarButtonItem itemNuoc_BieuDo;
        private DevExpress.XtraBars.BarButtonItem itemNuocNong_BieuDo;
        private DevExpress.XtraBars.BarButtonItem itemNuocSinhHoat_BieuDo;
        private DevExpress.XtraBars.BarButtonItem barButtonItem32;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private DevExpress.XtraBars.BarButtonItem itemPhanLoaiLich;
        private DevExpress.XtraBars.BarButtonItem itemThoiDiemLich;
        private DevExpress.XtraBars.BarButtonItem itemDanhSachLich;
        private DevExpress.XtraBars.BarButtonItem itemPhanLoai;
        private DevExpress.XtraBars.BarButtonItem itemTrangThai;
        private DevExpress.XtraBars.BarButtonItem itemMucDo;
        private DevExpress.XtraBars.BarButtonItem itemTienDo;
        private DevExpress.XtraBars.BarButtonItem itemThemMoi;
        private DevExpress.XtraBars.BarButtonItem itemDanhSach;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup20;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup21;
        private DevExpress.XtraBars.BarButtonItem itemTaiLieu;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup22;
        private DevExpress.XtraBars.BarButtonItem itemTaiLieu_Loai;
        private DevExpress.XtraBars.BarButtonItem itemReport_DaThuTheXe;
        private DevExpress.XtraBars.BarButtonItem itemPhanQuyenBaoCao;
        private DevExpress.XtraBars.BarButtonItem itemGanHetHan;
        private DevExpress.XtraBars.BarButtonItem itemDaHetHan;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoHDThueGianHangThueKHTHue;
        private DevExpress.XtraBars.BarButtonItem itemHoaDonDaXoa;
        private DevExpress.XtraBars.BarButtonItem itemPhieuThuDaXoa;
        private DevExpress.XtraBars.BarButtonItem itemTheXeDaXoa;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoCongNoTongHopTheoThang;
        private DevExpress.XtraBars.BarButtonItem itemQuocTich;
        private DevExpress.XtraBars.BarButtonItem itemLoaiYeuCau;
        private DevExpress.XtraBars.BarButtonItem itemMucDoLeTan;
        private DevExpress.XtraBars.BarButtonItem itemTrangThaiLeTan;
        private DevExpress.XtraBars.BarButtonItem itemTheThangMay;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup23;
        private DevExpress.XtraBars.BarButtonItem itemKhoThe;
        private DevExpress.XtraBars.BarButtonItem itemDSCapThe;
        private DevExpress.XtraBars.BarButtonItem itemNhatKyHeThong;
        private DevExpress.XtraBars.BarButtonItem itemLoaiKhachHang;
        private DevExpress.XtraBars.BarButtonItem itemConfigPhone;
        private DevExpress.XtraBars.BarButtonItem itemNhatKyCuocGoi;
        private DevExpress.XtraBars.BarSubItem barSubItem9;
        private DevExpress.XtraBars.BarButtonItem bbiDanhSachYeuCau;
        private DevExpress.XtraBars.BarButtonItem bbiCongViecCuaToi;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup26;
        private DevExpress.XtraBars.BarButtonItem itemMauMail;
        private DevExpress.XtraBars.BarButtonItem itemDanhSachNhan;
        private DevExpress.XtraBars.BarButtonItem itemThuongHieu;
        private DevExpress.XtraBars.BarButtonItem itemDanhSachGui;
        private DevExpress.XtraBars.BarButtonItem itemCheckTaiKhoan;
        private DevExpress.XtraBars.BarButtonItem barButtonItem29;
        private DevExpress.XtraBars.BarButtonItem itemCapNhatBangGiaDichVuCoBan;
        private DevExpress.XtraBars.BarButtonItem barButtonItem31;
        private DevExpress.XtraBars.BarButtonItem itemHDCTNSapHetHan;
        private DevExpress.XtraBars.BarButtonItem itemHDCTN;
        private DevExpress.XtraBars.BarButtonItem barButtonItem34;
        private DevExpress.XtraBars.BarButtonItem barButtonItem33;
        private DevExpress.XtraBars.BarButtonItem itemCongNoDongTien;
        private DevExpress.XtraBars.BarButtonItem itemChayLaiSoQuy;
        private DevExpress.XtraBars.BarButtonItem itemDSChuyenTien;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup pageGroupChuyenTienvaKyQuy;
        private DevExpress.XtraBars.BarButtonItem itemPhieuChiKyQuy;
        private DevExpress.XtraBars.BarSubItem itemBieuDoMotToaNha;
        private DevExpress.XtraBars.BarButtonItem itemThongKeTheoNhomCongViec;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup5;
        private DevExpress.XtraBars.BarButtonItem itemBDTinhTrangXuLy;
        private DevExpress.XtraBars.BarButtonItem itemTheoDanhGiaCuaCuDan;
        private DevExpress.XtraBars.BarButtonItem itemTheoNguonPhanAnh;
        private DevExpress.XtraBars.BarButtonItem itemDoUuTien;
        private DevExpress.XtraBars.BarButtonItem itemPhanAnhTheoToaNha;
        private DevExpress.XtraBars.BarSubItem itemTheoNhieuToaNha;
        private DevExpress.XtraBars.BarButtonItem itemNhomCongViecMuiltiTN;
        private DevExpress.XtraBars.BarButtonItem itemTinhTrangXuLyTheoNhieuToaNha;
        private DevExpress.XtraBars.BarButtonItem itemDanhGiaCuaCuDanTheoMuiltiToaNha;
        private DevExpress.XtraBars.BarButtonItem itemNguonTiepNhanTheoMuilti;
        private DevExpress.XtraBars.BarButtonItem itemViewBieuDoAll;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPageTaiSan;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPageVanHanh;
        private DevExpress.XtraBars.BarSubItem barSubItem10;
        private DevExpress.XtraBars.BarButtonItem itemTTTaiSan;
        private DevExpress.XtraBars.BarButtonItem itemNhaCCTS;
        private DevExpress.XtraBars.BarButtonItem itemDMHeThong;
        private DevExpress.XtraBars.BarButtonItem itemDMLoaiTaiSan;
        private DevExpress.XtraBars.BarButtonItem itemDMTenTaiSan;
        private DevExpress.XtraBars.BarButtonItem ItemCaiDatHeThongChoToaNha;
        private DevExpress.XtraBars.BarButtonItem itemDMChiTietTaiSan;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup3;
        private DevExpress.XtraBars.BarSubItem ItemDMVanHanh;
        private DevExpress.XtraBars.BarButtonItem ItemTanSuat;
        private DevExpress.XtraBars.BarButtonItem itemLoaiCaTruc;
        private DevExpress.XtraBars.BarButtonItem itemCongCuThietBi;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageDMVanHanh;
        private DevExpress.XtraBars.BarButtonItem ItemKeHoachVanHanh;
        private DevExpress.XtraBars.BarButtonItem itemPhieuVanHanh;
        private DevExpress.XtraBars.BarButtonItem itemProfile;
        private DevExpress.XtraBars.BarButtonItem itemGiaoNhanCa;
        private DevExpress.XtraBars.BarButtonItem itemDeXuatDoiCa;
        private DevExpress.XtraBars.BarButtonItem itemBangPhanCong;
        private DevExpress.XtraBars.BarButtonItem itemLichTruc;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup4;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupVanHanh;
        private DevExpress.XtraBars.BarButtonItem itemVHKeHoachBaoTri;
        private DevExpress.XtraBars.BarButtonItem itemVHPhieuBaoTri;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup6;
        private DevExpress.XtraBars.BarButtonItem itemGanProFileChoHeThong;
        private DevExpress.XtraBars.BarButtonItem itemDanhMucProfile;
        private DevExpress.XtraBars.BarButtonItem itemGanProfileChoToaNha;
        private DevExpress.XtraBars.BarButtonItem itemNhomProfile;
        private DevExpress.XtraBars.BarButtonItem itemCauHinhCapDuyet;
        private DevExpress.XtraBars.BarSubItem barDanhMucVatTu;
        private DevExpress.XtraBars.BarButtonItem itemVTDonViTinh;
        private DevExpress.XtraBars.BarButtonItem itemVTDanhMucVatTu;
        private DevExpress.XtraBars.BarButtonItem itemVTDanhMucKhoHang;
        private DevExpress.XtraBars.BarButtonItem itemVTDanhMucLoaiNhapKho;
        private DevExpress.XtraBars.BarButtonItem itemVTDanhMucLoaiXuatKho;
        private DevExpress.XtraBars.BarButtonItem itemDeXuatMuaHang;
        private DevExpress.XtraBars.BarButtonItem itemDanhSachMuaHang;
        private DevExpress.XtraBars.BarButtonItem itemVTNhapKho;
        private DevExpress.XtraBars.BarButtonItem itemVTXuatKho;
        private DevExpress.XtraBars.BarButtonItem itemVTTonKho;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup pageGroupVatTu;
        private DevExpress.XtraBars.BarButtonItem itemCauHinhAPITheXe;
        private DevExpress.XtraBars.BarSubItem barSubQuanLyHoSo;
        private DevExpress.XtraBars.BarButtonItem itemQLHS_KhoGiay;
        private DevExpress.XtraBars.BarButtonItem itemQLHS_LoaiVanBan;
        private DevExpress.XtraBars.BarButtonItem itemQLHS_DayKe;
        private DevExpress.XtraBars.BarButtonItem itemQLHS_MucDoBaoMat;
        private DevExpress.XtraBars.BarButtonItem itemQLHS_MucDoKhanCap;
        private DevExpress.XtraBars.BarButtonItem itemQLHS_HoSo;
        private DevExpress.XtraBars.BarButtonItem itemQuanLyHoSo;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup7;
        private DevExpress.XtraBars.BarButtonItem itemXuatKhoSuDung;
        private DevExpress.XtraBars.BarButtonItem itemDeXuatSuaChua;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup pageSuaChua;
        private DevExpress.XtraBars.BarButtonItem itemCauHinhNgayNghi;
        private DevExpress.XtraBars.BarButtonItem itemCauHinhNgayNghiTheoToaNha;
        private DevExpress.XtraBars.BarButtonItem itemThongKeThoiGian;
        private DevExpress.XtraBars.BarButtonItem itemNhomCongViec;
        private DevExpress.XtraBars.BarButtonItem itemCauHinhTinhTrangPhieu;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup_BaoCaoVanHanh;
        private DevExpress.XtraBars.BarSubItem itemThongKeSoLieuVH;
        private DevExpress.XtraBars.BarButtonItem itemTKCheckList;
        private DevExpress.XtraBars.BarButtonItem itemTKTinhHinhThucHien;
        private DevExpress.XtraBars.BarButtonItem itemTKTinhHinhKiemTraDinhKy;
        private DevExpress.XtraBars.BarButtonItem itemTKKiemTraDinhKy;
        private DevExpress.XtraBars.BarButtonItem itemViewPhieuBaoTri;
        private DevExpress.XtraBars.BarSubItem itemSubTinTuc;
        private DevExpress.XtraBars.BarSubItem itemSubApp;
        private DevExpress.XtraBars.BarButtonItem itemTinTuc_TyLeDangTin;
        private DevExpress.XtraBars.BarButtonItem itemTinTuc_ThongKeTheoTungToaNha;
        private DevExpress.XtraBars.BarButtonItem itemTinTuc_ThongKeTheoTongToaNha;
        private DevExpress.XtraBars.BarButtonItem itemTinTuc_ThongKeTongHop;
        private DevExpress.XtraBars.BarButtonItem itemApp_TyLeSuDungTheoTungToaNha;
        private DevExpress.XtraBars.BarButtonItem itemApp_TyLeSuDungTongToaNha;
        private DevExpress.XtraBars.BarButtonItem itemApp_ThongKeSuDungTungToaNha;
        private DevExpress.XtraBars.BarButtonItem itemApp_ThongKeSuDungCacToaNha;
        private DevExpress.XtraBars.BarButtonItem itemNhieuTN_SoLuongNhomCongViec;
        private DevExpress.XtraBars.BarButtonItem itemNhieuTN_PhanAnhTheoThang;
        private DevExpress.XtraBars.BarButtonItem itemNhieuTN_TongPhanAnh;
        private DevExpress.XtraBars.BarButtonItem itemNhieuTN_BaoCaoTongHop;
        private DevExpress.XtraBars.BarButtonItem itemViewKeHoachBaoTri;
        private DevExpress.XtraBars.BarButtonItem itemSMSSoDuTaiKhoan;
        private DevExpress.XtraBars.BarButtonItem itemSMSLichSu;
        private DevExpress.XtraBars.BarButtonItem itemSMS_Mau;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup_SMS;
        private DevExpress.XtraBars.BarButtonItem BtnCauHinhColor;
        private DevExpress.XtraBars.BarButtonItem itemCaiDatBieuMau;
        private DevExpress.XtraBars.BarButtonItem itemScheduleComfirm;
        private DevExpress.XtraBars.BarButtonItem itemEmailSetup;
        private DevExpress.XtraBars.BarButtonItem itemBcThuChiTm;
        private DevExpress.XtraBars.BarButtonItem itemBcCongNoDichVu;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup6;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoDaThu;
        private DevExpress.XtraBars.BarSubItem barSubItem11;
        private DevExpress.XtraBars.BarButtonItem barButtonItem30;
        private DevExpress.XtraBars.BarButtonItem barButtonItem35;
        private DevExpress.XtraBars.BarSubItem barSubItem12;
        private DevExpress.XtraBars.BarButtonItem itemBcChiTietThuPqlThang;
        private DevExpress.XtraBars.BarSubItem itemGroupBcCongNoTongHop;
        private DevExpress.XtraBars.BarButtonItem itemHoaDonThongKe;
        private DevExpress.XtraBars.BarButtonItem itemReportPhiDaThu;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoTongHopCongNoDichVu;
        private DevExpress.XtraBars.BarButtonItem itemBcCongNoTongHopTheoThang;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoCacKhoanDaKhauTru;
        private DevExpress.XtraBars.BarSubItem barSubItem13;
        private DevExpress.XtraBars.BarButtonItem itemReportBaoCaoTienDien;
        private DevExpress.XtraBars.BarButtonItem itemRreportDienDieuHoa;
        private DevExpress.XtraBars.BarButtonItem itemBieuDoTieuThuDien;
        private DevExpress.XtraBars.BarButtonItem itemBieuDoTieuThuDien3Pha;
        private DevExpress.XtraBars.BarButtonItem itemBieuDoTieuThuDienDieuHoa;
        private DevExpress.XtraBars.BarSubItem barSubItem14;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoDichVuNuoc;
        private DevExpress.XtraBars.BarButtonItem itemBieuDoTieuThuNuoc;
        private DevExpress.XtraBars.BarButtonItem itemBieuDoTieuThuNuocNong;
        private DevExpress.XtraBars.BarButtonItem itemBieuDoTieuThuNuocSinhHoat;
        private DevExpress.XtraBars.BarSubItem barSubItem15;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoDichVuGas;
        private DevExpress.XtraBars.BarButtonItem itemBieuDoTieuThuGas;
        private DevExpress.XtraBars.BarSubItem barSubItem16;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoDichVuGuiXe;
        private DevExpress.XtraBars.BarButtonItem itemSoCongNoTheXe;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoDaThuTheXePhatSinh;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoChiTietPhiGiuXeThang;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoDoanhThuGiuXeOTo;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoDoanhThuGiuXeMay;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoDoanhThuGiuXeDap;
        private DevExpress.XtraBars.BarButtonItem itemCauHinhNhanVienQuanLyNhanMail;
        private DevExpress.XtraBars.BarSubItem barSubItem18;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage3;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup11;
        private DevExpress.XtraBars.BarButtonItem itemScheduleStatus;
        private DevExpress.XtraBars.BarButtonItem itemScheduleComfirm1;
        private DevExpress.XtraBars.BarButtonItem ItemScheduleGroup;
        private DevExpress.XtraBars.BarButtonItem itemCarTyle;
        private DevExpress.XtraBars.BarButtonItem itemNewsTyle;
        private DevExpress.XtraBars.BarButtonItem itemSchedule;
        private DevExpress.XtraBars.BarButtonItem itemHandover;
        private DevExpress.XtraBars.BarButtonItem itemHandoverHistory;
        private DevExpress.XtraBars.BarButtonItem itemCarSetup;
        private DevExpress.XtraBars.BarButtonItem itemCarSchedule;
        private DevExpress.XtraBars.BarButtonItem itemNewsManager;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup12;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup25;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup29;
        private DevExpress.XtraBars.BarSubItem barSubItem19;
        private DevExpress.XtraBars.BarButtonItem itemSendMailToManager;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup8;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage5;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup9;
        private DevExpress.XtraBars.BarButtonItem itemDeposit;
        private DevExpress.XtraBars.BarButtonItem itemDepositDelete;
        private DevExpress.XtraBars.BarButtonItem itemWithDraw;
        private DevExpress.XtraBars.BarSubItem barSubItem20;
        private DevExpress.XtraBars.BarButtonItem itemDrTyle;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup30;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup10;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoCongNoDichVu;
        private DevExpress.XtraBars.BarButtonItem itemDepositManager;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup31;
        private DevExpress.XtraBars.BarButtonItem itemSoQuyDatCoc;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup32;
        private DevExpress.XtraBars.BarButtonItem itemHangMuc;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup33;
        private DevExpress.XtraBars.BarButtonItem itemChecklist;
        private DevExpress.XtraBars.BarButtonItem itemChecklistToaNha;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup34;
        private DevExpress.XtraBars.BarButtonItem itemHandoverLocal;
        private DevExpress.XtraBars.BarButtonItem itemUserHandover;
        private DevExpress.XtraBars.BarButtonItem itemPlanCustomer;
        private DevExpress.XtraBars.BarButtonItem itemScheduleCustomer;
        private DevExpress.XtraBars.BarButtonItem itemHandoverCustomer;
        private DevExpress.XtraBars.BarButtonItem itemDuty;
        private DevExpress.XtraBars.BarButtonItem itemStatus;
        private DevExpress.XtraBars.BarButtonItem itemHistoryCustomer;
        private DevExpress.XtraBars.BarButtonItem itemAssetCategory;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup35;
        private DevExpress.XtraBars.BarButtonItem itemAssetGroups;
        private DevExpress.XtraBars.BarButtonItem itemUnit;
        private DevExpress.XtraBars.BarButtonItem itemStatusAsset;
        private DevExpress.XtraBars.BarButtonItem itemGroupChecklist;
        private DevExpress.XtraBars.BarButtonItem itemBlockChecklist;
        private DevExpress.XtraBars.BarButtonItem itemDeXuatThayCa;
        private DevExpress.XtraBars.BarButtonItem itemNhomMB;
        private DevExpress.XtraBars.BarButtonItem itemDienTichLapDay;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage6;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup36;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup37;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup38;
        private DevExpress.XtraBars.BarButtonItem itemBieuMauHDT;
        private DevExpress.XtraBars.BarButtonItem itemTruongTronHDT;
        private DevExpress.XtraBars.BarButtonItem itemMauHDT;
        private DevExpress.XtraBars.BarButtonItem itemLapHoaDonHDT;
        private DevExpress.XtraBars.BarButtonItem itemHoaDonHDT;
        private DevExpress.XtraBars.BarButtonItem itemHoaDonDaXoaHDT;
        private DevExpress.XtraBars.BarButtonItem itemCongNoHDT;
        private DevExpress.XtraBars.BarButtonItem itemPhieuThuHDT;
        private DevExpress.XtraBars.BarButtonItem itemPhieuThuDaXoaHDT;
        private DevExpress.XtraBars.BarButtonItem itemPhieuDieuChuyenHDT;
        private DevExpress.XtraBars.BarButtonItem itemPhieuChiHDT;
        private DevExpress.XtraBars.BarButtonItem itemPhieuKhauTruHDT;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup39;
        private DevExpress.XtraBars.BarButtonItem itemMoneyPurpose;
        private DevExpress.XtraBars.BarButtonItem itemMoneyPurposeItems;
        private DevExpress.XtraBars.BarButtonItem itemHopDongDatCoc;
        private DevExpress.XtraBars.BarButtonItem itemKhachHangTiemNang;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup40;
        private DevExpress.XtraBars.Ribbon.RibbonPage pageHopDongThueNgoai;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup41;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage8;
        private DevExpress.XtraBars.BarButtonItem itemDanhSachCongViec;
        private DevExpress.XtraBars.BarButtonItem itemHopDongThueNgoai;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup groupHopDong;
        private DevExpress.XtraBars.BarButtonItem itemDeXuatDoiLich;
        private DevExpress.XtraBars.BarButtonItem itemDanhSachThanhCong;
        private DevExpress.XtraBars.BarButtonItem itemDanhSachSuaChua;
        private DevExpress.XtraBars.BarButtonItem itemTrangThaiDuyetDeXuat;
        private DevExpress.XtraBars.BarButtonItem barButtonItem36;
        private DevExpress.XtraBars.BarButtonItem itemTieuDeThongBao;
        private DevExpress.XtraBars.BarButtonItem itemNoiDungThongBao;
        private DevExpress.XtraBars.BarButtonItem itemHdtnGanHetHan;
        private DevExpress.XtraBars.BarButtonItem itemHdtnHetHan;
        private DevExpress.XtraBars.BarButtonItem itemThanhLyHdtn;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup43;
        private DevExpress.XtraBars.BarButtonItem itemCongNoTienDatCoc;
        private DevExpress.XtraBars.BarSubItem barSubItem21;
        private DevExpress.XtraBars.BarButtonItem itemNoiDungCongViec;
        private DevExpress.XtraBars.BarButtonItem itemNoiDungNhomCongViec;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup44;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup45;
        private DevExpress.XtraBars.BarButtonItem itemTruongTron;
        private DevExpress.XtraBars.BarButtonItem itemTruongTronHdtn;
        private DevExpress.XtraBars.BarButtonItem itemBieuMauHdtn;
        private DevExpress.XtraBars.BarButtonItem btnPhanQuyenBieuMauHdtn;
        private DevExpress.XtraBars.BarButtonItem itemCongNoDoiTac;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup groupBaoCaoHdtn;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoThongKeKinhPhi;
        private DevExpress.XtraBars.BarButtonItem itemSoDuDauKy;
        private DevExpress.XtraBars.BarButtonItem itemCongNoTongHopHdtn;
        private DevExpress.XtraBars.BarButtonItem itemTienTrinhThucHien;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup groupTienTrinh;
        private DevExpress.XtraBars.BarButtonItem itemLichThanhToan;
        private DevExpress.XtraBars.BarButtonItem itemDanhGiaHdtn;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup42;
        private DevExpress.XtraBars.BarButtonItem itemPhanQuyenBieuDoMain;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup46;
        private DevExpress.XtraBars.BarButtonItem itemCapNhatItemMain;
        private DevExpress.XtraBars.BarButtonItem itemPhanQuyenItem;
        private DevExpress.XtraBars.BarButtonItem itemCoPhanQuyen;
        private DevExpress.XtraBars.BarButtonItem itemTruongTronDatCocThiCong;
        private DevExpress.XtraBars.BarButtonItem itemBieuMauDatCocThiCong;
        private DevExpress.XtraBars.BarButtonItem itemPhanQuyenBieuMauDatCocThiCong;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup groupBieuMauDatCocThiCong;
        private DevExpress.XtraBars.BarButtonItem itemBaoCaoCongNoAll;
        private DevExpress.XtraBars.BarButtonItem itemPhiPhaiThuTrongThang;
        private DevExpress.XtraBars.BarButtonItem itemNoiBanHanh;
        private DevExpress.XtraBars.BarButtonItem itemPhanLoaiDiDen;
        private DevExpress.XtraBars.BarButtonItem itemVanBanDen;
        private DevExpress.XtraBars.BarButtonItem itemVanBanDi;
        private DevExpress.XtraBars.BarSubItem barSubItem22;
        private DevExpress.XtraBars.BarButtonItem itemChucVu;
        private DevExpress.XtraBars.BarButtonItem barButtonItem37;
        private DevExpress.XtraBars.BarButtonItem barButtonItem38;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup28;
        private DevExpress.XtraBars.BarSubItem barSubItem23;
        private DevExpress.XtraBars.BarButtonItem barButtonItem39;
        private DevExpress.XtraBars.BarButtonItem barButtonItem40;
        private DevExpress.XtraBars.BarButtonItem barButtonItem41;
        private DevExpress.XtraBars.BarButtonItem barButtonItem42;
        private DevExpress.XtraBars.BarButtonItem itemSoDoPhanLo;
        private DevExpress.XtraBars.BarButtonItem barButtonItem43;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup47;
        private DevExpress.XtraBars.BarSubItem barSubItem24;
        private DevExpress.XtraBars.BarButtonItem barButtonItem44;
        private DevExpress.XtraBars.BarButtonItem barButtonItem45;
        private DevExpress.XtraBars.BarButtonItem barButtonItem47;
        private DevExpress.XtraBars.BarButtonItem barButtonItem48;
        private DevExpress.XtraBars.BarButtonItem barButtonItem49;
        private DevExpress.XtraBars.BarButtonItem itemCauHinhPage;
        private DevExpress.XtraBars.BarButtonItem itemDanhSachMau;
        private DevExpress.XtraBars.BarButtonItem itemLayDanhSachKhachHang;
        private DevExpress.XtraBars.BarButtonItem IiemDanhsachkhachhangquantam;
        private DevExpress.XtraBars.BarButtonItem istemLichSuGuiSms;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup48;
        private DevExpress.XtraBars.BarButtonItem barButtonItem46;
        private DevExpress.XtraBars.BarButtonItem barButtonItem50;
        private DevExpress.XtraBars.BarSubItem itemDuTinh;
        private DevExpress.XtraBars.BarButtonItem barButtonItem51;
        private DevExpress.XtraBars.BarButtonItem itemDuTinhPQL;
        private DevExpress.XtraBars.BarButtonItem itemDuTinhXe;
        private DevExpress.XtraBars.BarButtonItem barButtonItem52;
        private DevExpress.XtraBars.BarButtonItem itemDuTinhHDT;
        private DevExpress.XtraBars.BarButtonItem itemDongHoDien;
        private DevExpress.XtraBars.BarButtonItem itemDongHoDienDieuHoa;
        private DevExpress.XtraBars.BarButtonItem itemNhanVienQuanTam;
        private DevExpress.XtraBars.BarButtonItem itemMauGuiNhanVien;
        private DevExpress.XtraBars.BarButtonItem itemLichSuGuiNhanVien;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage7;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup49;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup50;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup51;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup52;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup53;
        private DevExpress.XtraBars.BarButtonItem barButtonItem53;
        private DevExpress.XtraBars.BarButtonItem barButtonItem54;
        private DevExpress.XtraBars.BarButtonItem barButtonItem55;
        private DevExpress.XtraBars.BarButtonItem barButtonItem56;
        private DevExpress.XtraBars.BarButtonItem barButtonItem57;
        private DevExpress.XtraBars.BarButtonItem barButtonItem58;
        private DevExpress.XtraBars.BarButtonItem barButtonItem59;
        private DevExpress.XtraBars.BarButtonItem barButtonItem60;
        private DevExpress.XtraBars.BarButtonItem barButtonItem61;
        private DevExpress.XtraBars.BarSubItem barSubItem25;
        private DevExpress.XtraBars.BarButtonItem itemNguonKH;
        private DevExpress.XtraBars.BarButtonItem itemQuyMo;
        private DevExpress.XtraBars.BarSubItem itemLocation;
        private DevExpress.XtraBars.BarButtonItem itemXa;
        private DevExpress.XtraBars.BarButtonItem itemHuyen;
        private DevExpress.XtraBars.BarButtonItem itemTinh;
        private DevExpress.XtraBars.BarButtonItem itemHTTX;
        private DevExpress.XtraBars.BarButtonItem itemNhuCauThue;
        private DevExpress.XtraBars.BarButtonItem itemCauHinhTiemNang;
        private DevExpress.XtraBars.BarButtonItem itemLoaiBaoGia;
        private DevExpress.XtraBars.BarButtonItem itemTrangThaiCSKH;
        private DevExpress.XtraBars.BarButtonItem itemCSKH;
        private DevExpress.XtraBars.BarButtonItem itemCSKHChinhThuc;
        private DevExpress.XtraBars.BarButtonItem itemTraCuuDoanhNghiep;
        private DevExpress.XtraBars.BarButtonItem barButtonItem65;
        private DevExpress.XtraBars.BarButtonItem barButtonItem66;
        private DevExpress.XtraBars.BarButtonItem itemBaoGia;
        private DevExpress.XtraBars.BarButtonItem itemCoHoi;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup27;
        private DevExpress.XtraBars.BarButtonItem itemNgheNghiep;
        private DevExpress.XtraBars.BarButtonItem itemNguoiLienHe;
        private DevExpress.XtraBars.BarButtonItem barButtonItem62;
        private DevExpress.XtraBars.BarButtonItem barButtonItem63;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup54;
        private DevExpress.XtraBars.BarButtonItem barButtonItem64;
        private DevExpress.XtraBars.BarButtonItem barButtonItem67;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup55;
        private DevExpress.XtraBars.BarButtonItem itemKhaoSat;
        private DevExpress.XtraBars.BarButtonItem itemThongKeKhaoSat;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup itemPageKhaoSat;
        private DevExpress.XtraBars.BarButtonItem barButtonItem68;
        private DevExpress.XtraBars.BarButtonItem barButtonItem69;
        private DevExpress.XtraBars.BarButtonItem barButtonItem70;
        private DevExpress.XtraBars.BarButtonItem barButtonItem71;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup56;
        private DevExpress.XtraBars.BarButtonItem barButtonItem72;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup57;
        private DevExpress.XtraBars.BarButtonItem itemVer;
        private DevExpress.XtraBars.BarButtonItem btnBCDienTichChoThue;
        private DevExpress.XtraBars.BarButtonItem btnBaoCaoDienNuoc;
        private DevExpress.XtraBars.BarButtonItem btnBCTongHopNuoc;
        private DevExpress.XtraBars.BarButtonItem btnLienHe;
        private DevExpress.XtraBars.BarButtonItem btnCauHinhVAT;
        private DevExpress.XtraBars.BarButtonItem btnBanner;
        private DevExpress.XtraBars.BarButtonItem itemDongHoDien3Pha;
        private DevExpress.XtraBars.BarButtonItem itemBoPhanLienHe;
        private DevExpress.XtraBars.BarButtonItem itemNhomLienHe;
        private DevExpress.XtraBars.BarButtonItem btnDangKyChuyenDo;
        private DevExpress.XtraBars.BarButtonItem itemDienLanh;
        private DevExpress.XtraBars.BarButtonItem barButtonItem73;
        private DevExpress.XtraBars.BarSubItem btnMenuDVMoi;
        private DevExpress.XtraBars.BarButtonItem btnchuyendo;
        private DevExpress.XtraBars.BarButtonItem btnDSDangKyNV;
        private DevExpress.XtraBars.BarButtonItem btnLamNgoaiGio;
        private DevExpress.XtraBars.BarButtonItem itemDongHoDienLanh;
        private DevExpress.XtraBars.BarButtonItem itemKeHoachXitConTrung;
        private DevExpress.XtraBars.BarButtonItem itemLichBaoTri_Lich;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage9;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup58;
        private DevExpress.XtraBars.BarButtonItem itemLichBaoTri_KhachHangXacNhan;
    }
}
