﻿namespace LandSoftBuilding.Report
{
    partial class rptBaoCaoCacKhoanPhiDV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.XtraReports.UI.XRSummary xrSummary1 = new DevExpress.XtraReports.UI.XRSummary();
            this.Detail = new DevExpress.XtraReports.UI.DetailBand();
            this.xrTable15 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow16 = new DevExpress.XtraReports.UI.XRTableRow();
            this.cSTT = new DevExpress.XtraReports.UI.XRTableCell();
            this.cKH = new DevExpress.XtraReports.UI.XRTableCell();
            this.cDauKy = new DevExpress.XtraReports.UI.XRTableCell();
            this.cTienDien = new DevExpress.XtraReports.UI.XRTableCell();
            this.cTienDienDH = new DevExpress.XtraReports.UI.XRTableCell();
            this.cTienNuoc = new DevExpress.XtraReports.UI.XRTableCell();
            this.cTienXe = new DevExpress.XtraReports.UI.XRTableCell();
            this.cDT = new DevExpress.XtraReports.UI.XRTableCell();
            this.cNgoaiGio = new DevExpress.XtraReports.UI.XRTableCell();
            this.cThuKhac = new DevExpress.XtraReports.UI.XRTableCell();
            this.cPhaiThu = new DevExpress.XtraReports.UI.XRTableCell();
            this.cDaThu = new DevExpress.XtraReports.UI.XRTableCell();
            this.cConPhaiThu = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell73 = new DevExpress.XtraReports.UI.XRTableCell();
            this.TopMargin = new DevExpress.XtraReports.UI.TopMarginBand();
            this.BottomMargin = new DevExpress.XtraReports.UI.BottomMarginBand();
            this.ReportHeader = new DevExpress.XtraReports.UI.ReportHeaderBand();
            this.xrTable3 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow2 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell2 = new DevExpress.XtraReports.UI.XRTableCell();
            this.TongConPhaiThu = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTable11 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow11 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell77 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTable2 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow3 = new DevExpress.XtraReports.UI.XRTableRow();
            this.lblTitle = new DevExpress.XtraReports.UI.XRTableCell();
            this.TongPhaiThu = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTable13 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow13 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell84 = new DevExpress.XtraReports.UI.XRTableCell();
            this.lbTuyBien = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell86 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTable10 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow10 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell74 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell75 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell76 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTable1 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow1 = new DevExpress.XtraReports.UI.XRTableRow();
            this.lbThang = new DevExpress.XtraReports.UI.XRTableCell();
            this.TongDaThu = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTable14 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow14 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell87 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell88 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumDK = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumDien = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumTienDienDH = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumNuoc = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumXe = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumTienDienThoai = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumNgoaiGio = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell94 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumPhaiThu = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumDaThu = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumConPhaiThu = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell98 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTable12 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow12 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell78 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell1 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell79 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell80 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell4 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell81 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell82 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell83 = new DevExpress.XtraReports.UI.XRTableCell();
            this.GroupHeader1 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.xrTable9 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow15 = new DevExpress.XtraReports.UI.XRTableRow();
            this.cTenCongTy = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumCongTyDauKy = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumCongTyTienDien = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumCongTyTienDienDH = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumCongTyTienNuoc = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumCongTyTienXe = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumCongTyDienThoai = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumCongTyTienNgoaiGio = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell36 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumCongTyTongPhaiThu = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumCongTyDaThu = new DevExpress.XtraReports.UI.XRTableCell();
            this.cSumCongTyConPhaiThu = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell37 = new DevExpress.XtraReports.UI.XRTableCell();
            this.ReportFooter = new DevExpress.XtraReports.UI.ReportFooterBand();
            this.xrTable16 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow17 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell16 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell17 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTable5 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow6 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell15 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrSubreport1 = new DevExpress.XtraReports.UI.XRSubreport();
            this.PageHeader = new DevExpress.XtraReports.UI.PageHeaderBand();
            this.xrTable7 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow8 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell32 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell33 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell34 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTable8 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow9 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell35 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTable6 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow7 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell29 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell30 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell31 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTable4 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow5 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell7 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell8 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell9 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell10 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell11 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell12 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell13 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell14 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell3 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell5 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell6 = new DevExpress.XtraReports.UI.XRTableCell();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // Detail
            // 
            this.Detail.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTable15});
            this.Detail.HeightF = 25.00002F;
            this.Detail.Name = "Detail";
            this.Detail.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Detail.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrTable15
            // 
            this.xrTable15.Font = new System.Drawing.Font("Times New Roman", 11F);
            this.xrTable15.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrTable15.Name = "xrTable15";
            this.xrTable15.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow16});
            this.xrTable15.SizeF = new System.Drawing.SizeF(1603F, 25.00002F);
            this.xrTable15.StylePriority.UseFont = false;
            this.xrTable15.StylePriority.UseTextAlignment = false;
            this.xrTable15.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // xrTableRow16
            // 
            this.xrTableRow16.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.cSTT,
            this.cKH,
            this.cDauKy,
            this.cTienDien,
            this.cTienDienDH,
            this.cTienNuoc,
            this.cTienXe,
            this.cDT,
            this.cNgoaiGio,
            this.cThuKhac,
            this.cPhaiThu,
            this.cDaThu,
            this.cConPhaiThu,
            this.xrTableCell73});
            this.xrTableRow16.Name = "xrTableRow16";
            this.xrTableRow16.Weight = 1D;
            // 
            // cSTT
            // 
            this.cSTT.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSTT.Name = "cSTT";
            this.cSTT.StylePriority.UseBorders = false;
            xrSummary1.FormatString = "{0:n}";
            xrSummary1.Func = DevExpress.XtraReports.UI.SummaryFunc.RecordNumber;
            xrSummary1.Running = DevExpress.XtraReports.UI.SummaryRunning.Group;
            this.cSTT.Summary = xrSummary1;
            this.cSTT.Weight = 0.0948140374533382D;
            // 
            // cKH
            // 
            this.cKH.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cKH.Multiline = true;
            this.cKH.Name = "cKH";
            this.cKH.Padding = new DevExpress.XtraPrinting.PaddingInfo(5, 0, 0, 0, 100F);
            this.cKH.StylePriority.UseBorders = false;
            this.cKH.StylePriority.UsePadding = false;
            this.cKH.StylePriority.UseTextAlignment = false;
            this.cKH.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            this.cKH.Weight = 0.33738226408181354D;
            // 
            // cDauKy
            // 
            this.cDauKy.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cDauKy.Multiline = true;
            this.cDauKy.Name = "cDauKy";
            this.cDauKy.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cDauKy.StylePriority.UseBorders = false;
            this.cDauKy.StylePriority.UsePadding = false;
            this.cDauKy.StylePriority.UseTextAlignment = false;
            this.cDauKy.Text = "\r\n";
            this.cDauKy.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cDauKy.Weight = 0.20814472511704624D;
            // 
            // cTienDien
            // 
            this.cTienDien.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cTienDien.Multiline = true;
            this.cTienDien.Name = "cTienDien";
            this.cTienDien.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cTienDien.StylePriority.UseBorders = false;
            this.cTienDien.StylePriority.UsePadding = false;
            this.cTienDien.StylePriority.UseTextAlignment = false;
            this.cTienDien.Text = "\r\n";
            this.cTienDien.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cTienDien.Weight = 0.18667697241252806D;
            // 
            // cTienDienDH
            // 
            this.cTienDienDH.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cTienDienDH.Name = "cTienDienDH";
            this.cTienDienDH.StylePriority.UseBorders = false;
            this.cTienDienDH.Weight = 0.2207188351755211D;
            // 
            // cTienNuoc
            // 
            this.cTienNuoc.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cTienNuoc.Multiline = true;
            this.cTienNuoc.Name = "cTienNuoc";
            this.cTienNuoc.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cTienNuoc.StylePriority.UseBorders = false;
            this.cTienNuoc.StylePriority.UsePadding = false;
            this.cTienNuoc.StylePriority.UseTextAlignment = false;
            this.cTienNuoc.Text = "\r\n";
            this.cTienNuoc.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cTienNuoc.Weight = 0.1971702996337758D;
            // 
            // cTienXe
            // 
            this.cTienXe.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cTienXe.Multiline = true;
            this.cTienXe.Name = "cTienXe";
            this.cTienXe.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cTienXe.StylePriority.UseBorders = false;
            this.cTienXe.StylePriority.UsePadding = false;
            this.cTienXe.StylePriority.UseTextAlignment = false;
            this.cTienXe.Text = "\r\n";
            this.cTienXe.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cTienXe.Weight = 0.20123665110013328D;
            // 
            // cDT
            // 
            this.cDT.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cDT.Name = "cDT";
            this.cDT.StylePriority.UseBorders = false;
            this.cDT.Weight = 0.18308115052892038D;
            // 
            // cNgoaiGio
            // 
            this.cNgoaiGio.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cNgoaiGio.Multiline = true;
            this.cNgoaiGio.Name = "cNgoaiGio";
            this.cNgoaiGio.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cNgoaiGio.StylePriority.UseBorders = false;
            this.cNgoaiGio.StylePriority.UsePadding = false;
            this.cNgoaiGio.StylePriority.UseTextAlignment = false;
            this.cNgoaiGio.Text = "\r\n";
            this.cNgoaiGio.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cNgoaiGio.Weight = 0.3107037282942875D;
            // 
            // cThuKhac
            // 
            this.cThuKhac.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cThuKhac.Multiline = true;
            this.cThuKhac.Name = "cThuKhac";
            this.cThuKhac.StylePriority.UseBorders = false;
            this.cThuKhac.Text = "\r\n";
            this.cThuKhac.Weight = 0.20909941587034317D;
            // 
            // cPhaiThu
            // 
            this.cPhaiThu.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cPhaiThu.Multiline = true;
            this.cPhaiThu.Name = "cPhaiThu";
            this.cPhaiThu.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cPhaiThu.StylePriority.UseBorders = false;
            this.cPhaiThu.StylePriority.UsePadding = false;
            this.cPhaiThu.StylePriority.UseTextAlignment = false;
            this.cPhaiThu.Text = "\r\n";
            this.cPhaiThu.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cPhaiThu.Weight = 0.35151705381341009D;
            // 
            // cDaThu
            // 
            this.cDaThu.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cDaThu.Multiline = true;
            this.cDaThu.Name = "cDaThu";
            this.cDaThu.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cDaThu.StylePriority.UseBorders = false;
            this.cDaThu.StylePriority.UsePadding = false;
            this.cDaThu.StylePriority.UseTextAlignment = false;
            this.cDaThu.Text = "\r\n";
            this.cDaThu.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cDaThu.Weight = 0.21910054347431623D;
            // 
            // cConPhaiThu
            // 
            this.cConPhaiThu.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cConPhaiThu.Multiline = true;
            this.cConPhaiThu.Name = "cConPhaiThu";
            this.cConPhaiThu.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cConPhaiThu.StylePriority.UseBorders = false;
            this.cConPhaiThu.StylePriority.UsePadding = false;
            this.cConPhaiThu.StylePriority.UseTextAlignment = false;
            this.cConPhaiThu.Text = "\r\n";
            this.cConPhaiThu.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cConPhaiThu.Weight = 0.31587916201065336D;
            // 
            // xrTableCell73
            // 
            this.xrTableCell73.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top) 
            | DevExpress.XtraPrinting.BorderSide.Right)));
            this.xrTableCell73.Multiline = true;
            this.xrTableCell73.Name = "xrTableCell73";
            this.xrTableCell73.StylePriority.UseBorders = false;
            this.xrTableCell73.Text = "\r\n";
            this.xrTableCell73.Weight = 0.45685019829993523D;
            // 
            // TopMargin
            // 
            this.TopMargin.HeightF = 11F;
            this.TopMargin.Name = "TopMargin";
            this.TopMargin.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.TopMargin.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // BottomMargin
            // 
            this.BottomMargin.HeightF = 79F;
            this.BottomMargin.Name = "BottomMargin";
            this.BottomMargin.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.BottomMargin.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // ReportHeader
            // 
            this.ReportHeader.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTable3,
            this.xrTable11,
            this.xrTable2,
            this.xrTable13,
            this.xrTable10,
            this.xrTable1,
            this.xrTable14,
            this.xrTable12});
            this.ReportHeader.HeightF = 237.4784F;
            this.ReportHeader.Name = "ReportHeader";
            // 
            // xrTable3
            // 
            this.xrTable3.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold);
            this.xrTable3.LocationFloat = new DevExpress.Utils.PointFloat(3.973643E-05F, 78.12503F);
            this.xrTable3.Name = "xrTable3";
            this.xrTable3.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow2});
            this.xrTable3.SizeF = new System.Drawing.SizeF(1603F, 24.99999F);
            this.xrTable3.StylePriority.UseFont = false;
            this.xrTable3.StylePriority.UseTextAlignment = false;
            this.xrTable3.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // xrTableRow2
            // 
            this.xrTableRow2.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell2,
            this.xrTableCell6,
            this.TongConPhaiThu});
            this.xrTableRow2.Name = "xrTableRow2";
            this.xrTableRow2.Weight = 1D;
            // 
            // xrTableCell2
            // 
            this.xrTableCell2.Name = "xrTableCell2";
            this.xrTableCell2.Weight = 2.4883804749639351D;
            // 
            // TongConPhaiThu
            // 
            this.TongConPhaiThu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.TongConPhaiThu.Name = "TongConPhaiThu";
            this.TongConPhaiThu.StylePriority.UseFont = false;
            this.TongConPhaiThu.Weight = 0.23869299933230684D;
            // 
            // xrTable11
            // 
            this.xrTable11.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.xrTable11.LocationFloat = new DevExpress.Utils.PointFloat(293.9164F, 150F);
            this.xrTable11.Name = "xrTable11";
            this.xrTable11.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow11});
            this.xrTable11.SizeF = new System.Drawing.SizeF(853.8337F, 25F);
            this.xrTable11.StylePriority.UseFont = false;
            // 
            // xrTableRow11
            // 
            this.xrTableRow11.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell77});
            this.xrTableRow11.Name = "xrTableRow11";
            this.xrTableRow11.Weight = 1D;
            // 
            // xrTableCell77
            // 
            this.xrTableCell77.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell77.Name = "xrTableCell77";
            this.xrTableCell77.StylePriority.UseBorders = false;
            this.xrTableCell77.StylePriority.UseTextAlignment = false;
            this.xrTableCell77.Text = "CÁC KHOẢN PHÍ PHẢI THU";
            this.xrTableCell77.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell77.Weight = 3D;
            // 
            // xrTable2
            // 
            this.xrTable2.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold);
            this.xrTable2.LocationFloat = new DevExpress.Utils.PointFloat(0F, 28.125F);
            this.xrTable2.Name = "xrTable2";
            this.xrTable2.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow3});
            this.xrTable2.SizeF = new System.Drawing.SizeF(1603F, 25.00001F);
            this.xrTable2.StylePriority.UseFont = false;
            this.xrTable2.StylePriority.UseTextAlignment = false;
            this.xrTable2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // xrTableRow3
            // 
            this.xrTableRow3.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.lblTitle,
            this.xrTableCell3,
            this.TongPhaiThu});
            this.xrTableRow3.Name = "xrTableRow3";
            this.xrTableRow3.Weight = 1D;
            // 
            // lblTitle
            // 
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Text = "BÁO CÁO CÁC KHOẢN PHÍ DỊCH VỤ PHẢI THU";
            this.lblTitle.Weight = 2.4883807034174206D;
            // 
            // TongPhaiThu
            // 
            this.TongPhaiThu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.TongPhaiThu.Name = "TongPhaiThu";
            this.TongPhaiThu.StylePriority.UseFont = false;
            this.TongPhaiThu.Weight = 0.2386932277857923D;
            // 
            // xrTable13
            // 
            this.xrTable13.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.xrTable13.LocationFloat = new DevExpress.Utils.PointFloat(1147.75F, 149.9784F);
            this.xrTable13.Name = "xrTable13";
            this.xrTable13.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow13});
            this.xrTable13.SizeF = new System.Drawing.SizeF(455.25F, 62.5F);
            this.xrTable13.StylePriority.UseFont = false;
            this.xrTable13.StylePriority.UseTextAlignment = false;
            this.xrTable13.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // xrTableRow13
            // 
            this.xrTableRow13.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell84,
            this.lbTuyBien,
            this.xrTableCell86});
            this.xrTableRow13.Name = "xrTableRow13";
            this.xrTableRow13.Weight = 1D;
            // 
            // xrTableCell84
            // 
            this.xrTableCell84.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell84.Name = "xrTableCell84";
            this.xrTableCell84.StylePriority.UseBorders = false;
            this.xrTableCell84.Text = "Đã thu";
            this.xrTableCell84.Weight = 0.9091635081534708D;
            // 
            // lbTuyBien
            // 
            this.lbTuyBien.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.lbTuyBien.Multiline = true;
            this.lbTuyBien.Name = "lbTuyBien";
            this.lbTuyBien.StylePriority.UseBorders = false;
            this.lbTuyBien.Text = "CÒN PHẢI THU";
            this.lbTuyBien.Weight = 1.3107519965458878D;
            // 
            // xrTableCell86
            // 
            this.xrTableCell86.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top) 
            | DevExpress.XtraPrinting.BorderSide.Right)));
            this.xrTableCell86.Name = "xrTableCell86";
            this.xrTableCell86.StylePriority.UseBorders = false;
            this.xrTableCell86.Text = "Ghi chú - báo cáo - giải quyết";
            this.xrTableCell86.Weight = 1.8957125629481593D;
            // 
            // xrTable10
            // 
            this.xrTable10.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.xrTable10.LocationFloat = new DevExpress.Utils.PointFloat(0F, 150F);
            this.xrTable10.Name = "xrTable10";
            this.xrTable10.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow10});
            this.xrTable10.SizeF = new System.Drawing.SizeF(293.9166F, 62.5F);
            this.xrTable10.StylePriority.UseFont = false;
            this.xrTable10.StylePriority.UseTextAlignment = false;
            this.xrTable10.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // xrTableRow10
            // 
            this.xrTableRow10.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell74,
            this.xrTableCell75,
            this.xrTableCell76});
            this.xrTableRow10.Name = "xrTableRow10";
            this.xrTableRow10.Weight = 1D;
            // 
            // xrTableCell74
            // 
            this.xrTableCell74.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell74.Name = "xrTableCell74";
            this.xrTableCell74.StylePriority.UseBorders = false;
            this.xrTableCell74.Weight = 0.29705512101067189D;
            // 
            // xrTableCell75
            // 
            this.xrTableCell75.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell75.Name = "xrTableCell75";
            this.xrTableCell75.StylePriority.UseBorders = false;
            this.xrTableCell75.Text = "Khách hàng";
            this.xrTableCell75.Weight = 1.0570282013974175D;
            // 
            // xrTableCell76
            // 
            this.xrTableCell76.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell76.Name = "xrTableCell76";
            this.xrTableCell76.StylePriority.UseBorders = false;
            this.xrTableCell76.Text = "Nợ cũ chuyển sang";
            this.xrTableCell76.Weight = 0.652123937230072D;
            // 
            // xrTable1
            // 
            this.xrTable1.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold);
            this.xrTable1.LocationFloat = new DevExpress.Utils.PointFloat(0F, 53.12503F);
            this.xrTable1.Name = "xrTable1";
            this.xrTable1.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow1});
            this.xrTable1.SizeF = new System.Drawing.SizeF(1603F, 24.99999F);
            this.xrTable1.StylePriority.UseFont = false;
            this.xrTable1.StylePriority.UseTextAlignment = false;
            this.xrTable1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // xrTableRow1
            // 
            this.xrTableRow1.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.lbThang,
            this.xrTableCell5,
            this.TongDaThu});
            this.xrTableRow1.Name = "xrTableRow1";
            this.xrTableRow1.Weight = 1D;
            // 
            // lbThang
            // 
            this.lbThang.Name = "lbThang";
            this.lbThang.Text = "THÁNG 2/2016";
            this.lbThang.Weight = 2.4883804749639351D;
            // 
            // TongDaThu
            // 
            this.TongDaThu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.TongDaThu.Name = "TongDaThu";
            this.TongDaThu.StylePriority.UseFont = false;
            this.TongDaThu.Weight = 0.23869299933230684D;
            // 
            // xrTable14
            // 
            this.xrTable14.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.xrTable14.LocationFloat = new DevExpress.Utils.PointFloat(0F, 212.4784F);
            this.xrTable14.Name = "xrTable14";
            this.xrTable14.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow14});
            this.xrTable14.SizeF = new System.Drawing.SizeF(1603F, 25.00002F);
            this.xrTable14.StylePriority.UseFont = false;
            this.xrTable14.StylePriority.UseTextAlignment = false;
            this.xrTable14.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // xrTableRow14
            // 
            this.xrTableRow14.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell87,
            this.xrTableCell88,
            this.cSumDK,
            this.cSumDien,
            this.cSumTienDienDH,
            this.cSumNuoc,
            this.cSumXe,
            this.cSumTienDienThoai,
            this.cSumNgoaiGio,
            this.xrTableCell94,
            this.cSumPhaiThu,
            this.cSumDaThu,
            this.cSumConPhaiThu,
            this.xrTableCell98});
            this.xrTableRow14.Name = "xrTableRow14";
            this.xrTableRow14.Weight = 1D;
            // 
            // xrTableCell87
            // 
            this.xrTableCell87.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell87.Name = "xrTableCell87";
            this.xrTableCell87.StylePriority.UseBorders = false;
            this.xrTableCell87.Weight = 0.0948140374533382D;
            // 
            // xrTableCell88
            // 
            this.xrTableCell88.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell88.Name = "xrTableCell88";
            this.xrTableCell88.StylePriority.UseBorders = false;
            this.xrTableCell88.Text = "TỔNG CỘNG";
            this.xrTableCell88.Weight = 0.33738226408181354D;
            // 
            // cSumDK
            // 
            this.cSumDK.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumDK.Multiline = true;
            this.cSumDK.Name = "cSumDK";
            this.cSumDK.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cSumDK.StylePriority.UseBorders = false;
            this.cSumDK.StylePriority.UsePadding = false;
            this.cSumDK.StylePriority.UseTextAlignment = false;
            this.cSumDK.Text = "\r\n";
            this.cSumDK.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumDK.Weight = 0.20814472511704624D;
            // 
            // cSumDien
            // 
            this.cSumDien.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumDien.Multiline = true;
            this.cSumDien.Name = "cSumDien";
            this.cSumDien.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cSumDien.StylePriority.UseBorders = false;
            this.cSumDien.StylePriority.UsePadding = false;
            this.cSumDien.StylePriority.UseTextAlignment = false;
            this.cSumDien.Text = "\r\n";
            this.cSumDien.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumDien.Weight = 0.18667723836094488D;
            // 
            // cSumTienDienDH
            // 
            this.cSumTienDienDH.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumTienDienDH.Name = "cSumTienDienDH";
            this.cSumTienDienDH.StylePriority.UseBorders = false;
            this.cSumTienDienDH.StylePriority.UseTextAlignment = false;
            this.cSumTienDienDH.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumTienDienDH.Weight = 0.2207186689577606D;
            // 
            // cSumNuoc
            // 
            this.cSumNuoc.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumNuoc.Multiline = true;
            this.cSumNuoc.Name = "cSumNuoc";
            this.cSumNuoc.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cSumNuoc.StylePriority.UseBorders = false;
            this.cSumNuoc.StylePriority.UsePadding = false;
            this.cSumNuoc.StylePriority.UseTextAlignment = false;
            this.cSumNuoc.Text = "\r\n";
            this.cSumNuoc.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumNuoc.Weight = 0.1971702663902237D;
            // 
            // cSumXe
            // 
            this.cSumXe.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumXe.Multiline = true;
            this.cSumXe.Name = "cSumXe";
            this.cSumXe.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cSumXe.StylePriority.UseBorders = false;
            this.cSumXe.StylePriority.UsePadding = false;
            this.cSumXe.StylePriority.UseTextAlignment = false;
            this.cSumXe.Text = "\r\n";
            this.cSumXe.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumXe.Weight = 0.20123665110013325D;
            // 
            // cSumTienDienThoai
            // 
            this.cSumTienDienThoai.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumTienDienThoai.Name = "cSumTienDienThoai";
            this.cSumTienDienThoai.StylePriority.UseBorders = false;
            this.cSumTienDienThoai.Weight = 0.18308115052892041D;
            // 
            // cSumNgoaiGio
            // 
            this.cSumNgoaiGio.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumNgoaiGio.Multiline = true;
            this.cSumNgoaiGio.Name = "cSumNgoaiGio";
            this.cSumNgoaiGio.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cSumNgoaiGio.StylePriority.UseBorders = false;
            this.cSumNgoaiGio.StylePriority.UsePadding = false;
            this.cSumNgoaiGio.StylePriority.UseTextAlignment = false;
            this.cSumNgoaiGio.Text = "\r\n";
            this.cSumNgoaiGio.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumNgoaiGio.Weight = 0.31070367842895935D;
            // 
            // xrTableCell94
            // 
            this.xrTableCell94.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell94.Multiline = true;
            this.xrTableCell94.Name = "xrTableCell94";
            this.xrTableCell94.StylePriority.UseBorders = false;
            this.xrTableCell94.Text = "\r\n";
            this.xrTableCell94.Weight = 0.20909941587034311D;
            // 
            // cSumPhaiThu
            // 
            this.cSumPhaiThu.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumPhaiThu.Multiline = true;
            this.cSumPhaiThu.Name = "cSumPhaiThu";
            this.cSumPhaiThu.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cSumPhaiThu.StylePriority.UseBorders = false;
            this.cSumPhaiThu.StylePriority.UsePadding = false;
            this.cSumPhaiThu.StylePriority.UseTextAlignment = false;
            this.cSumPhaiThu.Text = "\r\n";
            this.cSumPhaiThu.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumPhaiThu.Weight = 0.35151705381341014D;
            // 
            // cSumDaThu
            // 
            this.cSumDaThu.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumDaThu.Multiline = true;
            this.cSumDaThu.Name = "cSumDaThu";
            this.cSumDaThu.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cSumDaThu.StylePriority.UseBorders = false;
            this.cSumDaThu.StylePriority.UsePadding = false;
            this.cSumDaThu.StylePriority.UseTextAlignment = false;
            this.cSumDaThu.Text = "\r\n";
            this.cSumDaThu.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumDaThu.Weight = 0.21910027752589939D;
            // 
            // cSumConPhaiThu
            // 
            this.cSumConPhaiThu.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumConPhaiThu.Multiline = true;
            this.cSumConPhaiThu.Name = "cSumConPhaiThu";
            this.cSumConPhaiThu.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cSumConPhaiThu.StylePriority.UseBorders = false;
            this.cSumConPhaiThu.StylePriority.UsePadding = false;
            this.cSumConPhaiThu.StylePriority.UseTextAlignment = false;
            this.cSumConPhaiThu.Text = "\r\n";
            this.cSumConPhaiThu.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumConPhaiThu.Weight = 0.3158794279590702D;
            // 
            // xrTableCell98
            // 
            this.xrTableCell98.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top) 
            | DevExpress.XtraPrinting.BorderSide.Right)));
            this.xrTableCell98.Multiline = true;
            this.xrTableCell98.Name = "xrTableCell98";
            this.xrTableCell98.StylePriority.UseBorders = false;
            this.xrTableCell98.Text = "\r\n";
            this.xrTableCell98.Weight = 0.45685018167815916D;
            // 
            // xrTable12
            // 
            this.xrTable12.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.xrTable12.LocationFloat = new DevExpress.Utils.PointFloat(293.9164F, 175F);
            this.xrTable12.Name = "xrTable12";
            this.xrTable12.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow12});
            this.xrTable12.SizeF = new System.Drawing.SizeF(853.8339F, 37.5F);
            this.xrTable12.StylePriority.UseFont = false;
            this.xrTable12.StylePriority.UseTextAlignment = false;
            this.xrTable12.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // xrTableRow12
            // 
            this.xrTableRow12.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell78,
            this.xrTableCell1,
            this.xrTableCell79,
            this.xrTableCell80,
            this.xrTableCell4,
            this.xrTableCell81,
            this.xrTableCell82,
            this.xrTableCell83});
            this.xrTableRow12.Name = "xrTableRow12";
            this.xrTableRow12.Weight = 1D;
            // 
            // xrTableCell78
            // 
            this.xrTableCell78.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell78.Name = "xrTableCell78";
            this.xrTableCell78.StylePriority.UseBorders = false;
            this.xrTableCell78.Text = "Tiền điện";
            this.xrTableCell78.Weight = 0.30105941702897282D;
            // 
            // xrTableCell1
            // 
            this.xrTableCell1.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell1.Name = "xrTableCell1";
            this.xrTableCell1.StylePriority.UseBorders = false;
            this.xrTableCell1.Text = "Tiền điện ĐH";
            this.xrTableCell1.Weight = 0.3559589364015408D;
            // 
            // xrTableCell79
            // 
            this.xrTableCell79.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell79.Name = "xrTableCell79";
            this.xrTableCell79.StylePriority.UseBorders = false;
            this.xrTableCell79.Text = "Tiền nước";
            this.xrTableCell79.Weight = 0.31798154891323649D;
            // 
            // xrTableCell80
            // 
            this.xrTableCell80.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell80.Name = "xrTableCell80";
            this.xrTableCell80.StylePriority.UseBorders = false;
            this.xrTableCell80.Text = "Tiền xe";
            this.xrTableCell80.Weight = 0.32453929984874552D;
            // 
            // xrTableCell4
            // 
            this.xrTableCell4.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell4.Name = "xrTableCell4";
            this.xrTableCell4.StylePriority.UseBorders = false;
            this.xrTableCell4.Text = "Tiền điện thoại";
            this.xrTableCell4.Weight = 0.29525973411178208D;
            // 
            // xrTableCell81
            // 
            this.xrTableCell81.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell81.Name = "xrTableCell81";
            this.xrTableCell81.StylePriority.UseBorders = false;
            this.xrTableCell81.Text = "Thu phí DV ngoài giờ phát sinh";
            this.xrTableCell81.Weight = 0.50108046368207149D;
            // 
            // xrTableCell82
            // 
            this.xrTableCell82.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell82.Name = "xrTableCell82";
            this.xrTableCell82.StylePriority.UseBorders = false;
            this.xrTableCell82.Text = "Thu khác";
            this.xrTableCell82.Weight = 0.33721958035674016D;
            // 
            // xrTableCell83
            // 
            this.xrTableCell83.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell83.Name = "xrTableCell83";
            this.xrTableCell83.StylePriority.UseBorders = false;
            this.xrTableCell83.Text = "Tổng phải thu";
            this.xrTableCell83.Weight = 0.56690101965691064D;
            // 
            // GroupHeader1
            // 
            this.GroupHeader1.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTable9});
            this.GroupHeader1.HeightF = 25.00002F;
            this.GroupHeader1.Name = "GroupHeader1";
            // 
            // xrTable9
            // 
            this.xrTable9.BackColor = System.Drawing.Color.Silver;
            this.xrTable9.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.xrTable9.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrTable9.Name = "xrTable9";
            this.xrTable9.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow15});
            this.xrTable9.SizeF = new System.Drawing.SizeF(1603F, 25.00002F);
            this.xrTable9.StylePriority.UseBackColor = false;
            this.xrTable9.StylePriority.UseFont = false;
            this.xrTable9.StylePriority.UseTextAlignment = false;
            this.xrTable9.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // xrTableRow15
            // 
            this.xrTableRow15.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.cTenCongTy,
            this.cSumCongTyDauKy,
            this.cSumCongTyTienDien,
            this.cSumCongTyTienDienDH,
            this.cSumCongTyTienNuoc,
            this.cSumCongTyTienXe,
            this.cSumCongTyDienThoai,
            this.cSumCongTyTienNgoaiGio,
            this.xrTableCell36,
            this.cSumCongTyTongPhaiThu,
            this.cSumCongTyDaThu,
            this.cSumCongTyConPhaiThu,
            this.xrTableCell37});
            this.xrTableRow15.Name = "xrTableRow15";
            this.xrTableRow15.Weight = 1D;
            // 
            // cTenCongTy
            // 
            this.cTenCongTy.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cTenCongTy.Multiline = true;
            this.cTenCongTy.Name = "cTenCongTy";
            this.cTenCongTy.StylePriority.UseBorders = false;
            this.cTenCongTy.Text = "Công Ty";
            this.cTenCongTy.Weight = 0.43219630153515176D;
            // 
            // cSumCongTyDauKy
            // 
            this.cSumCongTyDauKy.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumCongTyDauKy.Multiline = true;
            this.cSumCongTyDauKy.Name = "cSumCongTyDauKy";
            this.cSumCongTyDauKy.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cSumCongTyDauKy.StylePriority.UseBorders = false;
            this.cSumCongTyDauKy.StylePriority.UsePadding = false;
            this.cSumCongTyDauKy.StylePriority.UseTextAlignment = false;
            this.cSumCongTyDauKy.Text = "\r\n";
            this.cSumCongTyDauKy.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumCongTyDauKy.Weight = 0.20814472511704624D;
            // 
            // cSumCongTyTienDien
            // 
            this.cSumCongTyTienDien.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumCongTyTienDien.Multiline = true;
            this.cSumCongTyTienDien.Name = "cSumCongTyTienDien";
            this.cSumCongTyTienDien.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cSumCongTyTienDien.StylePriority.UseBorders = false;
            this.cSumCongTyTienDien.StylePriority.UsePadding = false;
            this.cSumCongTyTienDien.StylePriority.UseTextAlignment = false;
            this.cSumCongTyTienDien.Text = "\r\n";
            this.cSumCongTyTienDien.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumCongTyTienDien.Weight = 0.18667697241252806D;
            // 
            // cSumCongTyTienDienDH
            // 
            this.cSumCongTyTienDienDH.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumCongTyTienDienDH.Name = "cSumCongTyTienDienDH";
            this.cSumCongTyTienDienDH.StylePriority.UseBorders = false;
            this.cSumCongTyTienDienDH.StylePriority.UseTextAlignment = false;
            this.cSumCongTyTienDienDH.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumCongTyTienDienDH.Weight = 0.2207188351755211D;
            // 
            // cSumCongTyTienNuoc
            // 
            this.cSumCongTyTienNuoc.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumCongTyTienNuoc.Multiline = true;
            this.cSumCongTyTienNuoc.Name = "cSumCongTyTienNuoc";
            this.cSumCongTyTienNuoc.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cSumCongTyTienNuoc.StylePriority.UseBorders = false;
            this.cSumCongTyTienNuoc.StylePriority.UsePadding = false;
            this.cSumCongTyTienNuoc.StylePriority.UseTextAlignment = false;
            this.cSumCongTyTienNuoc.Text = "\r\n";
            this.cSumCongTyTienNuoc.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumCongTyTienNuoc.Weight = 0.1971702996337758D;
            // 
            // cSumCongTyTienXe
            // 
            this.cSumCongTyTienXe.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumCongTyTienXe.Multiline = true;
            this.cSumCongTyTienXe.Name = "cSumCongTyTienXe";
            this.cSumCongTyTienXe.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cSumCongTyTienXe.StylePriority.UseBorders = false;
            this.cSumCongTyTienXe.StylePriority.UsePadding = false;
            this.cSumCongTyTienXe.StylePriority.UseTextAlignment = false;
            this.cSumCongTyTienXe.Text = "\r\n";
            this.cSumCongTyTienXe.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumCongTyTienXe.Weight = 0.20123665110013328D;
            // 
            // cSumCongTyDienThoai
            // 
            this.cSumCongTyDienThoai.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumCongTyDienThoai.Name = "cSumCongTyDienThoai";
            this.cSumCongTyDienThoai.StylePriority.UseBorders = false;
            this.cSumCongTyDienThoai.Text = "-";
            this.cSumCongTyDienThoai.Weight = 0.18308115052892038D;
            // 
            // cSumCongTyTienNgoaiGio
            // 
            this.cSumCongTyTienNgoaiGio.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumCongTyTienNgoaiGio.Multiline = true;
            this.cSumCongTyTienNgoaiGio.Name = "cSumCongTyTienNgoaiGio";
            this.cSumCongTyTienNgoaiGio.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cSumCongTyTienNgoaiGio.StylePriority.UseBorders = false;
            this.cSumCongTyTienNgoaiGio.StylePriority.UsePadding = false;
            this.cSumCongTyTienNgoaiGio.StylePriority.UseTextAlignment = false;
            this.cSumCongTyTienNgoaiGio.Text = "\r\n";
            this.cSumCongTyTienNgoaiGio.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumCongTyTienNgoaiGio.Weight = 0.3107037282942875D;
            // 
            // xrTableCell36
            // 
            this.xrTableCell36.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell36.Multiline = true;
            this.xrTableCell36.Name = "xrTableCell36";
            this.xrTableCell36.StylePriority.UseBorders = false;
            this.xrTableCell36.Text = "-";
            this.xrTableCell36.Weight = 0.20909941587034317D;
            // 
            // cSumCongTyTongPhaiThu
            // 
            this.cSumCongTyTongPhaiThu.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumCongTyTongPhaiThu.Multiline = true;
            this.cSumCongTyTongPhaiThu.Name = "cSumCongTyTongPhaiThu";
            this.cSumCongTyTongPhaiThu.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cSumCongTyTongPhaiThu.StylePriority.UseBorders = false;
            this.cSumCongTyTongPhaiThu.StylePriority.UsePadding = false;
            this.cSumCongTyTongPhaiThu.StylePriority.UseTextAlignment = false;
            this.cSumCongTyTongPhaiThu.Text = "\r\n";
            this.cSumCongTyTongPhaiThu.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumCongTyTongPhaiThu.Weight = 0.35151705381341009D;
            // 
            // cSumCongTyDaThu
            // 
            this.cSumCongTyDaThu.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumCongTyDaThu.Multiline = true;
            this.cSumCongTyDaThu.Name = "cSumCongTyDaThu";
            this.cSumCongTyDaThu.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cSumCongTyDaThu.StylePriority.UseBorders = false;
            this.cSumCongTyDaThu.StylePriority.UsePadding = false;
            this.cSumCongTyDaThu.StylePriority.UseTextAlignment = false;
            this.cSumCongTyDaThu.Text = "\r\n";
            this.cSumCongTyDaThu.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumCongTyDaThu.Weight = 0.21910054347431623D;
            // 
            // cSumCongTyConPhaiThu
            // 
            this.cSumCongTyConPhaiThu.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.cSumCongTyConPhaiThu.Multiline = true;
            this.cSumCongTyConPhaiThu.Name = "cSumCongTyConPhaiThu";
            this.cSumCongTyConPhaiThu.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.cSumCongTyConPhaiThu.StylePriority.UseBorders = false;
            this.cSumCongTyConPhaiThu.StylePriority.UsePadding = false;
            this.cSumCongTyConPhaiThu.StylePriority.UseTextAlignment = false;
            this.cSumCongTyConPhaiThu.Text = "\r\n";
            this.cSumCongTyConPhaiThu.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.cSumCongTyConPhaiThu.Weight = 0.31587916201065336D;
            // 
            // xrTableCell37
            // 
            this.xrTableCell37.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top) 
            | DevExpress.XtraPrinting.BorderSide.Right)));
            this.xrTableCell37.Multiline = true;
            this.xrTableCell37.Name = "xrTableCell37";
            this.xrTableCell37.StylePriority.UseBorders = false;
            this.xrTableCell37.Text = "\r\n";
            this.xrTableCell37.Weight = 0.45685019829993523D;
            // 
            // ReportFooter
            // 
            this.ReportFooter.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTable16,
            this.xrTable5,
            this.xrSubreport1});
            this.ReportFooter.HeightF = 90.70829F;
            this.ReportFooter.Name = "ReportFooter";
            // 
            // xrTable16
            // 
            this.xrTable16.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.xrTable16.LocationFloat = new DevExpress.Utils.PointFloat(953.0127F, 55.70828F);
            this.xrTable16.Name = "xrTable16";
            this.xrTable16.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow17});
            this.xrTable16.SizeF = new System.Drawing.SizeF(608.8461F, 25F);
            this.xrTable16.StylePriority.UseFont = false;
            this.xrTable16.StylePriority.UseTextAlignment = false;
            this.xrTable16.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // xrTableRow17
            // 
            this.xrTableRow17.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell16,
            this.xrTableCell17});
            this.xrTableRow17.Name = "xrTableRow17";
            this.xrTableRow17.Weight = 1D;
            // 
            // xrTableCell16
            // 
            this.xrTableCell16.Name = "xrTableCell16";
            this.xrTableCell16.Text = "Kế toán";
            this.xrTableCell16.Weight = 1.6458331298828126D;
            // 
            // xrTableCell17
            // 
            this.xrTableCell17.Name = "xrTableCell17";
            this.xrTableCell17.Text = "Phụ trách";
            this.xrTableCell17.Weight = 1.3541668701171874D;
            // 
            // xrTable5
            // 
            this.xrTable5.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrTable5.Name = "xrTable5";
            this.xrTable5.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow6});
            this.xrTable5.SizeF = new System.Drawing.SizeF(1603F, 25F);
            // 
            // xrTableRow6
            // 
            this.xrTableRow6.Borders = DevExpress.XtraPrinting.BorderSide.Top;
            this.xrTableRow6.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell15});
            this.xrTableRow6.Name = "xrTableRow6";
            this.xrTableRow6.StylePriority.UseBorders = false;
            this.xrTableRow6.Weight = 1D;
            // 
            // xrTableCell15
            // 
            this.xrTableCell15.Name = "xrTableCell15";
            this.xrTableCell15.Weight = 3D;
            // 
            // xrSubreport1
            // 
            this.xrSubreport1.LocationFloat = new DevExpress.Utils.PointFloat(43.51964F, 0F);
            this.xrSubreport1.Name = "xrSubreport1";
            this.xrSubreport1.SizeF = new System.Drawing.SizeF(663.78F, 23F);
            this.xrSubreport1.BeforePrint += new System.Drawing.Printing.PrintEventHandler(this.xrSubreport1_BeforePrint);
            // 
            // PageHeader
            // 
            this.PageHeader.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTable7,
            this.xrTable8,
            this.xrTable6,
            this.xrTable4});
            this.PageHeader.HeightF = 65F;
            this.PageHeader.Name = "PageHeader";
            this.PageHeader.PrintOn = DevExpress.XtraReports.UI.PrintOnPages.NotWithReportHeader;
            // 
            // xrTable7
            // 
            this.xrTable7.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.xrTable7.LocationFloat = new DevExpress.Utils.PointFloat(1147.75F, 0F);
            this.xrTable7.Name = "xrTable7";
            this.xrTable7.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow8});
            this.xrTable7.SizeF = new System.Drawing.SizeF(455.25F, 65F);
            this.xrTable7.StylePriority.UseFont = false;
            this.xrTable7.StylePriority.UseTextAlignment = false;
            this.xrTable7.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // xrTableRow8
            // 
            this.xrTableRow8.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell32,
            this.xrTableCell33,
            this.xrTableCell34});
            this.xrTableRow8.Name = "xrTableRow8";
            this.xrTableRow8.Weight = 1D;
            // 
            // xrTableCell32
            // 
            this.xrTableCell32.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell32.Name = "xrTableCell32";
            this.xrTableCell32.StylePriority.UseBorders = false;
            this.xrTableCell32.Text = "Đã thu";
            this.xrTableCell32.Weight = 0.9091635081534708D;
            // 
            // xrTableCell33
            // 
            this.xrTableCell33.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell33.Multiline = true;
            this.xrTableCell33.Name = "xrTableCell33";
            this.xrTableCell33.StylePriority.UseBorders = false;
            this.xrTableCell33.Text = "CÒN PHẢI THU";
            this.xrTableCell33.Weight = 1.3107519965458878D;
            // 
            // xrTableCell34
            // 
            this.xrTableCell34.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top) 
            | DevExpress.XtraPrinting.BorderSide.Right)));
            this.xrTableCell34.Name = "xrTableCell34";
            this.xrTableCell34.StylePriority.UseBorders = false;
            this.xrTableCell34.Text = "Ghi chú - báo cáo - giải quyết";
            this.xrTableCell34.Weight = 1.8957125629481593D;
            // 
            // xrTable8
            // 
            this.xrTable8.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.xrTable8.LocationFloat = new DevExpress.Utils.PointFloat(293.9163F, 0F);
            this.xrTable8.Name = "xrTable8";
            this.xrTable8.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow9});
            this.xrTable8.SizeF = new System.Drawing.SizeF(853.8337F, 25F);
            this.xrTable8.StylePriority.UseFont = false;
            // 
            // xrTableRow9
            // 
            this.xrTableRow9.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell35});
            this.xrTableRow9.Name = "xrTableRow9";
            this.xrTableRow9.Weight = 1D;
            // 
            // xrTableCell35
            // 
            this.xrTableCell35.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell35.Name = "xrTableCell35";
            this.xrTableCell35.StylePriority.UseBorders = false;
            this.xrTableCell35.StylePriority.UseTextAlignment = false;
            this.xrTableCell35.Text = "CÁC KHOẢN PHÍ PHẢI THU";
            this.xrTableCell35.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell35.Weight = 3D;
            // 
            // xrTable6
            // 
            this.xrTable6.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.xrTable6.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrTable6.Name = "xrTable6";
            this.xrTable6.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow7});
            this.xrTable6.SizeF = new System.Drawing.SizeF(293.9166F, 65F);
            this.xrTable6.StylePriority.UseFont = false;
            this.xrTable6.StylePriority.UseTextAlignment = false;
            this.xrTable6.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // xrTableRow7
            // 
            this.xrTableRow7.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell29,
            this.xrTableCell30,
            this.xrTableCell31});
            this.xrTableRow7.Name = "xrTableRow7";
            this.xrTableRow7.Weight = 1D;
            // 
            // xrTableCell29
            // 
            this.xrTableCell29.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell29.Name = "xrTableCell29";
            this.xrTableCell29.StylePriority.UseBorders = false;
            this.xrTableCell29.Weight = 0.29705512101067189D;
            // 
            // xrTableCell30
            // 
            this.xrTableCell30.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell30.Name = "xrTableCell30";
            this.xrTableCell30.StylePriority.UseBorders = false;
            this.xrTableCell30.Text = "Khách hàng";
            this.xrTableCell30.Weight = 1.0570282013974175D;
            // 
            // xrTableCell31
            // 
            this.xrTableCell31.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell31.Name = "xrTableCell31";
            this.xrTableCell31.StylePriority.UseBorders = false;
            this.xrTableCell31.Text = "Nợ cũ chuyển sang";
            this.xrTableCell31.Weight = 0.652123937230072D;
            // 
            // xrTable4
            // 
            this.xrTable4.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.xrTable4.LocationFloat = new DevExpress.Utils.PointFloat(293.9163F, 25F);
            this.xrTable4.Name = "xrTable4";
            this.xrTable4.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow5});
            this.xrTable4.SizeF = new System.Drawing.SizeF(853.8339F, 37.5F);
            this.xrTable4.StylePriority.UseFont = false;
            this.xrTable4.StylePriority.UseTextAlignment = false;
            this.xrTable4.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // xrTableRow5
            // 
            this.xrTableRow5.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell7,
            this.xrTableCell8,
            this.xrTableCell9,
            this.xrTableCell10,
            this.xrTableCell11,
            this.xrTableCell12,
            this.xrTableCell13,
            this.xrTableCell14});
            this.xrTableRow5.Name = "xrTableRow5";
            this.xrTableRow5.Weight = 1D;
            // 
            // xrTableCell7
            // 
            this.xrTableCell7.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell7.Name = "xrTableCell7";
            this.xrTableCell7.StylePriority.UseBorders = false;
            this.xrTableCell7.Text = "Tiền điện";
            this.xrTableCell7.Weight = 0.30105941702897282D;
            // 
            // xrTableCell8
            // 
            this.xrTableCell8.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell8.Name = "xrTableCell8";
            this.xrTableCell8.StylePriority.UseBorders = false;
            this.xrTableCell8.Text = "Tiền điện ĐH";
            this.xrTableCell8.Weight = 0.3559589364015408D;
            // 
            // xrTableCell9
            // 
            this.xrTableCell9.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell9.Name = "xrTableCell9";
            this.xrTableCell9.StylePriority.UseBorders = false;
            this.xrTableCell9.Text = "Tiền nước";
            this.xrTableCell9.Weight = 0.31798154891323649D;
            // 
            // xrTableCell10
            // 
            this.xrTableCell10.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell10.Name = "xrTableCell10";
            this.xrTableCell10.StylePriority.UseBorders = false;
            this.xrTableCell10.Text = "Tiền xe";
            this.xrTableCell10.Weight = 0.32453929984874552D;
            // 
            // xrTableCell11
            // 
            this.xrTableCell11.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell11.Name = "xrTableCell11";
            this.xrTableCell11.StylePriority.UseBorders = false;
            this.xrTableCell11.Text = "Tiền điện thoại";
            this.xrTableCell11.Weight = 0.29525973411178208D;
            // 
            // xrTableCell12
            // 
            this.xrTableCell12.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell12.Name = "xrTableCell12";
            this.xrTableCell12.StylePriority.UseBorders = false;
            this.xrTableCell12.Text = "Thu phí DV ngoài giờ phát sinh";
            this.xrTableCell12.Weight = 0.50108046368207149D;
            // 
            // xrTableCell13
            // 
            this.xrTableCell13.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell13.Name = "xrTableCell13";
            this.xrTableCell13.StylePriority.UseBorders = false;
            this.xrTableCell13.Text = "Thu khác";
            this.xrTableCell13.Weight = 0.33721958035674016D;
            // 
            // xrTableCell14
            // 
            this.xrTableCell14.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell14.Name = "xrTableCell14";
            this.xrTableCell14.StylePriority.UseBorders = false;
            this.xrTableCell14.Text = "Tổng phải thu";
            this.xrTableCell14.Weight = 0.56690101965691064D;
            // 
            // xrTableCell3
            // 
            this.xrTableCell3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.xrTableCell3.Name = "xrTableCell3";
            this.xrTableCell3.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.xrTableCell3.StylePriority.UseFont = false;
            this.xrTableCell3.StylePriority.UsePadding = false;
            this.xrTableCell3.StylePriority.UseTextAlignment = false;
            this.xrTableCell3.Text = "Tổng phải thu";
            this.xrTableCell3.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.xrTableCell3.Weight = 0.27292606879678727D;
            // 
            // xrTableCell5
            // 
            this.xrTableCell5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.xrTableCell5.Name = "xrTableCell5";
            this.xrTableCell5.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.xrTableCell5.StylePriority.UseFont = false;
            this.xrTableCell5.StylePriority.UsePadding = false;
            this.xrTableCell5.StylePriority.UseTextAlignment = false;
            this.xrTableCell5.Text = "Tổng đã thu";
            this.xrTableCell5.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.xrTableCell5.Weight = 0.27292652570375842D;
            // 
            // xrTableCell6
            // 
            this.xrTableCell6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.xrTableCell6.Name = "xrTableCell6";
            this.xrTableCell6.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 5, 0, 0, 100F);
            this.xrTableCell6.StylePriority.UseFont = false;
            this.xrTableCell6.StylePriority.UsePadding = false;
            this.xrTableCell6.StylePriority.UseTextAlignment = false;
            this.xrTableCell6.Text = "Còn nợ";
            this.xrTableCell6.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.xrTableCell6.Weight = 0.27292652570375842D;
            // 
            // rptBaoCaoCacKhoanPhiDV
            // 
            this.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail,
            this.TopMargin,
            this.BottomMargin,
            this.ReportHeader,
            this.GroupHeader1,
            this.ReportFooter,
            this.PageHeader});
            this.Landscape = true;
            this.Margins = new System.Drawing.Printing.Margins(43, 100, 11, 79);
            this.PageHeight = 1276;
            this.PageWidth = 1803;
            this.PaperKind = System.Drawing.Printing.PaperKind.Custom;
            this.Version = "12.1";
            ((System.ComponentModel.ISupportInitialize)(this.xrTable15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }

        #endregion

        private DevExpress.XtraReports.UI.DetailBand Detail;
        private DevExpress.XtraReports.UI.TopMarginBand TopMargin;
        private DevExpress.XtraReports.UI.BottomMarginBand BottomMargin;
        private DevExpress.XtraReports.UI.ReportHeaderBand ReportHeader;
        private DevExpress.XtraReports.UI.GroupHeaderBand GroupHeader1;
        private DevExpress.XtraReports.UI.ReportFooterBand ReportFooter;
        private DevExpress.XtraReports.UI.PageHeaderBand PageHeader;
        private DevExpress.XtraReports.UI.XRTable xrTable11;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow11;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell77;
        private DevExpress.XtraReports.UI.XRTable xrTable2;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow3;
        private DevExpress.XtraReports.UI.XRTableCell lblTitle;
        private DevExpress.XtraReports.UI.XRTable xrTable13;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow13;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell84;
        private DevExpress.XtraReports.UI.XRTableCell lbTuyBien;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell86;
        private DevExpress.XtraReports.UI.XRTable xrTable10;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow10;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell74;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell75;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell76;
        private DevExpress.XtraReports.UI.XRTable xrTable1;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow1;
        private DevExpress.XtraReports.UI.XRTableCell lbThang;
        private DevExpress.XtraReports.UI.XRTable xrTable14;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow14;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell87;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell88;
        private DevExpress.XtraReports.UI.XRTableCell cSumDK;
        private DevExpress.XtraReports.UI.XRTableCell cSumDien;
        private DevExpress.XtraReports.UI.XRTableCell cSumNuoc;
        private DevExpress.XtraReports.UI.XRTableCell cSumXe;
        private DevExpress.XtraReports.UI.XRTableCell cSumNgoaiGio;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell94;
        private DevExpress.XtraReports.UI.XRTableCell cSumPhaiThu;
        private DevExpress.XtraReports.UI.XRTableCell cSumDaThu;
        private DevExpress.XtraReports.UI.XRTableCell cSumConPhaiThu;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell98;
        private DevExpress.XtraReports.UI.XRTable xrTable12;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow12;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell78;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell79;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell80;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell81;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell82;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell83;
        private DevExpress.XtraReports.UI.XRTableCell cSumTienDienDH;
        private DevExpress.XtraReports.UI.XRTableCell cSumTienDienThoai;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell1;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell4;
        private DevExpress.XtraReports.UI.XRTable xrTable7;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow8;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell32;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell33;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell34;
        private DevExpress.XtraReports.UI.XRTable xrTable8;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow9;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell35;
        private DevExpress.XtraReports.UI.XRTable xrTable6;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow7;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell29;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell30;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell31;
        private DevExpress.XtraReports.UI.XRTable xrTable4;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow5;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell7;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell8;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell9;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell10;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell11;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell12;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell13;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell14;
        private DevExpress.XtraReports.UI.XRTable xrTable9;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow15;
        private DevExpress.XtraReports.UI.XRTableCell cTenCongTy;
        private DevExpress.XtraReports.UI.XRTableCell cSumCongTyDauKy;
        private DevExpress.XtraReports.UI.XRTableCell cSumCongTyTienDien;
        private DevExpress.XtraReports.UI.XRTableCell cSumCongTyTienNuoc;
        private DevExpress.XtraReports.UI.XRTableCell cSumCongTyTienXe;
        private DevExpress.XtraReports.UI.XRTableCell cSumCongTyTienNgoaiGio;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell36;
        private DevExpress.XtraReports.UI.XRTableCell cSumCongTyTongPhaiThu;
        private DevExpress.XtraReports.UI.XRTableCell cSumCongTyDaThu;
        private DevExpress.XtraReports.UI.XRTableCell cSumCongTyConPhaiThu;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell37;
        private DevExpress.XtraReports.UI.XRTable xrTable15;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow16;
        private DevExpress.XtraReports.UI.XRTableCell cSTT;
        private DevExpress.XtraReports.UI.XRTableCell cKH;
        private DevExpress.XtraReports.UI.XRTableCell cDauKy;
        private DevExpress.XtraReports.UI.XRTableCell cTienDien;
        private DevExpress.XtraReports.UI.XRTableCell cTienNuoc;
        private DevExpress.XtraReports.UI.XRTableCell cTienXe;
        private DevExpress.XtraReports.UI.XRTableCell cNgoaiGio;
        private DevExpress.XtraReports.UI.XRTableCell cThuKhac;
        private DevExpress.XtraReports.UI.XRTableCell cPhaiThu;
        private DevExpress.XtraReports.UI.XRTableCell cDaThu;
        private DevExpress.XtraReports.UI.XRTableCell cConPhaiThu;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell73;
        private DevExpress.XtraReports.UI.XRTableCell cTienDienDH;
        private DevExpress.XtraReports.UI.XRTableCell cDT;
        private DevExpress.XtraReports.UI.XRTableCell cSumCongTyTienDienDH;
        private DevExpress.XtraReports.UI.XRTableCell cSumCongTyDienThoai;
        private DevExpress.XtraReports.UI.XRSubreport xrSubreport1;
        private DevExpress.XtraReports.UI.XRTable xrTable5;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow6;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell15;
        private DevExpress.XtraReports.UI.XRTable xrTable16;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow17;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell16;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell17;
        private DevExpress.XtraReports.UI.XRTable xrTable3;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow2;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell2;
        private DevExpress.XtraReports.UI.XRTableCell TongConPhaiThu;
        private DevExpress.XtraReports.UI.XRTableCell TongPhaiThu;
        private DevExpress.XtraReports.UI.XRTableCell TongDaThu;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell6;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell3;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell5;
    }
}
