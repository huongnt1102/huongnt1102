﻿namespace LandSoftBuilding.Receivables
{
    partial class frmDieuChinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEdit));
            this.glkMatBang = new DevExpress.XtraEditors.GridLookUpEdit();
            this.gridLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            this.txtFKey = new DevExpress.XtraEditors.TextEdit();
            this.txtSoHoaDon = new DevExpress.XtraEditors.TextEdit();
            this.lkLoaiHoaDon = new DevExpress.XtraEditors.LookUpEdit();
            this.spinEdit1 = new DevExpress.XtraEditors.SpinEdit();
            this.spTyLeVAT = new DevExpress.XtraEditors.SpinEdit();
            this.spTienVAT = new DevExpress.XtraEditors.SpinEdit();
            this.lkTheXe = new DevExpress.XtraEditors.LookUpEdit();
            this.ckThuThua = new DevExpress.XtraEditors.CheckEdit();
            this.btnLuu = new DevExpress.XtraEditors.SimpleButton();
            this.imageCollection1 = new DevExpress.Utils.ImageCollection(this.components);
            this.btnHuy = new DevExpress.XtraEditors.SimpleButton();
            this.spPhiDV = new DevExpress.XtraEditors.SpinEdit();
            this.glkKhachHang = new DevExpress.XtraEditors.GridLookUpEdit();
            this.gvKhachHang = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.lkLoaiDichVu = new DevExpress.XtraEditors.LookUpEdit();
            this.dateNgayTT = new DevExpress.XtraEditors.DateEdit();
            this.spKyTT = new DevExpress.XtraEditors.SpinEdit();
            this.txtDienGiai = new DevExpress.XtraEditors.MemoEdit();
            this.spTienTT = new DevExpress.XtraEditors.SpinEdit();
            this.spinTyLeCK = new DevExpress.XtraEditors.SpinEdit();
            this.dateDenNgay = new DevExpress.XtraEditors.DateEdit();
            this.spinTienCK = new DevExpress.XtraEditors.SpinEdit();
            this.spinThanhTien = new DevExpress.XtraEditors.SpinEdit();
            this.dateTuNgay = new DevExpress.XtraEditors.DateEdit();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem16 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem17 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem20 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem19 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem18 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem21 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem22 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem23 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            ((System.ComponentModel.ISupportInitialize)(this.glkMatBang.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).BeginInit();
            this.layoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtFKey.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoHoaDon.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lkLoaiHoaDon.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spTyLeVAT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spTienVAT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lkTheXe.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ckThuThua.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spPhiDV.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.glkKhachHang.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvKhachHang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lkLoaiDichVu.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateNgayTT.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateNgayTT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spKyTT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDienGiai.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spTienTT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinTyLeCK.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateDenNgay.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateDenNgay.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinTienCK.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinThanhTien.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTuNgay.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTuNgay.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            this.SuspendLayout();
            // 
            // glkMatBang
            // 
            this.glkMatBang.Location = new System.Drawing.Point(120, 36);
            this.glkMatBang.Name = "glkMatBang";
            this.glkMatBang.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.glkMatBang.Properties.DisplayMember = "MaSoMB";
            this.glkMatBang.Properties.NullText = "";
            this.glkMatBang.Properties.ValueMember = "MaMB";
            this.glkMatBang.Properties.View = this.gridLookUpEdit1View;
            this.glkMatBang.Size = new System.Drawing.Size(543, 20);
            this.glkMatBang.StyleController = this.layoutControl1;
            this.glkMatBang.TabIndex = 50;
            this.glkMatBang.EditValueChanged += new System.EventHandler(this.glkMatBang_EditValueChanged);
            // 
            // gridLookUpEdit1View
            // 
            this.gridLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn3,
            this.gridColumn5,
            this.gridColumn6});
            this.gridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridLookUpEdit1View.Name = "gridLookUpEdit1View";
            this.gridLookUpEdit1View.OptionsBehavior.Editable = false;
            this.gridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridLookUpEdit1View.OptionsView.ShowAutoFilterRow = true;
            this.gridLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "Mã số";
            this.gridColumn1.FieldName = "MaSoMB";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 203;
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "Khách hàng";
            this.gridColumn3.FieldName = "TenKH";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 1;
            this.gridColumn3.Width = 570;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "Tầng/Lầu";
            this.gridColumn5.FieldName = "TenTL";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 2;
            this.gridColumn5.Width = 150;
            // 
            // gridColumn6
            // 
            this.gridColumn6.Caption = "Khối nhà/Block";
            this.gridColumn6.FieldName = "TenKN";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 3;
            this.gridColumn6.Width = 171;
            // 
            // layoutControl1
            // 
            this.layoutControl1.Controls.Add(this.txtFKey);
            this.layoutControl1.Controls.Add(this.txtSoHoaDon);
            this.layoutControl1.Controls.Add(this.lkLoaiHoaDon);
            this.layoutControl1.Controls.Add(this.spinEdit1);
            this.layoutControl1.Controls.Add(this.spTyLeVAT);
            this.layoutControl1.Controls.Add(this.spTienVAT);
            this.layoutControl1.Controls.Add(this.lkTheXe);
            this.layoutControl1.Controls.Add(this.ckThuThua);
            this.layoutControl1.Controls.Add(this.btnLuu);
            this.layoutControl1.Controls.Add(this.btnHuy);
            this.layoutControl1.Controls.Add(this.spPhiDV);
            this.layoutControl1.Controls.Add(this.glkKhachHang);
            this.layoutControl1.Controls.Add(this.glkMatBang);
            this.layoutControl1.Controls.Add(this.lkLoaiDichVu);
            this.layoutControl1.Controls.Add(this.dateNgayTT);
            this.layoutControl1.Controls.Add(this.spKyTT);
            this.layoutControl1.Controls.Add(this.txtDienGiai);
            this.layoutControl1.Controls.Add(this.spTienTT);
            this.layoutControl1.Controls.Add(this.spinTyLeCK);
            this.layoutControl1.Controls.Add(this.dateDenNgay);
            this.layoutControl1.Controls.Add(this.spinTienCK);
            this.layoutControl1.Controls.Add(this.spinThanhTien);
            this.layoutControl1.Controls.Add(this.dateTuNgay);
            this.layoutControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl1.Location = new System.Drawing.Point(0, 0);
            this.layoutControl1.Name = "layoutControl1";
            this.layoutControl1.Root = this.layoutControlGroup1;
            this.layoutControl1.Size = new System.Drawing.Size(675, 390);
            this.layoutControl1.TabIndex = 76;
            this.layoutControl1.Text = "layoutControl1";
            // 
            // txtFKey
            // 
            this.txtFKey.EditValue = "FKey";
            this.txtFKey.Enabled = false;
            this.txtFKey.Location = new System.Drawing.Point(120, 132);
            this.txtFKey.Name = "txtFKey";
            this.txtFKey.Properties.Appearance.BackColor = System.Drawing.Color.LightGray;
            this.txtFKey.Properties.Appearance.ForeColor = System.Drawing.Color.Red;
            this.txtFKey.Properties.Appearance.Options.UseBackColor = true;
            this.txtFKey.Properties.Appearance.Options.UseForeColor = true;
            this.txtFKey.Size = new System.Drawing.Size(216, 20);
            this.txtFKey.StyleController = this.layoutControl1;
            this.txtFKey.TabIndex = 83;
            // 
            // txtSoHoaDon
            // 
            this.txtSoHoaDon.Location = new System.Drawing.Point(120, 108);
            this.txtSoHoaDon.Name = "txtSoHoaDon";
            this.txtSoHoaDon.Properties.NullText = "[F1 để search]";
            this.txtSoHoaDon.Size = new System.Drawing.Size(216, 20);
            this.txtSoHoaDon.StyleController = this.layoutControl1;
            this.txtSoHoaDon.TabIndex = 82;
            this.txtSoHoaDon.EditValueChanged += new System.EventHandler(this.txtSoHoaDon_EditValueChanged);
            this.txtSoHoaDon.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSoHoaDon_KeyDown);
            // 
            // lkLoaiHoaDon
            // 
            this.lkLoaiHoaDon.Location = new System.Drawing.Point(120, 84);
            this.lkLoaiHoaDon.Name = "lkLoaiHoaDon";
            this.lkLoaiHoaDon.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lkLoaiHoaDon.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Loai", "Name"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("LoaiVNPT", "Name")});
            this.lkLoaiHoaDon.Properties.DisplayMember = "Loai";
            this.lkLoaiHoaDon.Properties.NullText = "[Loại hóa đơn]";
            this.lkLoaiHoaDon.Properties.ValueMember = "ID";
            this.lkLoaiHoaDon.Size = new System.Drawing.Size(216, 20);
            this.lkLoaiHoaDon.StyleController = this.layoutControl1;
            this.lkLoaiHoaDon.TabIndex = 81;
            // 
            // spinEdit1
            // 
            this.spinEdit1.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.spinEdit1.Location = new System.Drawing.Point(120, 156);
            this.spinEdit1.Name = "spinEdit1";
            this.spinEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.spinEdit1.Properties.DisplayFormat.FormatString = "c0";
            this.spinEdit1.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.spinEdit1.Properties.Mask.EditMask = "c0";
            this.spinEdit1.Size = new System.Drawing.Size(543, 20);
            this.spinEdit1.StyleController = this.layoutControl1;
            this.spinEdit1.TabIndex = 80;
            // 
            // spTyLeVAT
            // 
            this.spTyLeVAT.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.spTyLeVAT.Location = new System.Drawing.Point(120, 228);
            this.spTyLeVAT.Name = "spTyLeVAT";
            this.spTyLeVAT.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.spTyLeVAT.Properties.DisplayFormat.FormatString = "p2";
            this.spTyLeVAT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.spTyLeVAT.Properties.EditFormat.FormatString = "p2";
            this.spTyLeVAT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.spTyLeVAT.Properties.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.spTyLeVAT.Properties.Mask.EditMask = "p2";
            this.spTyLeVAT.Size = new System.Drawing.Size(216, 20);
            this.spTyLeVAT.StyleController = this.layoutControl1;
            this.spTyLeVAT.TabIndex = 79;
            this.spTyLeVAT.EditValueChanged += new System.EventHandler(this.spTyLeVAT_EditValueChanged);
            // 
            // spTienVAT
            // 
            this.spTienVAT.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.spTienVAT.Location = new System.Drawing.Point(448, 228);
            this.spTienVAT.Name = "spTienVAT";
            this.spTienVAT.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.spTienVAT.Properties.DisplayFormat.FormatString = "c0";
            this.spTienVAT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.spTienVAT.Properties.Mask.EditMask = "c0";
            this.spTienVAT.Properties.ReadOnly = true;
            this.spTienVAT.Size = new System.Drawing.Size(215, 20);
            this.spTienVAT.StyleController = this.layoutControl1;
            this.spTienVAT.TabIndex = 78;
            // 
            // lkTheXe
            // 
            this.lkTheXe.Location = new System.Drawing.Point(448, 60);
            this.lkTheXe.Name = "lkTheXe";
            this.lkTheXe.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lkTheXe.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("SoThe", "Số thẻ"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("BienSo", "Biển số"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("NgayTT", "Ngày TT")});
            this.lkTheXe.Properties.DisplayMember = "SoThe";
            this.lkTheXe.Properties.NullText = "Chọn thẻ xe";
            this.lkTheXe.Properties.ValueMember = "ID";
            this.lkTheXe.Size = new System.Drawing.Size(215, 20);
            this.lkTheXe.StyleController = this.layoutControl1;
            this.lkTheXe.TabIndex = 77;
            this.lkTheXe.EditValueChanged += new System.EventHandler(this.lkTheXe_EditValueChanged);
            // 
            // ckThuThua
            // 
            this.ckThuThua.Location = new System.Drawing.Point(12, 352);
            this.ckThuThua.Name = "ckThuThua";
            this.ckThuThua.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckThuThua.Properties.Appearance.Options.UseFont = true;
            this.ckThuThua.Properties.Caption = "Xuất hóa đơn";
            this.ckThuThua.Size = new System.Drawing.Size(223, 19);
            this.ckThuThua.StyleController = this.layoutControl1;
            this.ckThuThua.TabIndex = 76;
            // 
            // btnLuu
            // 
            this.btnLuu.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuu.Appearance.Options.UseFont = true;
            this.btnLuu.ImageIndex = 0;
            this.btnLuu.ImageList = this.imageCollection1;
            this.btnLuu.Location = new System.Drawing.Point(467, 352);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(116, 26);
            this.btnLuu.StyleController = this.layoutControl1;
            this.btnLuu.TabIndex = 75;
            this.btnLuu.Text = "Lưu && Đóng";
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // imageCollection1
            // 
            this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection1.ImageStream")));
            this.imageCollection1.Images.SetKeyName(0, "OK.png");
            this.imageCollection1.Images.SetKeyName(1, "Cancel.png");
            this.imageCollection1.Images.SetKeyName(2, "Print.png");
            // 
            // btnHuy
            // 
            this.btnHuy.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHuy.Appearance.Options.UseFont = true;
            this.btnHuy.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnHuy.ImageIndex = 1;
            this.btnHuy.ImageList = this.imageCollection1;
            this.btnHuy.Location = new System.Drawing.Point(587, 352);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(76, 26);
            this.btnHuy.StyleController = this.layoutControl1;
            this.btnHuy.TabIndex = 75;
            this.btnHuy.Text = "Hủy";
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // spPhiDV
            // 
            this.spPhiDV.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.spPhiDV.Location = new System.Drawing.Point(448, 84);
            this.spPhiDV.Name = "spPhiDV";
            this.spPhiDV.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.spPhiDV.Properties.DisplayFormat.FormatString = "c0";
            this.spPhiDV.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.spPhiDV.Properties.Mask.EditMask = "c0";
            this.spPhiDV.Size = new System.Drawing.Size(215, 20);
            this.spPhiDV.StyleController = this.layoutControl1;
            this.spPhiDV.TabIndex = 65;
            this.spPhiDV.EditValueChanged += new System.EventHandler(this.spinEditValueChanged);
            // 
            // glkKhachHang
            // 
            this.glkKhachHang.Location = new System.Drawing.Point(120, 12);
            this.glkKhachHang.Name = "glkKhachHang";
            this.glkKhachHang.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.glkKhachHang.Properties.DisplayMember = "TenKH";
            this.glkKhachHang.Properties.NullText = "";
            this.glkKhachHang.Properties.ValueMember = "MaKH";
            this.glkKhachHang.Properties.View = this.gvKhachHang;
            this.glkKhachHang.Size = new System.Drawing.Size(543, 20);
            this.glkKhachHang.StyleController = this.layoutControl1;
            this.glkKhachHang.TabIndex = 51;
            this.glkKhachHang.EditValueChanged += new System.EventHandler(this.glkKhachHang_EditValueChanged);
            // 
            // gvKhachHang
            // 
            this.gvKhachHang.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn2,
            this.gridColumn4,
            this.gridColumn7});
            this.gvKhachHang.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gvKhachHang.Name = "gvKhachHang";
            this.gvKhachHang.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gvKhachHang.OptionsView.ShowAutoFilterRow = true;
            this.gvKhachHang.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "Ký hiệu";
            this.gridColumn2.FieldName = "KyHieu";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 0;
            this.gridColumn2.Width = 123;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "Tên khách hàng";
            this.gridColumn4.FieldName = "TenKH";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 1;
            this.gridColumn4.Width = 241;
            // 
            // gridColumn7
            // 
            this.gridColumn7.Caption = "Địa chỉ";
            this.gridColumn7.FieldName = "DiaChi";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 2;
            this.gridColumn7.Width = 400;
            // 
            // lkLoaiDichVu
            // 
            this.lkLoaiDichVu.Location = new System.Drawing.Point(120, 60);
            this.lkLoaiDichVu.Name = "lkLoaiDichVu";
            this.lkLoaiDichVu.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lkLoaiDichVu.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("TenLDV", "Name1")});
            this.lkLoaiDichVu.Properties.DisplayMember = "TenLDV";
            this.lkLoaiDichVu.Properties.NullText = "";
            this.lkLoaiDichVu.Properties.ShowHeader = false;
            this.lkLoaiDichVu.Properties.ValueMember = "ID";
            this.lkLoaiDichVu.Size = new System.Drawing.Size(216, 20);
            this.lkLoaiDichVu.StyleController = this.layoutControl1;
            this.lkLoaiDichVu.TabIndex = 64;
            this.lkLoaiDichVu.EditValueChanged += new System.EventHandler(this.lkLoaiDichVu_EditValueChanged);
            // 
            // dateNgayTT
            // 
            this.dateNgayTT.EditValue = null;
            this.dateNgayTT.Location = new System.Drawing.Point(448, 108);
            this.dateNgayTT.Name = "dateNgayTT";
            this.dateNgayTT.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateNgayTT.Properties.DisplayFormat.FormatString = "HH:mm | dd/MM/yyyy";
            this.dateNgayTT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.dateNgayTT.Properties.Mask.EditMask = "HH:mm | dd/MM/yyyy";
            this.dateNgayTT.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateNgayTT.Size = new System.Drawing.Size(215, 20);
            this.dateNgayTT.StyleController = this.layoutControl1;
            this.dateNgayTT.TabIndex = 66;
            this.dateNgayTT.EditValueChanged += new System.EventHandler(this.dateNgayTT_EditValueChanged);
            // 
            // spKyTT
            // 
            this.spKyTT.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.spKyTT.Location = new System.Drawing.Point(448, 132);
            this.spKyTT.Name = "spKyTT";
            this.spKyTT.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.spKyTT.Properties.DisplayFormat.FormatString = "{0:#,0.##} tháng";
            this.spKyTT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.spKyTT.Size = new System.Drawing.Size(215, 20);
            this.spKyTT.StyleController = this.layoutControl1;
            this.spKyTT.TabIndex = 65;
            this.spKyTT.EditValueChanged += new System.EventHandler(this.spinEditValueChanged);
            // 
            // txtDienGiai
            // 
            this.txtDienGiai.Location = new System.Drawing.Point(120, 324);
            this.txtDienGiai.Name = "txtDienGiai";
            this.txtDienGiai.Size = new System.Drawing.Size(543, 24);
            this.txtDienGiai.StyleController = this.layoutControl1;
            this.txtDienGiai.TabIndex = 73;
            // 
            // spTienTT
            // 
            this.spTienTT.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.spTienTT.Location = new System.Drawing.Point(120, 180);
            this.spTienTT.Name = "spTienTT";
            this.spTienTT.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.spTienTT.Properties.DisplayFormat.FormatString = "c0";
            this.spTienTT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.spTienTT.Properties.Mask.EditMask = "c0";
            this.spTienTT.Size = new System.Drawing.Size(543, 20);
            this.spTienTT.StyleController = this.layoutControl1;
            this.spTienTT.TabIndex = 67;
            this.spTienTT.EditValueChanged += new System.EventHandler(this.spinEditValueChanged);
            // 
            // spinTyLeCK
            // 
            this.spinTyLeCK.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.spinTyLeCK.Location = new System.Drawing.Point(120, 204);
            this.spinTyLeCK.Name = "spinTyLeCK";
            this.spinTyLeCK.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.spinTyLeCK.Properties.DisplayFormat.FormatString = "p2";
            this.spinTyLeCK.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.spinTyLeCK.Properties.Mask.EditMask = "p2";
            this.spinTyLeCK.Size = new System.Drawing.Size(216, 20);
            this.spinTyLeCK.StyleController = this.layoutControl1;
            this.spinTyLeCK.TabIndex = 65;
            this.spinTyLeCK.EditValueChanged += new System.EventHandler(this.spinEditValueChanged);
            // 
            // dateDenNgay
            // 
            this.dateDenNgay.EditValue = null;
            this.dateDenNgay.Location = new System.Drawing.Point(120, 300);
            this.dateDenNgay.Name = "dateDenNgay";
            this.dateDenNgay.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateDenNgay.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateDenNgay.Size = new System.Drawing.Size(543, 20);
            this.dateDenNgay.StyleController = this.layoutControl1;
            this.dateDenNgay.TabIndex = 72;
            // 
            // spinTienCK
            // 
            this.spinTienCK.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.spinTienCK.Location = new System.Drawing.Point(448, 204);
            this.spinTienCK.Name = "spinTienCK";
            this.spinTienCK.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.spinTienCK.Properties.DisplayFormat.FormatString = "c0";
            this.spinTienCK.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.spinTienCK.Properties.Mask.EditMask = "c0";
            this.spinTienCK.Properties.ReadOnly = true;
            this.spinTienCK.Size = new System.Drawing.Size(215, 20);
            this.spinTienCK.StyleController = this.layoutControl1;
            this.spinTienCK.TabIndex = 67;
            // 
            // spinThanhTien
            // 
            this.spinThanhTien.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.spinThanhTien.Location = new System.Drawing.Point(120, 252);
            this.spinThanhTien.Name = "spinThanhTien";
            this.spinThanhTien.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.spinThanhTien.Properties.DisplayFormat.FormatString = "c0";
            this.spinThanhTien.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.spinThanhTien.Properties.Mask.EditMask = "c0";
            this.spinThanhTien.Properties.ReadOnly = true;
            this.spinThanhTien.Size = new System.Drawing.Size(543, 20);
            this.spinThanhTien.StyleController = this.layoutControl1;
            this.spinThanhTien.TabIndex = 67;
            // 
            // dateTuNgay
            // 
            this.dateTuNgay.EditValue = null;
            this.dateTuNgay.Location = new System.Drawing.Point(120, 276);
            this.dateTuNgay.Name = "dateTuNgay";
            this.dateTuNgay.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateTuNgay.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateTuNgay.Size = new System.Drawing.Size(543, 20);
            this.dateTuNgay.StyleController = this.layoutControl1;
            this.dateTuNgay.TabIndex = 71;
            this.dateTuNgay.EditValueChanged += new System.EventHandler(this.spinEditValueChanged);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "layoutControlGroup1";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.layoutControlItem2,
            this.layoutControlItem3,
            this.layoutControlItem6,
            this.layoutControlItem7,
            this.layoutControlItem8,
            this.layoutControlItem10,
            this.layoutControlItem11,
            this.layoutControlItem12,
            this.layoutControlItem13,
            this.layoutControlItem14,
            this.layoutControlItem15,
            this.emptySpaceItem1,
            this.layoutControlItem16,
            this.layoutControlItem17,
            this.layoutControlItem4,
            this.layoutControlItem9,
            this.layoutControlItem20,
            this.layoutControlItem19,
            this.layoutControlItem18,
            this.layoutControlItem21,
            this.layoutControlItem22,
            this.layoutControlItem23,
            this.layoutControlItem5});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "layoutControlGroup1";
            this.layoutControlGroup1.Size = new System.Drawing.Size(675, 390);
            this.layoutControlGroup1.Text = "layoutControlGroup1";
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.glkKhachHang;
            this.layoutControlItem1.CustomizationFormText = "Khách hàng";
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(655, 24);
            this.layoutControlItem1.Text = "Khách hàng";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.glkMatBang;
            this.layoutControlItem2.CustomizationFormText = "Mặt bằng";
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 24);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(655, 24);
            this.layoutControlItem2.Text = "Mặt bằng";
            this.layoutControlItem2.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.lkLoaiDichVu;
            this.layoutControlItem3.CustomizationFormText = "Loại dịch vụ";
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 48);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(328, 24);
            this.layoutControlItem3.Text = "Loại dịch vụ";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.spKyTT;
            this.layoutControlItem6.CustomizationFormText = "Kỳ TT";
            this.layoutControlItem6.Location = new System.Drawing.Point(328, 120);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(327, 24);
            this.layoutControlItem6.Text = "Kỳ TT";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.spTienTT;
            this.layoutControlItem7.CustomizationFormText = "Tiền TT";
            this.layoutControlItem7.Location = new System.Drawing.Point(0, 168);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(655, 24);
            this.layoutControlItem7.Text = "Tiền TT";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.spinTyLeCK;
            this.layoutControlItem8.CustomizationFormText = "Tỷ lệ chiết khấu";
            this.layoutControlItem8.Location = new System.Drawing.Point(0, 192);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(328, 24);
            this.layoutControlItem8.Text = "Tỷ lệ chiết khấu";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.spinThanhTien;
            this.layoutControlItem10.CustomizationFormText = "Tiền phải thu";
            this.layoutControlItem10.Location = new System.Drawing.Point(0, 240);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(655, 24);
            this.layoutControlItem10.Text = "Tiền phải thu";
            this.layoutControlItem10.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.dateTuNgay;
            this.layoutControlItem11.CustomizationFormText = "Từ ngày";
            this.layoutControlItem11.Location = new System.Drawing.Point(0, 264);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(655, 24);
            this.layoutControlItem11.Text = "Từ ngày";
            this.layoutControlItem11.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.dateDenNgay;
            this.layoutControlItem12.CustomizationFormText = "Đến ngày";
            this.layoutControlItem12.Location = new System.Drawing.Point(0, 288);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(655, 24);
            this.layoutControlItem12.Text = "Đến ngày";
            this.layoutControlItem12.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.txtDienGiai;
            this.layoutControlItem13.CustomizationFormText = "Diễn giải";
            this.layoutControlItem13.Location = new System.Drawing.Point(0, 312);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(655, 28);
            this.layoutControlItem13.Text = "Diễn giải";
            this.layoutControlItem13.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.btnLuu;
            this.layoutControlItem14.CustomizationFormText = "layoutControlItem14";
            this.layoutControlItem14.Location = new System.Drawing.Point(455, 340);
            this.layoutControlItem14.MaxSize = new System.Drawing.Size(120, 30);
            this.layoutControlItem14.MinSize = new System.Drawing.Size(120, 30);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(120, 30);
            this.layoutControlItem14.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem14.Text = "layoutControlItem14";
            this.layoutControlItem14.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem14.TextToControlDistance = 0;
            this.layoutControlItem14.TextVisible = false;
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.Control = this.btnHuy;
            this.layoutControlItem15.CustomizationFormText = "layoutControlItem15";
            this.layoutControlItem15.Location = new System.Drawing.Point(575, 340);
            this.layoutControlItem15.MaxSize = new System.Drawing.Size(80, 30);
            this.layoutControlItem15.MinSize = new System.Drawing.Size(80, 30);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Size = new System.Drawing.Size(80, 30);
            this.layoutControlItem15.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem15.Text = "layoutControlItem15";
            this.layoutControlItem15.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem15.TextToControlDistance = 0;
            this.layoutControlItem15.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(227, 340);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(228, 30);
            this.emptySpaceItem1.Text = "emptySpaceItem1";
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem16
            // 
            this.layoutControlItem16.Control = this.ckThuThua;
            this.layoutControlItem16.CustomizationFormText = "layoutControlItem16";
            this.layoutControlItem16.Location = new System.Drawing.Point(0, 340);
            this.layoutControlItem16.Name = "layoutControlItem16";
            this.layoutControlItem16.Size = new System.Drawing.Size(227, 30);
            this.layoutControlItem16.Text = "layoutControlItem16";
            this.layoutControlItem16.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem16.TextToControlDistance = 0;
            this.layoutControlItem16.TextVisible = false;
            // 
            // layoutControlItem17
            // 
            this.layoutControlItem17.Control = this.lkTheXe;
            this.layoutControlItem17.CustomizationFormText = "Thẻ xe";
            this.layoutControlItem17.Location = new System.Drawing.Point(328, 48);
            this.layoutControlItem17.Name = "layoutControlItem17";
            this.layoutControlItem17.Size = new System.Drawing.Size(327, 24);
            this.layoutControlItem17.Text = "Thẻ xe";
            this.layoutControlItem17.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.spPhiDV;
            this.layoutControlItem4.CustomizationFormText = "Phí dịch vụ";
            this.layoutControlItem4.Location = new System.Drawing.Point(328, 72);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(327, 24);
            this.layoutControlItem4.Text = "Phí dịch vụ";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.spinTienCK;
            this.layoutControlItem9.CustomizationFormText = "Tiền CK";
            this.layoutControlItem9.Location = new System.Drawing.Point(328, 192);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(327, 24);
            this.layoutControlItem9.Text = "Tiền CK";
            this.layoutControlItem9.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem20
            // 
            this.layoutControlItem20.Control = this.spinEdit1;
            this.layoutControlItem20.CustomizationFormText = "Thành tiền";
            this.layoutControlItem20.Location = new System.Drawing.Point(0, 144);
            this.layoutControlItem20.Name = "layoutControlItem20";
            this.layoutControlItem20.Size = new System.Drawing.Size(655, 24);
            this.layoutControlItem20.Text = "Thành tiền";
            this.layoutControlItem20.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem19
            // 
            this.layoutControlItem19.Control = this.spTyLeVAT;
            this.layoutControlItem19.CustomizationFormText = "Tỷ lệ VAT";
            this.layoutControlItem19.Location = new System.Drawing.Point(0, 216);
            this.layoutControlItem19.Name = "layoutControlItem19";
            this.layoutControlItem19.Size = new System.Drawing.Size(328, 24);
            this.layoutControlItem19.Text = "Tỷ lệ VAT";
            this.layoutControlItem19.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem18
            // 
            this.layoutControlItem18.Control = this.spTienVAT;
            this.layoutControlItem18.CustomizationFormText = "Tiền VAT";
            this.layoutControlItem18.Location = new System.Drawing.Point(328, 216);
            this.layoutControlItem18.Name = "layoutControlItem18";
            this.layoutControlItem18.Size = new System.Drawing.Size(327, 24);
            this.layoutControlItem18.Text = "Tiền VAT";
            this.layoutControlItem18.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem21
            // 
            this.layoutControlItem21.Control = this.lkLoaiHoaDon;
            this.layoutControlItem21.CustomizationFormText = "Loại hóa đơn";
            this.layoutControlItem21.Location = new System.Drawing.Point(0, 72);
            this.layoutControlItem21.Name = "layoutControlItem21";
            this.layoutControlItem21.Size = new System.Drawing.Size(328, 24);
            this.layoutControlItem21.Text = "Loại hóa đơn";
            this.layoutControlItem21.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem22
            // 
            this.layoutControlItem22.Control = this.txtSoHoaDon;
            this.layoutControlItem22.CustomizationFormText = "Số hóa đơn điều chỉnh";
            this.layoutControlItem22.Location = new System.Drawing.Point(0, 96);
            this.layoutControlItem22.Name = "layoutControlItem22";
            this.layoutControlItem22.Size = new System.Drawing.Size(328, 24);
            this.layoutControlItem22.Text = "Số hóa đơn điều chỉnh";
            this.layoutControlItem22.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem23
            // 
            this.layoutControlItem23.Control = this.txtFKey;
            this.layoutControlItem23.CustomizationFormText = "FKey";
            this.layoutControlItem23.Location = new System.Drawing.Point(0, 120);
            this.layoutControlItem23.Name = "layoutControlItem23";
            this.layoutControlItem23.Size = new System.Drawing.Size(328, 24);
            this.layoutControlItem23.Text = "FKey";
            this.layoutControlItem23.TextSize = new System.Drawing.Size(105, 13);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.dateNgayTT;
            this.layoutControlItem5.CustomizationFormText = "Ngày TT";
            this.layoutControlItem5.Location = new System.Drawing.Point(328, 96);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(327, 24);
            this.layoutControlItem5.Text = "Ngày TT";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(105, 13);
            // 
            // frmEdit
            // 
            this.AcceptButton = this.btnLuu;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnHuy;
            this.ClientSize = new System.Drawing.Size(675, 390);
            this.Controls.Add(this.layoutControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.KeyPreview = true;
            this.MinimizeBox = false;
            this.Name = "frmEdit";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hóa đơn";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmEdit_FormClosing);
            this.Load += new System.EventHandler(this.frmEdit_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmEdit_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.glkMatBang.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).EndInit();
            this.layoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtFKey.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoHoaDon.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lkLoaiHoaDon.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spTyLeVAT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spTienVAT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lkTheXe.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ckThuThua.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spPhiDV.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.glkKhachHang.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvKhachHang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lkLoaiDichVu.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateNgayTT.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateNgayTT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spKyTT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDienGiai.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spTienTT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinTyLeCK.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateDenNgay.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateDenNgay.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinTienCK.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinThanhTien.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTuNgay.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTuNgay.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.GridLookUpEdit glkMatBang;
        private DevExpress.XtraGrid.Views.Grid.GridView gridLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraEditors.GridLookUpEdit glkKhachHang;
        private DevExpress.XtraGrid.Views.Grid.GridView gvKhachHang;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraEditors.LookUpEdit lkLoaiDichVu;
        private DevExpress.XtraEditors.SpinEdit spKyTT;
        private DevExpress.XtraEditors.DateEdit dateNgayTT;
        private DevExpress.XtraEditors.SpinEdit spTienTT;
        private DevExpress.XtraEditors.DateEdit dateTuNgay;
        private DevExpress.XtraEditors.DateEdit dateDenNgay;
        private DevExpress.XtraEditors.MemoEdit txtDienGiai;
        private DevExpress.XtraEditors.SpinEdit spinTyLeCK;
        private DevExpress.XtraEditors.SpinEdit spinTienCK;
        private DevExpress.XtraEditors.SpinEdit spinThanhTien;
        private DevExpress.XtraEditors.SimpleButton btnHuy;
        private DevExpress.XtraEditors.SimpleButton btnLuu;
        private DevExpress.Utils.ImageCollection imageCollection1;
        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        private DevExpress.XtraEditors.SpinEdit spPhiDV;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraEditors.CheckEdit ckThuThua;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem16;
        private DevExpress.XtraEditors.LookUpEdit lkTheXe;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem17;
        private DevExpress.XtraEditors.SpinEdit spTyLeVAT;
        private DevExpress.XtraEditors.SpinEdit spTienVAT;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem19;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem18;
        private DevExpress.XtraEditors.SpinEdit spinEdit1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem20;
        private DevExpress.XtraEditors.TextEdit txtSoHoaDon;
        private DevExpress.XtraEditors.LookUpEdit lkLoaiHoaDon;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem21;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem22;
        private DevExpress.XtraEditors.TextEdit txtFKey;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem23;
    }
}