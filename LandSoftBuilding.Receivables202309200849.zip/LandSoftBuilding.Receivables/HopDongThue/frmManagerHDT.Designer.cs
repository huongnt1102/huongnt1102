﻿namespace LandSoftBuilding.Receivables.HopDongThue
{
    partial class frmManagerHDT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmManagerHDT));
            this.barManager1 = new DevExpress.XtraBars.BarManager();
            this.bar1 = new DevExpress.XtraBars.Bar();
            this.itemToaNha = new DevExpress.XtraBars.BarEditItem();
            this.lkToaNha = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.itemKyBC = new DevExpress.XtraBars.BarEditItem();
            this.cbbKyBC = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.itemTuNgay = new DevExpress.XtraBars.BarEditItem();
            this.dateTuNgay = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.itemDenNgay = new DevExpress.XtraBars.BarEditItem();
            this.dateDenNgay = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.btnNap = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem1 = new DevExpress.XtraBars.BarSubItem();
            this.itemHoaDonNguoc = new DevExpress.XtraBars.BarButtonItem();
            this.btnThem = new DevExpress.XtraBars.BarButtonItem();
            this.itemAddMulti = new DevExpress.XtraBars.BarButtonItem();
            this.itemHDTTND = new DevExpress.XtraBars.BarButtonItem();
            this.itemPQL = new DevExpress.XtraBars.BarButtonItem();
            this.btnHoaDonXe = new DevExpress.XtraBars.BarButtonItem();
            this.itemThem = new DevExpress.XtraBars.BarButtonItem();
            this.itemSua = new DevExpress.XtraBars.BarButtonItem();
            this.itemDieuChinhHoaDon = new DevExpress.XtraBars.BarButtonItem();
            this.btnXoa = new DevExpress.XtraBars.BarButtonItem();
            this.barDuyet = new DevExpress.XtraBars.BarSubItem();
            this.itemDuyet = new DevExpress.XtraBars.BarButtonItem();
            this.itemDuyetAll = new DevExpress.XtraBars.BarButtonItem();
            this.itemKhongDuyet = new DevExpress.XtraBars.BarButtonItem();
            this.itemKhongDuyetAll = new DevExpress.XtraBars.BarButtonItem();
            this.itemThuTien = new DevExpress.XtraBars.BarButtonItem();
            this.itemImport = new DevExpress.XtraBars.BarButtonItem();
            this.itemExport = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.imageCollection1 = new DevExpress.Utils.ImageCollection();
            this.btnSua = new DevExpress.XtraBars.BarButtonItem();
            this.linqInstantFeedbackSource1 = new DevExpress.Data.Linq.LinqInstantFeedbackSource();
            this.gcHoaDon = new DevExpress.XtraGrid.GridControl();
            this.gvHoaDon = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn21 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn22 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn23 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn24 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn27 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn28 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn29 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn30 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn31 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn32 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn33 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn34 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn35 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn41 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn63 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn62 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn64 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn65 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn66 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn67 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn68 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn69 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn75 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn76 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn77 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn78 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn79 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.gcChiTiet = new DevExpress.XtraGrid.GridControl();
            this.gvChiTiet = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn26 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn25 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoExEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.gridColumn20 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            this.gcKhauTru = new DevExpress.XtraGrid.GridControl();
            this.grvKhauTru = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn36 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn37 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn38 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn39 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoExEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.gridColumn40 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.xtraTabPage3 = new DevExpress.XtraTab.XtraTabPage();
            this.gcKTTB = new DevExpress.XtraGrid.GridControl();
            this.grvKTTB = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn42 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn43 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn44 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn45 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoExEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.gridColumn46 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.xtraTabPage4 = new DevExpress.XtraTab.XtraTabPage();
            this.gcKTTG = new DevExpress.XtraGrid.GridControl();
            this.grvKTTG = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn47 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn48 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn49 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn50 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoExEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.gridColumn51 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.xtraTabPage5 = new DevExpress.XtraTab.XtraTabPage();
            this.gcKTBBQ = new DevExpress.XtraGrid.GridControl();
            this.grvKTBBQ = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn52 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn53 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn54 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn55 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoExEdit5 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.gridColumn56 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.xtraTabPage6 = new DevExpress.XtraTab.XtraTabPage();
            this.gcKTTC = new DevExpress.XtraGrid.GridControl();
            this.grvKTTC = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn57 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn58 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn59 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn60 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoExEdit6 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.gridColumn61 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.xtraTabPage7 = new DevExpress.XtraTab.XtraTabPage();
            this.gcKTHDT = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn70 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn71 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn72 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn73 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoExEdit7 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.gridColumn74 = new DevExpress.XtraGrid.Columns.GridColumn();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lkToaNha)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbbKyBC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTuNgay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTuNgay.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateDenNgay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateDenNgay.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcHoaDon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvHoaDon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
            this.splitContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.xtraTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcChiTiet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvChiTiet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit2)).BeginInit();
            this.xtraTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcKhauTru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvKhauTru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit3)).BeginInit();
            this.xtraTabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcKTTB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvKTTB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit1)).BeginInit();
            this.xtraTabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcKTTG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvKTTG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit4)).BeginInit();
            this.xtraTabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcKTBBQ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvKTBBQ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit5)).BeginInit();
            this.xtraTabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcKTTC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvKTTC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit6)).BeginInit();
            this.xtraTabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcKTHDT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit7)).BeginInit();
            this.SuspendLayout();
            // 
            // barManager1
            // 
            this.barManager1.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.bar1});
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.HideBarsWhenMerging = false;
            this.barManager1.Images = this.imageCollection1;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.btnNap,
            this.btnThem,
            this.btnXoa,
            this.btnSua,
            this.itemKyBC,
            this.itemTuNgay,
            this.itemDenNgay,
            this.itemToaNha,
            this.itemThuTien,
            this.itemImport,
            this.barDuyet,
            this.itemDuyet,
            this.itemKhongDuyet,
            this.itemThem,
            this.itemSua,
            this.itemDuyetAll,
            this.itemKhongDuyetAll,
            this.itemExport,
            this.barSubItem1,
            this.itemAddMulti,
            this.itemHDTTND,
            this.barButtonItem1,
            this.itemHoaDonNguoc,
            this.btnHoaDonXe,
            this.itemPQL,
            this.itemDieuChinhHoaDon});
            this.barManager1.MaxItemId = 34;
            this.barManager1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.cbbKyBC,
            this.dateTuNgay,
            this.dateDenNgay,
            this.lkToaNha});
            // 
            // bar1
            // 
            this.bar1.BarName = "Tools";
            this.bar1.DockCol = 0;
            this.bar1.DockRow = 0;
            this.bar1.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.bar1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemToaNha, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemKyBC),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemTuNgay),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDenNgay),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnNap, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barSubItem1, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemThem, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemSua, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemDieuChinhHoaDon, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnXoa, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barDuyet, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemThuTien, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemImport, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemExport, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem1, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.bar1.OptionsBar.AllowQuickCustomization = false;
            this.bar1.OptionsBar.DrawDragBorder = false;
            this.bar1.OptionsBar.UseWholeRow = true;
            this.bar1.Text = "Tools";
            // 
            // itemToaNha
            // 
            this.itemToaNha.Caption = "Dự án";
            this.itemToaNha.Edit = this.lkToaNha;
            this.itemToaNha.EditWidth = 91;
            this.itemToaNha.Id = 14;
            this.itemToaNha.Name = "itemToaNha";
            // 
            // lkToaNha
            // 
            this.lkToaNha.AutoHeight = false;
            this.lkToaNha.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lkToaNha.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("TenTN", "Dự án")});
            this.lkToaNha.DisplayMember = "TenTN";
            this.lkToaNha.Name = "lkToaNha";
            this.lkToaNha.NullText = "";
            this.lkToaNha.ValueMember = "MaTN";
            // 
            // itemKyBC
            // 
            this.itemKyBC.Caption = "Kỳ báo cáo";
            this.itemKyBC.Edit = this.cbbKyBC;
            this.itemKyBC.EditWidth = 100;
            this.itemKyBC.Id = 6;
            this.itemKyBC.Name = "itemKyBC";
            // 
            // cbbKyBC
            // 
            this.cbbKyBC.AutoHeight = false;
            this.cbbKyBC.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cbbKyBC.Name = "cbbKyBC";
            this.cbbKyBC.NullText = "Kỳ báo cáo";
            this.cbbKyBC.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.cbbKyBC.EditValueChanged += new System.EventHandler(this.cbbKyBC_EditValueChanged);
            // 
            // itemTuNgay
            // 
            this.itemTuNgay.Caption = "Từ Ngày";
            this.itemTuNgay.Edit = this.dateTuNgay;
            this.itemTuNgay.EditWidth = 100;
            this.itemTuNgay.Id = 7;
            this.itemTuNgay.Name = "itemTuNgay";
            // 
            // dateTuNgay
            // 
            this.dateTuNgay.AutoHeight = false;
            this.dateTuNgay.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateTuNgay.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateTuNgay.Name = "dateTuNgay";
            this.dateTuNgay.NullText = "Từ ngày";
            // 
            // itemDenNgay
            // 
            this.itemDenNgay.Caption = "Đến ngày";
            this.itemDenNgay.Edit = this.dateDenNgay;
            this.itemDenNgay.EditWidth = 100;
            this.itemDenNgay.Id = 8;
            this.itemDenNgay.Name = "itemDenNgay";
            // 
            // dateDenNgay
            // 
            this.dateDenNgay.AutoHeight = false;
            this.dateDenNgay.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateDenNgay.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateDenNgay.Name = "dateDenNgay";
            this.dateDenNgay.NullText = "Đến ngày";
            // 
            // btnNap
            // 
            this.btnNap.Caption = "Nạp";
            this.btnNap.Id = 0;
            this.btnNap.ImageOptions.ImageIndex = 0;
            this.btnNap.Name = "btnNap";
            this.btnNap.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnNap_ItemClick);
            // 
            // barSubItem1
            // 
            this.barSubItem1.Caption = "Thêm";
            this.barSubItem1.Id = 25;
            this.barSubItem1.ImageOptions.ImageIndex = 1;
            this.barSubItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemHoaDonNguoc),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnThem, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemAddMulti),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemHDTTND),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemPQL),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnHoaDonXe)});
            this.barSubItem1.Name = "barSubItem1";
            this.barSubItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // itemHoaDonNguoc
            // 
            this.itemHoaDonNguoc.Caption = "Lập hóa đơn ngược (/1.1)";
            this.itemHoaDonNguoc.Id = 29;
            this.itemHoaDonNguoc.Name = "itemHoaDonNguoc";
            this.itemHoaDonNguoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemHoaDonNguoc_ItemClick);
            // 
            // btnThem
            // 
            this.btnThem.Caption = "Lập hóa đơn tự động (trừ xe | PQL)";
            this.btnThem.Id = 1;
            this.btnThem.Name = "btnThem";
            this.btnThem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnThem_ItemClick);
            // 
            // itemAddMulti
            // 
            this.itemAddMulti.Caption = "Lập hóa đơn thu trước";
            this.itemAddMulti.Id = 26;
            this.itemAddMulti.Name = "itemAddMulti";
            this.itemAddMulti.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemAddMulti_ItemClick);
            // 
            // itemHDTTND
            // 
            this.itemHDTTND.Caption = "Lập hóa đơn thu trước nhiều phí";
            this.itemHDTTND.Id = 27;
            this.itemHDTTND.Name = "itemHDTTND";
            this.itemHDTTND.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem1_ItemClick);
            // 
            // itemPQL
            // 
            this.itemPQL.Caption = "Lập hóa đơn tự động riêng PQL";
            this.itemPQL.Id = 31;
            this.itemPQL.Name = "itemPQL";
            this.itemPQL.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPQL_ItemClick);
            // 
            // btnHoaDonXe
            // 
            this.btnHoaDonXe.Caption = "Lập hóa đơn tự động riêng xe";
            this.btnHoaDonXe.Id = 30;
            this.btnHoaDonXe.Name = "btnHoaDonXe";
            this.btnHoaDonXe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnHoaDonXe_ItemClick);
            // 
            // itemThem
            // 
            this.itemThem.Caption = "Thêm";
            this.itemThem.Id = 20;
            this.itemThem.ImageOptions.ImageIndex = 1;
            this.itemThem.Name = "itemThem";
            this.itemThem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThem_ItemClick);
            // 
            // itemSua
            // 
            this.itemSua.Caption = "Sửa";
            this.itemSua.Id = 21;
            this.itemSua.ImageOptions.ImageIndex = 6;
            this.itemSua.Name = "itemSua";
            this.itemSua.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemSua_ItemClick);
            // 
            // itemDieuChinhHoaDon
            // 
            this.itemDieuChinhHoaDon.Caption = "Điều chỉnh hóa đơn";
            this.itemDieuChinhHoaDon.Id = 33;
            this.itemDieuChinhHoaDon.ImageOptions.ImageIndex = 6;
            this.itemDieuChinhHoaDon.Name = "itemDieuChinhHoaDon";
            this.itemDieuChinhHoaDon.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemDieuChinhHoaDon.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDieuChinhHoaDon_ItemClick);
            // 
            // btnXoa
            // 
            this.btnXoa.Caption = "Xóa";
            this.btnXoa.Id = 2;
            this.btnXoa.ImageOptions.ImageIndex = 2;
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnXoa_ItemClick);
            // 
            // barDuyet
            // 
            this.barDuyet.Caption = "Duyệt";
            this.barDuyet.Id = 17;
            this.barDuyet.ImageOptions.ImageIndex = 5;
            this.barDuyet.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDuyet),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemDuyetAll),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemKhongDuyet, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemKhongDuyetAll)});
            this.barDuyet.Name = "barDuyet";
            // 
            // itemDuyet
            // 
            this.itemDuyet.Caption = "Duyệt";
            this.itemDuyet.Id = 18;
            this.itemDuyet.Name = "itemDuyet";
            this.itemDuyet.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDuyet_ItemClick);
            // 
            // itemDuyetAll
            // 
            this.itemDuyetAll.Caption = "Duyệt tất cả";
            this.itemDuyetAll.Id = 22;
            this.itemDuyetAll.Name = "itemDuyetAll";
            this.itemDuyetAll.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemDuyetAll_ItemClick);
            // 
            // itemKhongDuyet
            // 
            this.itemKhongDuyet.Caption = "Không duyệt";
            this.itemKhongDuyet.Id = 19;
            this.itemKhongDuyet.Name = "itemKhongDuyet";
            this.itemKhongDuyet.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKhongDuyet_ItemClick);
            // 
            // itemKhongDuyetAll
            // 
            this.itemKhongDuyetAll.Caption = "Không duyệt tất cả";
            this.itemKhongDuyetAll.Id = 23;
            this.itemKhongDuyetAll.Name = "itemKhongDuyetAll";
            this.itemKhongDuyetAll.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKhongDuyetAll_ItemClick);
            // 
            // itemThuTien
            // 
            this.itemThuTien.Caption = "Thu tiền";
            this.itemThuTien.Id = 15;
            this.itemThuTien.ImageOptions.ImageIndex = 5;
            this.itemThuTien.Name = "itemThuTien";
            this.itemThuTien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThuTien_ItemClick);
            // 
            // itemImport
            // 
            this.itemImport.Caption = "Import";
            this.itemImport.Id = 16;
            this.itemImport.ImageOptions.ImageIndex = 6;
            this.itemImport.Name = "itemImport";
            this.itemImport.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemImport_ItemClick);
            // 
            // itemExport
            // 
            this.itemExport.Caption = "Export";
            this.itemExport.Id = 24;
            this.itemExport.ImageOptions.ImageIndex = 7;
            this.itemExport.Name = "itemExport";
            this.itemExport.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemExport_ItemClick);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "Update ngày HH";
            this.barButtonItem1.Id = 28;
            this.barButtonItem1.ImageOptions.ImageIndex = 4;
            this.barButtonItem1.Name = "barButtonItem1";
            this.barButtonItem1.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem1_ItemClick_1);
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Manager = this.barManager1;
            this.barDockControlTop.Size = new System.Drawing.Size(1370, 31);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 749);
            this.barDockControlBottom.Manager = this.barManager1;
            this.barDockControlBottom.Size = new System.Drawing.Size(1370, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 31);
            this.barDockControlLeft.Manager = this.barManager1;
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 718);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(1370, 31);
            this.barDockControlRight.Manager = this.barManager1;
            this.barDockControlRight.Size = new System.Drawing.Size(0, 718);
            // 
            // imageCollection1
            // 
            this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection1.ImageStream")));
            this.imageCollection1.Images.SetKeyName(0, "Refresh1.png");
            this.imageCollection1.Images.SetKeyName(1, "Add1.png");
            this.imageCollection1.Images.SetKeyName(2, "Edit3.png");
            this.imageCollection1.Images.SetKeyName(3, "Delete1.png");
            this.imageCollection1.Images.SetKeyName(4, "DuyetYes.png");
            this.imageCollection1.Images.SetKeyName(5, "TienMat1.png");
            this.imageCollection1.Images.SetKeyName(6, "Import1.png");
            this.imageCollection1.Images.SetKeyName(7, "Export1.png");
            // 
            // btnSua
            // 
            this.btnSua.Caption = "Sửa";
            this.btnSua.Id = 3;
            this.btnSua.ImageOptions.ImageIndex = 2;
            this.btnSua.Name = "btnSua";
            // 
            // linqInstantFeedbackSource1
            // 
            this.linqInstantFeedbackSource1.KeyExpression = "ID";
            this.linqInstantFeedbackSource1.GetQueryable += new System.EventHandler<DevExpress.Data.Linq.GetQueryableEventArgs>(this.linqInstantFeedbackSource1_GetQueryable);
            this.linqInstantFeedbackSource1.DismissQueryable += new System.EventHandler<DevExpress.Data.Linq.GetQueryableEventArgs>(this.linqInstantFeedbackSource1_DismissQueryable);
            // 
            // gcHoaDon
            // 
            this.gcHoaDon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcHoaDon.Location = new System.Drawing.Point(0, 0);
            this.gcHoaDon.MainView = this.gvHoaDon;
            this.gcHoaDon.Name = "gcHoaDon";
            this.gcHoaDon.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1});
            this.gcHoaDon.Size = new System.Drawing.Size(1370, 543);
            this.gcHoaDon.TabIndex = 14;
            this.gcHoaDon.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvHoaDon});
            // 
            // gvHoaDon
            // 
            this.gvHoaDon.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn3,
            this.gridColumn5,
            this.gridColumn7,
            this.gridColumn1,
            this.gridColumn13,
            this.gridColumn2,
            this.gridColumn8,
            this.gridColumn9,
            this.gridColumn14,
            this.gridColumn17,
            this.gridColumn10,
            this.gridColumn11,
            this.gridColumn12,
            this.gridColumn21,
            this.gridColumn22,
            this.gridColumn23,
            this.gridColumn18,
            this.gridColumn19,
            this.gridColumn24,
            this.gridColumn4,
            this.gridColumn6,
            this.gridColumn27,
            this.gridColumn28,
            this.gridColumn29,
            this.gridColumn30,
            this.gridColumn31,
            this.gridColumn32,
            this.gridColumn33,
            this.gridColumn34,
            this.gridColumn35,
            this.gridColumn41,
            this.gridColumn63,
            this.gridColumn62,
            this.gridColumn64,
            this.gridColumn65,
            this.gridColumn66,
            this.gridColumn67,
            this.gridColumn68,
            this.gridColumn69,
            this.gridColumn75,
            this.gridColumn76,
            this.gridColumn77,
            this.gridColumn78,
            this.gridColumn79});
            this.gvHoaDon.GridControl = this.gcHoaDon;
            this.gvHoaDon.GroupFormat = "[#image]{1} | {2}";
            this.gvHoaDon.GroupPanelText = "Kéo cột lên đây để xem theo nhóm";
            this.gvHoaDon.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "PhaiThu", null, "Phải thu: {0:#,0.##}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "DaThu", null, "Đã thu: {0:#,0.##}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ConNo", null, "Còn nợ: {0:#,0.##}")});
            this.gvHoaDon.Name = "gvHoaDon";
            this.gvHoaDon.OptionsBehavior.Editable = false;
            this.gvHoaDon.OptionsSelection.MultiSelect = true;
            this.gvHoaDon.OptionsView.ColumnAutoWidth = false;
            this.gvHoaDon.OptionsView.ShowAutoFilterRow = true;
            this.gvHoaDon.OptionsView.ShowFooter = true;
            this.gvHoaDon.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumn8, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.gvHoaDon.RowCellStyle += new DevExpress.XtraGrid.Views.Grid.RowCellStyleEventHandler(this.gvHoaDon_RowCellStyle);
            this.gvHoaDon.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gvHoaDon_FocusedRowChanged);
            this.gvHoaDon.FocusedRowLoaded += new DevExpress.XtraGrid.Views.Base.RowEventHandler(this.gvHoaDon_FocusedRowLoaded);
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "STT";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 0;
            this.gridColumn3.Width = 52;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "Duyệt";
            this.gridColumn5.FieldName = "IsDuyet";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 19;
            this.gridColumn5.Width = 44;
            // 
            // gridColumn7
            // 
            this.gridColumn7.Caption = "Ngày TT";
            this.gridColumn7.FieldName = "NgayTT";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Count, "NgayTT", "{0:n0}")});
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 1;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "Mã khách hàng";
            this.gridColumn1.FieldName = "KyHieu";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 3;
            this.gridColumn1.Width = 90;
            // 
            // gridColumn13
            // 
            this.gridColumn13.Caption = "Mã phụ";
            this.gridColumn13.FieldName = "MaPhu";
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 4;
            this.gridColumn13.Width = 66;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "Tên khách hàng";
            this.gridColumn2.FieldName = "TenKH";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 5;
            this.gridColumn2.Width = 191;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "Hạng mục";
            this.gridColumn8.FieldName = "TenLDV";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 9;
            this.gridColumn8.Width = 104;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "Diễn giải";
            this.gridColumn9.FieldName = "DienGiai";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 20;
            this.gridColumn9.Width = 246;
            // 
            // gridColumn14
            // 
            this.gridColumn14.Caption = "Phí dịch vụ";
            this.gridColumn14.DisplayFormat.FormatString = "n0";
            this.gridColumn14.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn14.FieldName = "PhiDV";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn14.Width = 76;
            // 
            // gridColumn17
            // 
            this.gridColumn17.Caption = "Kỳ TT";
            this.gridColumn17.DisplayFormat.FormatString = "{0:#,0.##} tháng";
            this.gridColumn17.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn17.FieldName = "KyTT";
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 10;
            this.gridColumn17.Width = 50;
            // 
            // gridColumn10
            // 
            this.gridColumn10.Caption = "Tiền TT";
            this.gridColumn10.DisplayFormat.FormatString = "n0";
            this.gridColumn10.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn10.FieldName = "TienTT";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "TienTT", "{0:#,0.##}")});
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 11;
            this.gridColumn10.Width = 79;
            // 
            // gridColumn11
            // 
            this.gridColumn11.Caption = "Tỷ lệ CK";
            this.gridColumn11.DisplayFormat.FormatString = "p2";
            this.gridColumn11.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn11.FieldName = "TyLeCK";
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 14;
            this.gridColumn11.Width = 52;
            // 
            // gridColumn12
            // 
            this.gridColumn12.Caption = "Tiền CK";
            this.gridColumn12.DisplayFormat.FormatString = "n0";
            this.gridColumn12.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn12.FieldName = "TienCK";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "TienCK", "{0:#,0.##}")});
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 15;
            this.gridColumn12.Width = 63;
            // 
            // gridColumn21
            // 
            this.gridColumn21.Caption = "Phải thu";
            this.gridColumn21.DisplayFormat.FormatString = "n0";
            this.gridColumn21.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn21.FieldName = "PhaiThu";
            this.gridColumn21.Name = "gridColumn21";
            this.gridColumn21.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "PhaiThu", "{0:#,0.##}")});
            this.gridColumn21.Visible = true;
            this.gridColumn21.VisibleIndex = 16;
            this.gridColumn21.Width = 83;
            // 
            // gridColumn22
            // 
            this.gridColumn22.Caption = "Đã thu";
            this.gridColumn22.DisplayFormat.FormatString = "n0";
            this.gridColumn22.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn22.FieldName = "DaThu";
            this.gridColumn22.Name = "gridColumn22";
            this.gridColumn22.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "DaThu", "{0:#,0.##}")});
            this.gridColumn22.Visible = true;
            this.gridColumn22.VisibleIndex = 17;
            // 
            // gridColumn23
            // 
            this.gridColumn23.Caption = "Còn nợ";
            this.gridColumn23.DisplayFormat.FormatString = "n0";
            this.gridColumn23.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn23.FieldName = "ConNo";
            this.gridColumn23.Name = "gridColumn23";
            this.gridColumn23.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ConNo", "{0:#,0.##}")});
            this.gridColumn23.Visible = true;
            this.gridColumn23.VisibleIndex = 18;
            // 
            // gridColumn18
            // 
            this.gridColumn18.Caption = "Mặt bằng";
            this.gridColumn18.FieldName = "MaSoMB";
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 6;
            // 
            // gridColumn19
            // 
            this.gridColumn19.Caption = "Tầng/Lầu";
            this.gridColumn19.FieldName = "TenTL";
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 24;
            // 
            // gridColumn24
            // 
            this.gridColumn24.Caption = "Khối nhà/block";
            this.gridColumn24.FieldName = "TenKN";
            this.gridColumn24.Name = "gridColumn24";
            this.gridColumn24.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn24.Visible = true;
            this.gridColumn24.VisibleIndex = 23;
            this.gridColumn24.Width = 78;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "Loại mặt bằng";
            this.gridColumn4.FieldName = "TenLMB";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 22;
            this.gridColumn4.Width = 112;
            // 
            // gridColumn6
            // 
            this.gridColumn6.FieldName = "ID";
            this.gridColumn6.Name = "gridColumn6";
            // 
            // gridColumn27
            // 
            this.gridColumn27.Caption = "Ngày thu";
            this.gridColumn27.DisplayFormat.FormatString = "{0:dd/MM/yyyy}";
            this.gridColumn27.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn27.FieldName = "NgayThu";
            this.gridColumn27.Name = "gridColumn27";
            this.gridColumn27.Visible = true;
            this.gridColumn27.VisibleIndex = 32;
            this.gridColumn27.Width = 96;
            // 
            // gridColumn28
            // 
            this.gridColumn28.Caption = "Nhân viên nhập";
            this.gridColumn28.FieldName = "NhanVienNhap";
            this.gridColumn28.Name = "gridColumn28";
            this.gridColumn28.Visible = true;
            this.gridColumn28.VisibleIndex = 26;
            this.gridColumn28.Width = 156;
            // 
            // gridColumn29
            // 
            this.gridColumn29.Caption = "Ngày nhập";
            this.gridColumn29.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.gridColumn29.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn29.FieldName = "NgayNhap";
            this.gridColumn29.Name = "gridColumn29";
            this.gridColumn29.Visible = true;
            this.gridColumn29.VisibleIndex = 25;
            // 
            // gridColumn30
            // 
            this.gridColumn30.Caption = "Ngày sửa";
            this.gridColumn30.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.gridColumn30.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn30.FieldName = "NgaySua";
            this.gridColumn30.Name = "gridColumn30";
            this.gridColumn30.Visible = true;
            this.gridColumn30.VisibleIndex = 27;
            // 
            // gridColumn31
            // 
            this.gridColumn31.Caption = "Người sửa";
            this.gridColumn31.FieldName = "NhanVienSua";
            this.gridColumn31.Name = "gridColumn31";
            this.gridColumn31.Visible = true;
            this.gridColumn31.VisibleIndex = 28;
            this.gridColumn31.Width = 93;
            // 
            // gridColumn32
            // 
            this.gridColumn32.Caption = "Thuế GTGT";
            this.gridColumn32.DisplayFormat.FormatString = "p2";
            this.gridColumn32.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn32.FieldName = "ThueGTGT";
            this.gridColumn32.Name = "gridColumn32";
            this.gridColumn32.Visible = true;
            this.gridColumn32.VisibleIndex = 12;
            // 
            // gridColumn33
            // 
            this.gridColumn33.Caption = "Tiền thuế GTGT";
            this.gridColumn33.DisplayFormat.FormatString = "{0:#,0.##}";
            this.gridColumn33.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn33.FieldName = "TienThueGTGT";
            this.gridColumn33.Name = "gridColumn33";
            this.gridColumn33.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "TienThueGTGT", "{0:#,0.##}")});
            this.gridColumn33.Visible = true;
            this.gridColumn33.VisibleIndex = 13;
            this.gridColumn33.Width = 84;
            // 
            // gridColumn34
            // 
            this.gridColumn34.Caption = "Từ ngày";
            this.gridColumn34.DisplayFormat.FormatString = "{0:dd/MM/yyyy}";
            this.gridColumn34.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn34.FieldName = "TuNgay";
            this.gridColumn34.Name = "gridColumn34";
            this.gridColumn34.Visible = true;
            this.gridColumn34.VisibleIndex = 29;
            // 
            // gridColumn35
            // 
            this.gridColumn35.Caption = "Đến ngày";
            this.gridColumn35.DisplayFormat.FormatString = "{0:dd/MM/yyyy}";
            this.gridColumn35.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn35.FieldName = "DenNgay";
            this.gridColumn35.Name = "gridColumn35";
            this.gridColumn35.Visible = true;
            this.gridColumn35.VisibleIndex = 30;
            // 
            // gridColumn41
            // 
            this.gridColumn41.Caption = "Ngày tính phí";
            this.gridColumn41.DisplayFormat.FormatString = "{0:dd/MM/yyyy}";
            this.gridColumn41.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn41.FieldName = "NgayTinhPhi";
            this.gridColumn41.Name = "gridColumn41";
            this.gridColumn41.Visible = true;
            this.gridColumn41.VisibleIndex = 2;
            // 
            // gridColumn63
            // 
            this.gridColumn63.Caption = "Nhân viên thu";
            this.gridColumn63.FieldName = "NguoiThu";
            this.gridColumn63.Name = "gridColumn63";
            this.gridColumn63.Visible = true;
            this.gridColumn63.VisibleIndex = 31;
            this.gridColumn63.Width = 103;
            // 
            // gridColumn62
            // 
            this.gridColumn62.Caption = "LinkID";
            this.gridColumn62.FieldName = "LinkID";
            this.gridColumn62.Name = "gridColumn62";
            this.gridColumn62.Visible = true;
            this.gridColumn62.VisibleIndex = 34;
            // 
            // gridColumn64
            // 
            this.gridColumn64.Caption = "Loại thu";
            this.gridColumn64.FieldName = "LoaiThu";
            this.gridColumn64.Name = "gridColumn64";
            this.gridColumn64.Visible = true;
            this.gridColumn64.VisibleIndex = 33;
            this.gridColumn64.Width = 85;
            // 
            // gridColumn65
            // 
            this.gridColumn65.Caption = "Đã xuất HDDT";
            this.gridColumn65.FieldName = "IsDaXuatHoaDon";
            this.gridColumn65.Name = "gridColumn65";
            this.gridColumn65.Visible = true;
            this.gridColumn65.VisibleIndex = 35;
            this.gridColumn65.Width = 84;
            // 
            // gridColumn66
            // 
            this.gridColumn66.Caption = "Số thẻ GYM";
            this.gridColumn66.FieldName = "SoTheGym";
            this.gridColumn66.Name = "gridColumn66";
            this.gridColumn66.Visible = true;
            this.gridColumn66.VisibleIndex = 37;
            // 
            // gridColumn67
            // 
            this.gridColumn67.Caption = "Số thẻ bơi tháng";
            this.gridColumn67.FieldName = "SoTheBoi";
            this.gridColumn67.Name = "gridColumn67";
            this.gridColumn67.Visible = true;
            this.gridColumn67.VisibleIndex = 38;
            // 
            // gridColumn68
            // 
            this.gridColumn68.Caption = "Số thẻ bơi ngày";
            this.gridColumn68.FieldName = "SoTheBoiNgay";
            this.gridColumn68.Name = "gridColumn68";
            this.gridColumn68.Visible = true;
            this.gridColumn68.VisibleIndex = 39;
            // 
            // gridColumn69
            // 
            this.gridColumn69.Caption = "Số HĐĐT";
            this.gridColumn69.FieldName = "SoHoaDonDienTu";
            this.gridColumn69.Name = "gridColumn69";
            this.gridColumn69.Visible = true;
            this.gridColumn69.VisibleIndex = 36;
            // 
            // gridColumn75
            // 
            this.gridColumn75.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn75.AppearanceCell.Options.UseFont = true;
            this.gridColumn75.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn75.AppearanceHeader.Options.UseFont = true;
            this.gridColumn75.Caption = "Số hợp đồng";
            this.gridColumn75.FieldName = "SoHD";
            this.gridColumn75.Name = "gridColumn75";
            this.gridColumn75.Visible = true;
            this.gridColumn75.VisibleIndex = 7;
            this.gridColumn75.Width = 102;
            // 
            // gridColumn76
            // 
            this.gridColumn76.Caption = "Thanh lý";
            this.gridColumn76.ColumnEdit = this.repositoryItemCheckEdit1;
            this.gridColumn76.FieldName = "IsThanhLy";
            this.gridColumn76.Name = "gridColumn76";
            this.gridColumn76.Visible = true;
            this.gridColumn76.VisibleIndex = 8;
            this.gridColumn76.Width = 62;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // gridColumn77
            // 
            this.gridColumn77.Caption = "Chủ sở hữu";
            this.gridColumn77.FieldName = "CSH";
            this.gridColumn77.Name = "gridColumn77";
            this.gridColumn77.Visible = true;
            this.gridColumn77.VisibleIndex = 21;
            this.gridColumn77.Width = 95;
            // 
            // gridColumn78
            // 
            this.gridColumn78.Caption = "Hạn TT";
            this.gridColumn78.DisplayFormat.FormatString = "d";
            this.gridColumn78.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn78.FieldName = "HanTT";
            this.gridColumn78.Name = "gridColumn78";
            this.gridColumn78.Visible = true;
            this.gridColumn78.VisibleIndex = 40;
            // 
            // gridColumn79
            // 
            this.gridColumn79.Caption = "Số Ngày";
            this.gridColumn79.FieldName = "SoNgay";
            this.gridColumn79.Name = "gridColumn79";
            this.gridColumn79.Visible = true;
            this.gridColumn79.VisibleIndex = 41;
            // 
            // splitContainerControl1
            // 
            this.splitContainerControl1.CollapsePanel = DevExpress.XtraEditors.SplitCollapsePanel.Panel2;
            this.splitContainerControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl1.FixedPanel = DevExpress.XtraEditors.SplitFixedPanel.Panel2;
            this.splitContainerControl1.Horizontal = false;
            this.splitContainerControl1.Location = new System.Drawing.Point(0, 31);
            this.splitContainerControl1.Name = "splitContainerControl1";
            this.splitContainerControl1.Panel1.Controls.Add(this.gcHoaDon);
            this.splitContainerControl1.Panel1.Text = "Panel1";
            this.splitContainerControl1.Panel2.Controls.Add(this.xtraTabControl1);
            this.splitContainerControl1.Panel2.Text = "Panel2";
            this.splitContainerControl1.Size = new System.Drawing.Size(1370, 718);
            this.splitContainerControl1.SplitterPosition = 170;
            this.splitContainerControl1.TabIndex = 19;
            this.splitContainerControl1.Text = "splitContainerControl1";
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl1.Location = new System.Drawing.Point(0, 0);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPage1;
            this.xtraTabControl1.Size = new System.Drawing.Size(1370, 170);
            this.xtraTabControl1.TabIndex = 0;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1,
            this.xtraTabPage2,
            this.xtraTabPage3,
            this.xtraTabPage4,
            this.xtraTabPage5,
            this.xtraTabPage6,
            this.xtraTabPage7});
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.Controls.Add(this.gcChiTiet);
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(1364, 142);
            this.xtraTabPage1.Text = "1. Phiếu thu";
            // 
            // gcChiTiet
            // 
            this.gcChiTiet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcChiTiet.Location = new System.Drawing.Point(0, 0);
            this.gcChiTiet.MainView = this.gvChiTiet;
            this.gcChiTiet.MenuManager = this.barManager1;
            this.gcChiTiet.Name = "gcChiTiet";
            this.gcChiTiet.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoExEdit2});
            this.gcChiTiet.Size = new System.Drawing.Size(1364, 142);
            this.gcChiTiet.TabIndex = 5;
            this.gcChiTiet.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvChiTiet});
            // 
            // gvChiTiet
            // 
            this.gvChiTiet.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn15,
            this.gridColumn26,
            this.gridColumn25,
            this.gridColumn16,
            this.gridColumn20});
            this.gvChiTiet.GridControl = this.gcChiTiet;
            this.gvChiTiet.GroupPanelText = "Kéo một vài cột lên đây để xem theo nhóm";
            this.gvChiTiet.Name = "gvChiTiet";
            this.gvChiTiet.OptionsBehavior.Editable = false;
            this.gvChiTiet.OptionsSelection.MultiSelect = true;
            this.gvChiTiet.OptionsView.ColumnAutoWidth = false;
            this.gvChiTiet.OptionsView.ShowFooter = true;
            this.gvChiTiet.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn15
            // 
            this.gridColumn15.Caption = "STT";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.OptionsColumn.AllowEdit = false;
            this.gridColumn15.Visible = true;
            this.gridColumn15.VisibleIndex = 0;
            this.gridColumn15.Width = 41;
            // 
            // gridColumn26
            // 
            this.gridColumn26.Caption = "Ngày thu";
            this.gridColumn26.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.gridColumn26.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn26.FieldName = "NgayThu";
            this.gridColumn26.Name = "gridColumn26";
            this.gridColumn26.Visible = true;
            this.gridColumn26.VisibleIndex = 1;
            // 
            // gridColumn25
            // 
            this.gridColumn25.Caption = "Số phiếu";
            this.gridColumn25.FieldName = "SoPT";
            this.gridColumn25.Name = "gridColumn25";
            this.gridColumn25.Visible = true;
            this.gridColumn25.VisibleIndex = 2;
            this.gridColumn25.Width = 145;
            // 
            // gridColumn16
            // 
            this.gridColumn16.Caption = "Diễn giải";
            this.gridColumn16.ColumnEdit = this.repositoryItemMemoExEdit2;
            this.gridColumn16.FieldName = "DienGiai";
            this.gridColumn16.FilterMode = DevExpress.XtraGrid.ColumnFilterMode.DisplayText;
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn16.Visible = true;
            this.gridColumn16.VisibleIndex = 3;
            this.gridColumn16.Width = 378;
            // 
            // repositoryItemMemoExEdit2
            // 
            this.repositoryItemMemoExEdit2.AutoHeight = false;
            this.repositoryItemMemoExEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit2.Name = "repositoryItemMemoExEdit2";
            this.repositoryItemMemoExEdit2.PopupFormMinSize = new System.Drawing.Size(300, 0);
            this.repositoryItemMemoExEdit2.ReadOnly = true;
            this.repositoryItemMemoExEdit2.ShowDropDown = DevExpress.XtraEditors.Controls.ShowDropDown.DoubleClick;
            this.repositoryItemMemoExEdit2.ShowIcon = false;
            // 
            // gridColumn20
            // 
            this.gridColumn20.Caption = "Số tiền";
            this.gridColumn20.DisplayFormat.FormatString = "{0:#,0.##}";
            this.gridColumn20.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn20.FieldName = "SoTien";
            this.gridColumn20.FilterMode = DevExpress.XtraGrid.ColumnFilterMode.DisplayText;
            this.gridColumn20.Name = "gridColumn20";
            this.gridColumn20.OptionsColumn.AllowEdit = false;
            this.gridColumn20.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn20.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "SoTien", "{0:#,0.##}")});
            this.gridColumn20.Visible = true;
            this.gridColumn20.VisibleIndex = 4;
            this.gridColumn20.Width = 97;
            // 
            // xtraTabPage2
            // 
            this.xtraTabPage2.Controls.Add(this.gcKhauTru);
            this.xtraTabPage2.Name = "xtraTabPage2";
            this.xtraTabPage2.Size = new System.Drawing.Size(1364, 142);
            this.xtraTabPage2.Text = "2.Phiếu khấu trừ";
            // 
            // gcKhauTru
            // 
            this.gcKhauTru.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcKhauTru.Location = new System.Drawing.Point(0, 0);
            this.gcKhauTru.MainView = this.grvKhauTru;
            this.gcKhauTru.MenuManager = this.barManager1;
            this.gcKhauTru.Name = "gcKhauTru";
            this.gcKhauTru.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoExEdit3});
            this.gcKhauTru.Size = new System.Drawing.Size(1364, 142);
            this.gcKhauTru.TabIndex = 8;
            this.gcKhauTru.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvKhauTru});
            // 
            // grvKhauTru
            // 
            this.grvKhauTru.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn36,
            this.gridColumn37,
            this.gridColumn38,
            this.gridColumn39,
            this.gridColumn40});
            this.grvKhauTru.GridControl = this.gcKhauTru;
            this.grvKhauTru.GroupPanelText = "Kéo một vài cột lên đây để xem theo nhóm";
            this.grvKhauTru.Name = "grvKhauTru";
            this.grvKhauTru.OptionsBehavior.Editable = false;
            this.grvKhauTru.OptionsSelection.MultiSelect = true;
            this.grvKhauTru.OptionsView.ColumnAutoWidth = false;
            this.grvKhauTru.OptionsView.ShowFooter = true;
            this.grvKhauTru.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn36
            // 
            this.gridColumn36.Caption = "STT";
            this.gridColumn36.Name = "gridColumn36";
            this.gridColumn36.OptionsColumn.AllowEdit = false;
            this.gridColumn36.Visible = true;
            this.gridColumn36.VisibleIndex = 0;
            this.gridColumn36.Width = 41;
            // 
            // gridColumn37
            // 
            this.gridColumn37.Caption = "Ngày CT";
            this.gridColumn37.DisplayFormat.FormatString = "{0:hh:mm | dd/MM/yyyy}";
            this.gridColumn37.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn37.FieldName = "NgayCT";
            this.gridColumn37.Name = "gridColumn37";
            this.gridColumn37.Visible = true;
            this.gridColumn37.VisibleIndex = 1;
            // 
            // gridColumn38
            // 
            this.gridColumn38.Caption = "Số phiếu";
            this.gridColumn38.FieldName = "SoCT";
            this.gridColumn38.Name = "gridColumn38";
            this.gridColumn38.Visible = true;
            this.gridColumn38.VisibleIndex = 2;
            this.gridColumn38.Width = 145;
            // 
            // gridColumn39
            // 
            this.gridColumn39.Caption = "Diễn giải";
            this.gridColumn39.ColumnEdit = this.repositoryItemMemoExEdit3;
            this.gridColumn39.FieldName = "DienGiai";
            this.gridColumn39.FilterMode = DevExpress.XtraGrid.ColumnFilterMode.DisplayText;
            this.gridColumn39.Name = "gridColumn39";
            this.gridColumn39.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn39.Visible = true;
            this.gridColumn39.VisibleIndex = 3;
            this.gridColumn39.Width = 378;
            // 
            // repositoryItemMemoExEdit3
            // 
            this.repositoryItemMemoExEdit3.AutoHeight = false;
            this.repositoryItemMemoExEdit3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit3.Name = "repositoryItemMemoExEdit3";
            this.repositoryItemMemoExEdit3.PopupFormMinSize = new System.Drawing.Size(300, 0);
            this.repositoryItemMemoExEdit3.ReadOnly = true;
            this.repositoryItemMemoExEdit3.ShowDropDown = DevExpress.XtraEditors.Controls.ShowDropDown.DoubleClick;
            this.repositoryItemMemoExEdit3.ShowIcon = false;
            // 
            // gridColumn40
            // 
            this.gridColumn40.Caption = "Số tiền";
            this.gridColumn40.DisplayFormat.FormatString = "{0:#,0.##}";
            this.gridColumn40.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn40.FieldName = "SoTien";
            this.gridColumn40.FilterMode = DevExpress.XtraGrid.ColumnFilterMode.DisplayText;
            this.gridColumn40.Name = "gridColumn40";
            this.gridColumn40.OptionsColumn.AllowEdit = false;
            this.gridColumn40.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn40.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "SoTien", "{0:#,0.##}")});
            this.gridColumn40.Visible = true;
            this.gridColumn40.VisibleIndex = 4;
            this.gridColumn40.Width = 97;
            // 
            // xtraTabPage3
            // 
            this.xtraTabPage3.Controls.Add(this.gcKTTB);
            this.xtraTabPage3.Name = "xtraTabPage3";
            this.xtraTabPage3.Size = new System.Drawing.Size(1364, 142);
            this.xtraTabPage3.Text = "2. Khấu trừ thẻ bơi";
            // 
            // gcKTTB
            // 
            this.gcKTTB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcKTTB.Location = new System.Drawing.Point(0, 0);
            this.gcKTTB.MainView = this.grvKTTB;
            this.gcKTTB.MenuManager = this.barManager1;
            this.gcKTTB.Name = "gcKTTB";
            this.gcKTTB.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoExEdit1});
            this.gcKTTB.Size = new System.Drawing.Size(1364, 142);
            this.gcKTTB.TabIndex = 9;
            this.gcKTTB.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvKTTB});
            // 
            // grvKTTB
            // 
            this.grvKTTB.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn42,
            this.gridColumn43,
            this.gridColumn44,
            this.gridColumn45,
            this.gridColumn46});
            this.grvKTTB.GridControl = this.gcKTTB;
            this.grvKTTB.GroupPanelText = "Kéo một vài cột lên đây để xem theo nhóm";
            this.grvKTTB.Name = "grvKTTB";
            this.grvKTTB.OptionsBehavior.Editable = false;
            this.grvKTTB.OptionsSelection.MultiSelect = true;
            this.grvKTTB.OptionsView.ColumnAutoWidth = false;
            this.grvKTTB.OptionsView.ShowFooter = true;
            this.grvKTTB.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn42
            // 
            this.gridColumn42.Caption = "STT";
            this.gridColumn42.Name = "gridColumn42";
            this.gridColumn42.OptionsColumn.AllowEdit = false;
            this.gridColumn42.Visible = true;
            this.gridColumn42.VisibleIndex = 0;
            this.gridColumn42.Width = 41;
            // 
            // gridColumn43
            // 
            this.gridColumn43.Caption = "Ngày CT";
            this.gridColumn43.DisplayFormat.FormatString = "{0:hh:mm | dd/MM/yyyy}";
            this.gridColumn43.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn43.FieldName = "NgayCT";
            this.gridColumn43.Name = "gridColumn43";
            this.gridColumn43.Visible = true;
            this.gridColumn43.VisibleIndex = 1;
            // 
            // gridColumn44
            // 
            this.gridColumn44.Caption = "Số phiếu";
            this.gridColumn44.FieldName = "SoCT";
            this.gridColumn44.Name = "gridColumn44";
            this.gridColumn44.Visible = true;
            this.gridColumn44.VisibleIndex = 2;
            this.gridColumn44.Width = 145;
            // 
            // gridColumn45
            // 
            this.gridColumn45.Caption = "Diễn giải";
            this.gridColumn45.ColumnEdit = this.repositoryItemMemoExEdit1;
            this.gridColumn45.FieldName = "DienGiai";
            this.gridColumn45.FilterMode = DevExpress.XtraGrid.ColumnFilterMode.DisplayText;
            this.gridColumn45.Name = "gridColumn45";
            this.gridColumn45.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn45.Visible = true;
            this.gridColumn45.VisibleIndex = 3;
            this.gridColumn45.Width = 378;
            // 
            // repositoryItemMemoExEdit1
            // 
            this.repositoryItemMemoExEdit1.AutoHeight = false;
            this.repositoryItemMemoExEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit1.Name = "repositoryItemMemoExEdit1";
            this.repositoryItemMemoExEdit1.PopupFormMinSize = new System.Drawing.Size(300, 0);
            this.repositoryItemMemoExEdit1.ReadOnly = true;
            this.repositoryItemMemoExEdit1.ShowDropDown = DevExpress.XtraEditors.Controls.ShowDropDown.DoubleClick;
            this.repositoryItemMemoExEdit1.ShowIcon = false;
            // 
            // gridColumn46
            // 
            this.gridColumn46.Caption = "Số tiền";
            this.gridColumn46.DisplayFormat.FormatString = "{0:#,0.##}";
            this.gridColumn46.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn46.FieldName = "SoTien";
            this.gridColumn46.FilterMode = DevExpress.XtraGrid.ColumnFilterMode.DisplayText;
            this.gridColumn46.Name = "gridColumn46";
            this.gridColumn46.OptionsColumn.AllowEdit = false;
            this.gridColumn46.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn46.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "SoTien", "{0:#,0.##}")});
            this.gridColumn46.Visible = true;
            this.gridColumn46.VisibleIndex = 4;
            this.gridColumn46.Width = 97;
            // 
            // xtraTabPage4
            // 
            this.xtraTabPage4.Controls.Add(this.gcKTTG);
            this.xtraTabPage4.Name = "xtraTabPage4";
            this.xtraTabPage4.Size = new System.Drawing.Size(1364, 142);
            this.xtraTabPage4.Text = "3. Khấu trừ thẻ GYM";
            // 
            // gcKTTG
            // 
            this.gcKTTG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcKTTG.Location = new System.Drawing.Point(0, 0);
            this.gcKTTG.MainView = this.grvKTTG;
            this.gcKTTG.MenuManager = this.barManager1;
            this.gcKTTG.Name = "gcKTTG";
            this.gcKTTG.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoExEdit4});
            this.gcKTTG.Size = new System.Drawing.Size(1364, 142);
            this.gcKTTG.TabIndex = 9;
            this.gcKTTG.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvKTTG});
            // 
            // grvKTTG
            // 
            this.grvKTTG.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn47,
            this.gridColumn48,
            this.gridColumn49,
            this.gridColumn50,
            this.gridColumn51});
            this.grvKTTG.GridControl = this.gcKTTG;
            this.grvKTTG.GroupPanelText = "Kéo một vài cột lên đây để xem theo nhóm";
            this.grvKTTG.Name = "grvKTTG";
            this.grvKTTG.OptionsBehavior.Editable = false;
            this.grvKTTG.OptionsSelection.MultiSelect = true;
            this.grvKTTG.OptionsView.ColumnAutoWidth = false;
            this.grvKTTG.OptionsView.ShowFooter = true;
            this.grvKTTG.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn47
            // 
            this.gridColumn47.Caption = "STT";
            this.gridColumn47.Name = "gridColumn47";
            this.gridColumn47.OptionsColumn.AllowEdit = false;
            this.gridColumn47.Visible = true;
            this.gridColumn47.VisibleIndex = 0;
            this.gridColumn47.Width = 41;
            // 
            // gridColumn48
            // 
            this.gridColumn48.Caption = "Ngày CT";
            this.gridColumn48.DisplayFormat.FormatString = "{0:hh:mm | dd/MM/yyyy}";
            this.gridColumn48.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn48.FieldName = "NgayCT";
            this.gridColumn48.Name = "gridColumn48";
            this.gridColumn48.Visible = true;
            this.gridColumn48.VisibleIndex = 1;
            // 
            // gridColumn49
            // 
            this.gridColumn49.Caption = "Số phiếu";
            this.gridColumn49.FieldName = "SoCT";
            this.gridColumn49.Name = "gridColumn49";
            this.gridColumn49.Visible = true;
            this.gridColumn49.VisibleIndex = 2;
            this.gridColumn49.Width = 145;
            // 
            // gridColumn50
            // 
            this.gridColumn50.Caption = "Diễn giải";
            this.gridColumn50.ColumnEdit = this.repositoryItemMemoExEdit4;
            this.gridColumn50.FieldName = "DienGiai";
            this.gridColumn50.FilterMode = DevExpress.XtraGrid.ColumnFilterMode.DisplayText;
            this.gridColumn50.Name = "gridColumn50";
            this.gridColumn50.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn50.Visible = true;
            this.gridColumn50.VisibleIndex = 3;
            this.gridColumn50.Width = 378;
            // 
            // repositoryItemMemoExEdit4
            // 
            this.repositoryItemMemoExEdit4.AutoHeight = false;
            this.repositoryItemMemoExEdit4.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit4.Name = "repositoryItemMemoExEdit4";
            this.repositoryItemMemoExEdit4.PopupFormMinSize = new System.Drawing.Size(300, 0);
            this.repositoryItemMemoExEdit4.ReadOnly = true;
            this.repositoryItemMemoExEdit4.ShowDropDown = DevExpress.XtraEditors.Controls.ShowDropDown.DoubleClick;
            this.repositoryItemMemoExEdit4.ShowIcon = false;
            // 
            // gridColumn51
            // 
            this.gridColumn51.Caption = "Số tiền";
            this.gridColumn51.DisplayFormat.FormatString = "{0:#,0.##}";
            this.gridColumn51.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn51.FieldName = "SoTien";
            this.gridColumn51.FilterMode = DevExpress.XtraGrid.ColumnFilterMode.DisplayText;
            this.gridColumn51.Name = "gridColumn51";
            this.gridColumn51.OptionsColumn.AllowEdit = false;
            this.gridColumn51.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn51.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "SoTien", "{0:#,0.##}")});
            this.gridColumn51.Visible = true;
            this.gridColumn51.VisibleIndex = 4;
            this.gridColumn51.Width = 97;
            // 
            // xtraTabPage5
            // 
            this.xtraTabPage5.Controls.Add(this.gcKTBBQ);
            this.xtraTabPage5.Name = "xtraTabPage5";
            this.xtraTabPage5.Size = new System.Drawing.Size(1364, 142);
            this.xtraTabPage5.Text = "4. Khấu trừ BBQ";
            // 
            // gcKTBBQ
            // 
            this.gcKTBBQ.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcKTBBQ.Location = new System.Drawing.Point(0, 0);
            this.gcKTBBQ.MainView = this.grvKTBBQ;
            this.gcKTBBQ.MenuManager = this.barManager1;
            this.gcKTBBQ.Name = "gcKTBBQ";
            this.gcKTBBQ.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoExEdit5});
            this.gcKTBBQ.Size = new System.Drawing.Size(1364, 142);
            this.gcKTBBQ.TabIndex = 9;
            this.gcKTBBQ.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvKTBBQ});
            // 
            // grvKTBBQ
            // 
            this.grvKTBBQ.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn52,
            this.gridColumn53,
            this.gridColumn54,
            this.gridColumn55,
            this.gridColumn56});
            this.grvKTBBQ.GridControl = this.gcKTBBQ;
            this.grvKTBBQ.GroupPanelText = "Kéo một vài cột lên đây để xem theo nhóm";
            this.grvKTBBQ.Name = "grvKTBBQ";
            this.grvKTBBQ.OptionsBehavior.Editable = false;
            this.grvKTBBQ.OptionsSelection.MultiSelect = true;
            this.grvKTBBQ.OptionsView.ColumnAutoWidth = false;
            this.grvKTBBQ.OptionsView.ShowFooter = true;
            this.grvKTBBQ.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn52
            // 
            this.gridColumn52.Caption = "STT";
            this.gridColumn52.Name = "gridColumn52";
            this.gridColumn52.OptionsColumn.AllowEdit = false;
            this.gridColumn52.Width = 41;
            // 
            // gridColumn53
            // 
            this.gridColumn53.Caption = "Ngày CT";
            this.gridColumn53.DisplayFormat.FormatString = "{0:hh:mm | dd/MM/yyyy}";
            this.gridColumn53.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn53.FieldName = "NgayCT";
            this.gridColumn53.Name = "gridColumn53";
            // 
            // gridColumn54
            // 
            this.gridColumn54.Caption = "Số phiếu";
            this.gridColumn54.FieldName = "SoCT";
            this.gridColumn54.Name = "gridColumn54";
            this.gridColumn54.Width = 145;
            // 
            // gridColumn55
            // 
            this.gridColumn55.Caption = "Diễn giải";
            this.gridColumn55.ColumnEdit = this.repositoryItemMemoExEdit5;
            this.gridColumn55.FieldName = "DienGiai";
            this.gridColumn55.FilterMode = DevExpress.XtraGrid.ColumnFilterMode.DisplayText;
            this.gridColumn55.Name = "gridColumn55";
            this.gridColumn55.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn55.Width = 378;
            // 
            // repositoryItemMemoExEdit5
            // 
            this.repositoryItemMemoExEdit5.AutoHeight = false;
            this.repositoryItemMemoExEdit5.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit5.Name = "repositoryItemMemoExEdit5";
            this.repositoryItemMemoExEdit5.PopupFormMinSize = new System.Drawing.Size(300, 0);
            this.repositoryItemMemoExEdit5.ReadOnly = true;
            this.repositoryItemMemoExEdit5.ShowDropDown = DevExpress.XtraEditors.Controls.ShowDropDown.DoubleClick;
            this.repositoryItemMemoExEdit5.ShowIcon = false;
            // 
            // gridColumn56
            // 
            this.gridColumn56.Caption = "Số tiền";
            this.gridColumn56.DisplayFormat.FormatString = "{0:#,0.##}";
            this.gridColumn56.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn56.FieldName = "SoTien";
            this.gridColumn56.FilterMode = DevExpress.XtraGrid.ColumnFilterMode.DisplayText;
            this.gridColumn56.Name = "gridColumn56";
            this.gridColumn56.OptionsColumn.AllowEdit = false;
            this.gridColumn56.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn56.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "SoTien", "{0:#,0.##}")});
            this.gridColumn56.Width = 97;
            // 
            // xtraTabPage6
            // 
            this.xtraTabPage6.Controls.Add(this.gcKTTC);
            this.xtraTabPage6.Name = "xtraTabPage6";
            this.xtraTabPage6.Size = new System.Drawing.Size(1364, 142);
            this.xtraTabPage6.Text = "5. Khấu trừ đặt cọc thi công";
            // 
            // gcKTTC
            // 
            this.gcKTTC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcKTTC.Location = new System.Drawing.Point(0, 0);
            this.gcKTTC.MainView = this.grvKTTC;
            this.gcKTTC.MenuManager = this.barManager1;
            this.gcKTTC.Name = "gcKTTC";
            this.gcKTTC.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoExEdit6});
            this.gcKTTC.Size = new System.Drawing.Size(1364, 142);
            this.gcKTTC.TabIndex = 9;
            this.gcKTTC.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvKTTC});
            // 
            // grvKTTC
            // 
            this.grvKTTC.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn57,
            this.gridColumn58,
            this.gridColumn59,
            this.gridColumn60,
            this.gridColumn61});
            this.grvKTTC.GridControl = this.gcKTTC;
            this.grvKTTC.GroupPanelText = "Kéo một vài cột lên đây để xem theo nhóm";
            this.grvKTTC.Name = "grvKTTC";
            this.grvKTTC.OptionsBehavior.Editable = false;
            this.grvKTTC.OptionsSelection.MultiSelect = true;
            this.grvKTTC.OptionsView.ColumnAutoWidth = false;
            this.grvKTTC.OptionsView.ShowFooter = true;
            this.grvKTTC.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn57
            // 
            this.gridColumn57.Caption = "STT";
            this.gridColumn57.Name = "gridColumn57";
            this.gridColumn57.OptionsColumn.AllowEdit = false;
            this.gridColumn57.Visible = true;
            this.gridColumn57.VisibleIndex = 0;
            this.gridColumn57.Width = 41;
            // 
            // gridColumn58
            // 
            this.gridColumn58.Caption = "Ngày CT";
            this.gridColumn58.DisplayFormat.FormatString = "{0:hh:mm | dd/MM/yyyy}";
            this.gridColumn58.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn58.FieldName = "NgayCT";
            this.gridColumn58.Name = "gridColumn58";
            this.gridColumn58.Visible = true;
            this.gridColumn58.VisibleIndex = 1;
            // 
            // gridColumn59
            // 
            this.gridColumn59.Caption = "Số phiếu";
            this.gridColumn59.FieldName = "SoCT";
            this.gridColumn59.Name = "gridColumn59";
            this.gridColumn59.Visible = true;
            this.gridColumn59.VisibleIndex = 2;
            this.gridColumn59.Width = 145;
            // 
            // gridColumn60
            // 
            this.gridColumn60.Caption = "Diễn giải";
            this.gridColumn60.ColumnEdit = this.repositoryItemMemoExEdit6;
            this.gridColumn60.FieldName = "DienGiai";
            this.gridColumn60.FilterMode = DevExpress.XtraGrid.ColumnFilterMode.DisplayText;
            this.gridColumn60.Name = "gridColumn60";
            this.gridColumn60.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn60.Visible = true;
            this.gridColumn60.VisibleIndex = 3;
            this.gridColumn60.Width = 378;
            // 
            // repositoryItemMemoExEdit6
            // 
            this.repositoryItemMemoExEdit6.AutoHeight = false;
            this.repositoryItemMemoExEdit6.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit6.Name = "repositoryItemMemoExEdit6";
            this.repositoryItemMemoExEdit6.PopupFormMinSize = new System.Drawing.Size(300, 0);
            this.repositoryItemMemoExEdit6.ReadOnly = true;
            this.repositoryItemMemoExEdit6.ShowDropDown = DevExpress.XtraEditors.Controls.ShowDropDown.DoubleClick;
            this.repositoryItemMemoExEdit6.ShowIcon = false;
            // 
            // gridColumn61
            // 
            this.gridColumn61.Caption = "Số tiền";
            this.gridColumn61.DisplayFormat.FormatString = "{0:#,0.##}";
            this.gridColumn61.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn61.FieldName = "SoTien";
            this.gridColumn61.FilterMode = DevExpress.XtraGrid.ColumnFilterMode.DisplayText;
            this.gridColumn61.Name = "gridColumn61";
            this.gridColumn61.OptionsColumn.AllowEdit = false;
            this.gridColumn61.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn61.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "SoTien", "{0:#,0.##}")});
            this.gridColumn61.Visible = true;
            this.gridColumn61.VisibleIndex = 4;
            this.gridColumn61.Width = 97;
            // 
            // xtraTabPage7
            // 
            this.xtraTabPage7.Controls.Add(this.gcKTHDT);
            this.xtraTabPage7.Name = "xtraTabPage7";
            this.xtraTabPage7.Size = new System.Drawing.Size(1364, 142);
            this.xtraTabPage7.Text = "5. Khấu trừ đặt cọc hợp đồng thuê";
            // 
            // gcKTHDT
            // 
            this.gcKTHDT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcKTHDT.Location = new System.Drawing.Point(0, 0);
            this.gcKTHDT.MainView = this.gridView1;
            this.gcKTHDT.MenuManager = this.barManager1;
            this.gcKTHDT.Name = "gcKTHDT";
            this.gcKTHDT.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoExEdit7});
            this.gcKTHDT.Size = new System.Drawing.Size(1364, 142);
            this.gcKTHDT.TabIndex = 10;
            this.gcKTHDT.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn70,
            this.gridColumn71,
            this.gridColumn72,
            this.gridColumn73,
            this.gridColumn74});
            this.gridView1.GridControl = this.gcKTHDT;
            this.gridView1.GroupPanelText = "Kéo một vài cột lên đây để xem theo nhóm";
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.Editable = false;
            this.gridView1.OptionsSelection.MultiSelect = true;
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.ShowFooter = true;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn70
            // 
            this.gridColumn70.Caption = "STT";
            this.gridColumn70.Name = "gridColumn70";
            this.gridColumn70.OptionsColumn.AllowEdit = false;
            this.gridColumn70.Visible = true;
            this.gridColumn70.VisibleIndex = 0;
            this.gridColumn70.Width = 41;
            // 
            // gridColumn71
            // 
            this.gridColumn71.Caption = "Ngày CT";
            this.gridColumn71.DisplayFormat.FormatString = "{0:hh:mm | dd/MM/yyyy}";
            this.gridColumn71.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn71.FieldName = "NgayCT";
            this.gridColumn71.Name = "gridColumn71";
            this.gridColumn71.Visible = true;
            this.gridColumn71.VisibleIndex = 1;
            // 
            // gridColumn72
            // 
            this.gridColumn72.Caption = "Số phiếu";
            this.gridColumn72.FieldName = "SoCT";
            this.gridColumn72.Name = "gridColumn72";
            this.gridColumn72.Visible = true;
            this.gridColumn72.VisibleIndex = 2;
            this.gridColumn72.Width = 145;
            // 
            // gridColumn73
            // 
            this.gridColumn73.Caption = "Diễn giải";
            this.gridColumn73.ColumnEdit = this.repositoryItemMemoExEdit7;
            this.gridColumn73.FieldName = "DienGiai";
            this.gridColumn73.FilterMode = DevExpress.XtraGrid.ColumnFilterMode.DisplayText;
            this.gridColumn73.Name = "gridColumn73";
            this.gridColumn73.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn73.Visible = true;
            this.gridColumn73.VisibleIndex = 3;
            this.gridColumn73.Width = 378;
            // 
            // repositoryItemMemoExEdit7
            // 
            this.repositoryItemMemoExEdit7.AutoHeight = false;
            this.repositoryItemMemoExEdit7.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit7.Name = "repositoryItemMemoExEdit7";
            this.repositoryItemMemoExEdit7.PopupFormMinSize = new System.Drawing.Size(300, 0);
            this.repositoryItemMemoExEdit7.ReadOnly = true;
            this.repositoryItemMemoExEdit7.ShowDropDown = DevExpress.XtraEditors.Controls.ShowDropDown.DoubleClick;
            this.repositoryItemMemoExEdit7.ShowIcon = false;
            // 
            // gridColumn74
            // 
            this.gridColumn74.Caption = "Số tiền";
            this.gridColumn74.DisplayFormat.FormatString = "{0:#,0.##}";
            this.gridColumn74.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn74.FieldName = "SoTien";
            this.gridColumn74.FilterMode = DevExpress.XtraGrid.ColumnFilterMode.DisplayText;
            this.gridColumn74.Name = "gridColumn74";
            this.gridColumn74.OptionsColumn.AllowEdit = false;
            this.gridColumn74.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn74.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "SoTien", "{0:#,0.##}")});
            this.gridColumn74.Visible = true;
            this.gridColumn74.VisibleIndex = 4;
            this.gridColumn74.Width = 97;
            // 
            // frmManagerHDT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.splitContainerControl1);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "frmManagerHDT";
            this.Text = "Hóa đơn dịch vụ";
            this.Load += new System.EventHandler(this.frmManager_Load);
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lkToaNha)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbbKyBC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTuNgay.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTuNgay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateDenNgay.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateDenNgay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcHoaDon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvHoaDon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
            this.splitContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.xtraTabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gcChiTiet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvChiTiet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit2)).EndInit();
            this.xtraTabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gcKhauTru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvKhauTru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit3)).EndInit();
            this.xtraTabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gcKTTB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvKTTB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit1)).EndInit();
            this.xtraTabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gcKTTG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvKTTG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit4)).EndInit();
            this.xtraTabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gcKTBBQ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvKTBBQ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit5)).EndInit();
            this.xtraTabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gcKTTC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvKTTC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit6)).EndInit();
            this.xtraTabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gcKTHDT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.Bar bar1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.BarButtonItem btnNap;
        private DevExpress.XtraBars.BarButtonItem btnThem;
        private DevExpress.XtraBars.BarButtonItem btnXoa;
        private DevExpress.XtraBars.BarButtonItem btnSua;
        private DevExpress.XtraBars.BarEditItem itemKyBC;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox cbbKyBC;
        private DevExpress.XtraBars.BarEditItem itemTuNgay;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit dateTuNgay;
        private DevExpress.XtraBars.BarEditItem itemDenNgay;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit dateDenNgay;
        private DevExpress.XtraBars.BarEditItem itemToaNha;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit lkToaNha;
        private DevExpress.Data.Linq.LinqInstantFeedbackSource linqInstantFeedbackSource1;
        private DevExpress.XtraGrid.GridControl gcHoaDon;
        private DevExpress.XtraGrid.Views.Grid.GridView gvHoaDon;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn21;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn22;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn23;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn24;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraBars.BarButtonItem itemThuTien;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraBars.BarButtonItem itemImport;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraBars.BarSubItem barDuyet;
        private DevExpress.XtraBars.BarButtonItem itemDuyet;
        private DevExpress.XtraBars.BarButtonItem itemKhongDuyet;
        private DevExpress.XtraBars.BarButtonItem itemThem;
        private DevExpress.XtraBars.BarButtonItem itemSua;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraBars.BarButtonItem itemDuyetAll;
        private DevExpress.XtraBars.BarButtonItem itemKhongDuyetAll;
        private DevExpress.XtraBars.BarButtonItem itemExport;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraBars.BarSubItem barSubItem1;
        private DevExpress.XtraBars.BarButtonItem itemAddMulti;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraGrid.GridControl gcChiTiet;
        private DevExpress.XtraGrid.Views.Grid.GridView gvChiTiet;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn26;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn25;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn20;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn27;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn28;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn29;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn30;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn31;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn32;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn33;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn34;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn35;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private DevExpress.XtraGrid.GridControl gcKhauTru;
        private DevExpress.XtraGrid.Views.Grid.GridView grvKhauTru;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn36;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn37;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn38;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn39;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn40;
        private DevExpress.XtraBars.BarButtonItem itemHDTTND;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn41;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage3;
        private DevExpress.XtraGrid.GridControl gcKTTB;
        private DevExpress.XtraGrid.Views.Grid.GridView grvKTTB;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn42;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn43;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn44;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn45;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn46;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage4;
        private DevExpress.XtraGrid.GridControl gcKTTG;
        private DevExpress.XtraGrid.Views.Grid.GridView grvKTTG;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn47;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn48;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn49;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn50;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn51;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage5;
        private DevExpress.XtraGrid.GridControl gcKTBBQ;
        private DevExpress.XtraGrid.Views.Grid.GridView grvKTBBQ;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn52;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn53;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn54;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn55;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn56;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage6;
        private DevExpress.XtraGrid.GridControl gcKTTC;
        private DevExpress.XtraGrid.Views.Grid.GridView grvKTTC;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn57;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn58;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn59;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn60;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn61;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn63;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn62;
        private DevExpress.XtraBars.BarButtonItem itemHoaDonNguoc;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn64;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn65;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn66;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn67;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn68;
        private DevExpress.XtraBars.BarButtonItem btnHoaDonXe;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn69;
        private DevExpress.XtraBars.BarButtonItem itemPQL;
        private DevExpress.XtraBars.BarButtonItem itemDieuChinhHoaDon;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage7;
        private DevExpress.XtraGrid.GridControl gcKTHDT;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn70;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn71;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn72;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn73;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn74;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn75;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn76;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn77;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn78;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn79;
        private DevExpress.Utils.ImageCollection imageCollection1;
    }
}