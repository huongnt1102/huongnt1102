﻿namespace LandSoftBuilding.Receivables
{
    partial class frmReceivables
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmReceivables));
            DevExpress.XtraGrid.GridFormatRule gridFormatRule16 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRule3ColorScale formatConditionRule3ColorScale9 = new DevExpress.XtraEditors.FormatConditionRule3ColorScale();
            DevExpress.XtraGrid.GridFormatRule gridFormatRule17 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRule3ColorScale formatConditionRule3ColorScale10 = new DevExpress.XtraEditors.FormatConditionRule3ColorScale();
            DevExpress.XtraGrid.GridFormatRule gridFormatRule1 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRuleIconSet formatConditionRuleIconSet1 = new DevExpress.XtraEditors.FormatConditionRuleIconSet();
            DevExpress.XtraEditors.FormatConditionIconSet formatConditionIconSet1 = new DevExpress.XtraEditors.FormatConditionIconSet();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon1 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon2 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon3 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraGrid.GridFormatRule gridFormatRule2 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRuleIconSet formatConditionRuleIconSet2 = new DevExpress.XtraEditors.FormatConditionRuleIconSet();
            DevExpress.XtraEditors.FormatConditionIconSet formatConditionIconSet2 = new DevExpress.XtraEditors.FormatConditionIconSet();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon4 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon5 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon6 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraGrid.GridFormatRule gridFormatRule3 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRuleIconSet formatConditionRuleIconSet3 = new DevExpress.XtraEditors.FormatConditionRuleIconSet();
            DevExpress.XtraEditors.FormatConditionIconSet formatConditionIconSet3 = new DevExpress.XtraEditors.FormatConditionIconSet();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon7 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon8 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon9 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraGrid.GridFormatRule gridFormatRule4 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRuleIconSet formatConditionRuleIconSet4 = new DevExpress.XtraEditors.FormatConditionRuleIconSet();
            DevExpress.XtraEditors.FormatConditionIconSet formatConditionIconSet4 = new DevExpress.XtraEditors.FormatConditionIconSet();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon10 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon11 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon12 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraGrid.GridFormatRule gridFormatRule5 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRuleIconSet formatConditionRuleIconSet5 = new DevExpress.XtraEditors.FormatConditionRuleIconSet();
            DevExpress.XtraEditors.FormatConditionIconSet formatConditionIconSet5 = new DevExpress.XtraEditors.FormatConditionIconSet();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon13 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon14 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon15 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraGrid.GridFormatRule gridFormatRule6 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRuleIconSet formatConditionRuleIconSet6 = new DevExpress.XtraEditors.FormatConditionRuleIconSet();
            DevExpress.XtraEditors.FormatConditionIconSet formatConditionIconSet6 = new DevExpress.XtraEditors.FormatConditionIconSet();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon16 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon17 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon18 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon19 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon20 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraGrid.GridFormatRule gridFormatRule7 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRuleIconSet formatConditionRuleIconSet7 = new DevExpress.XtraEditors.FormatConditionRuleIconSet();
            DevExpress.XtraEditors.FormatConditionIconSet formatConditionIconSet7 = new DevExpress.XtraEditors.FormatConditionIconSet();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon21 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon22 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraEditors.FormatConditionIconSetIcon formatConditionIconSetIcon23 = new DevExpress.XtraEditors.FormatConditionIconSetIcon();
            DevExpress.XtraGrid.GridFormatRule gridFormatRule8 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRule3ColorScale formatConditionRule3ColorScale1 = new DevExpress.XtraEditors.FormatConditionRule3ColorScale();
            DevExpress.XtraGrid.GridFormatRule gridFormatRule9 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRule3ColorScale formatConditionRule3ColorScale2 = new DevExpress.XtraEditors.FormatConditionRule3ColorScale();
            DevExpress.XtraGrid.GridFormatRule gridFormatRule10 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRule3ColorScale formatConditionRule3ColorScale3 = new DevExpress.XtraEditors.FormatConditionRule3ColorScale();
            DevExpress.XtraGrid.GridFormatRule gridFormatRule11 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRule3ColorScale formatConditionRule3ColorScale4 = new DevExpress.XtraEditors.FormatConditionRule3ColorScale();
            DevExpress.XtraGrid.GridFormatRule gridFormatRule12 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRule3ColorScale formatConditionRule3ColorScale5 = new DevExpress.XtraEditors.FormatConditionRule3ColorScale();
            DevExpress.XtraGrid.GridFormatRule gridFormatRule13 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRule3ColorScale formatConditionRule3ColorScale6 = new DevExpress.XtraEditors.FormatConditionRule3ColorScale();
            DevExpress.XtraGrid.GridFormatRule gridFormatRule14 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRule3ColorScale formatConditionRule3ColorScale7 = new DevExpress.XtraEditors.FormatConditionRule3ColorScale();
            DevExpress.XtraGrid.GridFormatRule gridFormatRule15 = new DevExpress.XtraGrid.GridFormatRule();
            DevExpress.XtraEditors.FormatConditionRule3ColorScale formatConditionRule3ColorScale8 = new DevExpress.XtraEditors.FormatConditionRule3ColorScale();
            this.gridColumn27 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn31 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colNoDauKy = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPhatSinh = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDaThu = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colConNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colKhauTru = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colThuTruoc = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCongNoCuoi = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn23 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.imageCollection1 = new DevExpress.Utils.ImageCollection(this.components);
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.bar1 = new DevExpress.XtraBars.Bar();
            this.itemToaNha = new DevExpress.XtraBars.BarEditItem();
            this.lkToaNha = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.itemThang = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemSpinEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.itemNam = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemSpinEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.itemNap = new DevExpress.XtraBars.BarButtonItem();
            this.itemThuTien = new DevExpress.XtraBars.BarButtonItem();
            this.itemPrintAll = new DevExpress.XtraBars.BarSubItem();
            this.itemPrintSelect = new DevExpress.XtraBars.BarButtonItem();
            this.itemPrintSelectAll = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem1 = new DevExpress.XtraBars.BarSubItem();
            this.itemPreview = new DevExpress.XtraBars.BarButtonItem();
            this.itemPrintFund = new DevExpress.XtraBars.BarButtonItem();
            this.itemSendMail = new DevExpress.XtraBars.BarButtonItem();
            this.itemSmsZalo = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.itemKhauTuDong = new DevExpress.XtraBars.BarSubItem();
            this.itemKhautruTudongCanhan = new DevExpress.XtraBars.BarButtonItem();
            this.itemKhautruTudongTatca = new DevExpress.XtraBars.BarButtonItem();
            this.itemExport = new DevExpress.XtraBars.BarButtonItem();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.itemPrint = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.itemSuaPhieuThu = new DevExpress.XtraBars.BarButtonItem();
            this.repositoryItemLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.lookUpThang = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.lookUpKhoiNha = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemButtonEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.LookUpNam = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.repositoryItemTextEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.cmbThang = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.xtraTabPage3 = new DevExpress.XtraTab.XtraTabPage();
            this.gcPhieuThu = new DevExpress.XtraGrid.GridControl();
            this.gvPhieuThu = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn26 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn33 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn34 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn35 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn36 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn37 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn38 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn39 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn42 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn46 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn47 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn48 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.lookNhanVien = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemMemoExEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.popupMenuPhieuThu = new DevExpress.XtraBars.PopupMenu(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            this.gcHoaDon = new DevExpress.XtraGrid.GridControl();
            this.gvHoaDon = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn25 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn20 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn30 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn32 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.gcChiTiet = new DevExpress.XtraGrid.GridControl();
            this.gvChiTiet = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn28 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn21 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn22 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn29 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn24 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn58 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            this.ctlMailHistory1 = new LandSoftBuilding.Marketing.Mail.History.ctlMailHistory();
            this.xtraTabPage4 = new DevExpress.XtraTab.XtraTabPage();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn40 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn41 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn43 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn44 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn45 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn49 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn50 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn51 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn54 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn55 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn59 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn60 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn66 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn67 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemMemoExEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.xtraTabPage5 = new DevExpress.XtraTab.XtraTabPage();
            this.gridControl2 = new DevExpress.XtraGrid.GridControl();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn52 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn53 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn56 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn57 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.linqInstantFeedbackSource1 = new DevExpress.Data.Linq.LinqInstantFeedbackSource();
            this.gridColumn61 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn62 = new DevExpress.XtraGrid.Columns.GridColumn();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lkToaNha)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpThang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpKhoiNha)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LookUpNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbThang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            this.xtraTabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcPhieuThu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvPhieuThu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookNhanVien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenuPhieuThu)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
            this.splitContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcHoaDon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvHoaDon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.xtraTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcChiTiet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvChiTiet)).BeginInit();
            this.xtraTabPage2.SuspendLayout();
            this.xtraTabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit2)).BeginInit();
            this.xtraTabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // gridColumn27
            // 
            this.gridColumn27.Caption = "Phải thu";
            this.gridColumn27.DisplayFormat.FormatString = "{0:#,0.##}";
            this.gridColumn27.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn27.FieldName = "TienPhaiThu";
            this.gridColumn27.MinWidth = 23;
            this.gridColumn27.Name = "gridColumn27";
            this.gridColumn27.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "TienPhaiThu", "{0:#,0.##}")});
            this.gridColumn27.Visible = true;
            this.gridColumn27.VisibleIndex = 4;
            this.gridColumn27.Width = 136;
            // 
            // gridColumn31
            // 
            this.gridColumn31.Caption = "Số tiền thu";
            this.gridColumn31.DisplayFormat.FormatString = "N0";
            this.gridColumn31.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn31.FieldName = "SoTienThu";
            this.gridColumn31.MinWidth = 23;
            this.gridColumn31.Name = "gridColumn31";
            this.gridColumn31.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "SoTienThu", "{0:#,0.##}")});
            this.gridColumn31.Visible = true;
            this.gridColumn31.VisibleIndex = 5;
            this.gridColumn31.Width = 107;
            // 
            // colNoDauKy
            // 
            this.colNoDauKy.Caption = "Nợ đầu kỳ";
            this.colNoDauKy.DisplayFormat.FormatString = "{0:#,0.##; (#,0.##);-}";
            this.colNoDauKy.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colNoDauKy.FieldName = "NoDauKy";
            this.colNoDauKy.MinWidth = 23;
            this.colNoDauKy.Name = "colNoDauKy";
            this.colNoDauKy.OptionsColumn.AllowEdit = false;
            this.colNoDauKy.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "NoDauKy", "{0:#,0.##; (#,0.##);-}")});
            this.colNoDauKy.Visible = true;
            this.colNoDauKy.VisibleIndex = 7;
            this.colNoDauKy.Width = 124;
            // 
            // colPhatSinh
            // 
            this.colPhatSinh.Caption = "Phát sinh";
            this.colPhatSinh.DisplayFormat.FormatString = "{0:#,0.##; (#,0.##);-}";
            this.colPhatSinh.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colPhatSinh.FieldName = "PhatSinh";
            this.colPhatSinh.MinWidth = 23;
            this.colPhatSinh.Name = "colPhatSinh";
            this.colPhatSinh.OptionsColumn.AllowEdit = false;
            this.colPhatSinh.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "PhatSinh", "{0:#,0.##; (#,0.##);-}")});
            this.colPhatSinh.Visible = true;
            this.colPhatSinh.VisibleIndex = 8;
            this.colPhatSinh.Width = 118;
            // 
            // colDaThu
            // 
            this.colDaThu.Caption = "Đã thu";
            this.colDaThu.DisplayFormat.FormatString = "{0:#,0.##; (#,0.##);-}";
            this.colDaThu.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colDaThu.FieldName = "DaThu";
            this.colDaThu.MinWidth = 23;
            this.colDaThu.Name = "colDaThu";
            this.colDaThu.OptionsColumn.AllowEdit = false;
            this.colDaThu.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "DaThu", "{0:#,0.##; (#,0.##);-}")});
            this.colDaThu.Visible = true;
            this.colDaThu.VisibleIndex = 9;
            this.colDaThu.Width = 125;
            // 
            // colConNo
            // 
            this.colConNo.Caption = "Còn nợ";
            this.colConNo.DisplayFormat.FormatString = "{0:#,0.##; (#,0.##);-}";
            this.colConNo.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colConNo.FieldName = "ConNo";
            this.colConNo.MinWidth = 23;
            this.colConNo.Name = "colConNo";
            this.colConNo.OptionsColumn.AllowEdit = false;
            this.colConNo.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ConNo", "{0:#,0.##; (#,0.##);-}")});
            this.colConNo.Visible = true;
            this.colConNo.VisibleIndex = 11;
            this.colConNo.Width = 119;
            // 
            // colKhauTru
            // 
            this.colKhauTru.Caption = "Khấu trừ";
            this.colKhauTru.DisplayFormat.FormatString = "{0:#,0.##; (#,0.##);-}";
            this.colKhauTru.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colKhauTru.FieldName = "KhauTru";
            this.colKhauTru.MinWidth = 23;
            this.colKhauTru.Name = "colKhauTru";
            this.colKhauTru.OptionsColumn.AllowEdit = false;
            this.colKhauTru.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "KhauTru", "{0:#,0.##; (#,0.##);-}")});
            this.colKhauTru.Visible = true;
            this.colKhauTru.VisibleIndex = 10;
            this.colKhauTru.Width = 108;
            // 
            // colThuTruoc
            // 
            this.colThuTruoc.Caption = "Thu trước";
            this.colThuTruoc.DisplayFormat.FormatString = "{0:#,0.##; (#,0.##);-}";
            this.colThuTruoc.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colThuTruoc.FieldName = "ThuTruoc";
            this.colThuTruoc.MinWidth = 23;
            this.colThuTruoc.Name = "colThuTruoc";
            this.colThuTruoc.OptionsColumn.AllowEdit = false;
            this.colThuTruoc.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ThuTruoc", "{0:#,0.##; (#,0.##);-}")});
            this.colThuTruoc.Visible = true;
            this.colThuTruoc.VisibleIndex = 12;
            this.colThuTruoc.Width = 117;
            // 
            // colCongNoCuoi
            // 
            this.colCongNoCuoi.Caption = "Công nợ cuối";
            this.colCongNoCuoi.DisplayFormat.FormatString = "{0:#,0.##; (#,0.##);-}";
            this.colCongNoCuoi.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colCongNoCuoi.FieldName = "NoCuoi";
            this.colCongNoCuoi.MinWidth = 23;
            this.colCongNoCuoi.Name = "colCongNoCuoi";
            this.colCongNoCuoi.OptionsColumn.AllowEdit = false;
            this.colCongNoCuoi.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "NoCuoi", "{0:#,0.##; (#,0.##);-}")});
            this.colCongNoCuoi.Visible = true;
            this.colCongNoCuoi.VisibleIndex = 13;
            this.colCongNoCuoi.Width = 154;
            // 
            // gridColumn19
            // 
            this.gridColumn19.Caption = "Tầng/Lầu";
            this.gridColumn19.FieldName = "TenTL";
            this.gridColumn19.MinWidth = 23;
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 14;
            this.gridColumn19.Width = 87;
            // 
            // gridColumn23
            // 
            this.gridColumn23.Caption = "Còn nợ";
            this.gridColumn23.DisplayFormat.FormatString = "n0";
            this.gridColumn23.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn23.FieldName = "ConNo";
            this.gridColumn23.MinWidth = 23;
            this.gridColumn23.Name = "gridColumn23";
            this.gridColumn23.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ConNo", "{0:n0}")});
            this.gridColumn23.Visible = true;
            this.gridColumn23.VisibleIndex = 7;
            this.gridColumn23.Width = 101;
            // 
            // gridColumn10
            // 
            this.gridColumn10.Caption = "Tiền sau thuế";
            this.gridColumn10.DisplayFormat.FormatString = "n0";
            this.gridColumn10.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn10.FieldName = "TienTT";
            this.gridColumn10.MinWidth = 23;
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 11;
            this.gridColumn10.Width = 92;
            // 
            // imageCollection1
            // 
            this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection1.ImageStream")));
            this.imageCollection1.Images.SetKeyName(0, "Refresh1.png");
            this.imageCollection1.Images.SetKeyName(1, "Tien3.png");
            this.imageCollection1.Images.SetKeyName(2, "Print1.png");
            this.imageCollection1.Images.SetKeyName(3, "Mail2.png");
            this.imageCollection1.Images.SetKeyName(4, "List3.png");
            this.imageCollection1.Images.SetKeyName(5, "Export1.png");
            this.imageCollection1.Images.SetKeyName(6, "Edit3.png");
            this.imageCollection1.Images.SetKeyName(7, "icons8_sms_token_filled_50px.png");
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 83);
            this.barDockControlLeft.Manager = this.barManager1;
            this.barDockControlLeft.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 584);
            // 
            // barManager1
            // 
            this.barManager1.AllowCustomization = false;
            this.barManager1.AllowMoveBarOnToolbar = false;
            this.barManager1.AllowQuickCustomization = false;
            this.barManager1.AllowShowToolbarsPopup = false;
            this.barManager1.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.bar1});
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.HideBarsWhenMerging = false;
            this.barManager1.Images = this.imageCollection1;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.itemNap,
            this.itemToaNha,
            this.itemThuTien,
            this.itemThang,
            this.itemNam,
            this.itemPrint,
            this.itemSendMail,
            this.itemPreview,
            this.barSubItem1,
            this.itemPrintFund,
            this.itemPrintAll,
            this.itemPrintSelect,
            this.itemPrintSelectAll,
            this.barButtonItem1,
            this.itemKhauTuDong,
            this.itemKhautruTudongCanhan,
            this.itemKhautruTudongTatca,
            this.itemExport,
            this.itemSuaPhieuThu,
            this.itemSmsZalo,
            this.barButtonItem2});
            this.barManager1.MaxItemId = 77;
            this.barManager1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemLookUpEdit1,
            this.lookUpThang,
            this.repositoryItemTextEdit1,
            this.lookUpKhoiNha,
            this.repositoryItemButtonEdit1,
            this.LookUpNam,
            this.lkToaNha,
            this.repositoryItemDateEdit1,
            this.repositoryItemTextEdit2,
            this.cmbThang,
            this.repositoryItemComboBox1,
            this.repositoryItemSpinEdit1,
            this.repositoryItemSpinEdit2});
            this.barManager1.ShowFullMenus = true;
            // 
            // bar1
            // 
            this.bar1.BarName = "Tools";
            this.bar1.DockCol = 0;
            this.bar1.DockRow = 0;
            this.bar1.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.bar1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemToaNha, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemThang, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemNam, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemNap, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemThuTien, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemPrintAll, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barSubItem1, "", false, true, false, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemSendMail, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemSmsZalo, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem2, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemKhauTuDong, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemExport, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.bar1.OptionsBar.AllowQuickCustomization = false;
            this.bar1.OptionsBar.DrawDragBorder = false;
            this.bar1.OptionsBar.MultiLine = true;
            this.bar1.OptionsBar.UseWholeRow = true;
            this.bar1.Text = "Tools";
            // 
            // itemToaNha
            // 
            this.itemToaNha.Caption = "Dự án";
            this.itemToaNha.Edit = this.lkToaNha;
            this.itemToaNha.EditWidth = 150;
            this.itemToaNha.Id = 40;
            this.itemToaNha.Name = "itemToaNha";
            // 
            // lkToaNha
            // 
            this.lkToaNha.AutoHeight = false;
            this.lkToaNha.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lkToaNha.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("TenTN", "Name4")});
            this.lkToaNha.DisplayMember = "TenTN";
            this.lkToaNha.Name = "lkToaNha";
            this.lkToaNha.NullText = "";
            this.lkToaNha.ShowHeader = false;
            this.lkToaNha.ValueMember = "MaTN";
            // 
            // itemThang
            // 
            this.itemThang.Caption = "Tháng";
            this.itemThang.Edit = this.repositoryItemSpinEdit1;
            this.itemThang.Id = 49;
            this.itemThang.Name = "itemThang";
            // 
            // repositoryItemSpinEdit1
            // 
            this.repositoryItemSpinEdit1.AutoHeight = false;
            this.repositoryItemSpinEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemSpinEdit1.DisplayFormat.FormatString = "{0:00}";
            this.repositoryItemSpinEdit1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.repositoryItemSpinEdit1.EditFormat.FormatString = "{0:00}";
            this.repositoryItemSpinEdit1.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.repositoryItemSpinEdit1.MaxValue = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.repositoryItemSpinEdit1.MinValue = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.repositoryItemSpinEdit1.Name = "repositoryItemSpinEdit1";
            // 
            // itemNam
            // 
            this.itemNam.Caption = "Năm";
            this.itemNam.Edit = this.repositoryItemSpinEdit2;
            this.itemNam.EditWidth = 60;
            this.itemNam.Id = 50;
            this.itemNam.Name = "itemNam";
            // 
            // repositoryItemSpinEdit2
            // 
            this.repositoryItemSpinEdit2.AutoHeight = false;
            this.repositoryItemSpinEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemSpinEdit2.Name = "repositoryItemSpinEdit2";
            // 
            // itemNap
            // 
            this.itemNap.Caption = "Nạp";
            this.itemNap.Id = 3;
            this.itemNap.ImageOptions.ImageIndex = 0;
            this.itemNap.Name = "itemNap";
            this.itemNap.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemNap_ItemClick);
            // 
            // itemThuTien
            // 
            this.itemThuTien.Caption = "Thu tiền";
            this.itemThuTien.Id = 41;
            this.itemThuTien.ImageOptions.ImageIndex = 1;
            this.itemThuTien.Name = "itemThuTien";
            this.itemThuTien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemThuTien_ItemClick);
            // 
            // itemPrintAll
            // 
            this.itemPrintAll.Caption = "In thông báo phí";
            this.itemPrintAll.Id = 66;
            this.itemPrintAll.ImageOptions.ImageIndex = 2;
            this.itemPrintAll.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemPrintSelect),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemPrintSelectAll)});
            this.itemPrintAll.Name = "itemPrintAll";
            this.itemPrintAll.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPrint_ItemClick);
            // 
            // itemPrintSelect
            // 
            this.itemPrintSelect.Caption = "In dòng chọn";
            this.itemPrintSelect.Id = 67;
            this.itemPrintSelect.ImageOptions.ImageIndex = 2;
            this.itemPrintSelect.Name = "itemPrintSelect";
            this.itemPrintSelect.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemPrintSelect.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPrintSelect_ItemClick);
            // 
            // itemPrintSelectAll
            // 
            this.itemPrintSelectAll.Caption = "In tất cả";
            this.itemPrintSelectAll.Id = 68;
            this.itemPrintSelectAll.ImageOptions.ImageIndex = 2;
            this.itemPrintSelectAll.Name = "itemPrintSelectAll";
            this.itemPrintSelectAll.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.itemPrintSelectAll.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPrintSelectAll_ItemClick);
            // 
            // barSubItem1
            // 
            this.barSubItem1.Caption = "In phiếu thu";
            this.barSubItem1.Id = 63;
            this.barSubItem1.ImageOptions.ImageIndex = 2;
            this.barSubItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.itemPreview, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemPrintFund)});
            this.barSubItem1.Name = "barSubItem1";
            this.barSubItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // itemPreview
            // 
            this.itemPreview.Caption = "Xem";
            this.itemPreview.Id = 62;
            this.itemPreview.Name = "itemPreview";
            this.itemPreview.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPreview_ItemClick);
            // 
            // itemPrintFund
            // 
            this.itemPrintFund.Caption = "In";
            this.itemPrintFund.Id = 64;
            this.itemPrintFund.Name = "itemPrintFund";
            this.itemPrintFund.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPrintFund_ItemClick);
            // 
            // itemSendMail
            // 
            this.itemSendMail.Caption = "Gửi mail";
            this.itemSendMail.Id = 58;
            this.itemSendMail.ImageOptions.ImageIndex = 3;
            this.itemSendMail.Name = "itemSendMail";
            this.itemSendMail.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemSendMail_ItemClick);
            // 
            // itemSmsZalo
            // 
            this.itemSmsZalo.Caption = "sms Zalo";
            this.itemSmsZalo.Id = 75;
            this.itemSmsZalo.ImageOptions.ImageIndex = 3;
            this.itemSmsZalo.Name = "itemSmsZalo";
            this.itemSmsZalo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemSmsZalo_ItemClick);
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "Gửi notification";
            this.barButtonItem2.Id = 76;
            this.barButtonItem2.ImageOptions.ImageIndex = 7;
            this.barButtonItem2.Name = "barButtonItem2";
            this.barButtonItem2.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem2_ItemClick);
            // 
            // itemKhauTuDong
            // 
            this.itemKhauTuDong.Caption = "Khấu trừ tự động";
            this.itemKhauTuDong.Id = 70;
            this.itemKhauTuDong.ImageOptions.ImageIndex = 4;
            this.itemKhauTuDong.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemKhautruTudongCanhan),
            new DevExpress.XtraBars.LinkPersistInfo(this.itemKhautruTudongTatca)});
            this.itemKhauTuDong.Name = "itemKhauTuDong";
            // 
            // itemKhautruTudongCanhan
            // 
            this.itemKhautruTudongCanhan.Caption = "Dòng chọn";
            this.itemKhautruTudongCanhan.Id = 71;
            this.itemKhautruTudongCanhan.Name = "itemKhautruTudongCanhan";
            this.itemKhautruTudongCanhan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKhautruTudongCanhan_ItemClick);
            // 
            // itemKhautruTudongTatca
            // 
            this.itemKhautruTudongTatca.Caption = "Tất cả";
            this.itemKhautruTudongTatca.Id = 72;
            this.itemKhautruTudongTatca.Name = "itemKhautruTudongTatca";
            this.itemKhautruTudongTatca.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemKhautruTudongTatca_ItemClick);
            // 
            // itemExport
            // 
            this.itemExport.Caption = "Export";
            this.itemExport.Id = 73;
            this.itemExport.ImageOptions.ImageIndex = 5;
            this.itemExport.Name = "itemExport";
            this.itemExport.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemExport_ItemClick);
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Manager = this.barManager1;
            this.barDockControlTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.barDockControlTop.Size = new System.Drawing.Size(1059, 83);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 667);
            this.barDockControlBottom.Manager = this.barManager1;
            this.barDockControlBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.barDockControlBottom.Size = new System.Drawing.Size(1059, 0);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(1059, 83);
            this.barDockControlRight.Manager = this.barManager1;
            this.barDockControlRight.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 584);
            // 
            // itemPrint
            // 
            this.itemPrint.Caption = "In";
            this.itemPrint.Id = 57;
            this.itemPrint.ImageOptions.ImageIndex = 2;
            this.itemPrint.Name = "itemPrint";
            this.itemPrint.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemPrint_ItemClick);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "Khấu trừ tự động";
            this.barButtonItem1.Id = 69;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // itemSuaPhieuThu
            // 
            this.itemSuaPhieuThu.Caption = "Sửa";
            this.itemSuaPhieuThu.Id = 74;
            this.itemSuaPhieuThu.ImageOptions.ImageIndex = 6;
            this.itemSuaPhieuThu.Name = "itemSuaPhieuThu";
            this.itemSuaPhieuThu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.itemSuaPhieuThu_ItemClick);
            // 
            // repositoryItemLookUpEdit1
            // 
            this.repositoryItemLookUpEdit1.AutoHeight = false;
            this.repositoryItemLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit1.Name = "repositoryItemLookUpEdit1";
            this.repositoryItemLookUpEdit1.NullText = "Dự án";
            this.repositoryItemLookUpEdit1.ShowHeader = false;
            // 
            // lookUpThang
            // 
            this.lookUpThang.AutoHeight = false;
            this.lookUpThang.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpThang.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Thang", "Name1")});
            this.lookUpThang.DisplayMember = "Thang";
            this.lookUpThang.Name = "lookUpThang";
            this.lookUpThang.NullText = "[Chọn tháng]";
            this.lookUpThang.ShowHeader = false;
            this.lookUpThang.ValueMember = "Thang";
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // lookUpKhoiNha
            // 
            this.lookUpKhoiNha.AutoHeight = false;
            this.lookUpKhoiNha.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpKhoiNha.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("TenKN", "Name2")});
            this.lookUpKhoiNha.DisplayMember = "TenKN";
            this.lookUpKhoiNha.Name = "lookUpKhoiNha";
            this.lookUpKhoiNha.NullText = "[Khối nhà]";
            this.lookUpKhoiNha.ShowHeader = false;
            this.lookUpKhoiNha.ValueMember = "MaKN";
            // 
            // repositoryItemButtonEdit1
            // 
            this.repositoryItemButtonEdit1.AutoHeight = false;
            this.repositoryItemButtonEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEdit1.Name = "repositoryItemButtonEdit1";
            // 
            // LookUpNam
            // 
            this.LookUpNam.AutoHeight = false;
            this.LookUpNam.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.LookUpNam.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Nam", "Name4")});
            this.LookUpNam.DisplayMember = "Nam";
            this.LookUpNam.Name = "LookUpNam";
            this.LookUpNam.NullText = "Chọn Dự án";
            this.LookUpNam.SearchMode = DevExpress.XtraEditors.Controls.SearchMode.AutoComplete;
            this.LookUpNam.ShowHeader = false;
            this.LookUpNam.ValueMember = "Nam";
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AllowNullInput = DevExpress.Utils.DefaultBoolean.False;
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            this.repositoryItemDateEdit1.ShowToday = false;
            // 
            // repositoryItemTextEdit2
            // 
            this.repositoryItemTextEdit2.AutoHeight = false;
            this.repositoryItemTextEdit2.Name = "repositoryItemTextEdit2";
            // 
            // cmbThang
            // 
            this.cmbThang.AutoHeight = false;
            this.cmbThang.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmbThang.Name = "cmbThang";
            this.cmbThang.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.AutoHeight = false;
            this.repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            // 
            // xtraTabPage3
            // 
            this.xtraTabPage3.Controls.Add(this.gcPhieuThu);
            this.xtraTabPage3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.xtraTabPage3.Name = "xtraTabPage3";
            this.barManager1.SetPopupContextMenu(this.xtraTabPage3, this.popupMenuPhieuThu);
            this.xtraTabPage3.Size = new System.Drawing.Size(1052, 252);
            this.xtraTabPage3.Text = "3. Phiếu thu";
            // 
            // gcPhieuThu
            // 
            this.gcPhieuThu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcPhieuThu.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gcPhieuThu.Location = new System.Drawing.Point(0, 0);
            this.gcPhieuThu.MainView = this.gvPhieuThu;
            this.gcPhieuThu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gcPhieuThu.MenuManager = this.barManager1;
            this.gcPhieuThu.Name = "gcPhieuThu";
            this.gcPhieuThu.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.lookNhanVien,
            this.repositoryItemMemoExEdit1});
            this.gcPhieuThu.Size = new System.Drawing.Size(1052, 252);
            this.gcPhieuThu.TabIndex = 1;
            this.gcPhieuThu.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvPhieuThu});
            // 
            // gvPhieuThu
            // 
            this.gvPhieuThu.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn3,
            this.gridColumn13,
            this.gridColumn15,
            this.gridColumn26,
            this.gridColumn27,
            this.gridColumn31,
            this.gridColumn33,
            this.gridColumn34,
            this.gridColumn35,
            this.gridColumn36,
            this.gridColumn37,
            this.gridColumn38,
            this.gridColumn39,
            this.gridColumn42,
            this.gridColumn46,
            this.gridColumn47,
            this.gridColumn48});
            this.gvPhieuThu.DetailHeight = 431;
            gridFormatRule16.Column = this.gridColumn27;
            gridFormatRule16.Name = "Format0";
            formatConditionRule3ColorScale9.PredefinedName = "White, Red";
            gridFormatRule16.Rule = formatConditionRule3ColorScale9;
            gridFormatRule17.Column = this.gridColumn31;
            gridFormatRule17.Name = "Format1";
            formatConditionRule3ColorScale10.PredefinedName = "White, Azure";
            gridFormatRule17.Rule = formatConditionRule3ColorScale10;
            this.gvPhieuThu.FormatRules.Add(gridFormatRule16);
            this.gvPhieuThu.FormatRules.Add(gridFormatRule17);
            this.gvPhieuThu.GridControl = this.gcPhieuThu;
            this.gvPhieuThu.GroupPanelText = "Kéo một vài cột lên đây để xem theo nhóm";
            this.gvPhieuThu.Name = "gvPhieuThu";
            this.gvPhieuThu.OptionsBehavior.Editable = false;
            this.gvPhieuThu.OptionsPrint.AutoWidth = false;
            this.gvPhieuThu.OptionsSelection.MultiSelect = true;
            this.gvPhieuThu.OptionsView.ColumnAutoWidth = false;
            this.gvPhieuThu.OptionsView.ShowAutoFilterRow = true;
            this.gvPhieuThu.OptionsView.ShowFooter = true;
            this.gvPhieuThu.OptionsView.ShowGroupPanel = false;
            this.gvPhieuThu.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumn3, DevExpress.Data.ColumnSortOrder.Descending)});
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "Ngày thu";
            this.gridColumn3.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.gridColumn3.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn3.FieldName = "NgayThu";
            this.gridColumn3.MinWidth = 23;
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 0;
            this.gridColumn3.Width = 135;
            // 
            // gridColumn13
            // 
            this.gridColumn13.Caption = "Giờ Thu";
            this.gridColumn13.FieldName = "GioThu";
            this.gridColumn13.MinWidth = 23;
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 1;
            this.gridColumn13.Width = 140;
            // 
            // gridColumn15
            // 
            this.gridColumn15.Caption = "Số phiếu";
            this.gridColumn15.FieldName = "SoPT";
            this.gridColumn15.MinWidth = 23;
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn15.Visible = true;
            this.gridColumn15.VisibleIndex = 2;
            this.gridColumn15.Width = 115;
            // 
            // gridColumn26
            // 
            this.gridColumn26.Caption = "Diễn giải";
            this.gridColumn26.FieldName = "LyDo";
            this.gridColumn26.MinWidth = 23;
            this.gridColumn26.Name = "gridColumn26";
            this.gridColumn26.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn26.Visible = true;
            this.gridColumn26.VisibleIndex = 3;
            this.gridColumn26.Width = 251;
            // 
            // gridColumn33
            // 
            this.gridColumn33.Caption = "Tiền khấu trừ";
            this.gridColumn33.DisplayFormat.FormatString = "N0";
            this.gridColumn33.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn33.FieldName = "TienKhauTru";
            this.gridColumn33.MinWidth = 23;
            this.gridColumn33.Name = "gridColumn33";
            this.gridColumn33.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "TienKhauTru", "{0:#,0.##}")});
            this.gridColumn33.Visible = true;
            this.gridColumn33.VisibleIndex = 6;
            this.gridColumn33.Width = 87;
            // 
            // gridColumn34
            // 
            this.gridColumn34.Caption = "Tiền thu thừa";
            this.gridColumn34.DisplayFormat.FormatString = "N0";
            this.gridColumn34.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn34.FieldName = "TienThuThua";
            this.gridColumn34.MinWidth = 23;
            this.gridColumn34.Name = "gridColumn34";
            this.gridColumn34.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "TienThuThua", "{0:#,0.##}")});
            this.gridColumn34.Visible = true;
            this.gridColumn34.VisibleIndex = 7;
            this.gridColumn34.Width = 110;
            // 
            // gridColumn35
            // 
            this.gridColumn35.Caption = "Phân loại";
            this.gridColumn35.FieldName = "TenPL";
            this.gridColumn35.MinWidth = 23;
            this.gridColumn35.Name = "gridColumn35";
            this.gridColumn35.Visible = true;
            this.gridColumn35.VisibleIndex = 8;
            this.gridColumn35.Width = 135;
            // 
            // gridColumn36
            // 
            this.gridColumn36.Caption = "Mã khách hàng";
            this.gridColumn36.FieldName = "KyHieu";
            this.gridColumn36.MinWidth = 23;
            this.gridColumn36.Name = "gridColumn36";
            this.gridColumn36.Visible = true;
            this.gridColumn36.VisibleIndex = 9;
            this.gridColumn36.Width = 103;
            // 
            // gridColumn37
            // 
            this.gridColumn37.Caption = "Khách hàng";
            this.gridColumn37.FieldName = "TenKH";
            this.gridColumn37.MinWidth = 23;
            this.gridColumn37.Name = "gridColumn37";
            this.gridColumn37.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn37.Visible = true;
            this.gridColumn37.VisibleIndex = 10;
            this.gridColumn37.Width = 255;
            // 
            // gridColumn38
            // 
            this.gridColumn38.Caption = "Người thu";
            this.gridColumn38.FieldName = "NguoiThu";
            this.gridColumn38.MinWidth = 23;
            this.gridColumn38.Name = "gridColumn38";
            this.gridColumn38.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn38.Visible = true;
            this.gridColumn38.VisibleIndex = 11;
            this.gridColumn38.Width = 154;
            // 
            // gridColumn39
            // 
            this.gridColumn39.Caption = "Người nộp";
            this.gridColumn39.FieldName = "NguoiNop";
            this.gridColumn39.MinWidth = 23;
            this.gridColumn39.Name = "gridColumn39";
            this.gridColumn39.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn39.Visible = true;
            this.gridColumn39.VisibleIndex = 12;
            this.gridColumn39.Width = 140;
            // 
            // gridColumn42
            // 
            this.gridColumn42.Caption = "Hình thức TT";
            this.gridColumn42.FieldName = "PhuongThuc";
            this.gridColumn42.MinWidth = 23;
            this.gridColumn42.Name = "gridColumn42";
            this.gridColumn42.Visible = true;
            this.gridColumn42.VisibleIndex = 13;
            this.gridColumn42.Width = 105;
            // 
            // gridColumn46
            // 
            this.gridColumn46.Caption = "Nguồn thanh toán";
            this.gridColumn46.FieldName = "NguonThu";
            this.gridColumn46.MinWidth = 23;
            this.gridColumn46.Name = "gridColumn46";
            this.gridColumn46.Visible = true;
            this.gridColumn46.VisibleIndex = 14;
            this.gridColumn46.Width = 168;
            // 
            // gridColumn47
            // 
            this.gridColumn47.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic);
            this.gridColumn47.AppearanceCell.Options.UseFont = true;
            this.gridColumn47.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic);
            this.gridColumn47.AppearanceHeader.Options.UseFont = true;
            this.gridColumn47.Caption = "Người nhập";
            this.gridColumn47.FieldName = "NguoiNhap";
            this.gridColumn47.MinWidth = 23;
            this.gridColumn47.Name = "gridColumn47";
            this.gridColumn47.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn47.Visible = true;
            this.gridColumn47.VisibleIndex = 15;
            this.gridColumn47.Width = 138;
            // 
            // gridColumn48
            // 
            this.gridColumn48.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic);
            this.gridColumn48.AppearanceCell.Options.UseFont = true;
            this.gridColumn48.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic);
            this.gridColumn48.AppearanceHeader.Options.UseFont = true;
            this.gridColumn48.Caption = "Ngày nhập";
            this.gridColumn48.FieldName = "NgayNhap";
            this.gridColumn48.MinWidth = 23;
            this.gridColumn48.Name = "gridColumn48";
            this.gridColumn48.Visible = true;
            this.gridColumn48.VisibleIndex = 16;
            this.gridColumn48.Width = 87;
            // 
            // lookNhanVien
            // 
            this.lookNhanVien.AutoHeight = false;
            this.lookNhanVien.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookNhanVien.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("HoTenNV", "#")});
            this.lookNhanVien.DisplayMember = "HoTenNV";
            this.lookNhanVien.Name = "lookNhanVien";
            this.lookNhanVien.NullText = "";
            this.lookNhanVien.ShowHeader = false;
            this.lookNhanVien.ValueMember = "MaNV";
            // 
            // repositoryItemMemoExEdit1
            // 
            this.repositoryItemMemoExEdit1.AutoHeight = false;
            this.repositoryItemMemoExEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit1.Name = "repositoryItemMemoExEdit1";
            this.repositoryItemMemoExEdit1.PopupFormSize = new System.Drawing.Size(350, 0);
            this.repositoryItemMemoExEdit1.ReadOnly = true;
            this.repositoryItemMemoExEdit1.ShowDropDown = DevExpress.XtraEditors.Controls.ShowDropDown.DoubleClick;
            this.repositoryItemMemoExEdit1.ShowIcon = false;
            // 
            // popupMenuPhieuThu
            // 
            this.popupMenuPhieuThu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.itemSuaPhieuThu)});
            this.popupMenuPhieuThu.Manager = this.barManager1;
            this.popupMenuPhieuThu.Name = "popupMenuPhieuThu";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.splitContainerControl1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 83);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1059, 584);
            this.panel1.TabIndex = 4;
            // 
            // splitContainerControl1
            // 
            this.splitContainerControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl1.FixedPanel = DevExpress.XtraEditors.SplitFixedPanel.Panel2;
            this.splitContainerControl1.Horizontal = false;
            this.splitContainerControl1.Location = new System.Drawing.Point(0, 0);
            this.splitContainerControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.splitContainerControl1.Name = "splitContainerControl1";
            this.splitContainerControl1.Panel1.Controls.Add(this.gcHoaDon);
            this.splitContainerControl1.Panel1.Text = "Panel1";
            this.splitContainerControl1.Panel2.Controls.Add(this.xtraTabControl1);
            this.splitContainerControl1.Panel2.Text = "Panel2";
            this.splitContainerControl1.Size = new System.Drawing.Size(1059, 584);
            this.splitContainerControl1.SplitterPosition = 287;
            this.splitContainerControl1.TabIndex = 0;
            this.splitContainerControl1.Text = "splitContainerControl1";
            // 
            // gcHoaDon
            // 
            this.gcHoaDon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcHoaDon.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gcHoaDon.Location = new System.Drawing.Point(0, 0);
            this.gcHoaDon.MainView = this.gvHoaDon;
            this.gcHoaDon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gcHoaDon.Name = "gcHoaDon";
            this.gcHoaDon.Size = new System.Drawing.Size(1059, 291);
            this.gcHoaDon.TabIndex = 4;
            this.gcHoaDon.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvHoaDon});
            // 
            // gvHoaDon
            // 
            this.gvHoaDon.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn25,
            this.gridColumn20,
            this.gridColumn16,
            this.gridColumn1,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn6,
            this.colNoDauKy,
            this.colPhatSinh,
            this.colDaThu,
            this.colKhauTru,
            this.colConNo,
            this.colThuTruoc,
            this.gridColumn30,
            this.colCongNoCuoi,
            this.gridColumn32});
            this.gvHoaDon.DetailHeight = 431;
            gridFormatRule1.Column = this.colNoDauKy;
            gridFormatRule1.Name = "FormatNoDauKy";
            formatConditionIconSet1.CategoryName = "Positive/Negative";
            formatConditionIconSetIcon1.PredefinedName = "Triangles3_3.png";
            formatConditionIconSetIcon1.Value = new decimal(new int[] {
            -1,
            -1,
            -1,
            -2147483648});
            formatConditionIconSetIcon1.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSetIcon2.PredefinedName = "Triangles3_2.png";
            formatConditionIconSetIcon2.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSetIcon3.PredefinedName = "Triangles3_1.png";
            formatConditionIconSet1.Icons.Add(formatConditionIconSetIcon1);
            formatConditionIconSet1.Icons.Add(formatConditionIconSetIcon2);
            formatConditionIconSet1.Icons.Add(formatConditionIconSetIcon3);
            formatConditionIconSet1.Name = "PositiveNegativeTriangles";
            formatConditionIconSet1.ValueType = DevExpress.XtraEditors.FormatConditionValueType.Number;
            formatConditionRuleIconSet1.IconSet = formatConditionIconSet1;
            gridFormatRule1.Rule = formatConditionRuleIconSet1;
            gridFormatRule2.Column = this.colPhatSinh;
            gridFormatRule2.Name = "FormatPhatSinh";
            formatConditionIconSet2.CategoryName = "Positive/Negative";
            formatConditionIconSetIcon4.PredefinedName = "Triangles3_3.png";
            formatConditionIconSetIcon4.Value = new decimal(new int[] {
            -1,
            -1,
            -1,
            -2147483648});
            formatConditionIconSetIcon4.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSetIcon5.PredefinedName = "Triangles3_2.png";
            formatConditionIconSetIcon5.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSetIcon6.PredefinedName = "Triangles3_1.png";
            formatConditionIconSet2.Icons.Add(formatConditionIconSetIcon4);
            formatConditionIconSet2.Icons.Add(formatConditionIconSetIcon5);
            formatConditionIconSet2.Icons.Add(formatConditionIconSetIcon6);
            formatConditionIconSet2.Name = "PositiveNegativeTriangles";
            formatConditionIconSet2.ValueType = DevExpress.XtraEditors.FormatConditionValueType.Number;
            formatConditionRuleIconSet2.IconSet = formatConditionIconSet2;
            gridFormatRule2.Rule = formatConditionRuleIconSet2;
            gridFormatRule3.Column = this.colDaThu;
            gridFormatRule3.Name = "FormatDaThu";
            formatConditionIconSet3.CategoryName = "Positive/Negative";
            formatConditionIconSetIcon7.PredefinedName = "Triangles3_3.png";
            formatConditionIconSetIcon7.Value = new decimal(new int[] {
            -1,
            -1,
            -1,
            -2147483648});
            formatConditionIconSetIcon7.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSetIcon8.PredefinedName = "Triangles3_2.png";
            formatConditionIconSetIcon8.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSetIcon9.PredefinedName = "Triangles3_1.png";
            formatConditionIconSet3.Icons.Add(formatConditionIconSetIcon7);
            formatConditionIconSet3.Icons.Add(formatConditionIconSetIcon8);
            formatConditionIconSet3.Icons.Add(formatConditionIconSetIcon9);
            formatConditionIconSet3.Name = "PositiveNegativeTriangles";
            formatConditionIconSet3.ValueType = DevExpress.XtraEditors.FormatConditionValueType.Number;
            formatConditionRuleIconSet3.IconSet = formatConditionIconSet3;
            gridFormatRule3.Rule = formatConditionRuleIconSet3;
            gridFormatRule4.Column = this.colConNo;
            gridFormatRule4.Name = "FormatConNo";
            formatConditionIconSet4.CategoryName = "Positive/Negative";
            formatConditionIconSetIcon10.PredefinedName = "Triangles3_3.png";
            formatConditionIconSetIcon10.Value = new decimal(new int[] {
            -1,
            -1,
            -1,
            -2147483648});
            formatConditionIconSetIcon10.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSetIcon11.PredefinedName = "Triangles3_2.png";
            formatConditionIconSetIcon11.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSetIcon12.PredefinedName = "Triangles3_1.png";
            formatConditionIconSet4.Icons.Add(formatConditionIconSetIcon10);
            formatConditionIconSet4.Icons.Add(formatConditionIconSetIcon11);
            formatConditionIconSet4.Icons.Add(formatConditionIconSetIcon12);
            formatConditionIconSet4.Name = "PositiveNegativeTriangles";
            formatConditionIconSet4.ValueType = DevExpress.XtraEditors.FormatConditionValueType.Number;
            formatConditionRuleIconSet4.IconSet = formatConditionIconSet4;
            gridFormatRule4.Rule = formatConditionRuleIconSet4;
            gridFormatRule5.Column = this.colKhauTru;
            gridFormatRule5.Name = "FormatKhauTru";
            formatConditionIconSet5.CategoryName = "Positive/Negative";
            formatConditionIconSetIcon13.PredefinedName = "Triangles3_3.png";
            formatConditionIconSetIcon13.Value = new decimal(new int[] {
            -1,
            -1,
            -1,
            -2147483648});
            formatConditionIconSetIcon13.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSetIcon14.PredefinedName = "Triangles3_2.png";
            formatConditionIconSetIcon14.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSetIcon15.PredefinedName = "Triangles3_1.png";
            formatConditionIconSet5.Icons.Add(formatConditionIconSetIcon13);
            formatConditionIconSet5.Icons.Add(formatConditionIconSetIcon14);
            formatConditionIconSet5.Icons.Add(formatConditionIconSetIcon15);
            formatConditionIconSet5.Name = "PositiveNegativeTriangles";
            formatConditionIconSet5.ValueType = DevExpress.XtraEditors.FormatConditionValueType.Number;
            formatConditionRuleIconSet5.IconSet = formatConditionIconSet5;
            gridFormatRule5.Rule = formatConditionRuleIconSet5;
            gridFormatRule6.Column = this.colThuTruoc;
            gridFormatRule6.Name = "FormatThuTruoc";
            formatConditionIconSet6.CategoryName = "Ratings";
            formatConditionIconSetIcon16.PredefinedName = "Quarters5_1.png";
            formatConditionIconSetIcon16.Value = new decimal(new int[] {
            80,
            0,
            0,
            0});
            formatConditionIconSetIcon16.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSetIcon17.PredefinedName = "Quarters5_2.png";
            formatConditionIconSetIcon17.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            formatConditionIconSetIcon17.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSetIcon18.PredefinedName = "Quarters5_3.png";
            formatConditionIconSetIcon18.Value = new decimal(new int[] {
            40,
            0,
            0,
            0});
            formatConditionIconSetIcon18.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSetIcon19.PredefinedName = "Quarters5_4.png";
            formatConditionIconSetIcon19.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            formatConditionIconSetIcon19.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSetIcon20.PredefinedName = "Quarters5_5.png";
            formatConditionIconSetIcon20.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSet6.Icons.Add(formatConditionIconSetIcon16);
            formatConditionIconSet6.Icons.Add(formatConditionIconSetIcon17);
            formatConditionIconSet6.Icons.Add(formatConditionIconSetIcon18);
            formatConditionIconSet6.Icons.Add(formatConditionIconSetIcon19);
            formatConditionIconSet6.Icons.Add(formatConditionIconSetIcon20);
            formatConditionIconSet6.Name = "Quarters5";
            formatConditionIconSet6.ValueType = DevExpress.XtraEditors.FormatConditionValueType.Number;
            formatConditionRuleIconSet6.IconSet = formatConditionIconSet6;
            gridFormatRule6.Rule = formatConditionRuleIconSet6;
            gridFormatRule7.Column = this.colCongNoCuoi;
            gridFormatRule7.Name = "FormatCongNoCuoi";
            formatConditionIconSet7.CategoryName = "Positive/Negative";
            formatConditionIconSetIcon21.PredefinedName = "Triangles3_3.png";
            formatConditionIconSetIcon21.Value = new decimal(new int[] {
            -1,
            -1,
            -1,
            -2147483648});
            formatConditionIconSetIcon21.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSetIcon22.PredefinedName = "Triangles3_2.png";
            formatConditionIconSetIcon22.ValueComparison = DevExpress.XtraEditors.FormatConditionComparisonType.GreaterOrEqual;
            formatConditionIconSetIcon23.PredefinedName = "Triangles3_1.png";
            formatConditionIconSet7.Icons.Add(formatConditionIconSetIcon21);
            formatConditionIconSet7.Icons.Add(formatConditionIconSetIcon22);
            formatConditionIconSet7.Icons.Add(formatConditionIconSetIcon23);
            formatConditionIconSet7.Name = "PositiveNegativeTriangles";
            formatConditionIconSet7.ValueType = DevExpress.XtraEditors.FormatConditionValueType.Number;
            formatConditionRuleIconSet7.IconSet = formatConditionIconSet7;
            gridFormatRule7.Rule = formatConditionRuleIconSet7;
            gridFormatRule8.Column = this.colNoDauKy;
            gridFormatRule8.Name = "Format0";
            formatConditionRule3ColorScale1.PredefinedName = "White, Red";
            gridFormatRule8.Rule = formatConditionRule3ColorScale1;
            gridFormatRule9.Column = this.colPhatSinh;
            gridFormatRule9.Name = "Format1";
            formatConditionRule3ColorScale2.PredefinedName = "White, Red";
            gridFormatRule9.Rule = formatConditionRule3ColorScale2;
            gridFormatRule10.Column = this.colDaThu;
            gridFormatRule10.Name = "Format2";
            formatConditionRule3ColorScale3.PredefinedName = "White, Azure";
            gridFormatRule10.Rule = formatConditionRule3ColorScale3;
            gridFormatRule11.Column = this.colKhauTru;
            gridFormatRule11.Name = "Format3";
            formatConditionRule3ColorScale4.PredefinedName = "White, Azure";
            gridFormatRule11.Rule = formatConditionRule3ColorScale4;
            gridFormatRule12.Column = this.colThuTruoc;
            gridFormatRule12.Name = "Format4";
            formatConditionRule3ColorScale5.PredefinedName = "White, Azure";
            gridFormatRule12.Rule = formatConditionRule3ColorScale5;
            gridFormatRule13.Column = this.colConNo;
            gridFormatRule13.Name = "Format5";
            formatConditionRule3ColorScale6.PredefinedName = "White, Red";
            gridFormatRule13.Rule = formatConditionRule3ColorScale6;
            gridFormatRule14.Column = this.colCongNoCuoi;
            gridFormatRule14.Name = "Format6";
            formatConditionRule3ColorScale7.PredefinedName = "White, Red";
            gridFormatRule14.Rule = formatConditionRule3ColorScale7;
            this.gvHoaDon.FormatRules.Add(gridFormatRule1);
            this.gvHoaDon.FormatRules.Add(gridFormatRule2);
            this.gvHoaDon.FormatRules.Add(gridFormatRule3);
            this.gvHoaDon.FormatRules.Add(gridFormatRule4);
            this.gvHoaDon.FormatRules.Add(gridFormatRule5);
            this.gvHoaDon.FormatRules.Add(gridFormatRule6);
            this.gvHoaDon.FormatRules.Add(gridFormatRule7);
            this.gvHoaDon.FormatRules.Add(gridFormatRule8);
            this.gvHoaDon.FormatRules.Add(gridFormatRule9);
            this.gvHoaDon.FormatRules.Add(gridFormatRule10);
            this.gvHoaDon.FormatRules.Add(gridFormatRule11);
            this.gvHoaDon.FormatRules.Add(gridFormatRule12);
            this.gvHoaDon.FormatRules.Add(gridFormatRule13);
            this.gvHoaDon.FormatRules.Add(gridFormatRule14);
            this.gvHoaDon.GridControl = this.gcHoaDon;
            this.gvHoaDon.GroupPanelText = "Kéo cột lên đây để xem theo nhóm";
            this.gvHoaDon.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "DienTich", null, "{0:#,0.##} m2"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ThanhTien", null, "{0:#,0.##}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "DonGia", null, "{0:#,0.##}")});
            this.gvHoaDon.Name = "gvHoaDon";
            this.gvHoaDon.OptionsBehavior.ImmediateUpdateRowPosition = false;
            this.gvHoaDon.OptionsBehavior.KeepFocusedRowOnUpdate = false;
            this.gvHoaDon.OptionsFilter.DefaultFilterEditorView = DevExpress.XtraEditors.FilterEditorViewMode.Text;
            this.gvHoaDon.OptionsMenu.ShowConditionalFormattingItem = true;
            this.gvHoaDon.OptionsSelection.MultiSelect = true;
            this.gvHoaDon.OptionsView.ColumnAutoWidth = false;
            this.gvHoaDon.OptionsView.ShowAutoFilterRow = true;
            this.gvHoaDon.OptionsView.ShowFooter = true;
            this.gvHoaDon.OptionsView.ShowGroupPanel = false;
            this.gvHoaDon.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumn20, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.gvHoaDon.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gvHoaDon_FocusedRowChanged);
            this.gvHoaDon.FocusedRowLoaded += new DevExpress.XtraGrid.Views.Base.RowEventHandler(this.gvHoaDon_FocusedRowLoaded);
            // 
            // gridColumn25
            // 
            this.gridColumn25.Caption = "STT";
            this.gridColumn25.MinWidth = 23;
            this.gridColumn25.Name = "gridColumn25";
            this.gridColumn25.OptionsColumn.AllowEdit = false;
            this.gridColumn25.Visible = true;
            this.gridColumn25.VisibleIndex = 0;
            this.gridColumn25.Width = 51;
            // 
            // gridColumn20
            // 
            this.gridColumn20.Caption = "Mã KH";
            this.gridColumn20.FieldName = "KyHieu";
            this.gridColumn20.FilterMode = DevExpress.XtraGrid.ColumnFilterMode.DisplayText;
            this.gridColumn20.MinWidth = 23;
            this.gridColumn20.Name = "gridColumn20";
            this.gridColumn20.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn20.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Count, "KyHieu", "{0} dòng")});
            this.gridColumn20.Visible = true;
            this.gridColumn20.VisibleIndex = 1;
            this.gridColumn20.Width = 94;
            // 
            // gridColumn16
            // 
            this.gridColumn16.Caption = "Mã phụ";
            this.gridColumn16.FieldName = "MaPhu";
            this.gridColumn16.MinWidth = 23;
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn16.Visible = true;
            this.gridColumn16.VisibleIndex = 2;
            this.gridColumn16.Width = 90;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "Tên khách hàng";
            this.gridColumn1.FieldName = "TenKH";
            this.gridColumn1.MinWidth = 23;
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 3;
            this.gridColumn1.Width = 225;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "Địa chỉ";
            this.gridColumn4.FieldName = "DiaChi";
            this.gridColumn4.MinWidth = 23;
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 6;
            this.gridColumn4.Width = 101;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "Điện thoại";
            this.gridColumn5.FieldName = "DienThoai";
            this.gridColumn5.MinWidth = 23;
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 4;
            this.gridColumn5.Width = 105;
            // 
            // gridColumn6
            // 
            this.gridColumn6.Caption = "Email";
            this.gridColumn6.FieldName = "EmailKH";
            this.gridColumn6.MinWidth = 23;
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 5;
            this.gridColumn6.Width = 83;
            // 
            // gridColumn30
            // 
            this.gridColumn30.Caption = "Mặt bằng";
            this.gridColumn30.FieldName = "MaSoMB";
            this.gridColumn30.MinWidth = 23;
            this.gridColumn30.Name = "gridColumn30";
            this.gridColumn30.Width = 125;
            // 
            // gridColumn32
            // 
            this.gridColumn32.Caption = "Mặt bằng";
            this.gridColumn32.FieldName = "MaMB";
            this.gridColumn32.MinWidth = 23;
            this.gridColumn32.Name = "gridColumn32";
            this.gridColumn32.Width = 99;
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl1.Location = new System.Drawing.Point(0, 0);
            this.xtraTabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPage1;
            this.xtraTabControl1.Size = new System.Drawing.Size(1059, 287);
            this.xtraTabControl1.TabIndex = 0;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1,
            this.xtraTabPage2,
            this.xtraTabPage3,
            this.xtraTabPage4,
            this.xtraTabPage5});
            this.xtraTabControl1.SelectedPageChanged += new DevExpress.XtraTab.TabPageChangedEventHandler(this.xtraTabControl1_SelectedPageChanged);
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.Controls.Add(this.gcChiTiet);
            this.xtraTabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(1052, 252);
            this.xtraTabPage1.Text = "1. Thông tin chi tiết hóa đơn";
            // 
            // gcChiTiet
            // 
            this.gcChiTiet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcChiTiet.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gcChiTiet.Location = new System.Drawing.Point(0, 0);
            this.gcChiTiet.MainView = this.gvChiTiet;
            this.gcChiTiet.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gcChiTiet.Name = "gcChiTiet";
            this.gcChiTiet.Size = new System.Drawing.Size(1052, 252);
            this.gcChiTiet.TabIndex = 5;
            this.gcChiTiet.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvChiTiet});
            // 
            // gvChiTiet
            // 
            this.gvChiTiet.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn28,
            this.gridColumn7,
            this.gridColumn8,
            this.gridColumn9,
            this.gridColumn14,
            this.gridColumn17,
            this.gridColumn10,
            this.gridColumn11,
            this.gridColumn12,
            this.gridColumn21,
            this.gridColumn22,
            this.gridColumn23,
            this.gridColumn18,
            this.gridColumn19,
            this.gridColumn29,
            this.gridColumn24,
            this.gridColumn58,
            this.gridColumn62,
            this.gridColumn61});
            this.gvChiTiet.DetailHeight = 431;
            gridFormatRule15.Column = this.gridColumn19;
            gridFormatRule15.Name = "Format0";
            formatConditionRule3ColorScale8.PredefinedName = "White, Red";
            gridFormatRule15.Rule = formatConditionRule3ColorScale8;
            this.gvChiTiet.FormatRules.Add(gridFormatRule15);
            this.gvChiTiet.GridControl = this.gcChiTiet;
            this.gvChiTiet.GroupPanelText = "Kéo cột lên đây để xem theo nhóm";
            this.gvChiTiet.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "DienTich", null, "{0:#,0.##} m2"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ThanhTien", null, "{0:#,0.##}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "DonGia", null, "{0:#,0.##}")});
            this.gvChiTiet.Name = "gvChiTiet";
            this.gvChiTiet.OptionsBehavior.Editable = false;
            this.gvChiTiet.OptionsSelection.MultiSelect = true;
            this.gvChiTiet.OptionsView.ColumnAutoWidth = false;
            this.gvChiTiet.OptionsView.ShowAutoFilterRow = true;
            this.gvChiTiet.OptionsView.ShowFooter = true;
            this.gvChiTiet.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn28
            // 
            this.gridColumn28.Caption = "Đã duyệt";
            this.gridColumn28.FieldName = "IsDuyet";
            this.gridColumn28.MinWidth = 23;
            this.gridColumn28.Name = "gridColumn28";
            this.gridColumn28.OptionsColumn.AllowEdit = false;
            this.gridColumn28.Visible = true;
            this.gridColumn28.VisibleIndex = 0;
            this.gridColumn28.Width = 68;
            // 
            // gridColumn7
            // 
            this.gridColumn7.Caption = "Ngày TT";
            this.gridColumn7.FieldName = "NgayTT";
            this.gridColumn7.MinWidth = 23;
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Count, "NgayTT", "{0}")});
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 1;
            this.gridColumn7.Width = 87;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "Hạng mục";
            this.gridColumn8.FieldName = "TenLDV";
            this.gridColumn8.MinWidth = 23;
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 8;
            this.gridColumn8.Width = 188;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "Diễn giải";
            this.gridColumn9.FieldName = "DienGiai";
            this.gridColumn9.MinWidth = 23;
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 4;
            this.gridColumn9.Width = 287;
            // 
            // gridColumn14
            // 
            this.gridColumn14.Caption = "Tiền trước thuế";
            this.gridColumn14.DisplayFormat.FormatString = "n0";
            this.gridColumn14.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn14.FieldName = "TienTruocThue";
            this.gridColumn14.MinWidth = 23;
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 9;
            this.gridColumn14.Width = 103;
            // 
            // gridColumn17
            // 
            this.gridColumn17.Caption = "Kỳ TT";
            this.gridColumn17.DisplayFormat.FormatString = "{0} tháng";
            this.gridColumn17.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn17.FieldName = "KyTT";
            this.gridColumn17.MinWidth = 23;
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 10;
            // 
            // gridColumn11
            // 
            this.gridColumn11.Caption = "Tỷ lệ CK";
            this.gridColumn11.DisplayFormat.FormatString = "p2";
            this.gridColumn11.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn11.FieldName = "TyLeCK";
            this.gridColumn11.MinWidth = 23;
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 12;
            this.gridColumn11.Width = 71;
            // 
            // gridColumn12
            // 
            this.gridColumn12.Caption = "Tiền CK";
            this.gridColumn12.DisplayFormat.FormatString = "n0";
            this.gridColumn12.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn12.FieldName = "TienCK";
            this.gridColumn12.MinWidth = 23;
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 13;
            this.gridColumn12.Width = 96;
            // 
            // gridColumn21
            // 
            this.gridColumn21.Caption = "Phải thu";
            this.gridColumn21.DisplayFormat.FormatString = "n0";
            this.gridColumn21.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn21.FieldName = "PhaiThu";
            this.gridColumn21.MinWidth = 23;
            this.gridColumn21.Name = "gridColumn21";
            this.gridColumn21.Visible = true;
            this.gridColumn21.VisibleIndex = 5;
            this.gridColumn21.Width = 110;
            // 
            // gridColumn22
            // 
            this.gridColumn22.Caption = "Đã thu";
            this.gridColumn22.DisplayFormat.FormatString = "n0";
            this.gridColumn22.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn22.FieldName = "DaThu";
            this.gridColumn22.MinWidth = 23;
            this.gridColumn22.Name = "gridColumn22";
            this.gridColumn22.Visible = true;
            this.gridColumn22.VisibleIndex = 6;
            this.gridColumn22.Width = 87;
            // 
            // gridColumn18
            // 
            this.gridColumn18.Caption = "Mặt bằng";
            this.gridColumn18.FieldName = "MaSoMB";
            this.gridColumn18.MinWidth = 23;
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 2;
            this.gridColumn18.Width = 87;
            // 
            // gridColumn29
            // 
            this.gridColumn29.Caption = "Loại mặt bằng";
            this.gridColumn29.FieldName = "TenLMB";
            this.gridColumn29.MinWidth = 23;
            this.gridColumn29.Name = "gridColumn29";
            this.gridColumn29.Visible = true;
            this.gridColumn29.VisibleIndex = 3;
            this.gridColumn29.Width = 129;
            // 
            // gridColumn24
            // 
            this.gridColumn24.Caption = "Khối nhà/block";
            this.gridColumn24.FieldName = "TenKN";
            this.gridColumn24.MinWidth = 23;
            this.gridColumn24.Name = "gridColumn24";
            this.gridColumn24.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn24.Visible = true;
            this.gridColumn24.VisibleIndex = 15;
            this.gridColumn24.Width = 87;
            // 
            // gridColumn58
            // 
            this.gridColumn58.Caption = "Loại xe";
            this.gridColumn58.FieldName = "TenLX";
            this.gridColumn58.MinWidth = 23;
            this.gridColumn58.Name = "gridColumn58";
            this.gridColumn58.Visible = true;
            this.gridColumn58.VisibleIndex = 16;
            this.gridColumn58.Width = 87;
            // 
            // xtraTabPage2
            // 
            this.xtraTabPage2.Controls.Add(this.ctlMailHistory1);
            this.xtraTabPage2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.xtraTabPage2.Name = "xtraTabPage2";
            this.xtraTabPage2.Size = new System.Drawing.Size(1052, 252);
            this.xtraTabPage2.Text = "2. Email";
            // 
            // ctlMailHistory1
            // 
            this.ctlMailHistory1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctlMailHistory1.Location = new System.Drawing.Point(0, 0);
            this.ctlMailHistory1.MaKH = null;
            this.ctlMailHistory1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.ctlMailHistory1.Name = "ctlMailHistory1";
            this.ctlMailHistory1.Size = new System.Drawing.Size(1052, 252);
            this.ctlMailHistory1.TabIndex = 0;
            // 
            // xtraTabPage4
            // 
            this.xtraTabPage4.Controls.Add(this.gridControl1);
            this.xtraTabPage4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.xtraTabPage4.Name = "xtraTabPage4";
            this.xtraTabPage4.Size = new System.Drawing.Size(1052, 252);
            this.xtraTabPage4.Text = "4. Khấu trừ";
            // 
            // gridControl1
            // 
            this.gridControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControl1.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gridControl1.Location = new System.Drawing.Point(0, 0);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gridControl1.MenuManager = this.barManager1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemLookUpEdit2,
            this.repositoryItemMemoExEdit2});
            this.gridControl1.Size = new System.Drawing.Size(1052, 252);
            this.gridControl1.TabIndex = 1;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn40,
            this.gridColumn41,
            this.gridColumn43,
            this.gridColumn44,
            this.gridColumn45,
            this.gridColumn49,
            this.gridColumn50,
            this.gridColumn51,
            this.gridColumn54,
            this.gridColumn55,
            this.gridColumn59,
            this.gridColumn60,
            this.gridColumn66,
            this.gridColumn67});
            this.gridView1.DetailHeight = 431;
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.GroupPanelText = "Kéo một vài cột lên đây để xem theo nhóm";
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsPrint.AutoWidth = false;
            this.gridView1.OptionsSelection.MultiSelect = true;
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.ShowAutoFilterRow = true;
            this.gridView1.OptionsView.ShowFooter = true;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            this.gridView1.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumn40, DevExpress.Data.ColumnSortOrder.Descending)});
            // 
            // gridColumn40
            // 
            this.gridColumn40.Caption = "Ngày thu";
            this.gridColumn40.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.gridColumn40.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn40.FieldName = "NgayThu";
            this.gridColumn40.MinWidth = 23;
            this.gridColumn40.Name = "gridColumn40";
            this.gridColumn40.OptionsColumn.AllowEdit = false;
            this.gridColumn40.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn40.Visible = true;
            this.gridColumn40.VisibleIndex = 0;
            this.gridColumn40.Width = 135;
            // 
            // gridColumn41
            // 
            this.gridColumn41.Caption = "Số phiếu";
            this.gridColumn41.FieldName = "SoPT";
            this.gridColumn41.MinWidth = 23;
            this.gridColumn41.Name = "gridColumn41";
            this.gridColumn41.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn41.Visible = true;
            this.gridColumn41.VisibleIndex = 2;
            this.gridColumn41.Width = 115;
            // 
            // gridColumn43
            // 
            this.gridColumn43.Caption = "Diễn giải";
            this.gridColumn43.FieldName = "LyDo";
            this.gridColumn43.MinWidth = 23;
            this.gridColumn43.Name = "gridColumn43";
            this.gridColumn43.OptionsColumn.AllowEdit = false;
            this.gridColumn43.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn43.Visible = true;
            this.gridColumn43.VisibleIndex = 3;
            this.gridColumn43.Width = 251;
            // 
            // gridColumn44
            // 
            this.gridColumn44.Caption = "Phải thu";
            this.gridColumn44.DisplayFormat.FormatString = "{0:#,0.##}";
            this.gridColumn44.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn44.FieldName = "TienPhaiThu";
            this.gridColumn44.MinWidth = 23;
            this.gridColumn44.Name = "gridColumn44";
            this.gridColumn44.OptionsColumn.AllowEdit = false;
            this.gridColumn44.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "TienPhaiThu", "{0:#,0.##}")});
            this.gridColumn44.Visible = true;
            this.gridColumn44.VisibleIndex = 4;
            this.gridColumn44.Width = 136;
            // 
            // gridColumn45
            // 
            this.gridColumn45.Caption = "Mã khách hàng";
            this.gridColumn45.FieldName = "KyHieu";
            this.gridColumn45.MinWidth = 23;
            this.gridColumn45.Name = "gridColumn45";
            this.gridColumn45.OptionsColumn.AllowEdit = false;
            this.gridColumn45.Visible = true;
            this.gridColumn45.VisibleIndex = 7;
            this.gridColumn45.Width = 103;
            // 
            // gridColumn49
            // 
            this.gridColumn49.Caption = "Khách hàng";
            this.gridColumn49.FieldName = "TenKH";
            this.gridColumn49.MinWidth = 23;
            this.gridColumn49.Name = "gridColumn49";
            this.gridColumn49.OptionsColumn.AllowEdit = false;
            this.gridColumn49.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn49.Visible = true;
            this.gridColumn49.VisibleIndex = 8;
            this.gridColumn49.Width = 255;
            // 
            // gridColumn50
            // 
            this.gridColumn50.Caption = "Người thu";
            this.gridColumn50.FieldName = "NguoiThu";
            this.gridColumn50.MinWidth = 23;
            this.gridColumn50.Name = "gridColumn50";
            this.gridColumn50.OptionsColumn.AllowEdit = false;
            this.gridColumn50.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn50.Visible = true;
            this.gridColumn50.VisibleIndex = 9;
            this.gridColumn50.Width = 154;
            // 
            // gridColumn51
            // 
            this.gridColumn51.Caption = "Người nộp";
            this.gridColumn51.FieldName = "NguoiNop";
            this.gridColumn51.MinWidth = 23;
            this.gridColumn51.Name = "gridColumn51";
            this.gridColumn51.OptionsColumn.AllowEdit = false;
            this.gridColumn51.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn51.Visible = true;
            this.gridColumn51.VisibleIndex = 10;
            this.gridColumn51.Width = 140;
            // 
            // gridColumn54
            // 
            this.gridColumn54.Caption = "Phân loại";
            this.gridColumn54.FieldName = "TenPL";
            this.gridColumn54.MinWidth = 23;
            this.gridColumn54.Name = "gridColumn54";
            this.gridColumn54.OptionsColumn.AllowEdit = false;
            this.gridColumn54.Visible = true;
            this.gridColumn54.VisibleIndex = 6;
            this.gridColumn54.Width = 135;
            // 
            // gridColumn55
            // 
            this.gridColumn55.Caption = "Hình thức TT";
            this.gridColumn55.FieldName = "PhuongThuc";
            this.gridColumn55.MinWidth = 23;
            this.gridColumn55.Name = "gridColumn55";
            this.gridColumn55.OptionsColumn.AllowEdit = false;
            this.gridColumn55.Visible = true;
            this.gridColumn55.VisibleIndex = 11;
            this.gridColumn55.Width = 105;
            // 
            // gridColumn59
            // 
            this.gridColumn59.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic);
            this.gridColumn59.AppearanceCell.Options.UseFont = true;
            this.gridColumn59.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic);
            this.gridColumn59.AppearanceHeader.Options.UseFont = true;
            this.gridColumn59.Caption = "Người nhập";
            this.gridColumn59.FieldName = "NguoiNhap";
            this.gridColumn59.MinWidth = 23;
            this.gridColumn59.Name = "gridColumn59";
            this.gridColumn59.OptionsColumn.AllowEdit = false;
            this.gridColumn59.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn59.Visible = true;
            this.gridColumn59.VisibleIndex = 12;
            this.gridColumn59.Width = 138;
            // 
            // gridColumn60
            // 
            this.gridColumn60.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic);
            this.gridColumn60.AppearanceCell.Options.UseFont = true;
            this.gridColumn60.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic);
            this.gridColumn60.AppearanceHeader.Options.UseFont = true;
            this.gridColumn60.Caption = "Ngày nhập";
            this.gridColumn60.FieldName = "NgayNhap";
            this.gridColumn60.MinWidth = 23;
            this.gridColumn60.Name = "gridColumn60";
            this.gridColumn60.OptionsColumn.AllowEdit = false;
            this.gridColumn60.Visible = true;
            this.gridColumn60.VisibleIndex = 13;
            this.gridColumn60.Width = 87;
            // 
            // gridColumn66
            // 
            this.gridColumn66.Caption = "Giờ Thu";
            this.gridColumn66.FieldName = "GioThu";
            this.gridColumn66.MinWidth = 23;
            this.gridColumn66.Name = "gridColumn66";
            this.gridColumn66.OptionsColumn.AllowEdit = false;
            this.gridColumn66.Visible = true;
            this.gridColumn66.VisibleIndex = 1;
            this.gridColumn66.Width = 140;
            // 
            // gridColumn67
            // 
            this.gridColumn67.Caption = "Tiền khấu trừ";
            this.gridColumn67.DisplayFormat.FormatString = "N0";
            this.gridColumn67.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn67.FieldName = "TienKhauTru";
            this.gridColumn67.MinWidth = 23;
            this.gridColumn67.Name = "gridColumn67";
            this.gridColumn67.OptionsColumn.AllowEdit = false;
            this.gridColumn67.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "TienKhauTru", "{0:#,0.##}")});
            this.gridColumn67.Visible = true;
            this.gridColumn67.VisibleIndex = 5;
            this.gridColumn67.Width = 87;
            // 
            // repositoryItemLookUpEdit2
            // 
            this.repositoryItemLookUpEdit2.AutoHeight = false;
            this.repositoryItemLookUpEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit2.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("HoTenNV", "#")});
            this.repositoryItemLookUpEdit2.DisplayMember = "HoTenNV";
            this.repositoryItemLookUpEdit2.Name = "repositoryItemLookUpEdit2";
            this.repositoryItemLookUpEdit2.NullText = "";
            this.repositoryItemLookUpEdit2.ShowHeader = false;
            this.repositoryItemLookUpEdit2.ValueMember = "MaNV";
            // 
            // repositoryItemMemoExEdit2
            // 
            this.repositoryItemMemoExEdit2.AutoHeight = false;
            this.repositoryItemMemoExEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemMemoExEdit2.Name = "repositoryItemMemoExEdit2";
            this.repositoryItemMemoExEdit2.PopupFormSize = new System.Drawing.Size(350, 0);
            this.repositoryItemMemoExEdit2.ReadOnly = true;
            this.repositoryItemMemoExEdit2.ShowDropDown = DevExpress.XtraEditors.Controls.ShowDropDown.DoubleClick;
            this.repositoryItemMemoExEdit2.ShowIcon = false;
            // 
            // xtraTabPage5
            // 
            this.xtraTabPage5.Controls.Add(this.gridControl2);
            this.xtraTabPage5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.xtraTabPage5.Name = "xtraTabPage5";
            this.xtraTabPage5.Size = new System.Drawing.Size(1052, 252);
            this.xtraTabPage5.Text = "5. Lịch sử gửi notify";
            // 
            // gridControl2
            // 
            this.gridControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControl2.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gridControl2.Location = new System.Drawing.Point(0, 0);
            this.gridControl2.MainView = this.gridView2;
            this.gridControl2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gridControl2.MenuManager = this.barManager1;
            this.gridControl2.Name = "gridControl2";
            this.gridControl2.Size = new System.Drawing.Size(1052, 252);
            this.gridControl2.TabIndex = 0;
            this.gridControl2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView2});
            // 
            // gridView2
            // 
            this.gridView2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn2,
            this.gridColumn52,
            this.gridColumn53,
            this.gridColumn56,
            this.gridColumn57});
            this.gridView2.DetailHeight = 431;
            this.gridView2.GridControl = this.gridControl2;
            this.gridView2.Name = "gridView2";
            this.gridView2.OptionsView.ColumnAutoWidth = false;
            this.gridView2.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "Token";
            this.gridColumn2.FieldName = "Token";
            this.gridColumn2.MinWidth = 23;
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 0;
            this.gridColumn2.Width = 177;
            // 
            // gridColumn52
            // 
            this.gridColumn52.Caption = "Tiêu đề";
            this.gridColumn52.FieldName = "TieuDe";
            this.gridColumn52.MinWidth = 23;
            this.gridColumn52.Name = "gridColumn52";
            this.gridColumn52.Visible = true;
            this.gridColumn52.VisibleIndex = 1;
            this.gridColumn52.Width = 243;
            // 
            // gridColumn53
            // 
            this.gridColumn53.Caption = "Nội dung";
            this.gridColumn53.FieldName = "NoiDung";
            this.gridColumn53.MinWidth = 23;
            this.gridColumn53.Name = "gridColumn53";
            this.gridColumn53.Visible = true;
            this.gridColumn53.VisibleIndex = 2;
            this.gridColumn53.Width = 356;
            // 
            // gridColumn56
            // 
            this.gridColumn56.Caption = "Số điện thoại";
            this.gridColumn56.FieldName = "Phone";
            this.gridColumn56.MinWidth = 23;
            this.gridColumn56.Name = "gridColumn56";
            this.gridColumn56.Visible = true;
            this.gridColumn56.VisibleIndex = 3;
            this.gridColumn56.Width = 164;
            // 
            // gridColumn57
            // 
            this.gridColumn57.Caption = "Ngày gửi";
            this.gridColumn57.FieldName = "DateCreate";
            this.gridColumn57.MinWidth = 23;
            this.gridColumn57.Name = "gridColumn57";
            this.gridColumn57.Visible = true;
            this.gridColumn57.VisibleIndex = 4;
            this.gridColumn57.Width = 164;
            // 
            // gridColumn61
            // 
            this.gridColumn61.Caption = "gridColumn61";
            this.gridColumn61.FieldName = "ID";
            this.gridColumn61.MinWidth = 25;
            this.gridColumn61.Name = "gridColumn61";
            this.gridColumn61.Width = 109;
            // 
            // gridColumn62
            // 
            this.gridColumn62.Caption = "gridColumn62";
            this.gridColumn62.FieldName = "LinkID";
            this.gridColumn62.MinWidth = 25;
            this.gridColumn62.Name = "gridColumn62";
            this.gridColumn62.Width = 109;
            // 
            // frmReceivables
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1059, 667);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmReceivables";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Công nợ tổng hợp theo khách hàng";
            this.Load += new System.EventHandler(this.frmManager_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lkToaNha)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpThang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpKhoiNha)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LookUpNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbThang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            this.xtraTabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gcPhieuThu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvPhieuThu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookNhanVien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenuPhieuThu)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
            this.splitContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gcHoaDon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvHoaDon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.xtraTabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gcChiTiet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvChiTiet)).EndInit();
            this.xtraTabPage2.ResumeLayout(false);
            this.xtraTabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoExEdit2)).EndInit();
            this.xtraTabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.Utils.ImageCollection imageCollection1;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarButtonItem itemNap;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit lookUpThang;
        private DevExpress.XtraBars.Bar bar1;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit lookUpKhoiNha;
        private System.Windows.Forms.Panel panel1;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit LookUpNam;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private DevExpress.XtraGrid.GridControl gcHoaDon;
        private DevExpress.XtraGrid.Views.Grid.GridView gvHoaDon;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn20;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraBars.BarEditItem itemToaNha;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit lkToaNha;
        private DevExpress.XtraGrid.Columns.GridColumn colDaThu;
        private DevExpress.XtraGrid.Columns.GridColumn colConNo;
        private DevExpress.Data.Linq.LinqInstantFeedbackSource linqInstantFeedbackSource1;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraGrid.GridControl gcChiTiet;
        private DevExpress.XtraGrid.Views.Grid.GridView gvChiTiet;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn21;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn22;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn23;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn24;
        private DevExpress.XtraBars.BarButtonItem itemThuTien;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit2;
        private DevExpress.XtraBars.BarEditItem itemThang;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit1;
        private DevExpress.XtraBars.BarEditItem itemNam;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox cmbThang;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn25;
        private DevExpress.XtraBars.BarButtonItem itemPrint;
        private DevExpress.XtraGrid.Columns.GridColumn colNoDauKy;
        private DevExpress.XtraGrid.Columns.GridColumn colPhatSinh;
        private DevExpress.XtraGrid.Columns.GridColumn colThuTruoc;
        private DevExpress.XtraBars.BarButtonItem itemSendMail;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private Marketing.Mail.History.ctlMailHistory ctlMailHistory1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn28;
        private DevExpress.XtraGrid.Columns.GridColumn colKhauTru;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraBars.BarSubItem barSubItem1;
        private DevExpress.XtraBars.BarButtonItem itemPreview;
        private DevExpress.XtraBars.BarButtonItem itemPrintFund;
        private DevExpress.XtraBars.BarSubItem itemPrintAll;
        private DevExpress.XtraBars.BarButtonItem itemPrintSelect;
        private DevExpress.XtraBars.BarButtonItem itemPrintSelectAll;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn29;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn30;
        private DevExpress.XtraBars.BarSubItem itemKhauTuDong;
        private DevExpress.XtraBars.BarButtonItem itemKhautruTudongCanhan;
        private DevExpress.XtraBars.BarButtonItem itemKhautruTudongTatca;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraGrid.Columns.GridColumn colCongNoCuoi;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn32;
        private DevExpress.XtraBars.BarButtonItem itemExport;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage3;
        private DevExpress.XtraGrid.GridControl gcPhieuThu;
        private DevExpress.XtraGrid.Views.Grid.GridView gvPhieuThu;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn26;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn27;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn31;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn33;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn34;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn35;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn36;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn37;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn38;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn39;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn42;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn46;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn47;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn48;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit lookNhanVien;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage4;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn40;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn41;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn43;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn44;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn45;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn49;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn50;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn51;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn54;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn55;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn59;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn60;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn66;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn67;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit repositoryItemMemoExEdit2;
        private DevExpress.XtraBars.BarButtonItem itemSuaPhieuThu;
        private DevExpress.XtraBars.PopupMenu popupMenuPhieuThu;
        private DevExpress.XtraBars.BarButtonItem itemSmsZalo;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage5;
        private DevExpress.XtraGrid.GridControl gridControl2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn52;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn53;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn56;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn57;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn58;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn62;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn61;
    }
}