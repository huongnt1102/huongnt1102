﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Library;
using System.Linq;
using System.Data.Linq.SqlClient;
using DevExpress.XtraReports.UI;
using DevExpress.Data.PivotGrid;
using Remotion.FunctionalProgramming;

namespace LandSoftBuilding.Receivables.Reports
{
    public partial class frmCongNoTrongThang : DevExpress.XtraEditors.XtraForm
    {
        public frmCongNoTrongThang()
        {
            InitializeComponent();
        }

        void SetDate(int index)
        {
            var objKBC = new KyBaoCao()
            {
                Index = index
            };
            objKBC.SetToDate();

            itemTuNgay.EditValue = objKBC.DateFrom;
            itemDenNgay.EditValue = objKBC.DateTo;
        }

        List<byte?> GetToaNha()
        {
            var ltToaNha = new List<byte?>();
            var arrMaTN = (itemToaNha.EditValue ?? "").ToString().Split(',');
            foreach (var s in arrMaTN)
                if (s != "")
                    ltToaNha.Add(byte.Parse(s));
            return ltToaNha;
        }

        void LoadData()
        {
            var wait = DialogBox.WaitingForm();
            var db = new MasterDataContext();
            try
            {
                var ltToaNha = this.GetToaNha();
                var _TuNgay = (DateTime)itemTuNgay.EditValue;
                var _DenNgay = (DateTime)itemDenNgay.EditValue;
                string HinhThuc = itemHinhThucThu.EditValue.ToString();

                //Số dư đầu kỳ
                var ltData = from hd in db.dvHoaDons
                             where ltToaNha.Contains(hd.MaTN)
                             & SqlMethods.DateDiffDay(hd.NgayTT, (hd.MaLDV == 5 || hd.MaLDV == 8 || hd.MaLDV == 9 || hd.MaLDV == 10 || hd.MaLDV == 11 || hd.MaLDV == 20 || hd.MaLDV == 22 || hd.MaLDV == 23 || hd.MaLDV == 30) ? _TuNgay.AddMonths(+1) : _TuNgay) > 0 
                             & hd.IsDuyet == true// hd.MaKH == 9855 &
                             group hd by new { hd.MaTN, hd.MaKH, hd.MaMB, hd.MaLDV,hd.ID } into gr
                             select new
                             {
                                 KyBC = "1. Đầu kỳ",
                                 gr.Key.MaTN,
                                 gr.Key.MaKH,
                                 gr.Key.MaMB,
                                 gr.Key.MaLDV,
                                 SoTien = gr.Sum(p => p.PhaiThu - (from ct in db.ptChiTietPhieuThus
                                                                   join pt in db.ptPhieuThus on ct.MaPT equals pt.ID
                                                                   where ct.TableName == "dvHoaDon" & ct.LinkID == p.ID
                                                                   & SqlMethods.DateDiffDay(pt.NgayThu, _TuNgay) > 0
                                                                   & ( HinhThuc == "Tất cả" || (HinhThuc == "Tiền mặt" && pt.MaTKNH == null) || (HinhThuc == "Chuyển khoản" && pt.MaTKNH != null) ) 
                                                                   select ct.SoTien).Sum().GetValueOrDefault() -(from ct in db.ktttChiTiets
                                                                                                                   join pt in db.ktttKhauTruThuTruocs on ct.MaCT equals pt.ID
                                                                                                                  where ct.TableName == "dvHoaDon" & ct.LinkID == p.ID
                                                                                                                   & SqlMethods.DateDiffDay(pt.NgayCT, _TuNgay) > 0
                                                                                                                   select ct.SoTien).Sum().GetValueOrDefault()).GetValueOrDefault()
                                
                                                                   
                             };

                //Phát sinh trong kỳ
                ltData = ltData.Concat(from hd in db.dvHoaDons
                                       where ltToaNha.Contains(hd.MaTN)
                                       & SqlMethods.DateDiffDay((hd.MaLDV == 5 || hd.MaLDV == 8 || hd.MaLDV == 9 || hd.MaLDV == 10 || hd.MaLDV == 11 || hd.MaLDV == 20 || hd.MaLDV == 22 || hd.MaLDV == 23 || hd.MaLDV == 30) ? _TuNgay.AddMonths(+1) : _TuNgay, hd.NgayTT) >= 0
                                       & SqlMethods.DateDiffDay(hd.NgayTT, (hd.MaLDV == 5 || hd.MaLDV == 8 || hd.MaLDV == 9 || hd.MaLDV == 10 || hd.MaLDV == 11 || hd.MaLDV == 20 || hd.MaLDV == 22 || hd.MaLDV == 23 || hd.MaLDV == 30) ? _DenNgay.AddMonths(+1) : _DenNgay) >= 0
                                       & hd.IsDuyet == true
                                                                    
                                       group hd by new { hd.MaTN, hd.MaKH, hd.MaMB, hd.MaLDV } into gr
                                       select new
                                       {
                                           KyBC = "2. Phát sinh",
                                           gr.Key.MaTN,
                                           gr.Key.MaKH,
                                           gr.Key.MaMB,
                                           gr.Key.MaLDV,
                                           SoTien = gr.Sum(p => p.PhaiThu).GetValueOrDefault()
                                       });

                ltData = ltData.Concat(from ct in db.ptChiTietPhieuThus
                                       join pt in db.ptPhieuThus on ct.MaPT equals pt.ID
                                       join hd in db.dvHoaDons on new { ct.TableName, ct.LinkID } equals new { TableName = "dvHoaDon", LinkID = (long?)hd.ID }
                                       where ltToaNha.Contains(pt.MaTN)
                                       & SqlMethods.DateDiffDay(_TuNgay, pt.NgayThu) >= 0
                                       & SqlMethods.DateDiffDay(pt.NgayThu, _DenNgay) >= 0
                                        & (HinhThuc == "Tất cả" || (HinhThuc == "Tiền mặt" && pt.MaTKNH == null) || (HinhThuc == "Chuyển khoản" && pt.MaTKNH != null))
                                       //& SqlMethods.DateDiffDay(_TuNgay, hd.NgayTT) >= 0
                                       //& SqlMethods.DateDiffDay(hd.NgayTT, _DenNgay) >= 0 
                                       //& hd.IsDuyet == true
                                       group ct by new { pt.MaTN, pt.MaKH, hd.MaMB, hd.MaLDV } into gr
                                       select new
                                       {
                                           KyBC = "3. Đã thu",
                                           gr.Key.MaTN,
                                           gr.Key.MaKH,
                                           gr.Key.MaMB,
                                           gr.Key.MaLDV,
                                           SoTien = -gr.Sum(p => p.SoTien).GetValueOrDefault()
                                       });
                // Thu trước trong kỳ
                ltData = ltData.Concat(from ct in db.ptChiTietPhieuThus
                                       join pt in db.ptPhieuThus on ct.MaPT equals pt.ID
                                       join hd in db.dvHoaDons on new { ct.TableName, ct.LinkID } equals new { TableName = "dvHoaDon", LinkID = (long?)hd.ID }
                                       where ltToaNha.Contains(pt.MaTN)
                                       & SqlMethods.DateDiffDay(_TuNgay, pt.NgayThu) >= 0
                                       & SqlMethods.DateDiffDay(pt.NgayThu, _DenNgay) >= 0
                                       & SqlMethods.DateDiffDay(_DenNgay, hd.NgayTT) > 0
                                       & ( (HinhThuc == "Tất cả") || (HinhThuc == "Tiền mặt" && pt.MaTKNH == null) || (HinhThuc == "Chuyển khoản" && pt.MaTKNH != null)) 
                                       group ct by new { pt.MaTN, pt.MaKH, hd.MaMB, hd.MaLDV } into gr
                                       select new
                                       {
                                           KyBC = "4. Thu trước",
                                           gr.Key.MaTN,
                                           gr.Key.MaKH,
                                           gr.Key.MaMB,
                                           gr.Key.MaLDV,
                                           SoTien = gr.Sum(p => p.SoTien).GetValueOrDefault()
                                       });

                ltData = ltData.Concat(from ct in db.ptChiTietPhieuThus
                                       join pt in db.ptPhieuThus on ct.MaPT equals pt.ID
                                       join hd in db.dvHoaDons on new { ct.TableName, ct.LinkID } equals new { TableName = "dvHoaDon", LinkID = (long?)hd.ID }
                                       where ltToaNha.Contains(pt.MaTN)
                                       & SqlMethods.DateDiffDay(pt.NgayThu, _TuNgay) > 0
                                       & SqlMethods.DateDiffDay((hd.MaLDV == 5 || hd.MaLDV == 8 || hd.MaLDV == 9 || hd.MaLDV == 10 || hd.MaLDV == 11 || hd.MaLDV == 20 || hd.MaLDV == 22 || hd.MaLDV == 23 || hd.MaLDV == 30) ? _TuNgay.AddMonths(+1) : _TuNgay, hd.NgayTT) >= 0
                                       & SqlMethods.DateDiffDay(hd.NgayTT, (hd.MaLDV == 5 || hd.MaLDV == 8 || hd.MaLDV == 9 || hd.MaLDV == 10 || hd.MaLDV == 11 || hd.MaLDV == 20 || hd.MaLDV == 22 || hd.MaLDV == 23 || hd.MaLDV == 30) ? _DenNgay.AddMonths(+1) : _DenNgay) >= 0
                                       & (HinhThuc == "Tất cả" || (HinhThuc == "Tiền mặt" && pt.MaTKNH == null) || (HinhThuc == "Chuyển khoản" && pt.MaTKNH != null)) 
                                       & hd.IsDuyet == true
                                       group ct by new { pt.MaTN, pt.MaKH, hd.MaMB, hd.MaLDV } into gr
                                       select new
                                       {
                                           KyBC = "5. Khấu trừ thu trước",
                                           gr.Key.MaTN,
                                           gr.Key.MaKH,
                                           gr.Key.MaMB,
                                           gr.Key.MaLDV,
                                           SoTien = -gr.Sum(p => p.SoTien).GetValueOrDefault()
                                       });

                //Nap vào pivot
                pvHoaDon.DataSource = (from hd in ltData
                                       join kh in db.tnKhachHangs on hd.MaKH equals kh.MaKH
                                       join l in db.dvLoaiDichVus on hd.MaLDV equals l.ID
                                       join mb in db.mbMatBangs on hd.MaMB equals mb.MaMB into tblMatBang
                                       from mb in tblMatBang.DefaultIfEmpty()
                                       join tl in db.mbTangLaus on mb.MaTL equals tl.MaTL into tblTangLau
                                       from tl in tblTangLau.DefaultIfEmpty()
                                       join kn in db.mbKhoiNhas on tl.MaKN equals kn.MaKN into tblKhoiNha
                                       from kn in tblKhoiNha.DefaultIfEmpty()
                                       join tn in db.tnToaNhas on hd.MaTN equals tn.MaTN
                                       join lmb in db.mbLoaiMatBangs on mb.MaLMB equals lmb.MaLMB into tblLoaiMatBang
                                       from lmb in tblLoaiMatBang.DefaultIfEmpty()
                                       select new
                                       {
                                           hd.KyBC,
                                           lmb.TenLMB,
                                           tn.TenTN,
                                           kn.TenKN,
                                           tl.TenTL,
                                           mb.MaSoMB,
                                           kh.KyHieu,
                                           kh.MaPhu,
                                           TenKH = kh.IsCaNhan == true ? (kh.HoKH + " " + kh.TenKH) : kh.CtyTen,
                                           TenLDV = l.TenHienThi,
                                           hd.SoTien
                                       }).ToList();
            }
            catch
            {
            }
            finally
            {
                db.Dispose();
                wait.Close();
            }
        }

        void Print()
        {
            var rpt = new rptCongNo(Common.User.MaTN.Value);
            var stream = new System.IO.MemoryStream();
            var _KyBC = (itemKyBaoCao.EditValue ?? "").ToString();
            var _TuNgay = (DateTime)itemTuNgay.EditValue;
            var _DenNgay = (DateTime)itemDenNgay.EditValue;

            pvHoaDon.OptionsView.ShowColumnHeaders = false;
            pvHoaDon.OptionsView.ShowDataHeaders = false;
            pvHoaDon.OptionsView.ShowFilterHeaders = false;
            pvHoaDon.SavePivotGridToStream(stream);
            pvHoaDon.OptionsView.ShowColumnHeaders = true;
            pvHoaDon.OptionsView.ShowDataHeaders = true;
            pvHoaDon.OptionsView.ShowFilterHeaders = true;

            rpt.LoadData(_KyBC, _TuNgay, _DenNgay, stream);
            rpt.ShowPreviewDialog();
        }

        private void frmCongNo_Load(object sender, EventArgs e)
        {
            TranslateLanguage.TranslateControl(this, barManager1);

            Library.HeThongCls.PhanQuyenCls.Authorize(this, Common.User, barManager1);

            ckbToaNha.DataSource = Common.TowerList;
            itemToaNha.EditValue = Common.User.MaTN.ToString();
            itemHinhThucThu.EditValue = "Tất cả";
            KyBaoCao objKBC = new KyBaoCao();
            objKBC.Initialize(cmbKyBaoCao);
            var index = DateTime.Now.Month + 8;
            itemKyBaoCao.EditValue = objKBC.Source[index];
            SetDate(index);

            LoadData();
        }

        private void cmbKyBaoCao_EditValueChanged(object sender, EventArgs e)
        {
            SetDate((sender as ComboBoxEdit).SelectedIndex);
        }

        private void btnNap_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            LoadData();
        }

        private void itemPrint_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            this.Print();
        }

        private void pvHoaDon_FieldValueDisplayText(object sender, DevExpress.XtraPivotGrid.PivotFieldDisplayTextEventArgs e)
        {
            if (e.ValueType == DevExpress.XtraPivotGrid.PivotGridValueType.Total)
                e.DisplayText = string.Format("{0} ({1})", e.Value, "Tổng");
            else if (e.ValueType == DevExpress.XtraPivotGrid.PivotGridValueType.GrandTotal)
                e.DisplayText = "Tổng cộng";
        }
    }
}